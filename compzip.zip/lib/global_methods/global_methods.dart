import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';

List<Instrument> getsortlist(List<Instrument> list, int index,
    {List<String> sortOrder = const []}) {
  List<Instrument> sortedList = list;
  switch (index) {
    case 0:
      sortedList.sort(((a, b) => (a.securityName).compareTo(b.securityName)));
      break;
    case 1:
      sortedList.sort(((a, b) => (b.securityName).compareTo(a.securityName)));
      break;
    case 2:
      sortedList.sort(((a, b) => (a.lastTrdPrice).compareTo(b.lastTrdPrice)));
      break;
    case 3:
      sortedList.sort(((a, b) => (b.lastTrdPrice).compareTo(a.lastTrdPrice)));
      break;
    case 4:
      sortedList.sort(((a, b) => (a.percChange).compareTo(b.percChange)));
      break;
    case 5:
      sortedList.sort(((a, b) => (b.percChange).compareTo(a.percChange)));
      break;
    case -1:
      {
        if (sortOrder.isNotEmpty) {
          List<Instrument> tempList = [];
          for (var element in sortOrder) {
            for (Instrument item in sortedList) {
              if (item.getRicAddress() == element) {
                tempList.add(item);
                sortedList.remove(item);
                break;
              }
            }
          }
          tempList.addAll(sortedList);
          sortedList = tempList;
        }
        break;
      }
  }
  return sortedList;
}

maskStringWithStar(
    {required String inputString, int startIndex = 0, int endIndex = 1}) {
  if (inputString.isNotEmpty) {
    return inputString.replaceRange(startIndex, endIndex, '*' * endIndex);
  }
}

// stringSeparationToList(
//     {required String inputString, required String separatoinValue}) {
//   return inputString.split(separatoinValue);
// }

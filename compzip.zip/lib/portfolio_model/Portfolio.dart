import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:trading_api/responses/portfolio_responce.dart';
import 'package:trading_api/utils/utils.dart';

class HoldingModel {
  HoldingModel({
    required String venuecode,
    required String venuescripcode,
    required String securitycode,
    required String securityname,
    this.pendingboughtqty = 0,
    this.units = "",
    this.availablenetqty = 0,
    this.intradaybuy = "",
    this.avgrate = 0.0,
    this.category = "",
    this.securitycode1 = "",
    this.pledgeqty = 0,
    this.dpqty = 0,
    this.dailyavgrate = 0.0,
    this.intradaybuyval = "",
    this.producttype = "",
    this.todaysnetqty = 0,
    this.intradaysell = "",
    this.ricaddress = "",
    this.categorydesc = "",
    this.realpl = 0.0,
    double mktrate = 0.0,
    this.closerate = 0.0,
    String otherseries = "",
  }) {
    instrument = Instrument(
        scripcode: venuescripcode,
        venueIndex: getVenueIndex(venuecode),
        securityCode: securitycode,
        securityName: securityname,
        closePrice: closerate,
        lastTrdPrice: mktrate,
        otherSeries: otherseries,
        subscriptionType: SubscriptionType.watch);
  }
  late Instrument instrument;
  // String venuescripcode;
  // String venuecode;
  // String securityname;
  // String securitycode;
  // double mktrate;
  double closerate;
  // String otherseries;
  int pendingboughtqty;
  String units;
  double availablenetqty;
  String intradaybuy;
  double avgrate;
  String category;
  String securitycode1;
  int pledgeqty;
  String categorydesc;
  int dpqty;
  double dailyavgrate;
  String intradaybuyval;
  String producttype;
  int todaysnetqty;
  String intradaysell;
  String ricaddress;
  double realpl;
  // double lasttradeprice;
  double pl = 0.0; // qty * (ltp - avgrate)
  double plPercentage = 0.0; // (pl * 100) / (avg * qty)
  double todaysPl = 0.0; //todays p&l = ltp - closingprice
  double investedAmount = 0.0;
  double currentAmount = 0.0;
  double buyRate = 0.0;
  double sellRate = 0.0;
  double todaysInvestedAmount = 0.0;
  double todaysPlPercentage = 0.0;

  static HoldingModel updateHoldingModel(Intraday result) {
    return HoldingModel(
      venuecode: result.venuecode,
      venuescripcode: result.venuescripcode,
      securitycode: result.securitycode,
      securityname: result.securityname,
      pendingboughtqty: result.pendingboughtqty,
      units: result.units,
      availablenetqty: result.availablenetqty,
      intradaybuy: result.intradaybuy,
      avgrate: result.avgrate,
      category: result.category,
      securitycode1: result.securitycode1,
      pledgeqty: result.pledgeqty,
      dpqty: result.dpqty,
      dailyavgrate: result.dailyavgrate,
      intradaybuyval: result.intradaybuyval,
      producttype: result.producttype,
      todaysnetqty: result.todaysnetqty,
      intradaysell: result.intradaysell,
      categorydesc: result.categorydesc,
      realpl: result.realpl,
      mktrate: result.mktrate,
      closerate: result.closerate,
      // securitycode : result.securitycode;
      // venuecode : result.venuecode;
      // lasttradeprice : result.mktrate;
      // instrument.lastTrdPrice : result.mktrate,
      // instrument.closePrice : result.closerate,
    );
    // venuescripcode = result.venuescripcode;
    // otherseries = result.otherseries;
    // securityname = result.securityname;
  }

  double gtepl() {
    currentAmount = availablenetqty * instrument.lastTrdPrice;
    investedAmount = avgrate * availablenetqty;
    pl = (currentAmount - investedAmount) + realpl;
    todaysPl = (instrument.lastTrdPrice - closerate) * availablenetqty;
    plPercentage = ((pl * 100) / currentAmount).isNaN ||
            ((pl * 100) / currentAmount).isInfinite
        ? 0.00
        : (pl * 100) / currentAmount;
    todaysPlPercentage =
        ((todaysPl * 100) / (closerate * availablenetqty)).isNaN ||
                ((todaysPl * 100) / (closerate * availablenetqty)).isInfinite
            ? 0.00
            : ((todaysPl * 100) / (closerate * availablenetqty));
    return pl;
  }

  double getplperc() {
    return plPercentage;
  }
}

class PositionModel {
  PositionModel(
      {this.venuescripcode = "",
      this.otherseries = "",
      this.securityname = "",
      this.pendingboughtqty = 0,
      this.units = "",
      this.availablenetqty = 0,
      this.intradaybuy = "",
      this.avgrate = 0.0,
      this.category = "",
      this.mktrate = 0.0,
      this.closerate = 0.0,
      this.securitycode1 = "",
      this.pledgeqty = 0,
      this.dpqty = 0,
      this.dailyavgrate = 0.0,
      this.intradaybuyval = "",
      this.venuecode = "",
      this.producttype = "",
      this.todaysnetqty = 0,
      this.intradaysell = "",
      this.securitycode = "",
      this.ricaddress = "",
      this.boughtqty = "",
      this.soldqty = "",
      this.sellvalnew = "",
      this.buyvalnew = "",
      this.realpl = 0.0,
      this.buyRate = 0.0,
      this.sellRate = 0.0}) {
    instrument = Instrument(
        scripcode: venuescripcode,
        securityCode: securitycode,
        securityName: securityname,
        closePrice: closerate,
        lastTrdPrice: mktrate,
        otherSeries: otherseries,
        venueIndex: getVenueIndex(venuecode),
        subscriptionType: SubscriptionType.watch);
  }
  late Instrument instrument;
  String venuescripcode;
  String otherseries;
  String securityname;
  int pendingboughtqty;
  String units;
  double availablenetqty;
  String intradaybuy;
  double avgrate;
  String category;
  double mktrate;
  double closerate;
  String securitycode1;
  int pledgeqty;
  int dpqty;
  double dailyavgrate;
  String intradaybuyval;
  String venuecode;
  String producttype;
  int todaysnetqty;
  String intradaysell;
  String securitycode;
  String ricaddress;
  String soldqty;
  String boughtqty;
  String sellvalnew;
  String buyvalnew;
  double realpl;
  double buyRate;
  double sellRate;
  double pl = 0.0; // qty * (ltp - avgrate)
  double plPercentage = 0.0; // (pl * 100) / (avg * qty)
  double todaysPl = 0.0; //todays p&l = ltp - closingprice
  double investedAmount = 0.0;
  double currentAmount = 0.0;
  double todaysInvestedAmount = 0.0;
  double todaysPlPercentage = 0.0;
  double changeprice = 0.0;

  static PositionModel updatePosition(Result4 result) {
    return PositionModel(
        venuescripcode: result.venuescripcode,
        otherseries: result.otherseries,
        securityname: result.securitycode1,
        pendingboughtqty: int.parse(result.pendingboughtqty),
        units: result.units,
        availablenetqty: result.netqty,
        avgrate: result.avgrate,
        mktrate: result.closingrate,
        closerate: result.closingrate,
        securitycode1: result.securitycode1,
        venuecode: result.venuecode,
        producttype: result.producttype,
        soldqty: result.soldqty,
        boughtqty: result.boughtqty,
        sellvalnew: result.sellvalnew,
        buyvalnew: result.buyvalnew,
        securitycode: result.securitycode,
        realpl: double.parse(result.realpl),
        buyRate: result.buyrate,
        sellRate: result.sellrate);
    // instrument!.lastTrdPrice = result.lasttradeprice;
  }

  double gtepl() {
    currentAmount = availablenetqty * instrument.lastTrdPrice;
    if (currentAmount.isNaN || currentAmount.isInfinite) currentAmount = 0.00;
    investedAmount = avgrate * availablenetqty;
    if (investedAmount.isNaN || investedAmount.isInfinite)
      investedAmount = 0.00;
    pl = (currentAmount - investedAmount) + realpl;
    if (pl.isNaN || pl.isInfinite) pl = 0.00;
    todaysPl = (instrument.lastTrdPrice - closerate) * availablenetqty;
    if (todaysPl.isNaN || todaysPl.isInfinite) todaysPl = 0.00;
    changeprice = instrument.changePrice;
    plPercentage = (pl * 100) / investedAmount;
    if (plPercentage.isNaN || plPercentage.isInfinite) plPercentage = 0.00;
    todaysPlPercentage = ((todaysPl * 100) / (closerate * availablenetqty));
    if (todaysPlPercentage.isNaN || todaysPlPercentage.isInfinite) {
      todaysPlPercentage = 0.00;
    }
    return pl;
  }

  double gettodayspl() {
    return todaysPl;
  }

  double getchangeprice() {
    return changeprice;
  }

  double getplperc() {
    return plPercentage;
  }
}

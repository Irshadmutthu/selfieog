import 'dart:async';
import 'dart:developer';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/restart_widget.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/theme/custom_theme.dart';

import 'app.dart';

//################## DEVE DEVFLAIR ###########################
// const baseUrl =
//     String.fromEnvironment('BASE_URL', defaultValue: "http://192.168.39.207");
// const applicationPath = String.fromEnvironment('APPLICATION_PATH',
//     defaultValue: "/traderx-ws/service");
// const mdsUrl = String.fromEnvironment("MDS_URL",
//     defaultValue: "http://192.168.69.21:8080/m/r");

//################## DEVE FREEFLAIR ###########################
const baseUrl =
    String.fromEnvironment('BASE_URL', defaultValue: "http://192.168.39.207");
const applicationPath = String.fromEnvironment('APPLICATION_PATH',
    defaultValue: "/traderx-ws/service");
const mdsUrl = String.fromEnvironment("MDS_URL",
    defaultValue: "http://freeflair.geojit.net:443/m/r");

//################## DEVE FLAIR ###########################
// const baseUrl =
//     String.fromEnvironment('BASE_URL', defaultValue: "http://192.168.39.207");
// const applicationPath = String.fromEnvironment('APPLICATION_PATH',
//     defaultValue: "/traderx-ws/service");
// const mdsUrl = String.fromEnvironment("MDS_URL",
//     defaultValue: "http://flair.geojit.net:443/m/r");

//################## PREPROD ###########################
// const baseUrl = String.fromEnvironment('BASE_URL',
//     defaultValue: "https://traderx.geojit.com");
// const applicationPath = String.fromEnvironment('APPLICATION_PATH',
//     defaultValue: "/selfiepro-ws/service");
// const mdsUrl = String.fromEnvironment("MDS_URL",
//     defaultValue: "http://freeflair.geojit.com:443/m/r");

const environment = String.fromEnvironment('FLAVOR', defaultValue: 'staging');
const debuggable = bool.fromEnvironment('DEBUGGABLE', defaultValue: true);
const loggable = bool.fromEnvironment('LOGGABLE', defaultValue: true);
void main() {
  const initialRoute =
      String.fromEnvironment('INITIAL_ROUTE', defaultValue: '/login');
  runZonedGuarded<void>(() {
    if (kReleaseMode) {
    } else if (kDebugMode) {
      // disableCrashlytics();
    }

    final locator =
        ServiceLocator(baseUrl, applicationPath, debuggable: loggable)
          ..config();
    if (debuggable) {
      runApp(RestartWidget(
        child: ChangeNotifierProvider<CustomTheme>(
            create: (BuildContext context) =>
                CustomTheme(themeMode: CustomMode.Light),
            child: TradingApp(
              serviceLocator: locator,
              initialRoute: initialRoute,
            )),
      ));
    } else {
      runApp(RestartWidget(
        child: ChangeNotifierProvider<CustomTheme>(
            create: (BuildContext context) {
              return CustomTheme(themeMode: CustomMode.Light);
            },
            child: TradingApp(
              serviceLocator: locator,
              initialRoute: initialRoute,
            )),
      ));
    }
  }, (error, stackTrace) {
    if (kReleaseMode) {}
    log('TradingAppError', error: error, stackTrace: stackTrace);
  });
}

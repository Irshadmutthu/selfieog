import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/model/bond_application_model.dart';
import 'package:selfie_mobile_flutter/navigation/navigation.dart';
import 'package:selfie_mobile_flutter/portfolio_model/Portfolio.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/featur_symbolsearch/custom_symbolsearch/ui/custom_symbol_search_routbuilder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/bonds_feature_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/page_bond_details/bond_details_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/page_bond_details_invest/bond_details_invest_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_confirm/ui/confirm_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_dashboard/dashboard_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_feedback/feedback_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/ipo_application_submission/ipo_appliction_submission_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/ipo_applied_detail_page/ipo_applied_detail_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/ipo_detail_page/ipo_detail_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/ipo_detail_page_final/ipo_detail_page_final_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/ipo_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_login/login/tfa/tfa_auth_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_login/login_page_rootbuilder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_login/splash_route.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_aboutus/aboutus_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_alerts/alerts_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_create_alerts/create_alerts_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_contact_geojit/ui/contact_geojit_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_funds/add_funds/online_transaction/ui/online_transaction_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_funds/add_funds/ui/add_funds_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_funds/ui/funds_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_funds/withdraw_funds/ui/withdraw_funds_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_get_a_callback/ui/get_a_callback_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_help/help_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_invite_friend/invite_friend_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_licences/licenses_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_market_simulator/ui/market_simulator_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_raise_a_ticket/ui/raise_a_ticket_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_setting_notification/setting_notification_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_setting_others/setting_others_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_settings/settings_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_support/support_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_myapps/myapps_page_routebuilder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_option_chain/feature_confirm/remarks/option_remark_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_open_cancel_page/order_open_cancel_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/basket/basket_edit/basket_edit_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/basket/basket_edit_inner/basket_edit_inner_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/basket/basket_inner/basket_inner_page_route_name.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/basket/basket_order_confirm/basket_order_confirm_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_settings/ui/order_settings_route_buildert.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/oco_order/oco_order_routbuilder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_pages/order_window_routbuilder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/roll_order/roll_order_routbuilder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/page_holding_overview/ui/holding_routbuilder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/position_long_press/ui/position_long_press_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_profile/profile_page_routeBuilder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_review_and_send/ui/remarks/ui/remark_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_review_and_send/ui/review_and_order_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_review_and_send/ui/roll_order_review_page/ui/roll_order_review_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/deals/ui/deals_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_suggest/suggest_page_route_builder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_all_watchlist/ui/all_watchlist_page_rootbuilder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_manage_watchlist/ui/manage_watchlist/manage_watchlist_page_rootbuilder.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_watchlist_edit/watchlist_edit_page_route_builder.dart';

import 'package:selfie_mobile_flutter/selfie/presentation_layer/workspace/ui/workspace_page_rootbuilder.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_calander/tset_calander/custom_calander_route_builder.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:trading_api/responses/order_status_item_response.dart';
import 'selfie/presentation_layer/features/featur_symbolsearch/symbol_search/ui/symbol_search_routbuilder.dart';
import 'selfie/presentation_layer/features/feature_more/page_become_partner/become_partner_page_route_builder.dart';
import 'selfie/presentation_layer/features/feature_more/page_notification/notification_page_route_builder.dart';
import 'selfie/presentation_layer/features/feature_stock/index_detail_page/ui/index_routebuilder.dart';
import 'selfie/presentation_layer/features/feature_stock/individual_stock_page/ui/individual_stock_routbuilder.dart';
import 'selfie/presentation_layer/features/feature_stock/option_and_future_page/ui/option_and_future_routebuilder_page.dart';
import 'selfie/presentation_layer/features/feature_stock/spread_page/ui/spread_page_routebuilder.dart';
import 'selfie/presentation_layer/features/feature_stock/stock_chart_page/ui/stock_page_routbuilder.dart';
import 'selfie/presentation_layer/features/feature_watchlist/page_manage_watchlist/ui/preset_watchlist/manage_preset_watchlist_rootbuilder.dart';

class AppRoutesFactory extends RoutesFactory {
  final ServiceLocator _serviceLocator;

  AppRoutesFactory(this._serviceLocator);

  @override
  Route<dynamic> createSplashPageRoute() {
    return MaterialPageRoute(
      builder: SplashRouteBuilder(),
    );
  }

  @override
  Route<dynamic> createLoginPageRoute() {
    return MaterialPageRoute(
      builder: LoginPageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route<dynamic> createIndexDetailPageRoute(Map<String, dynamic> data) {
    return MaterialPageRoute(
      builder: IndexDetailPageRouteBuilder(_serviceLocator, data),
    );
  }

  @override
  Route createWorkspacePageRoute() {
    return MaterialPageRoute(
      builder: WorkspacePageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route createWatchlistManagePageRoute(Map<String, dynamic> data) {
    return MaterialPageRoute(
      builder: ManageWatchlistPageRouteBuilder(_serviceLocator, data),
    );
  }

  @override
  Route createPresetManageWatchlistPageRoute(Map<String, dynamic> data) {
    return MaterialPageRoute(
      builder: ManagePresetWatchlistPageRouteBuilder(_serviceLocator, data),
    );
  }

  @override
  Route createAllWatchlistPageRoute() {
    return MaterialPageRoute(
      builder: AllWatchlistPageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route createWatchlistEditPageRoute(Map<String, dynamic> data) {
    return MaterialPageRoute(
        builder: WatchlistEditPageRouteBuilder(_serviceLocator, data));
  }

  @override
  Route createSymbolSearchPageRoute(Map<String, dynamic> fromPage) {
    return MaterialPageRoute(
      builder: SymbolSearchPageRouteBuilder(_serviceLocator, fromPage),
    );
  }

  @override
  Route createCustomSymbolSearchPageRoute(Map<String, dynamic> fromPage) {
    return MaterialPageRoute(
      builder: CustomSymolSearchRoutbuilder(_serviceLocator, fromPage),
    );
  }

  @override
  Route createPostionLongPressPageRoute(List<PositionModel> positionModels) {
    return MaterialPageRoute(
        builder:
            PositionLongPressRouteBuilder(_serviceLocator, positionModels));
  }

  @override
  Route createHoldingPageRoute() {
    return MaterialPageRoute(
      builder: HoldingPageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route createSpreadPageRoute() {
    return MaterialPageRoute(
      builder: SpreadPageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route createOrderSettingsPageRoute() {
    return MaterialPageRoute(
        builder: OrderSettingsRouteBuilder(_serviceLocator));
  }

  @override
  Route createIndividualStockPage(Map<String, dynamic> data) {
    return MaterialPageRoute(
      builder: IndividualStockPageRouteBuilder(_serviceLocator, data),
    );
  }

  @override
  Route createIndividualDealsPage() {
    return MaterialPageRoute(
      builder: DealsPageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route createOptionAndFutureRoute() {
    return MaterialPageRoute(
      builder: OptionAndFuturePageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route createStockChartPageRoute() {
    return MaterialPageRoute(
      builder: StockChartPageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route createCalanderPageRoute() {
    return MaterialPageRoute(
      builder: CalanderPageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route createProfilePageRoute() {
    return MaterialPageRoute(
      builder: ProfilePageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route createOrderWindowPageRoute(Map<String, dynamic> data) {
    //
    return MaterialPageRoute(
      builder: OrderWindowPageRouteBuilder(_serviceLocator, data["order"]),
    );
  }

  @override
  Route createReviewOrderPageRoute(Map<String, dynamic> data) {
    return MaterialPageRoute(
      builder: ReviewAndOrderPageRouteBuilder(_serviceLocator, data["order"]),
    );
  }

  @override
  Route createRemarkPageRoute() {
    return MaterialPageRoute(builder: RemarkPageRouteBuilder(_serviceLocator));
  }

  @override
  Route createConfirmPageRoute(Map<String, dynamic> data) {
    return MaterialPageRoute(
        builder: ConfirmPagePageRouteBuilder(
            _serviceLocator, data["OrderResponse"]));
  }

  @override
  Route createMoreAlertsPageRoute() {
    return MaterialPageRoute(builder: AlertsPageRouteBuilder(_serviceLocator));
  }

  @override
  Route createRollOrderPageRoute(Map<String, dynamic> data) {
    return MaterialPageRoute(
      builder: RollOrderPageRouteBuilder(_serviceLocator, data),
    );
  }

  @override
  Route createOCOOrderPageRoute(Map<String, dynamic> data) {
    return MaterialPageRoute(
      builder: OCOOrderPageRouteBuilder(_serviceLocator, data["order"]),
    );
  }

  @override
  Route createOrderOpenLongpressRoute(List<OrderStatusResult3> data) {
    return MaterialPageRoute(
        builder: OrderOpenCancelPageRoute(_serviceLocator, data));
  }

  @override
  Route createRollOrderReviewPage() {
    return MaterialPageRoute(
        builder: RollReviewAndOrderPageRouteBuilder(_serviceLocator));
  }

  @override
  Route createAlertPageRoute(String title, String symbol, String ltp) {
    return MaterialPageRoute(
        builder:
            CreateAlertsPageRouteBuilder(_serviceLocator, title, symbol, ltp));
  }

  @override
  Route<dynamic> createContactGeojitPage() {
    return MaterialPageRoute(
      builder: ContactGeojitPageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route<dynamic> createGetACallbackPage() {
    return MaterialPageRoute(
      builder: GetACallbackRoutePageBuilder(_serviceLocator),
    );
  }

  @override
  Route<dynamic> createRaiseATicketPage() {
    return MaterialPageRoute(
      builder: RaiseATicketPageBuilder(_serviceLocator),
    );
  }

  @override
  Route createDashBoardPage() {
    return MaterialPageRoute(
        builder: DashboardPageRouteBuilder(_serviceLocator));
  }

  @override
  Route<dynamic> createHelpPageRoute() {
    return MaterialPageRoute(
      builder: HelpPageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route<dynamic> createSupportPageRoute() {
    return MaterialPageRoute(
      builder: SupportPageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route<dynamic> createAboutUsPage() {
    return MaterialPageRoute(
      builder: AboutPageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route<dynamic> createLicencePage() {
    return MaterialPageRoute(
      builder: LicensePageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route<dynamic> createInviteFriend() {
    return MaterialPageRoute(
      builder: InviteFriendPageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route<dynamic> createBecomePartnerPage() {
    return MaterialPageRoute(
      builder: BecomePartnerRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route<dynamic> createNotificationPageRoute() {
    return MaterialPageRoute(
      builder: NotificationPageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route<dynamic> createMarketSimulatorPageRoute() {
    return MaterialPageRoute(
        builder: MarketSimulatorPageRouteBuilder(_serviceLocator));
  }

  @override
  Route createMyAppsPageRoute() {
    return MaterialPageRoute(
      builder: MyAppsPageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route<dynamic> createSuggestPageRoute() {
    return MaterialPageRoute(
      builder: SuggestPageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route<dynamic> createSettingsPageRoute() {
    return MaterialPageRoute(
      builder: SettingsPageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route<dynamic> createSettingsNotificationPageRoute() {
    return MaterialPageRoute(
      builder: SettingNotificationPageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route<dynamic> createSettingOtherspageRoute() {
    return MaterialPageRoute(
      builder: SettingOthersPageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route createFeedBackPageRoute() {
    return MaterialPageRoute(
      builder: FeedBackPageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route createOptionRemarkPageRoute() {
    return MaterialPageRoute(
      builder: OptionRemarkPageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route createIpoPageRoute() {
    return MaterialPageRoute(
      builder: IpoPageRouteBuilder(_serviceLocator),
    );
  }

  @override
  Route createBasketInnerPageRouteName() {
    return MaterialPageRoute(
        builder: BasketInnerPageRouteBuilder(_serviceLocator));
  }

  @override
  Route createIpoDetailPageRouteName() {
    return MaterialPageRoute(
        builder: IpoDetailPageRouteBuilder(_serviceLocator));
  }

  @override
  Route createIpoAppliedDetailpageRoutename() {
    return MaterialPageRoute(
        builder: IpoAppliedDetailPageRouteBuilder(_serviceLocator));
  }

  @override
  Route createBasketOrderConfirmPageRouteName() {
    return MaterialPageRoute(
        builder: BasketOrderConfirmRouteBuilder(_serviceLocator));
  }

  @override
  Route createEditBasketInner() {
    return MaterialPageRoute(
        builder: BasketEditInnerRouteBuilder(_serviceLocator));
  }

  @override
  Route createEditMyBasket() {
    return MaterialPageRoute(builder: BasketEditRouteBuilder(_serviceLocator));
  }

  @override
  Route createIpoApplicationSubmissionPageRouteName() {
    return MaterialPageRoute(
        builder: IpoApplcationSubmissionPageRouteBuilder(_serviceLocator));
  }

  @override
  Route createIpoDetailPageFinalPageRouteBuilder() {
    return MaterialPageRoute(
        builder: IpoDetailPageFinalRouteBuilder(_serviceLocator));
  }

  @override
  Route createTfaPageRoute(Map<String, dynamic> data) {
    return MaterialPageRoute(
        builder: TfaAuthPageRouteBuilder(_serviceLocator, data));
  }

  @override
  Route createFundsPageRoute() {
    return MaterialPageRoute(builder: FundsPageRouteBuilder(_serviceLocator));
  }

  @override
  Route createAddFundsPageRoute() {
    return MaterialPageRoute(
        builder: AddFundsPageRouteBuilder(_serviceLocator));
  }

  @override
  Route createOnlineTransactionPageRoute() {
    return MaterialPageRoute(
        builder: OnlineTransactionPageRouteBuilder(_serviceLocator));
  }

  @override
  Route createFundsWithdrawPageRoute() {
    return MaterialPageRoute(
        builder: WithdrawFundsPageRouteBuilder(_serviceLocator));
  }

  @override
  Route createBondsFeaturePageRoute() {
    return MaterialPageRoute(
        builder: BondsFeaturePageRouteBuilder(_serviceLocator));
  }

  @override
  Route createBondDetailsPageRoute(int bondId) {
    // TODO: implement createBondDetailsPageRoute
    return MaterialPageRoute(
        builder: BondDetailsPageRouteBuilder(_serviceLocator, bondId));
  }

  @override
  Route createBondDetailsInvestPageRoute(
      BondApplicationArgumentModel bondApplicationArgumentModel) {
    // TODO: implement createBondDetailsInvestPageRoute
    return MaterialPageRoute(
        builder: BondDetailsInvestPageRouteBuilder(
            _serviceLocator, bondApplicationArgumentModel));
  }
}

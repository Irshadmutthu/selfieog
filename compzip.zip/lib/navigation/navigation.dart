import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/model/bond_application_model.dart';
import 'package:selfie_mobile_flutter/portfolio_model/Portfolio.dart';
import 'package:trading_api/responses/fund_response.dart';

import 'package:trading_api/responses/order_status_item_response.dart';

part 'routes_arguments.dart';

part 'routes_factory.dart';

part 'routes_mapper.dart';

part 'routes_names.dart';

part 'navigation_service.dart';

part of 'navigation.dart';

abstract class RoutesFactory {
  Route<dynamic> createSplashPageRoute();
  Route<dynamic> createLoginPageRoute();
  Route<dynamic> createTfaPageRoute(Map<String, dynamic> data);
  Route<dynamic> createSymbolSearchPageRoute(Map<String, dynamic> fromPage);
  Route<dynamic> createCustomSymbolSearchPageRoute(
      Map<String, dynamic> fromPage);
  Route<dynamic> createWorkspacePageRoute();
  Route<dynamic> createWatchlistEditPageRoute(Map<String, dynamic> data);
  Route<dynamic> createWatchlistManagePageRoute(Map<String, dynamic> data);
  Route<dynamic> createOrderWindowPageRoute(Map<String, dynamic> data);
  Route<dynamic> createRollOrderPageRoute(Map<String, dynamic> data);
  Route<dynamic> createOCOOrderPageRoute(Map<String, dynamic> data);
  Route<dynamic> createAllWatchlistPageRoute();
  Route<dynamic> createPostionLongPressPageRoute(
      List<PositionModel> positionModel);
  Route<dynamic> createHoldingPageRoute();
  Route<dynamic> createOrderSettingsPageRoute();
  Route<dynamic> createIndividualStockPage(Map<String, dynamic> data);
  Route<dynamic> createIndividualDealsPage();
  Route<dynamic> createCalanderPageRoute();
  Route<dynamic> createProfilePageRoute();
  Route<dynamic> createStockChartPageRoute();
  Route<dynamic> createIndexDetailPageRoute(Map<String, dynamic> data);
  Route<dynamic> createReviewOrderPageRoute(Map<String, dynamic> data);
  Route<dynamic> createRemarkPageRoute();
  Route<dynamic> createConfirmPageRoute(Map<String, dynamic> data);
  Route<dynamic> createMoreAlertsPageRoute();
  Route<dynamic> createOptionAndFutureRoute();
  Route<dynamic> createSpreadPageRoute();
  Route<dynamic> createOrderOpenLongpressRoute(List<OrderStatusResult3> data);
  Route<dynamic> createRollOrderReviewPage();
  Route<dynamic> createAlertPageRoute(String title, String symbol, String ltp);
  Route<dynamic> createContactGeojitPage();
  Route<dynamic> createGetACallbackPage();
  Route<dynamic> createRaiseATicketPage();
  Route<dynamic> createDashBoardPage();
  Route<dynamic> createHelpPageRoute();
  Route<dynamic> createSupportPageRoute();
  Route<dynamic> createAboutUsPage();
  Route<dynamic> createLicencePage();
  Route<dynamic> createInviteFriend();
  Route<dynamic> createBecomePartnerPage();
  Route<dynamic> createNotificationPageRoute();
  Route<dynamic> createMarketSimulatorPageRoute();
  Route<dynamic> createMyAppsPageRoute();
  Route<dynamic> createSuggestPageRoute();
  Route<dynamic> createSettingsPageRoute();
  Route<dynamic> createSettingsNotificationPageRoute();
  Route<dynamic> createSettingOtherspageRoute();
  Route<dynamic> createFeedBackPageRoute();
  Route<dynamic> createOptionRemarkPageRoute();
  Route<dynamic> createIpoPageRoute();
  Route<dynamic> createBasketInnerPageRouteName();
  Route<dynamic> createIpoDetailPageRouteName();
  Route<dynamic> createIpoAppliedDetailpageRoutename();
  Route<dynamic> createBasketOrderConfirmPageRouteName();
  Route<dynamic> createEditBasketInner();
  Route<dynamic> createEditMyBasket();
  Route<dynamic> createIpoApplicationSubmissionPageRouteName();
  Route<dynamic> createIpoDetailPageFinalPageRouteBuilder();
  Route<dynamic> createFundsPageRoute();
  Route<dynamic> createAddFundsPageRoute();
  Route<dynamic> createOnlineTransactionPageRoute();
  Route<dynamic> createPresetManageWatchlistPageRoute(
      Map<String, dynamic> data);
  Route<dynamic> createFundsWithdrawPageRoute();
  Route<dynamic> createBondsFeaturePageRoute();
  Route<dynamic> createBondDetailsPageRoute(int bondId);
  Route<dynamic> createBondDetailsInvestPageRoute(
      BondApplicationArgumentModel bondApplicationArgumentModel);
}

part of 'navigation.dart';

class MapArguments {
  final Map<String, dynamic> data;

  MapArguments(this.data);
}

class PositionLongpressargs {
  List<PositionModel> positions;

  PositionLongpressargs(this.positions);
}

class AlertPages {
  String title;
  String Symbol;
  String ltp;
  AlertPages(this.title, this.Symbol, this.ltp);
}

class OpenCancelPage {
  final List<OrderStatusResult3> data;
  OpenCancelPage(this.data);
}

class BondDetailsArgs {
  int bondId;
  // BondApplicationArgumentModel bondApplicationArgumentModel;
  BondDetailsArgs(
    this.bondId,
    // this.bondApplicationArgumentModel,
  );
}

class BondApplicationArgs {
  BondApplicationArgumentModel bondApplicationArgumentModel;
  BondApplicationArgs(this.bondApplicationArgumentModel);
}

import 'package:flutter/cupertino.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/error_response.dart';

class GeneralMethods {
  static int getWatchIndex() {
    String _index = UserController.userController.selectedWatchIndex;
    if (int.tryParse(_index) != null) {
      return UserController.userController.watchlists
          .indexWhere((element) => element.watchlistData.watchlistid == _index);
    } else {
      return UserController.userController.presetWatchList
          .indexWhere((element) => element.watchlistData.watchname == _index);
    }
  }

  static bool isMyWatch() {
    String _index = UserController.userController.selectedWatchIndex;

    if (int.tryParse(_index) != null) {
      return true;
    } else {
      return false;
    }
  }

  static Future<ErrorResponse> updateMarketOverviewSlot(
      {required BuildContext context,
      required Instrument instrument,
      required int index}) async {
    final _response = await context.gTradingApiGateway.updateMarketWatchSlot(
        userID: UserController().userId,
        venuCode: instrument.venuecode,
        venuScriptCode: instrument.scripcode,
        symbolName: instrument.securityCode,
        sortOrder: index);
    return _response;
  }

  static bool checkWatchNameDuplication({required String watchname}) {
    String _currentWatchName = UserController()
        .watchlists[GeneralMethods.getWatchIndex()]
        .watchlistData
        .watchname;
    for (int i = 0; i < UserController.userController.watchlists.length; i++) {
      if (UserController.userController.watchlists[i].watchlistData.watchname
                  .toUpperCase() ==
              watchname.toUpperCase() &&
          UserController.userController.watchlists[i].watchlistData.watchname
                  .toUpperCase() !=
              _currentWatchName.toUpperCase()) {
        return true;
      }
    }
    return false;
  }
}

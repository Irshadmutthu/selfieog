enum ActionType {
  delete,
  save,
}

enum SortFilterLocation { position, holding }

enum Exchange { askEveryTime, nse, bse }

enum Order { regular, bo }

enum OrderType { market, limit, stopLossLimit, stopLossMarket }

enum Product { cash, intraday, btst, mtf }

enum TimeCondition { day, ioc, conditional, gtd }

enum Condition { greaterThan, lessThan }

enum OrderStatus { completed, pending, conditional }

enum SymbolSearchStatus { watchlist, alert, basket }

getExchangeString(Exchange exchange) {
  switch (exchange) {
    case Exchange.askEveryTime:
      return "Ask Everytime";
    case Exchange.nse:
      return "NSE";
    case Exchange.bse:
      return "BSE";
    default:
  }
}

getOrderString(Order order) {
  switch (order) {
    case Order.regular:
      return "Regular";
    case Order.bo:
      return "BO";
    default:
  }
}

getOrderTypeString(OrderType orderType) {
  switch (orderType) {
    case OrderType.market:
      return "Market";
    case OrderType.limit:
      return "Limit";
    case OrderType.stopLossLimit:
      return "Stop Loss Limit";
    case OrderType.stopLossMarket:
      return "Stop Loss Market";
  }
}

getProductString(Product product) {
  switch (product) {
    case Product.cash:
      return "Cash";
    case Product.intraday:
      return "Intraday";
    case Product.btst:
      return "BTST";
    case Product.mtf:
      return "MTF";
  }
}

getTimeConditionString(TimeCondition timeCondition) {
  switch (timeCondition) {
    case TimeCondition.gtd:
      return "GTD";
    case TimeCondition.ioc:
      return "IOC";
    case TimeCondition.day:
      return "Day";
    case TimeCondition.conditional:
      return "Conditional";
  }
}

getConditionString(Condition condition) {
  switch (condition) {
    case Condition.greaterThan:
      return "Greater Than";
    case Condition.lessThan:
      return "Less Than";
  }
}

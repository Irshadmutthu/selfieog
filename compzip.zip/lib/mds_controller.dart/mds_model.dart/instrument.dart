import 'dart:ui';

import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:trading_api/utils/utils.dart';

enum SubscriptionType { watch, mbp }

enum ltpColor { grey, green, red }
// String securityCODE = "HDFCBANK";
// String securityName = "HDFC bank ltd";
// String venueIndex = "2";
// String venueCode = "BSE";
// String scripCode = "11789";
// Instrument inst =
// Instrument(
//   venueIndex: getVenueIndex(venueCode),
//   scripcode: scripCode,
//   securityCode: securityCODE,
//   securityName: securityName
//   );

enum TriggerType { greaterOrEqual, lessOrEqual }

class AlertItemModel {
  final String alertType;
  final DateTime validDate;
  final double triggerValue;
  final TriggerType triggerType;
  final Instrument instrument;

  AlertItemModel(
      {required this.alertType,
      required this.validDate,
      required this.triggerValue,
      required this.triggerType,
      required this.instrument});

  get getAlertType => alertType;
}

class Instrument {
  final String scripcode; //eg 1593
  final int venueIndex; //eg 1= NSE, 2=BSE
  late String venuecode; //eg NSE, BSE
  String securityCode; //eg TATAMOTORS
  String securityName; //eg TATA MOTORS LTD
  String series; //eg EQ, CM, MF
  String type; //eg intrument type

  String isin;
  String isliquid;
  int tradetotrade;
  String otherScripCode;
  String otherSeries;

  String lastTrdTime;
  String contractDate;
  double openPrice;
  double dayHighPrice;
  double dayLowPrice;
  double avgTrdPrice;
  double upperCheckLmt;
  double lowerCheckLmt;
  double spotPrice;
  double high52Week;
  double low52Week;
  double bestBuyPrice;
  double bestSellPrice;
  double lastTrdPrice;
  double changePrice;
  double strikePrice;
  double percChange;
  double closePrice;
  int lastTrdQty;
  int totalBuyQty;
  int totalSellQty;
  int totalTrdQty;
  int subscriptionCount;
  int precision;
  // List<double> bestBuyPrices;
  // List<double> bestSellPrices;
  // List<int> bestBuyQtys;
  // List<int> bestSellQtys;
  List<String> events = [];
  int change;
  String weekly = "";
  double? ticksize;
  int? lotsize;
  String? displayName;
  SubscriptionType subscriptionType;
  Instrument(
      {required this.scripcode,
      required this.venueIndex,
      this.isin = "",
      this.isliquid = "",
      this.tradetotrade = 0,
      this.securityCode = "",
      this.securityName = "",
      this.series = "",
      this.type = "", // 10 = mutual fund
      this.otherScripCode = "",
      this.otherSeries = "",
      this.lastTrdTime = "00-00-0000 00:00:00",
      this.contractDate = "00:00:00",
      this.openPrice = 0.00,
      this.dayHighPrice = 0.00,
      this.dayLowPrice = 0.00,
      this.avgTrdPrice = 0.00,
      this.upperCheckLmt = 0.00,
      this.lowerCheckLmt = 0.00,
      this.spotPrice = 0.00,
      this.high52Week = 0.00,
      this.low52Week = 0.00,
      this.bestBuyPrice = 0.00,
      this.bestSellPrice = 0.00,
      this.strikePrice = 0.00,
      this.lastTrdPrice = 0.00,
      this.changePrice = 0.00,
      this.percChange = 0.00,
      this.closePrice = 0.00,
      this.lastTrdQty = 0,
      this.totalBuyQty = 0,
      this.totalSellQty = 0,
      this.totalTrdQty = 0,
      this.subscriptionCount = 0,
      this.precision = 2,
      // this.bestBuyPrices = const [],
      // this.bestSellPrices = const [],
      // this.bestBuyQtys = const [],
      // this.bestSellQtys = const [],
      this.change = 0,
      this.ticksize,
      this.lotsize = 1,
      this.displayName = "",
      this.subscriptionType = SubscriptionType.watch,
      String? code,
      String ca = ""}) {
    venuecode = code ??
        getVenueCode(venueIndex); //VENUE_CODES.indexOf(venueIndex.toString())
    this.precision = getPrecision(venueIndex);
    this.events = ca.split(",");
  }
  Color getLtpColor() => changePrice > 0
      ? customColors().success
      : changePrice < 0
          ? customColors().danger
          : customColors().fontSecondary;

  // bool isNonDerivative() {
  //   return type == TYPE_EQUITY || type == TYPE_MARKET_INDEX || type == TYPE_MF;
  // }

  // bool isMF() {
  //   return type == TYPE_MF;
  // }

  bool isEquity() {
    return type == "CM";
  }

  // bool isIndex() {
  //   return type == TYPE_MARKET_INDEX;
  // }
  bool isSopt() {
    return (type == "COMDTY" || type == "UNDCUR");
  }
  // bool isCommodity() {
  //   return type == TYPE_FUTCOM ||
  //       type == TYPE_OPTFUT ||
  //       type == TYPE_COMDTY ||
  //       type == TYPE_OPTCOM; //
  // }

  // bool isCommodityBase() {
  //   return type == TYPE_COMDTY;
  // }

  bool isEqual(Instrument instrument) {
    return venueIndex == instrument.venueIndex &&
        scripcode == instrument.scripcode;
  }

  bool isFao() {
    return type.startsWith("FUT") ||
        type.startsWith("OPT") ||
        type.startsWith("COM") ||
        type.startsWith("UND");
  }

  bool isCommodity() {
    return type.startsWith("COM");
  }

  // bool isDerivative() {
  //   return !isNonDerivative();
  // }

  // bool isCd() {
  //   return VENUE_TYPES[venueIndex] == VENUE_CD;
  // }

  String getPriceConditionAsString(int pCondition) {
    switch (pCondition) {
      case 1:
        return "Market";

      case 2:
        return "Limit";
      case 3:
        return "Stop Loss Limit";
      case 4:
        return "Stop Loss Market";
      default:
        return "";
    }
  }

  String getRicAddress() {
    int type = 0;
    switch (subscriptionType) {
      case SubscriptionType.mbp:
        type = 2;
        break;
      case SubscriptionType.watch:
        type = 1;
        break;
    }
    return generateRIC_Address(
        scripCode: scripcode, venueIndex: venueIndex, type: type);
  }
}

import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:trading_api/utils/utils.dart';

class MbpInstrument {
  final String scripcode;
  final int venueIndex; //eg 1= NSE, 2=BSE
  late int precision;
  String? venueCode; //eg NSE, BSE
  String bestBuyPrice;
  String bestSellPrice;
  String bestBuyQty;
  String bestSellQty;
  List<double> bestBuyPrices;
  List<double> bestSellPrices;
  List<int> bestBuyQtys;
  List<int> bestSellQtys;
  List<double> bidQtyPerc;
  List<double> askQtyPerc;
  double openPrice;
  double closePrice;
  double avgTrdPrice;
  double todaysLow;
  double todaysHigh;
  double lowerCheckLmt;
  double upperCheckLmt;
  double qtyBoughtPer;
  double qtySoldPer;
  int spot;
  int oI;
  int changeInOI;
  int volume;
  int totalBuyQty;
  int totalSellQty;
  int change;
  SubscriptionType subscriptionType;

  MbpInstrument(
      {required this.scripcode,
      required this.venueIndex,
      this.bestBuyQty = "",
      this.bestSellQty = "",
      this.bestBuyPrice = "",
      this.bestSellPrice = "",
      this.bestBuyPrices = const [0, 0, 0, 0, 0],
      this.bestSellPrices = const [0, 0, 0, 0, 0],
      this.bestBuyQtys = const [0, 0, 0, 0, 0],
      this.bestSellQtys = const [0, 0, 0, 0, 0],
      this.bidQtyPerc = const [0, 0, 0, 0, 0],
      this.askQtyPerc = const [0, 0, 0, 0, 0],
      this.openPrice = 0.00,
      this.closePrice = 0.00,
      this.avgTrdPrice = 0.00,
      this.todaysLow = 0.00,
      this.todaysHigh = 0.00,
      this.lowerCheckLmt = 0.00,
      this.upperCheckLmt = 0.00,
      this.qtyBoughtPer = 0.00,
      this.qtySoldPer = 0.00,
      this.spot = 0,
      this.oI = 0,
      this.changeInOI = 0,
      this.volume = 0,
      this.totalBuyQty = 0,
      this.totalSellQty = 0,
      this.change = 0,
      this.subscriptionType = SubscriptionType.mbp}) {
    venueCode = venueCode ?? getVenueCode(venueIndex);
    precision = getPrecision(venueIndex);
  }

  updateInstrument() {
    bestBuyPrices = splitStringToListDouble(bestBuyPrice);
    bestSellPrices = splitStringToListDouble(bestSellPrice);
    bestBuyQtys = splitStringToListInt(bestBuyQty);
    bestSellQtys = splitStringToListInt(bestSellQty);
    askQtyPerc = getPercentageInt(bestSellQtys);
    bidQtyPerc = getPercentageInt(bestBuyQtys);
    getBuyAndSellStat();
  }

  List<double> splitStringToListDouble(String val) {
    List<String> splitedList = val.split(" ");
    return List<double>.generate(5, (i) {
      if (splitedList.length <= i) return 0.00;
      return double.tryParse(splitedList[i]) ?? 0.00;
    });
  }

  List<int> splitStringToListInt(String val) {
    List<String> splitedList = val.split(" ");
    return List<int>.generate(5, (i) {
      if (splitedList.length <= i) return 0;
      return int.tryParse(splitedList[i]) ?? 0;
    });
  }

  List<double> getPercentageDouble(List<double> list) {
    double totalBidQty = list.reduce((a, b) => a + b);
    if (totalBidQty == 0) return [0, 0, 0, 0, 0];
    return List<double>.generate(5, (index) {
      if (list.length <= index) return 0;
      return list[index] != 0 ? list[index] / totalBidQty : 0;
    });
  }

  List<double> getPercentageInt(List<int> list) {
    int totalBidQty = list.reduce((a, b) => a + b);
    if (totalBidQty == 0) return [0, 0, 0, 0, 0];
    return List<double>.generate(5, (index) {
      if (list.length <= index) return 0;
      return list[index] != 0 ? list[index] / totalBidQty : 0;
    });
  }

  getBuyAndSellStat() {
    int totalQty = totalBuyQty + totalSellQty;
    if (totalQty == 0) return;
    qtyBoughtPer = totalBuyQty != 0 ? totalBuyQty / totalQty : 0;
    qtySoldPer = totalSellQty != 0 ? totalSellQty / totalQty : 0;
  }

  String getRicAddress() {
    int type = 0;
    switch (subscriptionType) {
      case SubscriptionType.mbp:
        type = 2;
        break;
      case SubscriptionType.watch:
        type = 1;
        break;
    }
    return generateRIC_Address(
        scripCode: scripcode, venueIndex: venueIndex, type: type);
  }
}

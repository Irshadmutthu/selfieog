import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';

Map<String, Instrument> subscriptionList = {};
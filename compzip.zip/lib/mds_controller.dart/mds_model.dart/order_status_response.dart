import 'dart:convert';

import 'package:selfie_mobile_flutter/mds_controller.dart/config.dart';

class OrderStatusResponse {
  OrderStatusResponse(
      {required this.instrument,
      required this.genMessage1,
      required this.venue,
      this.statusList = const []
      // required this.adminMsg1,
      // required this.genNumeric1,
      // required this.bestBuyPrice,
      // required this.avgPrice,
      // required this.genInteger1,
      // required this.genInteger2,
      // required this.genNumeric3,
      // required this.actFlag3,
      // required this.lstTrdPrice,
      // required this.netChange,
      // required this.genNumeric2,
      // required this.actFlag2,
      // required this.genInteger3,
      // required this.genNumeric4,
      // required this.totBuyQty,
      // required this.actFlag4,
      // required this.genMessage2,
      // required this.genNumeric5,
      // required this.actFlag5,
      // required this.percChange,
      // required this.actFlag1,
      // required this.genMessage3,
      // required this.totTrdValue,
      // required this.sendSubject,
      // required this.series,
      // required this.username,
      });

  String instrument;
  String genMessage1;
  String venue;
  List<String> statusList;

  // String adminMsg1;
  // int genNumeric1;
  // double bestBuyPrice;
  // String avgPrice;
  // String genInteger1;
  // String genInteger2;
  // String genNumeric3;
  // int actFlag3;
  // String lstTrdPrice;
  // double netChange;
  // int genNumeric2;
  // int actFlag2;
  // int genInteger3;
  // int genNumeric4;
  // int totBuyQty;
  // int actFlag4;
  // String genMessage2;
  // int genNumeric5;
  // String actFlag5;
  // String percChange;
  // int actFlag1;
  // String genMessage3;
  // String totTrdValue;
  // String sendSubject;
  // String series;
  // String username;

  String get getOrderStatus {
    if (statusList.length < 5) return "Order Status";
    return orderStatus[statusList[4]].toString();
  }

  String get getQuotedMessage => genMessage1;

  OrderStatusResponse copyWith({
    String? instrument,
    String? genMessage1,
    String? venue,
    List<String>? statusList,
    // String? adminMsg1,
    // int? genNumeric1,
    // double? bestBuyPrice,
    // String? avgPrice,
    // String? genInteger1,
    // String? genInteger2,
    // String? genNumeric3,
    // int? actFlag3,
    // String? lstTrdPrice,
    // double? netChange,
    // int? genNumeric2,
    // int? actFlag2,
    // int? genInteger3,
    // int? genNumeric4,
    // int? totBuyQty,
    // int? actFlag4,
    // String? genMessage2,
    // int? genNumeric5,
    // String? actFlag5,
    // String? percChange,
    // int? actFlag1,
    // String? genMessage3,
    // String? totTrdValue,
    // String? sendSubject,
    // String? series,
    // String? username,
  }) =>
      OrderStatusResponse(
          instrument: instrument ?? this.instrument,
          genMessage1: genMessage1 ?? this.genMessage1,
          venue: venue ?? this.venue,
          statusList: statusList ?? this.statusList

          // adminMsg1: adminMsg1 ?? this.adminMsg1,
          // genNumeric1: genNumeric1 ?? this.genNumeric1,
          // bestBuyPrice: bestBuyPrice ?? this.bestBuyPrice,
          // avgPrice: avgPrice ?? this.avgPrice,
          // genInteger1: genInteger1 ?? this.genInteger1,
          // genInteger2: genInteger2 ?? this.genInteger2,
          // genNumeric3: genNumeric3 ?? this.genNumeric3,
          // actFlag3: actFlag3 ?? this.actFlag3,
          // lstTrdPrice: lstTrdPrice ?? this.lstTrdPrice,
          // netChange: netChange ?? this.netChange,
          // genNumeric2: genNumeric2 ?? this.genNumeric2,
          // actFlag2: actFlag2 ?? this.actFlag2,
          // genInteger3: genInteger3 ?? this.genInteger3,
          // genNumeric4: genNumeric4 ?? this.genNumeric4,
          // totBuyQty: totBuyQty ?? this.totBuyQty,
          // actFlag4: actFlag4 ?? this.actFlag4,
          // genMessage2: genMessage2 ?? this.genMessage2,
          // genNumeric5: genNumeric5 ?? this.genNumeric5,
          // actFlag5: actFlag5 ?? this.actFlag5,
          // percChange: percChange ?? this.percChange,
          // actFlag1: actFlag1 ?? this.actFlag1,
          // genMessage3: genMessage3 ?? this.genMessage3,
          // totTrdValue: totTrdValue ?? this.totTrdValue,
          // sendSubject: sendSubject ?? this.sendSubject,
          // series: series ?? this.series,
          // username: username ?? this.username,
          );

  factory OrderStatusResponse.fromJson(String str) =>
      OrderStatusResponse.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory OrderStatusResponse.fromMap(Map<String, dynamic> json) =>
      OrderStatusResponse(
        instrument: json["INSTRUMENT"] ?? "",
        genMessage1: json["GEN_MESSAGE_1"] ?? "",
        venue: json["VENUE"] ?? "",
        // adminMsg1: json["ADMIN_MSG_1"] ?? "",
        // genNumeric1: json["GEN_NUMERIC1"] ?? 0,
        // bestBuyPrice: json["BEST_BUY_PRICE"] ?? 0.0,
        // avgPrice: json["AVG_PRICE"] ?? "",
        // genInteger1: json["GEN_INTEGER1"] ?? "",
        // genInteger2: json["GEN_INTEGER2"] ?? "",
        // genNumeric3: json["GEN_NUMERIC3"] ?? "",
        // actFlag3: json["ACT_FLAG_3"] ?? 0,
        // lstTrdPrice: json["LST_TRD_PRICE"] ?? "",
        // netChange: json["NET_CHANGE"] ?? 0.0,
        // genNumeric2: json["GEN_NUMERIC2"] ?? "",
        // actFlag2: json["ACT_FLAG_2"] ?? 0,
        // genInteger3: json["GEN_INTEGER3"] ?? 0,
        // genNumeric4: json["GEN_NUMERIC4"] ?? 0,
        // totBuyQty: json["TOT_BUY_QTY"] ?? 0,
        // actFlag4: json["ACT_FLAG_4"] ?? 0,
        // genMessage2: json["GEN_MESSAGE_2"] ?? "",
        // genNumeric5: json["GEN_NUMERIC5"] ?? 0,
        // actFlag5: json["ACT_FLAG_5"] ?? "",
        // percChange: json["PERC_CHANGE"] ?? "",
        // actFlag1: json["ACT_FLAG_1"] ?? 0,
        // genMessage3: json["GEN_MESSAGE_3"] ?? "",
        // totTrdValue: json["TOT_TRD_VALUE"] ?? "",
        // sendSubject: json["SEND_SUBJECT"] ?? "",
        // series: json["SERIES"] ?? "",
        // username: json["USERNAME"] ?? "",
      );

  Map<String, dynamic> toMap() => {
        "INSTRUMENT": instrument,
        "VENUE": venue,
        "GEN_MESSAGE_1": genMessage1,

        // "ADMIN_MSG_1": adminMsg1,
        // "GEN_NUMERIC1": genNumeric1,
        // "BEST_BUY_PRICE": bestBuyPrice,
        // "AVG_PRICE": avgPrice,
        // "GEN_INTEGER1": genInteger1,
        // "GEN_INTEGER2": genInteger2,
        // "GEN_NUMERIC3": genNumeric3,
        // "ACT_FLAG_3": actFlag3,
        // "LST_TRD_PRICE": lstTrdPrice,
        // "NET_CHANGE": netChange,
        // "GEN_NUMERIC2": genNumeric2,
        // "ACT_FLAG_2": actFlag2,
        // "GEN_INTEGER3": genInteger3,
        // "GEN_NUMERIC4": genNumeric4,
        // "TOT_BUY_QTY": totBuyQty,
        // "ACT_FLAG_4": actFlag4,
        // "GEN_MESSAGE_2": genMessage2,
        // "GEN_NUMERIC5": genNumeric5,
        // "ACT_FLAG_5": actFlag5,
        // "PERC_CHANGE": percChange,
        // "ACT_FLAG_1": actFlag1,
        // "GEN_MESSAGE_3": genMessage3,
        // "TOT_TRD_VALUE": totTrdValue,
        // "SEND_SUBJECT": sendSubject,
        // "SERIES": series,
        // "USERNAME": username,
      };
}



    // if (element.containsKey(ADMIN_MSG_1)) {
    //   orderStatusResponse.adminMsg1 = element[ADMIN_MSG_1].toString();
    // }
    // if (element.containsKey(GEN_NUMERIC1)) {
    //   orderStatusResponse.genNumeric1 =
    //       int.tryParse(element[GEN_NUMERIC1].toString()) ?? 0;
    // }
    // if (element.containsKey(BEST_BUY_PRICE)) {
    //   orderStatusResponse.bestBuyPrice =
    //       double.tryParse(element[BEST_BUY_PRICE].toString()) ?? 0.0;
    // }
    // if (element.containsKey(AVG_PRICE)) {
    //   orderStatusResponse.avgPrice = element[AVG_PRICE].toString();
    // }

    // if (element.containsKey(GEN_INTEGER1)) {
    //   orderStatusResponse.genInteger1 = element[GEN_INTEGER1].toString();
    // }
    // if (element.containsKey(GEN_INTEGER2)) {
    //   orderStatusResponse.genInteger2 = element[GEN_INTEGER2].toString();
    // }
    // if (element.containsKey(GEN_NUMERIC3)) {
    //   orderStatusResponse.genNumeric3 = element[GEN_NUMERIC3].toString();
    // }
    // if (element.containsKey(ACT_FLAG_3)) {
    //   orderStatusResponse.actFlag3 =
    //       int.tryParse(element[ACT_FLAG_3].toString()) ?? 0;
    // }
    // if (element.containsKey(LST_TRD_PRICE)) {
    //   orderStatusResponse.lstTrdPrice = element[LST_TRD_PRICE].toString();
    // }
    
    // if (element.containsKey(NET_CHANGE)) {
    //   orderStatusResponse.netChange =
    //       double.tryParse(element[NET_CHANGE].toString()) ?? 0.0;
    // }
    // if (element.containsKey(GEN_NUMERIC2)) {
    //   orderStatusResponse.genNumeric2 =
    //       int.tryParse(element[GEN_NUMERIC2].toString()) ?? 0;
    // }
    // if (element.containsKey(ACT_FLAG_2)) {
    //   orderStatusResponse.actFlag2 =
    //       int.tryParse(element[ACT_FLAG_2].toString()) ?? 0;
    // }
    // if (element.containsKey(GEN_INTEGER3)) {
    //   orderStatusResponse.genInteger3 =
    //       int.tryParse(element[GEN_INTEGER3].toString()) ?? 0;
    // }
    // if (element.containsKey(GEN_NUMERIC4)) {
    //   orderStatusResponse.genNumeric4 =
    //       int.tryParse(element[GEN_NUMERIC4].toString()) ?? 0;
    // }
    // if (element.containsKey(TOT_BUY_QTY)) {
    //   orderStatusResponse.totBuyQty =
    //       int.tryParse(element[TOT_BUY_QTY].toString()) ?? 0;
    // }
    // if (element.containsKey(ACT_FLAG_4)) {
    //   orderStatusResponse.actFlag4 =
    //       int.tryParse(element[ACT_FLAG_4].toString()) ?? 0;
    // }
    // if (element.containsKey(GEN_MESSAGE_2)) {
    //   orderStatusResponse.genMessage2 = element[GEN_MESSAGE_2].toString();
    // }
    // if (element.containsKey(GEN_NUMERIC5)) {
    //   orderStatusResponse.genNumeric5 =
    //       int.tryParse(element[GEN_NUMERIC5].toString()) ?? 0;
    // }
    // if (element.containsKey(ACT_FLAG_5)) {
    //   orderStatusResponse.actFlag5 = element[ACT_FLAG_5].toString();
    // }
    // if (element.containsKey(PERC_CHANGE)) {
    //   orderStatusResponse.percChange = element[PERC_CHANGE].toString();
    // }
    // if (element.containsKey(ACT_FLAG_1)) {
    //   orderStatusResponse.actFlag1 =
    //       int.tryParse(element[ACT_FLAG_1].toString()) ?? 0;
    // }

    // if (element.containsKey(GEN_MESSAGE_3)) {
    //   orderStatusResponse.genMessage3 = element[GEN_MESSAGE_3].toString();
    // }

    // if (element.containsKey(TOT_TRD_VALUE)) {
    //   orderStatusResponse.totTrdValue = element[TOT_TRD_VALUE].toString();
    // }

    // if (element.containsKey(SEND_SUBJECT)) {
    //   orderStatusResponse.sendSubject = element[SEND_SUBJECT].toString();
    // }

    // if (element.containsKey(SERIES)) {
    //   orderStatusResponse.series = element[SERIES].toString();
    // }

    // if (element.containsKey(USERNAME)) {
    //   orderStatusResponse.username = element[USERNAME].toString();
    // }

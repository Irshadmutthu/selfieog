// import 'package:mds/response/flair_polling_response.dart';
// import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
// import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller_interface.dart';

// class MDS_Controller_Impl extends MDS_Controller_interface{
  
//   final MDS_Controller _mds_controller = MDS_Controller();

//   @override
//   startPolling() {
//     _mds_controller.startPolling();
//   }

//   @override
//   stopPolling() {
//     _mds_controller.stopPolling();
//   }

//   @override
//   subscribe() {
//     _mds_controller.subscrbe();
//   }

//   @override
//   unsubscribe() {
//     _mds_controller.unsubscribe();
//   }

//   @override
//   Stream<Map<String, Object>> getStreamerInstance() {
//     return _mds_controller.getStreamInstance();
//   }

//   @override
//   Future<void> sendLogin({String username = "VYJ252", String password = "" }) async {
//     // return _mds_controller.mdsLogin(username, password);
//   }
  
// }

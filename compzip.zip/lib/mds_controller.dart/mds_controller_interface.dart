// import 'package:mds/response/flair_polling_response.dart';

// abstract class MDS_Controller_interface {
//   subscribe();
//   unsubscribe();
//   startPolling();
//   stopPolling();
//   Stream<Map<String, Object>> getStreamerInstance();
//   Future<void> sendLogin({String username, String password});
// }

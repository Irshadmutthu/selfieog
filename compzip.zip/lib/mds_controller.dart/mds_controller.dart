import 'dart:async';
import 'dart:developer';
import 'package:flutter/foundation.dart';
import 'package:mds/mds.dart';
import 'package:mds/response/flair_response_keys.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/mbp_instrument.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/order_status_response.dart';

//enum FeedSubscriptionType { watch, mbp, mbpOther }
// "1.6.1.236116", GOLDM MCX
// "1.6.1.237883", GOLDM MCX
const int ADMIN_FEED_MSG = 110;
const int ALERT_MSG = 112;
const int LOGIN_MSG = 1;
const int MARKET_WATCH_SUBSCRIPTION_MSG = 2;
const int DISCONNECT_MSG = 102;
const int LOGGED_OUT = 104;
const int MBP_MSG = 103;
const int INSTRUMENT_FEED_MSG = 100;
const int MARKET_INDEX_FEED_MSG = 101;
const int TIMEANDSALES_MSG = 105;

class FlairResponseModel {
  final String ric;
  final Instrument instrument;
  FlairResponseModel(this.ric, this.instrument);
}

class FeedResponseInstance {
  final String key;
  final Instrument instrument;
  FeedResponseInstance({required this.key, required this.instrument});
}

class MDS_Controller {
  String? mdsUrl;
  late MDS_Login mds;
  String userName = "";
  Map<String, Instrument> feedData = {};
  Map<String, int> feedCount = {};
  Map<String, MbpInstrument> mbpData = {};
  Map<String, int> mbpCount = {};
  late StreamController<List<FlairResponseModel>> _marketStreamController;
  Stream<List<FlairResponseModel>> get marketUpdateStream =>
      _marketStreamController.stream;

  late StreamController<OrderStatusResponse> _orderStreamController;
  Stream<OrderStatusResponse> get orderStatusStream =>
      _orderStreamController.stream;

  late StreamController<Map<String, MbpInstrument>> _mbpStreamController;
  Stream<Map<String, MbpInstrument>> get mbpStream =>
      _mbpStreamController.stream;

  static final MDS_Controller mdsController =
      MDS_Controller._privateConstructor();

  MDS_Controller._privateConstructor() {
    _marketStreamController =
        StreamController<List<FlairResponseModel>>.broadcast();
    _orderStreamController = StreamController<OrderStatusResponse>.broadcast();
    _mbpStreamController =
        StreamController<Map<String, MbpInstrument>>.broadcast();
    mds = MDS_Login.createMdsLogin(
        url: mdsUrl ?? "http://freeflair.geojit.net:443/m/r");
    mds.stream.listen((List<Map<String, Object>> event) {
      List<FlairResponseModel> responseList = [];
      for (Map<String, Object> element in event) {
        int type = -1;
        if (element.containsKey(GEN_INTEGER5)) {
          type = int.tryParse(element[SEND_SUBJECT].toString()) ?? -1;
        }
        if (type == -1 && element.containsKey(SEND_SUBJECT)) {
          type = getMessageIdFromSendSubject(
              subject: element[SEND_SUBJECT].toString());
        }

        if (type == -1) {
          print(
              "######################## UNSPECIFIC RESPONSE TYPE ##########################");
          print("data : [$element]");
        }

        switch (type) {
          // case LOGIN_MSG : //handle login response
          // break;
          // case MARKET_WATCH_SUBSCRIPTION_MSG : //handle subscription response
          // break;
          // case DISCONNECT_MSG : //handle handle disconnected message
          // break;
          // case LOGGED_OUT : //handle logged out
          case ADMIN_FEED_MSG:
            handleOrderStatus(element: element);
            break;
          case MBP_MSG:
            {
              handleMbpData(element: element);
              break;
            }
          case INSTRUMENT_FEED_MSG: //handle feed
          default:
            {
              FlairResponseModel? model = handleWatchData(element: element);
              if (model != null) {
                responseList.add(model);
              }
            }
        }
      }
      if (responseList.isNotEmpty) {
        _marketStreamController.sink.add(responseList);
      }
    });
    // initStream();
  }

  factory MDS_Controller({String? url}) {
    if (url != null) {
      mdsController.mdsUrl = url;
    }
    return mdsController;
  }

  FlairResponseModel? handleWatchData({required Map<String, Object> element}) {
    if (element.containsKey(SEND_SUBJECT)) {
      // print("poll update for ${event["76"]}");
      String key = element[SEND_SUBJECT].toString(); //1.6.1.237883
      Instrument? instrument = feedData[key];
      if (instrument == null) return null;

      if (element.containsKey(LST_TRD_PRICE)) {
        double prevLtp = instrument.lastTrdPrice;
        double ltp = double.tryParse(element[LST_TRD_PRICE].toString()) ?? 0.00;
        if (ltp > prevLtp) {
          instrument.change = 1;
        } else if (ltp < prevLtp) {
          instrument.change = -1;
        }
        instrument.lastTrdPrice = ltp;
      }
      if (element.containsKey(NET_CHANGE)) {
        instrument.changePrice =
            double.tryParse(element[NET_CHANGE].toString()) ?? 0.00;
      }
      if (element.containsKey(PERC_CHANGE)) {
        instrument.percChange =
            double.tryParse(element[PERC_CHANGE].toString()) ?? 0.00;
      }
      if (element.containsKey(LST_TRD_QTY)) {
        instrument.lastTrdQty =
            int.tryParse(element[LST_TRD_QTY].toString()) ?? 0;
      }
      if (element.containsKey(LST_TRD_TIME)) {
        instrument.lastTrdTime = element[LST_TRD_TIME] == null
            ? ""
            : element[LST_TRD_TIME].toString();
      }
      if (element.containsKey(OPEN_PRICE)) {
        instrument.openPrice =
            double.tryParse(element[OPEN_PRICE].toString()) ?? 0.00;
      }
      if (element.containsKey(CLOSE_PRICE)) {
        instrument.closePrice =
            double.tryParse(element[CLOSE_PRICE].toString()) ?? 0.00;
      }
      if (element.containsKey(DAY_HIGH)) {
        instrument.dayHighPrice =
            double.tryParse(element[DAY_HIGH].toString()) ?? 0.00;
      }
      if (element.containsKey(DAY_LOW)) {
        instrument.dayLowPrice =
            double.tryParse(element[DAY_LOW].toString()) ?? 0.00;
      }
      if (element.containsKey(AVG_PRICE)) {
        instrument.avgTrdPrice =
            double.tryParse(element[AVG_PRICE].toString()) ?? 0.00;
      }
      if (element.containsKey(UPPER_CHK_LIMIT)) {
        instrument.upperCheckLmt =
            double.tryParse(element[UPPER_CHK_LIMIT].toString()) ?? 0.00;
      }
      if (element.containsKey(LOWER_CHK_LIMIT)) {
        instrument.lowerCheckLmt =
            double.tryParse(element[LOWER_CHK_LIMIT].toString()) ?? 0.00;
      }
      if (element.containsKey(WEEKS52_HIGH)) {
        instrument.high52Week =
            double.tryParse(splitData(element[WEEKS52_HIGH].toString(), 0)) ??
                0.00;
      }
      if (element.containsKey(WEEKS52_LOW)) {
        instrument.low52Week =
            double.tryParse(splitData(element[WEEKS52_LOW].toString(), 0)) ??
                0.00;
      }
      if (element.containsKey(BEST_BUY_PRICE)) {
        instrument.bestBuyPrice =
            double.tryParse(element[BEST_BUY_PRICE].toString()) ?? 0.00;
      }
      if (element.containsKey(BEST_SELL_PRICE)) {
        instrument.bestSellPrice =
            double.tryParse(element[BEST_SELL_PRICE].toString()) ?? 0.00;
      }
      if (element.containsKey(STRIKE_PRICE)) {
        instrument.strikePrice =
            double.tryParse(element[STRIKE_PRICE].toString()) ?? 0.00;
      }
      if (element.containsKey(PERC_CHANGE)) {
        instrument.percChange =
            double.tryParse(element[PERC_CHANGE].toString()) ?? 0.00;
      }
      if (element.containsKey(TOT_BUY_QTY)) {
        instrument.totalBuyQty =
            int.tryParse(element[TOT_BUY_QTY].toString()) ?? 0;
      }
      if (element.containsKey(TOT_SELL_QTY)) {
        instrument.totalSellQty =
            int.tryParse(element[TOT_SELL_QTY].toString()) ?? 0;
      }
      if (element.containsKey(TOT_TRD_QTY)) {
        instrument.totalTrdQty =
            int.tryParse(element[TOT_TRD_QTY].toString()) ?? 0;
      }

      return FlairResponseModel(key, instrument);
    }
  }

  handleMbpData({required Map<String, Object> element}) {
    if (!element.containsKey(SEND_SUBJECT)) return null;
    // print("poll update for ${event["76"]}");
    String key = element[SEND_SUBJECT].toString(); //1.6.1.237883
    MbpInstrument? mbpInstrument = mbpData[key];
    if (mbpInstrument == null) return null;

    if (element.containsKey(BEST_BUY_QTY)) {
      mbpInstrument.bestBuyQty = element[BEST_BUY_QTY].toString();
    }
    if (element.containsKey(BEST_SELL_QTY)) {
      mbpInstrument.bestSellQty = element[BEST_SELL_QTY].toString();
    }
    if (element.containsKey(BEST_BUY_PRICE)) {
      mbpInstrument.bestBuyPrice = element[BEST_BUY_PRICE].toString();
    }
    if (element.containsKey(BEST_SELL_PRICE)) {
      mbpInstrument.bestSellPrice = element[BEST_SELL_PRICE].toString();
    }
    if (element.containsKey(OPEN_PRICE)) {
      mbpInstrument.openPrice =
          double.tryParse(element[OPEN_PRICE].toString()) ?? 0.0;
    }
    if (element.containsKey(CLOSE_PRICE)) {
      mbpInstrument.closePrice =
          double.tryParse(element[CLOSE_PRICE].toString()) ?? 0.0;
    }
    if (element.containsKey(AVG_PRICE)) {
      mbpInstrument.avgTrdPrice =
          double.tryParse(element[AVG_PRICE].toString()) ?? 0.0;
    }
    if (element.containsKey(DAY_LOW)) {
      mbpInstrument.todaysLow =
          double.tryParse(element[DAY_LOW].toString()) ?? 0.00;
    }
    if (element.containsKey(DAY_HIGH)) {
      mbpInstrument.todaysHigh =
          double.tryParse(element[DAY_HIGH].toString()) ?? 0.00;
    }
    if (element.containsKey(LOWER_CHK_LIMIT)) {
      mbpInstrument.lowerCheckLmt =
          double.tryParse(element[LOWER_CHK_LIMIT].toString()) ?? 0.00;
    }
    if (element.containsKey(UPPER_CHK_LIMIT)) {
      mbpInstrument.upperCheckLmt =
          double.tryParse(element[UPPER_CHK_LIMIT].toString()) ?? 0.00;
    }

    if (element.containsKey(TOT_BUY_QTY)) {
      mbpInstrument.totalBuyQty =
          int.tryParse(element[TOT_BUY_QTY].toString()) ?? 0;
    }
    if (element.containsKey(TOT_SELL_QTY)) {
      mbpInstrument.totalSellQty =
          int.tryParse(element[TOT_SELL_QTY].toString()) ?? 0;
    }
    if (element.containsKey(TOT_TRD_QTY)) {
      mbpInstrument.volume = int.tryParse(element[TOT_TRD_QTY].toString()) ?? 0;
    }
    if (element.containsKey(CHANGE_IN_OPEN_INTER)) {
      mbpInstrument.changeInOI =
          int.tryParse(element[CHANGE_IN_OPEN_INTER].toString()) ?? 0;
    }
    if (element.containsKey(OPEN_INTEREST)) {
      mbpInstrument.oI = int.tryParse(element[OPEN_INTEREST].toString()) ?? 0;
    }

    _mbpStreamController.sink.add({key: mbpInstrument});
  }

  handleOrderStatus({required Map<String, Object> element}) {
    OrderStatusResponse orderStatusResponse =
        OrderStatusResponse.fromJson("{}");
    if (element.containsKey(GEN_MESSAGE_1)) {
      orderStatusResponse.genMessage1 = element[GEN_MESSAGE_1].toString();
    }

    if (element.containsKey(GEN_INTEGER1)) {
      orderStatusResponse.statusList =
          element[GEN_INTEGER1].toString().split(" ").toList();
    }

    if (element.containsKey(INSTRUMENT)) {
      orderStatusResponse.instrument = element[INSTRUMENT].toString();
    }

    if (element.containsKey(VENUE)) {
      orderStatusResponse.venue = element[VENUE].toString();
    }

    _orderStreamController.sink.add(orderStatusResponse);
  }

  logSubscriptionDetails() {
    print("## subscription count = ${feedData.length}, ${feedCount.length}");
    print("## subscription Map = $feedCount");
  }

  subscribeMbpSymbol(MbpInstrument mbpInstrument) {
    String ric = mbpInstrument.getRicAddress();
    if (mbpCount.containsKey(ric)) {
      //since count is not empty get count and increment
      int count = (mbpCount[ric] ?? 0) + 1;
      if (count > 0) {
        mbpCount[ric] = count;
        if (mbpData.containsKey(ric)) {
          //since mbpData has instrument pass the reference
          mbpInstrument = mbpData[ric]!;
        }
      }
    } else {
      //since count is empty subscribe and set count as 1
      _subscrbeSymbol(ric);
      mbpData[ric] = mbpInstrument;
      mbpCount[ric] = 1;
    }
    logSubscriptionDetails();
  }

  unsubscribeMbpSymbol(MbpInstrument mbpInstrument) {
    String ric = mbpInstrument.getRicAddress();
    if (mbpCount.containsKey(ric)) {
      //since count already exist decrement
      int count = (mbpCount[ric] ?? 0) - 1;
      if (count < 1) {
        //since count less than 1 unsubscribe and remove
        _unsubscribeSymbol(ric);
        mbpCount.remove(ric);
        mbpData.remove(ric);
      } else {
        //update count since not less than 1 update count
        mbpCount[ric] = count;
      }
    }
    logSubscriptionDetails();
  }

  subscribeSymbol(Instrument data) {
    String ric = data.getRicAddress();
    if (feedCount.containsKey(ric)) {
      //since count is not empty get count and increment
      int count = (feedCount[ric] ?? 0) + 1;
      if (count > 0) {
        feedCount[ric] = count;
        if (feedData.containsKey(ric)) {
          //since feedData has instrument pass the reference
          data = feedData[ric]!;
        }
      }
    } else {
      //since count is empty subscribe and set count as 1
      _subscrbeSymbol(ric);
      feedData[ric] = data;
      feedCount[ric] = 1;
    }
    logSubscriptionDetails();
  }

  subscribeSymbols(List<Instrument> data) {
    if (data.isEmpty) return;
    List<String> ricList = [];
    for (var i = 0; i < data.length; i++) {
      String ric = data[i].getRicAddress();
      if (feedCount.containsKey(ric)) {
        //since count is not empty get count and increment
        int count = (feedCount[ric] ?? 0) + 1;
        if (count > 0) {
          feedCount[ric] = count;
          if (feedData.containsKey(ric)) {
            //since feedData has instrument pass the reference
            data[i] = feedData[ric]!;
          }
        }
      } else {
        //since count is empty subscribe and set count as 1
        ricList.add(ric);
        feedData[ric] = data[i];
        feedCount[ric] = 1;
      }
    }
    if (ricList.isNotEmpty) _batchSubscrbe(ricList);
    logSubscriptionDetails();
  }

  unsubscribeSymbol(Instrument instrument) {
    String ric = instrument.getRicAddress();
    if (feedCount.containsKey(ric)) {
      //since count already exist decrement
      int count = (feedCount[ric] ?? 0) - 1;
      if (count < 1) {
        //since count less than 1 unsubscribe and remove
        _unsubscribeSymbol(ric);
        feedCount.remove(ric);
        feedData.remove(ric);
      } else {
        //update count since not less than 1 update count
        feedCount[ric] = count;
      }
    }
    logSubscriptionDetails();
  }

  unsubscribeSymbols(List<Instrument> data) {
    if (data.isEmpty) return;
    List<String> ricList = [];
    for (var i = 0; i < data.length; i++) {
      String ric = data[i].getRicAddress();
      if (feedCount.containsKey(ric)) {
        //since count already exist decrement
        int count = (feedCount[ric] ?? 0) - 1;
        if (count < 1) {
          //since count less than 1 unsubscribe and remove
          ricList.add(ric);
          feedCount.remove(ric);
          feedData.remove(ric);
        } else {
          //update count since not less than 1 update count
          feedCount[ric] = count;
        }
      }
    }
    if (ricList.isNotEmpty) _batchUnsubscribe(ricList);
    logSubscriptionDetails();
  }

  splitData(String str, int index) {
    return str.split(" ").elementAt(index);
  }

  getLatestFeedUpdates(List<Instrument> data) {
    for (var i = 0; i < data.length; i++) {
      String ric = data[i].getRicAddress();
      if (feedData.containsKey(ric)) {
        data[i] = feedData[ric]!;
      }
    }
  }

  // subscribeAndUnsubscribeSymbol(String ric, String unSubScrip) {
  //   mds.subscribeUnsubscribe(ric, unSubScrip);
  // }

  _subscrbeSymbol(String ric) {
    mds.subscribeSingle(ric);
  }

  _unsubscribeSymbol(String ric) {
    mds.unsubscribeSingle(ric);
  }

  _batchSubscrbe(List<String> data) {
    mds.subscribeBatch(data);
  }

  _batchUnsubscribe(List<String> data) {
    mds.unsubscribeBatch(data);
  }

  onLogout() async {
    try {
      //mds.sendUnsubscriptionRequest(feedData.keys.join(" "));
      //Add small delay here for sending unsubsciption successfully
      mds.unsubscribeBatch(feedData.keys.toList());
      feedData.clear();
      await mds.dispose();
      _marketStreamController.done;
      _orderStreamController.done;
    } catch (e) {
      if (kDebugMode) {
        log("dispose error", error: e);
      }
    }
  }

  mdsLogin({required String tradecode, required String password}) async {
    userName = tradecode;
    await mds.flair(tradecode, password);
  }

  mdsInit({required String tradecode, required String omsSessionId}) async {
    await mds.sendCombinedStatusRequest(
        tradecode: tradecode, omsSessionId: omsSessionId);
  }

  /// returns formatted double value with fixedFraction point
  /// ```dart
  /// formatDouble(123.0123);
  /// ```
  /// returns [123.01]
  /// ```dart
  /// formatDouble(123.0, fractionPoint: 3);
  /// ```
  /// returns [123.000]
  String formatDouble(double value, {int fractionPoint = 2}) {
    return value.toStringAsFixed(fractionPoint);
  }
}

/// Create RIC address
/// scripcode = venueScripCode eg: "1465"
/// venueIndex = exchange eg: NSE = "0", BSE = "1"
/// type = subscriptionType eg: Watchlist = "1", MBP = "2"
/// generateRIC_Address(scripCode: "2135", venueIndex: 1, type: 1);
String generateRIC_Address(
    {required String scripCode, required int venueIndex, required int type}) {
  if (scripCode.contains(".")) return scripCode;
  return "1" +
      "." +
      venueIndex.toString() +
      "." +
      type.toString() +
      "." +
      scripCode;
}

int getMessageIdFromSendSubject({required String subject}) {
  if (subject == "0.0.0.0") {
    return DISCONNECT_MSG;
  }
  if (subject.startsWith("1.0.0.") && subject.endsWith("_M")) {
    return ADMIN_FEED_MSG;
  }
  if (subject.startsWith("1.0.ALERT.")) {
    return ALERT_MSG;
  }
  int subserviceStr = -1;
  int secondIndex = (subject.indexOf(".", (subject.indexOf(".") + 1))) + 1;
  int thirdIndex = (subject.indexOf(
      ".", (subject.indexOf(".", (subject.indexOf(".") + 1)) + 1)));
  if (thirdIndex > secondIndex) {
    subserviceStr =
        int.tryParse(subject.substring(secondIndex, thirdIndex)) ?? -1;
  }
  switch (subserviceStr) {
    case 1:
      return INSTRUMENT_FEED_MSG;
    case 2:
      return MBP_MSG;
    case 3:
      return MARKET_INDEX_FEED_MSG;
    case 6:
      return TIMEANDSALES_MSG;
  }
  return -1;
}

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/watchlist_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/restart_widget.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';

List<Map<String, dynamic>> callbackrequestList = [
  {
    "name": "General Enquiry",
    "sidebarcolor": red200,
    "badge": "MY GEOJIT",
    "status": "UPCOMING",
    "description": "I am not able to chnage password in my system default",
    "date": "18/02/22",
    "time": "04:30pm"
  },
  {
    "name": "Others",
    "sidebarcolor": red200,
    "badge": "SELFIE APP",
    "status": "PENDING",
    "description": "I am not able to chnage password in my system default",
    "date": "18/02/22",
    "time": "04:30pm"
  },
  {
    "name": "Others",
    "sidebarcolor": red200,
    "badge": "SELFIE APP",
    "status": "RECEIVED",
    "description": "I am not able to chnage password in my system default",
    "date": "18/02/22",
    "time": "04:30pm"
  }
];

List<Map<String, dynamic>> raiseATicketTopicList = [
  {
    "name": "Watchlist",
  },
  {
    "name": "Portfolio",
  },
  {
    "name": "Orders",
  },
  {
    "name": "Charts",
  },
  {
    "name": "Funds & Margin",
  },
  {
    "name": "Others",
  },
];

class MoreListClass {
  morelistGenerate(BuildContext context) {
    List<Map<String, dynamic>> moreList = [
      {
        "leading_image": "assets/icon_funds.png",
        "title": "Funds",
        "navigation": () {} //context.gNavigationService.openFundPage(context)
      },
      {
        "leading_image": "assets/user_dashbord_icon.png",
        "title": "Dashboard",
        "navigation": () =>
            context.gNavigationService.openDashBoardPage(context)
      },
      {
        "leading_image": "assets/user_alert.png",
        "title": "Alerts",
        "navigation": () =>
            context.gNavigationService.openMoreAlertsPage(context)
      },
      {
        "leading_image": "assets/icon_myapp.png",
        "title": "My Apps",
        "navigation": () => context.gNavigationService.openMyAppsPage(context)
      },
      {
        "leading_image": "assets/icon_setting.png",
        "title": "Settings",
        "navigation": () => context.gNavigationService.openSettingsPage(context)
      },
      {
        "leading_image": "assets/menu_item_calendar.png",
        "title": "Calendar",
        "navigation": () {}
      },
      {
        "leading_image": "assets/menu_item_notification.png",
        "title": "Notifications",
        "navigation": () =>
            context.gNavigationService.openNotificationPage(context)
      },
      {
        "leading_image": "assets/menu_item_marketsimulator.png",
        "title": "Market Simulator",
        "navigation": () => {
              // context.gNavigationService.openMarketSimulatorPage(context)
            }
      },
      {
        "leading_image": "assets/menu_item_help.png",
        "title": "Help",
        "navigation": () => context.gNavigationService.openHelpPage(context)
      },
      {
        "leading_image": "assets/switch_User.png",
        "title": "Switch Account",
        "navigation": () {
          // customBottomSheet(
          //   context: context,
          //   inputWidget: SwitchAccountInner(),
          // );
        }
      },
      {
        "leading_image": "assets/menu_item_logout.png",
        "title": "Logout",
        "navigation": () {
          logout(context);
        }
      }
    ];
    return moreList;
  }
}

logout(BuildContext context) async {
  watchSortMap.clear();
  await MDS_Controller().onLogout();
  UserController().allowOrderbookRequest = true;
  UserController().allowPortfolioRequest = true;
  RestartWidget.restartApp(context);
  UserController().dispose();
}

List<Map<String, dynamic>> profileActiveSegmentList1 = [
  {"name": "MF"},
  {"name": "BSE"},
  {"name": "NSE"},
];

List<Map<String, dynamic>> profileActiveSegmentList2 = [
  {"name": "MF"},
  {"name": "BSE"},
  {"name": "NSE"},
  {"name": "NFO"},
  {"name": "BFO"},
  {"name": "MCX"},
  {"name": "CDS"},
];

List<Map<String, dynamic>> profileInactiveSegmentList1 = [
  {"name": "NFO"},
  {"name": "BFO"},
  {"name": "MCX"},
  {"name": "CDS"},
];
List<Map<String, dynamic>> profileInactiveSegmentList2 = [];

List<Map<String, dynamic>> profileActiveProductList1 = [
  {"name": "MTF"},
];
List<Map<String, dynamic>> profileActiveProductList2 = [
  {"name": "MTF"},
  {"name": "BTST"},
];

List<Map<String, dynamic>> profileInactiveProductList1 = [
  {"name": "BTST"},
];
List<Map<String, dynamic>> profileInactiveProductList2 = [];

List<Map<String, dynamic>> generalnotifications = [
  {
    "name": "Equity Market Open/Close",
    // "pushStatus": UserSettings().notificationSettings.equityMarketOpenClosePush,
    // "soundStatus":
    //     UserSettings().notificationSettings.equityMarketOpenCloseSound
  },
  {
    "name": "Alerts",
    // "pushStatus": UserSettings().notificationSettings.alertsPush,
    // "soundStatus": UserSettings().notificationSettings.alertsSound
  },
  {
    "name": "Nudge",
    // "pushStatus": UserSettings().notificationSettings.nudgePush,
    // "soundStatus": UserSettings().notificationSettings.nudgeSound
  },
  {
    "name": "Security",
    // "pushStatus": UserSettings().notificationSettings.securityPush,
    // "soundStatus": UserSettings().notificationSettings.securitySound
  },
  {
    "name": "Risk Managment System",
    // "pushStatus": UserSettings().notificationSettings.riskManagmentSystemPush,
    // "soundStatus": UserSettings().notificationSettings.riskManagmentSystemSound
  },
];

List<Map<String, dynamic>> orderNotifications = [
  {
    "name": "Order Execution",
    // "pushStatus": UserSettings().notificationSettings[0]["push"],
    // "soundStatus": UserSettings().notificationSettings[0]["sound"],
  },
  {
    "name": "Review Order & Send",
    // "pushStatus": UserSettings().notificationSettings[0]["push"],
    // "soundStatus": UserSettings().notificationSettings[0]["sound"],
  },
];

List<Map<String, dynamic>> researchNotifications = [
  {
    "name": "Fundamental",
    // "pushStatus": UserSettings().notificationSettings[0]["push"],
    // "soundStatus": UserSettings().notificationSettings[0]["sound"],
  },
  {
    "name": "Technical",
    // "pushStatus": UserSettings().notificationSettings[0]["push"],
    // "soundStatus": UserSettings().notificationSettings[0]["sound"],
  },
  {
    "name": "Equity",
    // "pushStatus": UserSettings().notificationSettings[0]["push"],
    // "soundStatus": UserSettings().notificationSettings[0]["sound"],
  },
  {
    "name": "F&O",
    // "pushStatus": UserSettings().notificationSettings[0]["push"],
    // "soundStatus": UserSettings().notificationSettings[0]["sound"],
  },
  {
    "name": "Currency",
    // "pushStatus": UserSettings().notificationSettings[0]["push"],
    // "soundStatus": UserSettings().notificationSettings[0]["sound"],
  },
  {
    "name": "Commodity",
    // "pushStatus": UserSettings().notificationSettings[0]["push"],
    // "soundStatus": UserSettings().notificationSettings[0]["sound"],
  },
];

const List<Map<String, dynamic>> BondsfilterList = [
  {
    "category": "Credit Rating",
    "items": [
      {"itemName": "AAA (High Safety)", "selected": false},
      {"itemName": "AA (Balanced)", "selected": false},
      {"itemName": "A & Below (High Yield)", "selected": false}
    ]
  },
  {
    "category": "Yield",
    "items": [
      {"itemName": "Upto 8 %", "selected": false},
      {"itemName": "8 - 10%", "selected": false},
      {"itemName": "More Then 10%", "selected": false},
    ]
  },
  {
    "category": "Coupon",
    "items": [
      {"itemName": "Upto 8 %", "selected": false},
      {"itemName": "8 - 10%", "selected": false},
      {"itemName": "More Then 10%", "selected": false},
    ]
  },
  {
    "category": "Investment Ammount",
    "items": [
      {"itemName": "Less Than 5 Lacs", "selected": false},
      {"itemName": "5 - 10 Lacs", "selected": false},
      {"itemName": "10 - 50 Lacs", "selected": false},
      {"itemName": "50 Lacs And More", "selected": false},
    ]
  },
  {
    "category": "Payment Frequency",
    "items": [
      {"itemName": "Annual", "selected": false},
      {"itemName": "Monthly", "selected": false},
      {"itemName": "Quarterly", "selected": false},
      {"itemName": "Half Yearly", "selected": false},
      {"itemName": "Payment on Maturity", "selected": false},
    ]
  },
  {
    "category": "*** Investment Purpose",
    "items": [
      {"itemName": "Earn higher fixed income than FDs", "selected": false},
      {"itemName": "Get tax free returns", "selected": false},
      {"itemName": "Invest for short term", "selected": false},
      {"itemName": "Save capital gains tax", "selected": false},
      {"itemName": "Pledge for F&O", "selected": false},
      {"itemName": "Get tax exemption (HUF)", "selected": false},
      {"itemName": "Invest in NRI eligible bonds", "selected": false},
    ]
  },
  {
    "category": "*** Issuer Type",
    "items": [
      {"itemName": "State Govt guaranteed", "selected": false},
      {"itemName": "Public Sector Undertaking (Bank)", "selected": false},
      {"itemName": "Public Sector Undertaking (Others)", "selected": false},
      {"itemName": "Private Sector Bank", "selected": false},
      {"itemName": "Corporates", "selected": false},
      {"itemName": "NBFC", "selected": false},
    ]
  },
  {
    "category": "*** Asset Type",
    "items": [
      {"itemName": "Gold Bonds", "selected": false},
      {"itemName": "Goverment Bonds", "selected": false},
      {"itemName": "Corporate Bonds", "selected": false},
    ]
  },
  {
    "category": "*** Tenure Remaining",
    "items": [
      {"itemName": "Less than 1 year", "selected": false},
      {"itemName": "1-5 years", "selected": false},
      {"itemName": "5-10 years", "selected": false},
      {"itemName": "More then 10 Years", "selected": false},
    ]
  },
  {
    "category": "*** NRI Eligible",
    "items": [
      {"itemName": "Eligible for NRI", "selected": false},
      {"itemName": "Not Eligible for NRI", "selected": false},
    ]
  },
  {
    "category": "*** Issuer Mode",
    "items": [
      {"itemName": "Public placement", "selected": false},
      {"itemName": "Private placement", "selected": false},
    ]
  },
  {
    "category": "*** Face Value",
    "items": [
      {"itemName": "1000", "selected": false},
      {"itemName": "10,000", "selected": false},
      {"itemName": "1,00,000", "selected": false},
      {"itemName": "2,00,000", "selected": false},
      {"itemName": "10,00,000", "selected": false},
      {"itemName": "Above 10 Lacs", "selected": false},
    ]
  },
  {
    "category": "*** Taxation",
    "items": [
      {"itemName": "Tax Free", "selected": false},
      {"itemName": "Taxable", "selected": false},
    ]
  },
  {
    "category": "*** Bond Price Level",
    "items": [
      {"itemName": "At discount value", "selected": false},
      {"itemName": "At par value", "selected": false},
      {"itemName": "At premium value", "selected": false},
    ]
  },
  {
    "category": "*** Bank Bond Type",
    "items": [
      {"itemName": "Tier I", "selected": false},
      {"itemName": "Tier II", "selected": false},
      {"itemName": "Tier III", "selected": false},
    ]
  },
  {
    "category": "*** Seniority",
    "items": [
      {"itemName": "Seniority", "selected": false},
      {"itemName": "Subordinate", "selected": false},
    ]
  },
  {
    "category": "*** Perpetual",
    "items": [
      {"itemName": "Yes", "selected": false},
      {"itemName": "No", "selected": false},
    ]
  },
  {
    "category": "*** Call Option",
    "items": [
      {"itemName": "Yes", "selected": false},
      {"itemName": "No", "selected": false},
    ]
  }
];

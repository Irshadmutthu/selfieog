List<Map<String, dynamic>> allBondsSortList = [
  {
    "firstName": 'Min Investment',
    "secondName": "High to Low",
    "activeStatus": false
  },
  {
    "firstName": 'Min Investment',
    "secondName": "Low to High",
    "activeStatus": false
  },
  {"firstName": 'Safety', "secondName": "High to Low", "activeStatus": false},
  {"firstName": 'Safety', "secondName": "Low to High", "activeStatus": false},
  {"firstName": 'Yield', "secondName": "High to Low", "activeStatus": false},
  {"firstName": 'Yield', "secondName": "Low to High", "activeStatus": false},
  {"firstName": 'Tenure', "secondName": "High to Low", "activeStatus": false},
  {"firstName": 'Tenure', "secondName": "Low to High", "activeStatus": false},
];

List<Map<String, dynamic>> myBondsSortList = [
  {
    "firstName": 'Min Investment',
    "secondName": "High to Low",
    "activeStatus": false
  },
  {
    "firstName": 'Min Investment',
    "secondName": "Low to High",
    "activeStatus": false
  },
  {"firstName": 'Safety', "secondName": "High to Low", "activeStatus": false},
  {"firstName": 'Safety', "secondName": "Low to High", "activeStatus": false},
  {"firstName": 'Yield', "secondName": "High to Low", "activeStatus": false},
  {"firstName": 'Yield', "secondName": "Low to High", "activeStatus": false},
  {"firstName": 'Tenure', "secondName": "High to Low", "activeStatus": false},
  {"firstName": 'Tenure', "secondName": "Low to High", "activeStatus": false},
];

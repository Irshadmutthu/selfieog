List<Map<String, dynamic>> OptionChainCOntent = [
  {
    "date": "30 DEC 2021",
    "days": "10D",
    "tagname": "RESULT",
    "ivdata": "IV: 18.32",
    "tagdate": "15th Feb",
    "pldata": "(±423.95)"
  },
  {
    "date": "06 JAN 2022",
    "days": "10D",
    "tagname": "DIVIDEND",
    "ivdata": "IV: 18.32",
    "indicators": ["W", "P"],
    "tagdate": "",
    "pldata": "(±423.95)"
  },
  {
    "date": "13 JAN 2022",
    "days": "10D",
    "tagname": "SPLIT",
    "ivdata": "IV: 18.32",
    "indicators": ["W"],
    "tagdate": "15th Feb",
    "pldata": "(±423.95)"
  },
  {
    "date": "20 JAN 2022",
    "days": "10D",
    "tagname": "RESULT",
    "ivdata": "IV: 18.32",
    "indicators": ["W"],
    "tagdate": "15th Feb",
    "pldata": "(±423.95)"
  },
  {
    "date": "27 JAN 2022",
    "days": "10D",
    "tagname": "RESULT",
    "ivdata": "IV: 18.32",
    "indicators": ["W", "P"],
    "tagdate": "15th Feb",
    "pldata": "(±423.95)"
  },
  {
    "date": "03 FEB 2022",
    "days": "10D",
    "tagname": "RESULT",
    "ivdata": "IV: 18.32",
    "indicators": ["W"],
    "tagdate": "15th Feb",
    "pldata": "(±423.95)"
  },
  {
    "date": "10 FEB 2022",
    "days": "10D",
    "tagname": "RESULT",
    "ivdata": "IV: 18.32",
    "tagdate": "15th Feb",
    "pldata": "(±423.95)"
  },
  {
    "date": "17 FEB 2022",
    "days": "10D",
    "tagname": "RESULT",
    "ivdata": "IV: 18.32",
    "tagdate": "15th Feb",
    "pldata": "(±423.95)"
  }
];

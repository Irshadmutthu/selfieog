import 'package:selfie_mobile_flutter/theme/styles.dart';

List<Map<String, dynamic>> openList = [
  {
    "name": "HDFCBANK",
    "position":"BUY",
    "basket":true,
    "order_type": "INTRADAY",
    "last_update":"5mins ago",
    "status":"CONFIRMED",
    "quantity": 250,
    "total_quantity":250,
    "value":1242.17,
    "total_value":1250,
    "cash_type":"AMO-Cash",
    "market":"Lmt"
  },

  {
    "name": "SUZLON",
    "position":"SELL",
    // "basket":true,
    "order_type": "CASH",
    "last_update":"17mins ago",
    "status":"PENDING",
    "quantity": 50,
    "total_quantity":50,
    "value":7.02,
    "total_value":7.25,
    "cash_type":"OCO-Cash",
    "market":"SL-Lmt"
  },
  {
   "name": "TATAMOTORS",
    "position":"SELL",
    // "basket":true,
    "order_type": "CASH",
    "last_update":"1hr ago",
    "status":"SAVED",
    "quantity": 50,
    "total_quantity":50,
    "value":405.12,
    "total_value":510.23,
    "cash_type":"OCO-Cash",
    "market":"SL-Mkt"
  },
  {
    "name": "HDFCBANK",
    "position":"BUY",
    "basket":true,
    "order_type": "INTRADAY",
    "last_update":"5mins ago",
    "status":"CONFIRMED",
    "quantity": 250,
    "total_quantity":250,
    "value":1242.17,
    "total_value":1250,
    "cash_type":"AMO-Cash",
    "market":"Lmt"
  },

  {
    "name": "SUZLON",
    "position":"SELL",
    // "basket":true,
    "order_type": "CASH",
    "last_update":"17mins ago",
    "status":"PENDING",
    "quantity": 50,
    "total_quantity":50,
    "value":7.02,
    "total_value":7.25,
    "cash_type":"OCO-Cash",
    "market":"SL-Lmt"
  },
  {
   "name": "TATAMOTORS",
    "position":"SELL",
    // "basket":true,
    "order_type": "CASH",
    "last_update":"1hr ago",
    "status":"SAVED",
    "quantity": 50,
    "total_quantity":50,
    "value":405.12,
    "total_value":510.23,
    "cash_type":"OCO-Cash",
    "market":"SL-Mkt"
  },
  {
    "name": "HDFCBANK",
    "position":"BUY",
    "basket":true,
    "order_type": "INTRADAY",
    "last_update":"5mins ago",
    "status":"CONFIRMED",
    "quantity": 250,
    "total_quantity":250,
    "value":1242.17,
    "total_value":1250,
    "cash_type":"AMO-Cash",
    "market":"Lmt"
  },

  {
    "name": "SUZLON",
    "position":"SELL",
    // "basket":true,
    "order_type": "CASH",
    "last_update":"17mins ago",
    "status":"PENDING",
    "quantity": 50,
    "total_quantity":50,
    "value":7.02,
    "total_value":7.25,
    "cash_type":"OCO-Cash",
    "market":"SL-Lmt"
  },
  {
   "name": "TATAMOTORS",
    "position":"SELL",
    // "basket":true,
    "order_type": "CASH",
    "last_update":"1hr ago",
    "status":"SAVED",
    "quantity": 50,
    "total_quantity":50,
    "value":405.12,
    "total_value":510.23,
    "cash_type":"OCO-Cash",
    "market":"SL-Mkt"
  },
  
  
];


List<Map<String, dynamic>> closedList = [
  {
    "name": "HDFCBANK",
    "position":"BUY",
    "order_type": "INTRADAY",
    "quantity": 250,
    "total_quantity":250,
    "last_update":"5mins ago",
    "status":"EXECUTED",
    "value":1242.17,
    "market":"Lmt"
  },

  {
    "name": "TATAMOTORS",
    "position":"SELL",
    "order_type": "INTRADAY",
    "quantity": 250,
    "total_quantity":250,
    "last_update":"5mins ago",
    "status":"REJECTED",
    "value":1242.17,
    "market":"Lmt"
  },
  {
    "name": "CAMS",
    "position":"SELL",
    "order_type": "BTST",
    "quantity": 250,
    "total_quantity":250,
    "last_update":"5mins ago",
    "status":"CANCELLED",
    "value":1242.17,
    "market":"Lmt"
  },
  {
    "name": "HDFCBANK",
    "position":"BUY",
    "order_type": "INTRADAY",
    "quantity": 250,
    "total_quantity":250,
    "last_update":"5mins ago",
    "status":"PExe",
    "value":1242.17,
    "market":"Lmt"
  },
  {
    "name": "HDFCBANK",
    "position":"BUY",
    "order_type": "INTRADAY",
    "quantity": 250,
    "total_quantity":250,
    "last_update":"5mins ago",
    "status":"EXECUTED",
    "value":1242.17,
    "market":"Lmt"
  },

  {
    "name": "TATAMOTORS",
    "position":"SELL",
    "order_type": "INTRADAY",
    "quantity": 250,
    "total_quantity":250,
    "last_update":"5mins ago",
    "status":"REJECTED",
    "value":1242.17,
    "market":"Lmt"
  },
  {
    "name": "CAMS",
    "position":"SELL",
    "order_type": "BTST",
    "quantity": 250,
    "total_quantity":250,
    "last_update":"5mins ago",
    "status":"CANCELLED",
    "value":1242.17,
    "market":"Lmt"
  },
  {
    "name": "HDFCBANK",
    "position":"BUY",
    "order_type": "INTRADAY",
    "quantity": 250,
    "total_quantity":250,
    "last_update":"5mins ago",
    "status":"PExe",
    "value":1242.17,
    "market":"Lmt"
  },
  {
    "name": "HDFCBANK",
    "position":"BUY",
    "order_type": "INTRADAY",
    "quantity": 250,
    "total_quantity":250,
    "last_update":"5mins ago",
    "status":"EXECUTED",
    "value":1242.17,
    "market":"Lmt"
  },

  {
    "name": "TATAMOTORS",
    "position":"SELL",
    "order_type": "INTRADAY",
    "quantity": 250,
    "total_quantity":250,
    "last_update":"5mins ago",
    "status":"REJECTED",
    "value":1242.17,
    "market":"Lmt"
  },
  {
    "name": "CAMS",
    "position":"SELL",
    "order_type": "BTST",
    "quantity": 250,
    "total_quantity":250,
    "last_update":"5mins ago",
    "status":"CANCELLED",
    "value":1242.17,
    "market":"Lmt"
  },
  {
    "name": "HDFCBANK",
    "position":"BUY",
    "order_type": "INTRADAY",
    "quantity": 250,
    "total_quantity":250,
    "last_update":"5mins ago",
    "status":"PExe",
    "value":1242.17,
    "market":"Lmt"
  },
  
];

List<Map<String, dynamic>> gtdList = [
  {
    "name": "HDFCBANK",
    "position":"BUY",
    "OrderType": "CASH",
    "quantity": 230,
    "date":"22/03/22",
    // "amo":"amo",
    "status":"ACTIVE",
    "market":"LTP",
    "market_value":1324.98,
    "value":1200.09,
    "total_value":1498.12,

    
  },

  {
    "name": "TCS",
    "position":"BUY",
    "OrderType": "CASH",
    "quantity": 230,
    "date":"22/03/22",
    "amo":"AMO",
    "status":"ACTIVE",
    "market":"LTP",
    "market_value":1324.98,
    "value":1200.09,
    "total_value":1498.12,


   
  },
  {
    "name": "HDFCBANK",
    "position":"BUY",
    "OrderType": "CASH",
    "quantity": 230,
    "date":"22/03/22",
    // "amo":"amo",
    "status":"ACTIVE",
    "market":"LTP",
    "market_value":1324.98,
    "value":1200.09,
    "total_value":1498.12,

    
  },

  {
    "name": "TCS",
    "position":"BUY",
    "OrderType": "CASH",
    "quantity": 230,
    "date":"22/03/22",
    "amo":"AMO",
    "status":"ACTIVE",
    "market":"LTP",
    "market_value":1324.98,
    "value":1200.09,
    "total_value":1498.12,


   
  },
  {
    "name": "HDFCBANK",
    "position":"BUY",
    "OrderType": "CASH",
    "quantity": 230,
    "date":"22/03/22",
    // "amo":"amo",
    "status":"ACTIVE",
    "market":"LTP",
    "market_value":1324.98,
    "value":1200.09,
    "total_value":1498.12,

    
  },

  {
    "name": "TCS",
    "position":"BUY",
    "OrderType": "CASH",
    "quantity": 230,
    "date":"22/03/22",
    "amo":"AMO",
    "status":"ACTIVE",
    "market":"LTP",
    "market_value":1324.98,
    "value":1200.09,
    "total_value":1498.12,


   
  },
  {
    "name": "HDFCBANK",
    "position":"BUY",
    "OrderType": "CASH",
    "quantity": 230,
    "date":"22/03/22",
    // "amo":"amo",
    "status":"ACTIVE",
    "market":"LTP",
    "market_value":1324.98,
    "value":1200.09,
    "total_value":1498.12,

    
  },

  {
    "name": "TCS",
    "position":"BUY",
    "OrderType": "CASH",
    "quantity": 230,
    "date":"22/03/22",
    "amo":"AMO",
    "status":"ACTIVE",
    "market":"LTP",
    "market_value":1324.98,
    "value":1200.09,
    "total_value":1498.12,


   
  },
  {
    "name": "HDFCBANK",
    "position":"BUY",
    "OrderType": "CASH",
    "quantity": 230,
    "date":"22/03/22",
    // "amo":"amo",
    "status":"ACTIVE",
    "market":"LTP",
    "market_value":1324.98,
    "value":1200.09,
    "total_value":1498.12,

    
  },

  {
    "name": "TCS",
    "position":"BUY",
    "OrderType": "CASH",
    "quantity": 230,
    "date":"22/03/22",
    "amo":"AMO",
    "status":"ACTIVE",
    "market":"LTP",
    "market_value":1324.98,
    "value":1200.09,
    "total_value":1498.12,


   
  },
  {
    "name": "HDFCBANK",
    "position":"BUY",
    "OrderType": "CASH",
    "quantity": 230,
    "date":"22/03/22",
    // "amo":"amo",
    "status":"ACTIVE",
    "market":"LTP",
    "market_value":1324.98,
    "value":1200.09,
    "total_value":1498.12,

    
  },

  {
    "name": "TCS",
    "position":"BUY",
    "OrderType": "CASH",
    "quantity": 230,
    "date":"22/03/22",
    "amo":"AMO",
    "status":"ACTIVE",
    "market":"LTP",
    "market_value":1324.98,
    "value":1200.09,
    "total_value":1498.12,


   
  },
  
];

List<Map<String, dynamic>> basketList = [
  {
    "name": "Trial Basket",
    "date":"09/12/22",
    "value":0,
    "total_value":25,
  },
  {
    "name": "Tech Stocks 2022",
    "date":"09/12/22",
    "value":17,
    "total_value":25,
  },
  {
    "name": "Smallcap Banking Stock",
    "date":"09/12/22",
    "value":12,
    "total_value":25,
  },
  {
    "name": "Trial Basket",
    "date":"09/12/22",
    "value":0,
    "total_value":25,
  },
  {
    "name": "Tech Stocks 2022",
    "date":"09/12/22",
    "value":17,
    "total_value":25,
  },
  {
    "name": "Smallcap Banking Stock",
    "date":"09/12/22",
    "value":12,
    "total_value":25,
  },
  {
    "name": "Trial Basket",
    "date":"09/12/22",
    "value":0,
    "total_value":25,
  },
  {
    "name": "Tech Stocks 2022",
    "date":"09/12/22",
    "value":17,
    "total_value":25,
  },
  {
    "name": "Smallcap Banking Stock",
    "date":"09/12/22",
    "value":12,
    "total_value":25,
  },
  {
    "name": "Trial Basket",
    "date":"09/12/22",
    "value":0,
    "total_value":25,
  },
  {
    "name": "Tech Stocks 2022",
    "date":"09/12/22",
    "value":17,
    "total_value":25,
  },
  {
    "name": "Smallcap Banking Stock",
    "date":"09/12/22",
    "value":12,
    "total_value":25,
  },
  {
    "name": "Trial Basket",
    "date":"09/12/22",
    "value":0,
    "total_value":25,
  },
  {
    "name": "Tech Stocks 2022",
    "date":"09/12/22",
    "value":17,
    "total_value":25,
  },
  {
    "name": "Smallcap Banking Stock",
    "date":"09/12/22",
    "value":12,
    "total_value":25,
  },

  
];

List<Map<String, dynamic>> smartfolioList = [
  {
    "name": "24 K",
    "icon":"",
    "aprox_amt":10000,
    "date":"28/10/22"
  },
  {
    "name": "Ace",
    "icon":"",
    "aprox_amt":10000,
    "date":"28/10/22"
  },
  {
    "name": "24 K",
    "icon":"",
    "aprox_amt":10000,
    "date":"28/10/22"
  },
  {
    "name": "Ace",
    "icon":"",
    "aprox_amt":10000,
    "date":"28/10/22"
  },
  {
    "name": "24 K",
    "icon":"",
    "aprox_amt":10000,
    "date":"28/10/22"
  },
  {
    "name": "Ace",
    "icon":"",
    "aprox_amt":10000,
    "date":"28/10/22"
  },
  {
    "name": "24 K",
    "icon":"",
    "aprox_amt":10000,
    "date":"28/10/22"
  },
  {
    "name": "Ace",
    "icon":"",
    "aprox_amt":10000,
    "date":"28/10/22"
  },
  {
    "name": "24 K",
    "icon":"",
    "aprox_amt":10000,
    "date":"28/10/22"
  },
  {
    "name": "Ace",
    "icon":"",
    "aprox_amt":10000,
    "date":"28/10/22"
  },
  {
    "name": "24 K",
    "icon":"",
    "aprox_amt":10000,
    "date":"28/10/22"
  },
  {
    "name": "Ace",
    "icon":"",
    "aprox_amt":10000,
    "date":"28/10/22"
  },
  {
    "name": "24 K",
    "icon":"",
    "aprox_amt":10000,
    "date":"28/10/22"
  },
  {
    "name": "Ace",
    "icon":"",
    "aprox_amt":10000,
    "date":"28/10/22"
  },
];


import 'package:selfie_mobile_flutter/model/watch_sort_model.dart';

List<Map<String, dynamic>> myWatchListItems = [
  {
    "Name": "Swing Monday",
    "properties": {"selected": true, "enabled": true}
  },
  {
    "Name": "Intraday Wednesday",
    "properties": {"selected": false, "enabled": true}
  },
  {
    "Name": "Option January",
    "properties": {"selected": false, "enabled": true}
  },
  {
    "Name": "Future Infosys",
    "properties": {"selected": false, "enabled": true}
  },
  {
    "Name": "Long term watchlist",
    "properties": {"selected": false, "enabled": true}
  },
  {
    "Name": "Tech Stocks 2022",
    "properties": {"selected": false, "enabled": true}
  },
  {
    "Name": "Sugar Stocks",
    "properties": {"selected": false, "enabled": true}
  },
];

List<Map<String, dynamic>> presetWatchListItems = [
  {
    "Name": "Sensex",
    "properties": {"selected": true, "enabled": true}
  },
  {
    "Name": "Nifty 50",
    "properties": {"selected": false, "enabled": true}
  },
  {
    "Name": "Nifty Next 50",
    "properties": {"selected": false, "enabled": true}
  },
  {
    "Name": "Nifty Auto",
    "properties": {"selected": false, "enabled": true}
  },
  {
    "Name": "Nifty Pharma",
    "properties": {"selected": false, "enabled": false}
  },
  {
    "Name": "Midcap 100",
    "properties": {"selected": false, "enabled": true}
  },
  {
    "Name": "Smallcap 100",
    "properties": {"selected": false, "enabled": true}
  },
  {
    "Name": "Nifty 100",
    "properties": {"selected": false, "enabled": false}
  },
  {
    "Name": "Nifty 150",
    "properties": {"selected": false, "enabled": false}
  },
  {
    "Name": "Nifty 200",
    "properties": {"selected": false, "enabled": false}
  },
];

// List<Map<String, dynamic>> indicesList = [
//   {
//     "dataHeadding": "NIFTY",
//     "value": 18235,
//     "margin": 1.50,
//   },
//   {"dataHeadding": "BANKNIFTY", "value": 37916, "margin": 4.12}
// ];
// Map<String, int>  {}
// int currentindex = -1;

Map<String, WatchSortModel> watchSortMap = {};
List<Map<String, dynamic>> watchlistContent = [
  {
    "name": "TATA MOTORS",
    "value": 404.12,
    "NSEBSE": "NSE",
    "BONUS": "BONUS",
    "BONUSCOLOR": 0xff9768E1,
    // "HOLDORRELEASE": "HOLD",
    "value2": "+12",
    "margin": "+1.50",
  },
  {
    "name": "KPITTECH",
    "value": -642.45,
    "NSEBSE": "NSE",
    "BONUS": "DIVIDENT",
    "BONUSCOLOR": 0xffE7A640,
    "HOLDORRELEASE": "HOLD",
    "value2": "-20.23",
    "margin": "-4.32",
    // "weekly": true,
    // "month": "JAN",
    // "callput": "PE",
    // "monthValue": 37700
  },
  {
    "name": "BANKNIFTY",
    "value": -345.33,
    "NSEBSE": "NFO",
    // "BONUS": "DIVIDENT",
    // "BONUSCOLOR": 0xffE7A640,
    // "HOLDORRELEASE": "HOLD",
    "value2": "+109.23",
    "margin": "+123.76",
    "weekly": true,
    "month": "JAN",
    "callput": "PE",
    "monthValue": 37700
  },
  {
    "name": "TRENT",
    "value": 1098.13,
    "NSEBSE": "BSE",
    "BONUS": "BUY",
    "BONUSCOLOR": 0xff0BAA60,
    // "HOLDORRELEASE": "HOLD",
    "value2": "+32.32",
    "margin": "+7.55",
    // "weekly": true,
    // "month": "JAN",
    // "callput": "PE",
    // "monthValue": 37700
  },
  {
    "name": "SUZLON",
    "value": -7.45,
    "NSEBSE": "NSE",
    // "BONUS": "BUY",
    // "BONUSCOLOR": 0xff0BAA60,
    // "HOLDORRELEASE": "HOLD",
    "value2": "-0.22",
    "margin": "-3.88",
    // "weekly": true,
    // "month": "JAN",
    // "callput": "PE",
    // "monthValue": 37700
  },
  {
    "name": "HDFC BANK",
    "value": 1678,
    "NSEBSE": "NSE",
    "BONUS": "SPLIT",
    "BONUSCOLOR": 0xff0395BE,
    // "HOLDORRELEASE": "HOLD",
    "value2": "-0.22",
    "margin": "-3.88",
    // "weekly": true,
    // "month": "JAN",
    // "callput": "PE",
    // "monthValue": 37700
  },
  {
    "name": "TATA MOTORS",
    "value": 404.12,
    "NSEBSE": "NSE",
    "BONUS": "BONUS",
    "BONUSCOLOR": 0xff9768E1,
    // "HOLDORRELEASE": "HOLD",
    "value2": "+12",
    "margin": "+1.50",
  },
  {
    "name": "KPITTECH",
    "value": -642.45,
    "NSEBSE": "NSE",
    "BONUS": "DIVIDENT",
    "BONUSCOLOR": 0xffE7A640,
    "HOLDORRELEASE": "HOLD",
    "value2": "-20.23",
    "margin": "-4.32",
    // "weekly": true,
    // "month": "JAN",
    // "callput": "PE",
    // "monthValue": 37700
  },
  {
    "name": "BANKNIFTY",
    "value": -345.33,
    "NSEBSE": "NFO",
    // "BONUS": "DIVIDENT",
    // "BONUSCOLOR": 0xffE7A640,
    // "HOLDORRELEASE": "HOLD",
    "value2": "+109.23",
    "margin": "+123.76",
    "weekly": true,
    "month": "JAN",
    "callput": "PE",
    "monthValue": 37700
  },
  {
    "name": "TRENT",
    "value": 1098.13,
    "NSEBSE": "BSE",
    "BONUS": "BUY",
    "BONUSCOLOR": 0xff0BAA60,
    // "HOLDORRELEASE": "HOLD",
    "value2": "+32.32",
    "margin": "+7.55",
    // "weekly": true,
    // "month": "JAN",
    // "callput": "PE",
    // "monthValue": 37700
  },
  {
    "name": "SUZLON",
    "value": -7.45,
    "NSEBSE": "NSE",
    // "BONUS": "BUY",
    // "BONUSCOLOR": 0xff0BAA60,
    // "HOLDORRELEASE": "HOLD",
    "value2": "-0.22",
    "margin": "-3.88",
    // "weekly": true,
    // "month": "JAN",
    // "callput": "PE",
    // "monthValue": 37700
  },
  {
    "name": "BANKNIFTY",
    "value": -345.33,
    "NSEBSE": "NFO",
    // "BONUS": "DIVIDENT",
    // "BONUSCOLOR": 0xffE7A640,
    // "HOLDORRELEASE": "HOLD",
    "value2": "+109.23",
    "margin": "+123.76",
    "weekly": true,
    "month": "JAN",
    "callput": "PE",
    "monthValue": 37700
  },
  {
    "name": "TRENT",
    "value": 1098.13,
    "NSEBSE": "BSE",
    "BONUS": "BUY",
    "BONUSCOLOR": 0xff0BAA60,
    // "HOLDORRELEASE": "HOLD",
    "value2": "+32.32",
    "margin": "+7.55",
    // "weekly": true,
    // "month": "JAN",
    // "callput": "PE",
    // "monthValue": 37700
  },
  {
    "name": "SUZLON",
    "value": -7.45,
    "NSEBSE": "NSE",
    // "BONUS": "BUY",
    // "BONUSCOLOR": 0xff0BAA60,
    // "HOLDORRELEASE": "HOLD",
    "value2": "-0.22",
    "margin": "-3.88",
    // "weekly": true,
    // "month": "JAN",
    // "callput": "PE",
    // "monthValue": 37700
  },
];

List<Map<String, dynamic>> watchContent = [
  {
    "name": "TATA MOTORS",
    "value": 404.12,
    "NSEBSE": "NSE",
    "BONUS": "BONUS",
    "BONUSCOLOR": 0xff9768E1,
    // "HOLDORRELEASE": "HOLD",
    "value2": "+12",
    "margin": "+1.50",
  },
  {
    "name": "KPITTECH",
    "value": -642.45,
    "NSEBSE": "NSE",
    "BONUS": "DIVIDENT",
    "BONUSCOLOR": 0xffE7A640,
    "HOLDORRELEASE": "HOLD",
    "value2": "-20.23",
    "margin": "-4.32",
    // "weekly": true,
    // "month": "JAN",
    // "callput": "PE",
    // "monthValue": 37700
  },
  {
    "name": "BANKNIFTY",
    "value": -345.33,
    "NSEBSE": "NFO",
    // "BONUS": "DIVIDENT",
    // "BONUSCOLOR": 0xffE7A640,
    // "HOLDORRELEASE": "HOLD",
    "value2": "+109.23",
    "margin": "+123.76",
    "weekly": true,
    "month": "JAN",
    "callput": "PE",
    "monthValue": 37700
  },
  {
    "name": "TRENT",
    "value": 1098.13,
    "NSEBSE": "BSE",
    "BONUS": "BUY",
    "BONUSCOLOR": 0xff0BAA60,
    // "HOLDORRELEASE": "HOLD",
    "value2": "+32.32",
    "margin": "+7.55",
    // "weekly": true,
    // "month": "JAN",
    // "callput": "PE",
    // "monthValue": 37700
  },
  {
    "name": "SUZLON",
    "value": -7.45,
    "NSEBSE": "NSE",
    // "BONUS": "BUY",
    // "BONUSCOLOR": 0xff0BAA60,
    // "HOLDORRELEASE": "HOLD",
    "value2": "-0.22",
    "margin": "-3.88",
    // "weekly": true,
    // "month": "JAN",
    // "callput": "PE",
    // "monthValue": 37700
  },
  {
    "name": "HDFC BANK",
    "value": 1678,
    "NSEBSE": "NSE",
    "BONUS": "SPLIT",
    "BONUSCOLOR": 0xff0395BE,
    // "HOLDORRELEASE": "HOLD",
    "value2": "-0.22",
    "margin": "-3.88",
    // "weekly": true,
    // "month": "JAN",
    // "callput": "PE",
    // "monthValue": 37700
  },
  {
    "name": "TATA MOTORS",
    "value": 404.12,
    "NSEBSE": "NSE",
    "BONUS": "BONUS",
    "BONUSCOLOR": 0xff9768E1,
    // "HOLDORRELEASE": "HOLD",
    "value2": "+12",
    "margin": "+1.50",
  },
  {
    "name": "KPITTECH",
    "value": -642.45,
    "NSEBSE": "NSE",
    "BONUS": "DIVIDENT",
    "BONUSCOLOR": 0xffE7A640,
    "HOLDORRELEASE": "HOLD",
    "value2": "-20.23",
    "margin": "-4.32",
    // "weekly": true,
    // "month": "JAN",
    // "callput": "PE",
    // "monthValue": 37700
  },
  {
    "name": "BANKNIFTY",
    "value": -345.33,
    "NSEBSE": "NFO",
    // "BONUS": "DIVIDENT",
    // "BONUSCOLOR": 0xffE7A640,
    // "HOLDORRELEASE": "HOLD",
    "value2": "+109.23",
    "margin": "+123.76",
    "weekly": true,
    "month": "JAN",
    "callput": "PE",
    "monthValue": 37700
  },
  {
    "name": "TRENT",
    "value": 1098.13,
    "NSEBSE": "BSE",
    "BONUS": "BUY",
    "BONUSCOLOR": 0xff0BAA60,
    // "HOLDORRELEASE": "HOLD",
    "value2": "+32.32",
    "margin": "+7.55",
    // "weekly": true,
    // "month": "JAN",
    // "callput": "PE",
    // "monthValue": 37700
  },
  {
    "name": "SUZLON",
    "value": -7.45,
    "NSEBSE": "NSE",
    // "BONUS": "BUY",
    // "BONUSCOLOR": 0xff0BAA60,
    // "HOLDORRELEASE": "HOLD",
    "value2": "-0.22",
    "margin": "-3.88",
    // "weekly": true,
    // "month": "JAN",
    // "callput": "PE",
    // "monthValue": 37700
  },
  {
    "name": "BANKNIFTY",
    "value": -345.33,
    "NSEBSE": "NFO",
    // "BONUS": "DIVIDENT",
    // "BONUSCOLOR": 0xffE7A640,
    // "HOLDORRELEASE": "HOLD",
    "value2": "+109.23",
    "margin": "+123.76",
    "weekly": true,
    "month": "JAN",
    "callput": "PE",
    "monthValue": 37700
  },
  {
    "name": "TRENT",
    "value": 1098.13,
    "NSEBSE": "BSE",
    "BONUS": "BUY",
    "BONUSCOLOR": 0xff0BAA60,
    // "HOLDORRELEASE": "HOLD",
    "value2": "+32.32",
    "margin": "+7.55",
    // "weekly": true,
    // "month": "JAN",
    // "callput": "PE",
    // "monthValue": 37700
  },
  {
    "name": "SUZLON",
    "value": -7.45,
    "NSEBSE": "NSE",
    // "BONUS": "BUY",
    // "BONUSCOLOR": 0xff0BAA60,
    // "HOLDORRELEASE": "HOLD",
    "value2": "-0.22",
    "margin": "-3.88",
    // "weekly": true,
    // "month": "JAN",
    // "callput": "PE",
    // "monthValue": 37700
  },
];

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/utils/shimmer_loader.dart';

class AllBondsShimmerLoader extends StatelessWidget {
  const AllBondsShimmerLoader({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return ListView.builder(
      itemBuilder: (context, index) => Padding(
        padding: const EdgeInsets.only(
          left: 16,
          right: 16,
          bottom: 12,
        ),
        child: Container(
          padding: EdgeInsets.only(
              left: screenSize.width * .033,
              right: screenSize.width * .033,
              top: 16,
              bottom: 20),
          decoration: BoxDecoration(
              border: Border.all(color: customColors().backgroundTertiary),
              borderRadius: BorderRadius.circular(4)),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        ShimmerLoader(
                            height: screenSize.height * .04,
                            width: screenSize.width * .08),
                        Padding(
                            padding: const EdgeInsets.only(left: 20, right: 13),
                            child: ShimmerLoader(
                                height: screenSize.height * .04,
                                width: screenSize.width * .4))
                      ],
                    ),
                    ShimmerLoader(
                        height: screenSize.height * .02,
                        width: screenSize.width * .1)
                  ],
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(bottom: 2),
                        child: ShimmerLoader(
                            height: 16.0, width: screenSize.width * .075),
                      ),
                      ShimmerLoader(
                          height: 16.0, width: screenSize.width * .11),
                      SizedBox(
                        height: screenSize.height * .025,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 2),
                        child: ShimmerLoader(
                            height: 16.0, width: screenSize.width * .125),
                      ),
                      ShimmerLoader(
                          height: 16.0, width: screenSize.width * .077),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(bottom: 2),
                        child: ShimmerLoader(
                            height: 16.0, width: screenSize.width * .075),
                      ),
                      ShimmerLoader(
                          height: 16.0, width: screenSize.width * .11),
                      SizedBox(
                        height: screenSize.height * .025,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 2),
                        child: ShimmerLoader(
                            height: 16.0, width: screenSize.width * .125),
                      ),
                      ShimmerLoader(
                          height: 16.0, width: screenSize.width * .07),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(bottom: 2),
                        child: ShimmerLoader(
                            height: 16.0, width: screenSize.width * .075),
                      ),
                      ShimmerLoader(
                          height: 16.0, width: screenSize.width * .11),
                      SizedBox(
                        height: screenSize.height * .025,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 2),
                        child: ShimmerLoader(
                            height: 16.0, width: screenSize.width * .125),
                      ),
                      ShimmerLoader(
                          height: 16.0, width: screenSize.width * .07),
                    ],
                  ),
                ],
              )
            ],
          ),
        ),
      ),
      itemCount: 5,
    );
  }
}

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:selfie_mobile_flutter/model/bond_details_overview_model.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_profile/profile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_top_tab.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/utils/shimmer_loader.dart';

class BondDetailsShimmer extends StatelessWidget {
  BondDetailsShimmer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: Column(
        children: [
          CustomAppBarInner(
              title: "Bond Details",
              onBackPressed: () {
                // context.gNavigationService.back(context);
              }),

          Container(
            color: customColors().backgroundSecondary,
            child: Padding(
              padding: const EdgeInsets.only(
                left: 16,
              ),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 20, bottom: 20),
                    child: Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(right: 16),
                          child: ShimmerLoader(height: 40, width: 40),
                        ),
                        ShimmerLoader(height: 40, width: 230),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  ShimmerLoader(height: 18, width: 60),
                                  ShimmerLoader(height: 20, width: 69),
                                ],
                              ),
                            ),
                            Container(
                              width: screenSize.width * .45,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  ShimmerLoader(height: 18, width: 23),
                                  ShimmerLoader(height: 20, width: 101),
                                ],
                              ),
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          //  Text("container"),
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 8.0),
                  child:
                      ShimmerLoader(height: 30, width: screenSize.width * .2),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0),
                  child:
                      ShimmerLoader(height: 30, width: screenSize.width * .2),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0),
                  child:
                      ShimmerLoader(height: 30, width: screenSize.width * .2),
                ),
              ],
            ),
          ),

          Padding(
            padding:
                const EdgeInsets.only(top: 20, bottom: 20, left: 16, right: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                ShimmerLoader(height: 40, width: screenSize.width * .55),
                Expanded(child: SizedBox()),
                ShimmerLoader(height: 22, width: screenSize.width * .1),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  overviewShimmerDesign(
                      titleWidth: screenSize.width * .35,
                      valueWidth: screenSize.width * .2),
                  overviewShimmerDesign(
                      titleWidth: screenSize.width * .239,
                      valueWidth: screenSize.width * .2),
                  overviewShimmerDesign(
                      titleWidth: screenSize.width * .35,
                      valueWidth: screenSize.width * .2),
                  overviewShimmerDesign(
                      titleWidth: screenSize.width * .35,
                      valueWidth: screenSize.width * .2),
                  overviewShimmerDesign(
                      titleWidth: screenSize.width * .25,
                      valueWidth: screenSize.width * .2),
                  overviewShimmerDesign(
                      titleWidth: screenSize.width * .328,
                      valueWidth: screenSize.width * .2),
                  overviewShimmerDesign(
                      titleWidth: screenSize.width * .427,
                      valueWidth: screenSize.width * .2),
                  overviewShimmerDesign(
                      titleWidth: screenSize.width * .35,
                      valueWidth: screenSize.width * .2),
                  overviewShimmerDesign(
                      titleWidth: screenSize.width * .25,
                      valueWidth: screenSize.width * .2),
                  overviewShimmerDesign(
                      titleWidth: screenSize.width * .188,
                      valueWidth: screenSize.width * .2),
                  overviewShimmerDesign(
                      titleWidth: screenSize.width * .5,
                      valueWidth: screenSize.width * .2),
                  overviewShimmerDesign(
                      titleWidth: screenSize.width * .38,
                      valueWidth: screenSize.width * .2),
                  overviewShimmerDesign(
                      titleWidth: screenSize.width * .5,
                      valueWidth: screenSize.width * .2),
                  overviewShimmerDesign(
                      titleWidth: screenSize.width * .5,
                      valueWidth: screenSize.width * .2),
                ],
              ),
            ),
          ),

          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CustomDividerWithPadding(
                horizondalPadding: 0,
              ),
              Padding(
                padding: const EdgeInsets.only(
                    left: 16, right: 16, top: 12, bottom: 12),
                child: ShimmerLoader(height: 48, width: screenSize.width),
              ),
            ],
          )
        ],
      ),
    );
  }
}

class overviewShimmerDesign extends StatelessWidget {
  overviewShimmerDesign({
    required this.titleWidth,
    required this.valueWidth,
    Key? key,
  }) : super(key: key);
  double titleWidth;
  double valueWidth;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 16, right: 16, bottom: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          ShimmerLoader(height: 15, width: titleWidth),
          ShimmerLoader(height: 15, width: valueWidth),
        ],
      ),
    );
  }
}

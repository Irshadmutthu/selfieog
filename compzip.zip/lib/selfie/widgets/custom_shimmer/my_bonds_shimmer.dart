import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_profile/profile.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/utils/shimmer_loader.dart';

class MyBondsShimmerLoader extends StatelessWidget {
  const MyBondsShimmerLoader({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return ListView.builder(
      itemBuilder: (context, index) => Padding(
        padding: const EdgeInsets.only(
          left: 16,
          right: 16,
          bottom: 12,
        ),
        child: Container(
          decoration: BoxDecoration(
              border: Border.all(color: customColors().backgroundTertiary),
              borderRadius: BorderRadius.circular(4)),
          child: Column(children: [
            Padding(
              padding: EdgeInsets.only(
                  left: screenSize.width * .033,
                  right: screenSize.width * .033,
                  top: 16,
                  bottom: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      ShimmerLoader(
                          height: screenSize.height * .04,
                          width: screenSize.width * .08),
                      Padding(
                        padding: const EdgeInsets.only(
                          left: 20,
                        ),
                        child: ShimmerLoader(
                            height: screenSize.height * .04,
                            width: screenSize.width * .41),
                      )
                    ],
                  ),
                  ShimmerLoader(
                      height: screenSize.height * .02,
                      width: screenSize.width * .1),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                  left: screenSize.width * .033,
                  right: screenSize.width * .033,
                  bottom: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(bottom: 2),
                        child: ShimmerLoader(
                            height: 16.0, width: screenSize.width * .075),
                      ),
                      ShimmerLoader(
                          height: 16.0, width: screenSize.width * .11),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(bottom: 2),
                        child: ShimmerLoader(
                            height: 16.0, width: screenSize.width * .075),
                      ),
                      ShimmerLoader(
                          height: 16.0, width: screenSize.width * .11),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(bottom: 2),
                        child: ShimmerLoader(
                            height: 16.0, width: screenSize.width * .075),
                      ),
                      ShimmerLoader(
                          height: 16.0, width: screenSize.width * .11),
                    ],
                  )
                ],
              ),
            ),
            CustomDividerWithPadding(horizondalPadding: 0),
            Padding(
              padding: EdgeInsets.only(
                  left: screenSize.width * .033,
                  right: screenSize.width * .033,
                  top: 4,
                  bottom: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(bottom: 2),
                        child: ShimmerLoader(
                            height: 16.0, width: screenSize.width * .075),
                      ),
                      ShimmerLoader(
                          height: 16.0, width: screenSize.width * .11),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(bottom: 2),
                        child: ShimmerLoader(
                            height: 16.0, width: screenSize.width * .075),
                      ),
                      ShimmerLoader(
                          height: 16.0, width: screenSize.width * .11),
                    ],
                  )
                ],
              ),
            ),
          ]),
        ),
      ),
      itemCount: 5,
    );
  }
}

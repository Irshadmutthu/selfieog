import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/enums.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/portfolio_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_bottom_sheet/custom_filter_tab.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_bottom_sheet/custom_sort_tab.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SortFilterResetBottomSheet extends StatefulWidget {
  SortFilterLocation? selectedLocation;
  int? selectedTabIndex;
  void Function(int, int, bool) onPressFilter;
  final void Function(int index)? onPressSort;
  int selectedSortIndex;
  final void Function() onPressReset;
  final bool resetStatus;
  List<String>? filterarrayposition = [];
  List<Map<String, dynamic>> sortList;
  List<Map<String, dynamic>> filterList;
  SortFilterResetBottomSheet(
      {Key? key,
      this.selectedTabIndex = 0,
      this.selectedLocation,
      required this.onPressFilter,
      required this.onPressReset,
      this.onPressSort,
      this.filterarrayposition,
      this.resetStatus = false,
      this.sortList = const [],
      this.filterList = const [],
      this.selectedSortIndex = 0})
      : super(key: key);

  @override
  State<SortFilterResetBottomSheet> createState() =>
      _SortFilterResetBottomSheetState();
}

class _SortFilterResetBottomSheetState extends State<SortFilterResetBottomSheet>
    with SingleTickerProviderStateMixin {
  final List<Tab> myTabs = const <Tab>[
    Tab(text: 'Sort'),
    Tab(text: 'Filters'),
  ];
  // int selectedTabIndex = 0;
  List<Widget> tabbarViewList = [];
  late final TabController _tabController =
      TabController(length: myTabs.length, vsync: this);

  @override
  void initState() {
    super.initState();
    setState(() {
      _tabController.index = widget.selectedTabIndex!;
      widget.selectedTabIndex = widget.selectedTabIndex!;
    });
  }

  @override
  Widget build(BuildContext context) {
    tabbarViewList = [
      BondsSortTab(
        onSortpress: widget.onPressSort,
        currentval: widget.selectedSortIndex,
        sortList: widget.sortList,
      ),
      BondsFilterTab(
        onfilterpress: widget.onPressFilter,
        filterList: widget.filterList,
      ),
    ];

    return DefaultTabController(
        length: myTabs.length,
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  child: TabBar(
                      controller: _tabController,
                      isScrollable: true,
                      indicatorPadding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 0),
                      onTap: (index) {
                        setState(() {
                          widget.selectedTabIndex = index;
                        });
                      },
                      unselectedLabelStyle: customTextStyle(
                          fontStyle: FontStyle.BodyL_Regular,
                          color: FontColor.FontSecondary),
                      unselectedLabelColor: customColors().fontSecondary,
                      indicatorColor: customColors().primary,
                      indicatorSize: TabBarIndicatorSize.tab,
                      indicatorWeight: 2,
                      labelColor: customColors().primary,
                      tabs: myTabs),
                ),
                Visibility(
                  visible: widget.resetStatus,
                  child: Padding(
                    padding: const EdgeInsets.only(right: 16.0),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: InkWell(
                        onTap: () {
                          setState(() {
                            sortval = "All";
                          });
                          widget.onPressReset();
                        },
                        child: Text(
                          "Reset",
                          style: customTextStyle(
                            fontStyle: FontStyle.BodyL_SemiBold,
                            color: FontColor.Primary,
                          ).copyWith(color: customColors().primary),
                        ),
                      ),
                    ),
                  ),
                )
              ],
            ),
            tabbarViewList[widget.selectedTabIndex!],
          ],
        ));
  }
}

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_check_box/custom_check_box.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class BondsFilterTab extends StatefulWidget {
  final void Function(int, int, bool) onfilterpress;
  List<String>? filterarrayposition;
  List<Map<String, dynamic>> filterList;
  BondsFilterTab(
      {Key? key,
      required this.onfilterpress,
      this.filterarrayposition = const [],
      required this.filterList})
      : super(key: key);

  @override
  State<BondsFilterTab> createState() => _BondsFilterTabState();
}

class _BondsFilterTabState extends State<BondsFilterTab> {
  bool flag = false;

  int _selectedCategory = 0;

  final ScrollController scrollController = ScrollController();

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Divider(
          height: 0,
          thickness: 1,
          color: customColors().backgroundTertiary,
        ),
        Container(
            height: (screenSize.height * .505),
            child: Row(
              children: [
                SingleChildScrollView(
                  controller: scrollController,
                  child: RawScrollbar(
                    thumbColor: customColors().silverDust,
                    controller: scrollController,
                    thumbVisibility: true,
                    interactive: true,
                    thickness: 6,
                    radius: Radius.circular(4),
                    child: Column(
                      children: List.generate(
                        widget.filterList.length,
                        (index) => InkWell(
                          onTap: () => setState(() {
                            _selectedCategory = index;
                          }),
                          child: Container(
                              alignment: Alignment.centerLeft,
                              color: (_selectedCategory == index)
                                  ? customColors().backgroundSecondary
                                  : customColors().backgroundPrimary,
                              padding: EdgeInsets.symmetric(horizontal: 12),
                              width: screenSize.width * .33,
                              height: 48,
                              child: Text(
                                widget.filterList[index]["category"],
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_SemiBold,
                                    color: FontColor.FontPrimary),
                              )),
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: (widget.filterList.isEmpty)
                      ? Container()
                      : Container(
                          color: customColors().backgroundSecondary,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: List.generate(
                                widget.filterList[_selectedCategory]["items"]
                                    .length,
                                (itemIndex) => Padding(
                                      padding: const EdgeInsets.only(
                                        left: 16,
                                        right: 23,
                                        top: 14,
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                right: 13),
                                            child: CustomCustomCheckBox(
                                              isSelect: widget.filterList[
                                                          _selectedCategory]
                                                      ["items"][itemIndex]
                                                  ["selected"],
                                              onCheckPress: (bool val) {
                                                widget.onfilterpress(
                                                    _selectedCategory,
                                                    itemIndex,
                                                    val);
                                                setState(() {});
                                              },
                                            ),
                                          ),
                                          Expanded(
                                            child: Text(
                                                widget
                                                                .filterList[
                                                            _selectedCategory]
                                                        ["items"][itemIndex]
                                                    ["itemName"],
                                                style: customTextStyle(
                                                    fontStyle: FontStyle
                                                        .BodyM_SemiBold,
                                                    color:
                                                        FontColor.FontPrimary)),
                                          ),
                                        ],
                                      ),
                                    )),
                          ),
                        ),
                )
              ],
            )),
      ],
    );
  }
}

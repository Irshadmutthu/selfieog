import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/custom_radio_button.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class BondsSortTab extends StatefulWidget {
  final void Function(int)? onSortpress;
  int? currentval;
  List<Map<String, dynamic>> sortList;

  BondsSortTab(
      {Key? key, this.onSortpress, this.currentval, required this.sortList})
      : super(key: key);

  @override
  State<BondsSortTab> createState() => _BondsSortTabState();
}

class _BondsSortTabState extends State<BondsSortTab> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Divider(
          height: 0,
          thickness: 1,
          color: customColors().backgroundTertiary,
        ),
        Container(
          child: Padding(
            padding: const EdgeInsets.only(left: 10),
            child: Column(
              children: [
                ListView.builder(
                    shrinkWrap: true,
                    itemCount: widget.sortList.length,
                    itemBuilder: (context, index) {
                      return MyRadioListTile<int>(
                        value: index,
                        groupValue: widget.currentval ?? 0,
                        title: RichText(
                            text: TextSpan(children: [
                          TextSpan(
                            text: widget.sortList[index]["firstName"],
                            style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary,
                            ),
                          ),
                          TextSpan(
                            text: " - " + widget.sortList[index]["secondName"],
                            style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Regular,
                              color: FontColor.FontPrimary,
                            ),
                          ),
                        ])),
                        // title: Text(
                        //   widget.sortList[index]["name"],
                        //   style: customTextStyle(
                        //     fontStyle: FontStyle.BodyL_Regular,
                        //     color: FontColor.FontPrimary,
                        //   ),
                        // ),
                        onChanged: (value) {
                          setState(() {
                            widget.currentval = value!;
                          });
                          widget.onSortpress!(value!);
                        },
                      );
                    }),
              ],
            ),
          ),
        )
      ],
    );
  }
}

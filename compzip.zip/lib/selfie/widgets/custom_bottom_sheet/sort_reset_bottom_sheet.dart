import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/watchlist_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/custom_radio_button.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SortResetBottomSheet extends StatefulWidget {
  final Function(int)? onchange_effect;
  int? currentindex;
  VoidCallback onresetPress;
  SortResetBottomSheet(
      {Key? key,
      this.onchange_effect,
      this.currentindex,
      required this.onresetPress})
      : super(key: key);

  @override
  State<SortResetBottomSheet> createState() => _SortResetBottomSheetState();
}

class _SortResetBottomSheetState extends State<SortResetBottomSheet> {
  List<String> sortchecklist = [
    'A - Z',
    'Z - A',
    'Price: Low - High',
    'Price: High - Low',
    '% Change: Low - High',
    '% Change: High - Low',
  ];

  @override
  Widget build(BuildContext context) {
    return StatefulBuilder(
      builder: (context, StateSetter setState) => Column(
        children: [
          Padding(
            padding:
                const EdgeInsets.only(left: 12, right: 12, top: 12, bottom: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Sort",
                  style: customTextStyle(
                    fontStyle: FontStyle.HeaderXS_SemiBold,
                    color: FontColor.FontPrimary,
                  ),
                ),
                InkWell(
                  onTap: widget.onresetPress,
                  child: Text(
                    "Reset",
                    style: customTextStyle(
                      fontStyle: FontStyle.BodyL_SemiBold,
                      color: FontColor.Primary,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Divider(
            height: 0,
            thickness: 1,
            color: customColors().backgroundTertiary,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 10),
            child: Column(
              children: [
                ListView.builder(
                    shrinkWrap: true,
                    itemCount: sortchecklist.length,
                    itemBuilder: (context, index) {
                      return MyRadioListTile<int>(
                        value: index,
                        groupValue: widget.currentindex!,
                        title: Text(
                          sortchecklist[index],
                          style: customTextStyle(
                            fontStyle: FontStyle.BodyL_Regular,
                            color: FontColor.FontPrimary,
                          ),
                        ),
                        onChanged: (value) {
                          setState(() {
                            widget.currentindex = value!;
                            widget.onchange_effect!(value);
                          });
                        },
                      );
                    })
              ],
            ),
          ),
        ],
      ),
    );
  }
}

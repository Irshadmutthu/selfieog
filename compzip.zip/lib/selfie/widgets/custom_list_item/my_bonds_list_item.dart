import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/model/bonds_list_data_model.dart';
import 'package:selfie_mobile_flutter/model/my_bonds_model.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_profile/profile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_tags/custom_tag.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class MyBondsListItem extends StatelessWidget {
  final BondsListData myBondsListItem;
  const MyBondsListItem({
    required this.myBondsListItem,
    Key? key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Padding(
      padding: const EdgeInsets.only(
        left: 16,
        right: 16,
        bottom: 12,
      ),
      child: Container(
        decoration: BoxDecoration(
            border: Border.all(color: customColors().backgroundTertiary),
            borderRadius: BorderRadius.circular(4)),
        child: Column(children: [
          Padding(
            padding: EdgeInsets.only(
                left: screenSize.width * .033,
                right: screenSize.width * .033,
                top: 16,
                bottom: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Image.asset('assets/bonds_icon.png'),
                    Container(
                      width: screenSize.width * .45,
                      padding: const EdgeInsets.only(
                        left: 16,
                      ),
                      child: Text(
                        ((myBondsListItem.type == "R")
                                ? "Regular Income "
                                : "IPO - ") +
                            myBondsListItem.name.toString(),
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_SemiBold,
                            color: FontColor.FontPrimary),
                      ),
                    ),
                  ],
                ),
                if (myBondsListItem.misc1 != "-")
                  customTag(
                      value: myBondsListItem.misc1.toString(),
                      size: TagSize.small),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
                left: screenSize.width * .033,
                right: screenSize.width * .033,
                bottom: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Yield",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_Regular,
                          color: FontColor.FontTertiary),
                    ),
                    Text(
                      myBondsListItem.yield.toString() +
                          ((myBondsListItem.yield == "-") ? "" : "%"),
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.FontPrimary),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Interest Payment",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_Regular,
                          color: FontColor.FontTertiary),
                    ),
                    Text(
                      myBondsListItem.interestpayment.toString(),
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.FontPrimary),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Maturity Date",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_Regular,
                          color: FontColor.FontTertiary),
                    ),
                    Text(
                      myBondsListItem.maturitydate.toString(),
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.FontPrimary),
                    ),
                  ],
                )
              ],
            ),
          ),
          CustomDividerWithPadding(horizondalPadding: 0),
          Padding(
            padding: EdgeInsets.only(
                left: screenSize.width * .033,
                right: screenSize.width * .033,
                top: 4,
                bottom: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Interest",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_Regular,
                          color: FontColor.FontTertiary),
                    ),
                    Text(
                      (myBondsListItem.interest == "-")
                          ? myBondsListItem.interest.toString()
                          : "₹" +
                              Formats.valueFormatIndian2.format(double.tryParse(
                                  myBondsListItem.interest.toString())),
                      //dataItem.interest.toString(),
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.FontPrimary),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      "Next Payment",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_Regular,
                          color: FontColor.FontTertiary),
                    ),
                    Text(
                      myBondsListItem.nextpayment.toString(),
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.FontPrimary),
                    ),
                  ],
                )
              ],
            ),
          ),
        ]),
      ),
    );
  }
}

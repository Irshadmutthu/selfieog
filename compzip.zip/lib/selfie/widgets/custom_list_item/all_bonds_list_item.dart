import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/model/all_bonds_model.dart';
import 'package:selfie_mobile_flutter/model/bonds_list_data_model.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_tags/custom_tag.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class AllBondListItem extends StatelessWidget {
  final BondsListData allBondsListItem;
  const AllBondListItem({required this.allBondsListItem, Key? key})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Padding(
      padding: const EdgeInsets.only(
        left: 16,
        right: 16,
        bottom: 12,
      ),
      child: Container(
        padding: EdgeInsets.only(
            left: screenSize.width * .033,
            right: screenSize.width * .033,
            top: 16,
            bottom: 20),
        decoration: BoxDecoration(
            border: Border.all(color: customColors().backgroundTertiary),
            borderRadius: BorderRadius.circular(4)),
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                          color: customColors().backgroundSecondary,
                          borderRadius: BorderRadius.circular(4)),
                      padding: const EdgeInsets.all(4),
                      height: 36,
                      width: 36,
                      child: Image.asset('assets/bonds_icon.png'),
                    ),
                    Container(
                      width: screenSize.width * .45,
                      padding: const EdgeInsets.only(
                        left: 16,
                      ),
                      child: Text(
                        ((allBondsListItem.type == "R")
                                ? "Regular Income "
                                : "IPO - ") +
                            allBondsListItem.name.toString(),
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_SemiBold,
                            color: FontColor.FontPrimary),
                      ),
                    )
                  ],
                ),
                if (allBondsListItem.misc1 != "-")
                  customTag(
                      value: allBondsListItem.misc1.toString(),
                      size: TagSize.small),
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Yield",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontTertiary),
                  ),
                  Text(
                    allBondsListItem.yield.toString() +
                        ((allBondsListItem.yield == "-") ? "" : "%"),
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontPrimary),
                  ),
                  SizedBox(
                    height: screenSize.height * .025,
                  ),
                  Text(
                    "Coupon",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontTertiary),
                  ),
                  Text(
                    allBondsListItem.coupon.toString() +
                        ((allBondsListItem.coupon == "-") ? "" : "%"),
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontPrimary),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Min Investment",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontTertiary),
                  ),
                  Text(
                    (allBondsListItem.mininvestment == "-")
                        ? allBondsListItem.mininvestment.toString()
                        : "₹" +
                            Formats.valueFormatIndian2.format(double.tryParse(
                                allBondsListItem.interest.toString())),
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontPrimary),
                  ),
                  SizedBox(
                    height: screenSize.height * .025,
                  ),
                  Text(
                    "Interest Payment",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontTertiary),
                  ),
                  Text(
                    allBondsListItem.interestpayment.toString(),
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontPrimary),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Maturity Date",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontTertiary),
                  ),
                  Text(
                    allBondsListItem.maturitydate.toString(),
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontPrimary),
                  ),
                  SizedBox(
                    height: screenSize.height * .025,
                  ),
                  Text(
                    "Issue Date",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontTertiary),
                  ),
                  Text(
                    allBondsListItem.issuedate.toString(),
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontPrimary),
                  ),
                ],
              )
            ],
          ),
        ]),
      ),
    );
  }
}

import 'package:flutter/material.dart';

import '../../../theme/styles.dart';

class DashBoardNewsListItem extends StatelessWidget {
  Map<String, dynamic> newslist;
  DashBoardNewsListItem({Key? key, required this.newslist}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Container(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(4),
            border: Border.all(color: customColors().backgroundTertiary)),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            children: [
              Column(
                children: [
                  Image.asset(
                    newslist['image'],
                    height: 80.0,
                    width: 80.0,
                  ),
                ],
              ),
              const SizedBox(width: 13),
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8.0),
                    child: Row(
                      children: [
                        Text(
                          newslist['source'] + " | ",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyS_Regular,
                              color: FontColor.FontSecondary),
                        ),
                        Text(
                          newslist['time'],
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyS_Regular,
                              color: FontColor.FontSecondary),
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    width: 200.0,
                    child: Text(
                      newslist['newshead'],
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.FontPrimary),
                      maxLines: 3,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class ActionTile extends StatefulWidget {
  Map<String, dynamic> actioncontents;
  ActionTile({Key? key, required this.actioncontents}) : super(key: key);

  @override
  State<ActionTile> createState() => _ActionTileState();
}

class _ActionTileState extends State<ActionTile> {
  @override
  Widget build(BuildContext context) {
    return widget.actioncontents.containsValue('AMC Dues')
        ? Container(
            decoration: BoxDecoration(
                color: customColors().backgroundSecondary,
                borderRadius: BorderRadius.circular(4.0)),
            padding: const EdgeInsets.only(
                top: 16.0, left: 16.0, right: 18.0, bottom: 16.0),
            child: Row(children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          widget.actioncontents['title'].toString(),
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 4.0),
                      child: Container(
                        width: 250.0,
                        child: Text(
                          widget.actioncontents['content'].toString(),
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_Regular,
                              color: FontColor.FontSecondary),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              Expanded(
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        widget.actioncontents.containsValue('AMC Dues')
                            ? Container(
                                height: 32.0,
                                width: 80.0,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(4.0),
                                    border: Border.all(
                                        color:
                                            Color.fromRGBO(156, 207, 202, 1))),
                                child: Center(
                                  child: Text(
                                    "Pay Now",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_SemiBold,
                                        color: FontColor.Primary),
                                  ),
                                ),
                              )
                            : Image.asset('assets/rightbtn.png'),
                      ],
                    )
                  ],
                ),
              )
            ]),
          )
        : Container(
            decoration: BoxDecoration(
                color: customColors().backgroundSecondary,
                borderRadius: BorderRadius.circular(4.0)),
            padding: const EdgeInsets.only(
                top: 16.0, left: 16.0, right: 18.0, bottom: 16.0),
            child: Row(children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          widget.actioncontents['title'].toString(),
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 4.0),
                      child: Container(
                        width: 250.0,
                        child: Text(
                          widget.actioncontents['content'].toString(),
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_Regular,
                              color: FontColor.FontSecondary),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              Image.asset('assets/rightbtn.png')
              // Expanded(
              //   child: Column(
              //     children: [
              //       Row(
              //         mainAxisAlignment: MainAxisAlignment.end,
              //         children: [
              //           widget.actioncontents.containsValue('AMC Dues')
              //               ? Container(
              //                   height: 32.0,
              //                   width: 80.0,
              //                   decoration: BoxDecoration(
              //                       borderRadius: BorderRadius.circular(4.0),
              //                       border: Border.all(
              //                           color: Color.fromRGBO(156, 207, 202, 1))),
              //                   child: Center(
              //                     child: Text(
              //                       "Pay Now",
              //                       style: customTextStyle(
              //                           fontStyle: FontStyle.BodyM_SemiBold,
              //                           color: FontColor.Primary),
              //                     ),
              //                   ),
              //                 )
              //               : Image.asset('assets/rightbtn.png'),
              //         ],
              //       )
              //     ],
              //   ),
              // )
            ]),
          );
  }
}

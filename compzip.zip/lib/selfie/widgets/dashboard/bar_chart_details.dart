import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class BarChartDetails extends StatefulWidget {
  const BarChartDetails({Key? key}) : super(key: key);

  @override
  State<BarChartDetails> createState() => _BarChartDetailsState();
}

class _BarChartDetailsState extends State<BarChartDetails> {
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Padding(
      padding: const EdgeInsets.only(top: 16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          SizedBox(
            width: screenSize.width * 0.4,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          height: 10,
                          width: 10,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: customColors().islandAqua),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 4.0),
                          child: Text(
                            "Stocks",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyS_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                        )
                      ],
                    ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(left: 40.0),
                        child: Text(
                          "₹ 23,25,200",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyS_Regular,
                              color: FontColor.FontSecondary),
                          textAlign: TextAlign.end,
                        ),
                      ),
                    )
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 6.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            height: 10,
                            width: 10,
                            decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: customColors().accent),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 4.0),
                            child: Text(
                              "Bonds",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyS_SemiBold,
                                  color: FontColor.FontPrimary),
                            ),
                          )
                        ],
                      ),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 40.0),
                          child: Text(
                            "₹ 3,00,000",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyS_Regular,
                                color: FontColor.FontSecondary),
                            textAlign: TextAlign.end,
                          ),
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
          const Expanded(child: SizedBox()),
          Container(
            width: 1,
            color: customColors().backgroundTertiary,
            height: 25.0,
          ),
          // VerticalDivider(
          //   width: 1.0,
          //   thickness: 1.0,
          //   color: Color.fromRGBO(213, 217, 223, 1),
          // ),
          const Expanded(child: SizedBox()),
          SizedBox(
            width: screenSize.width * 0.4,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          height: 10,
                          width: 10,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: customColors().dodgerBlue),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 4.0),
                          child: Text(
                            "MF (Debt)",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyS_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                        )
                      ],
                    ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(left: 31.0),
                        child: Text(
                          "₹ 3,00,000",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyS_Regular,
                              color: FontColor.FontSecondary),
                          textAlign: TextAlign.end,
                        ),
                      ),
                    )
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 6.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            height: 10,
                            width: 10,
                            decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: customColors().ultraviolet),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 4.0),
                            child: Text(
                              "MF (Equity)",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyS_SemiBold,
                                  color: FontColor.FontPrimary),
                            ),
                          )
                        ],
                      ),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 24.0),
                          child: Text(
                            "₹ 2,00,000",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyS_Regular,
                                color: FontColor.FontSecondary),
                            textAlign: TextAlign.end,
                          ),
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}

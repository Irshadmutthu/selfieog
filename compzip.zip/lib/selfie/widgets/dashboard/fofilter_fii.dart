import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/fofilter_list_item.dart';

import '../../../theme/styles.dart';

class FoFilterFill extends StatefulWidget {
  const FoFilterFill({Key? key}) : super(key: key);

  @override
  State<FoFilterFill> createState() => _FoFilterFillState();
}

class _FoFilterFillState extends State<FoFilterFill> {
  List<Map<String, dynamic>> fofilterarray = [
    {
      'option': 'Futures',
      'sub': 'Net Long',
      '13th': '+184k',
      'change': '+84k',
      '14th': '-192k'
    },
    {
      'option': 'Call',
      'sub': 'Net Long',
      '13th': '-184k',
      'change': '+84k',
      '14th': '+192k'
    },
    {
      'option': 'Put',
      'sub': 'Net Long',
      '13th': '-184k',
      'change': '+84k',
      '14th': '-219k'
    },
  ];

  List<Map<String, dynamic>> stockarray = [
    {
      'option': 'Futures',
      'sub': 'Net Long',
      '13th': '+184k',
      'change': '+84k',
      '14th': '-192k'
    },
    {
      'option': 'Call',
      'sub': 'Net Long',
      '13th': '-184k',
      'change': '+84k',
      '14th': '+192k'
    },
    {
      'option': 'Put',
      'sub': 'Net Long',
      '13th': '-184k',
      'change': '+84k',
      '14th': '-219k'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 20.0),
            child: Container(
              padding: const EdgeInsets.only(left: 12.0, right: 12.0),
              width: MediaQuery.of(context).size.width,
              height: 20.0,
              child: Row(
                children: [
                  Expanded(
                      child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                        "Index",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      )
                    ],
                  )),
                  Expanded(
                      child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        "13th",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      )
                    ],
                  )),
                  Expanded(
                      child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        "Change",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      )
                    ],
                  )),
                  Expanded(
                      child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        "14th",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      )
                    ],
                  )),
                ],
              ),
            ),
          ),
          SizedBox(
            height: 8,
          ),
          ListView.builder(
              itemCount: fofilterarray.length,
              shrinkWrap: true,
              physics: ScrollPhysics(),
              itemBuilder: (context, index) {
                return FoFilterListItem(
                  index: index,
                  list: fofilterarray[index],
                );
              }),
          Container(
            padding: const EdgeInsets.only(left: 12.0, right: 12.0),
            width: MediaQuery.of(context).size.width,
            height: 40.0,
            decoration:
                BoxDecoration(color: customColors().backgroundSecondary),
            child: Row(
              children: [
                Expanded(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      "Total",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.FontPrimary),
                    )
                  ],
                )),
                Expanded(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      "+384k",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.Success),
                    )
                  ],
                )),
                Expanded(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      "+84k",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.Danger),
                    )
                  ],
                )),
                Expanded(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      "-392k",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.Danger),
                    )
                  ],
                )),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20.0),
            child: Container(
              padding: const EdgeInsets.only(left: 12.0, right: 12.0),
              width: MediaQuery.of(context).size.width,
              height: 20.0,
              child: Row(
                children: [
                  Expanded(
                      child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                        "Stocks",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      )
                    ],
                  )),
                  Expanded(
                      child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        "13th",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      )
                    ],
                  )),
                  Expanded(
                      child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        "Change",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      )
                    ],
                  )),
                  Expanded(
                      child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        "14th",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      )
                    ],
                  )),
                ],
              ),
            ),
          ),
          SizedBox(
            height: 8,
          ),
          ListView.builder(
              itemCount: fofilterarray.length,
              shrinkWrap: true,
              physics: ScrollPhysics(),
              itemBuilder: (context, index) {
                return FoFilterListItem(
                  index: index,
                  list: fofilterarray[index],
                );
              }),
          Container(
            padding: const EdgeInsets.only(left: 12.0, right: 12.0),
            width: MediaQuery.of(context).size.width,
            height: 40.0,
            decoration:
                BoxDecoration(color: customColors().backgroundSecondary),
            child: Row(
              children: [
                Expanded(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      "Total",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.FontPrimary),
                    )
                  ],
                )),
                Expanded(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      "+384k",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.Success),
                    )
                  ],
                )),
                Expanded(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      "+84k",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.Danger),
                    )
                  ],
                )),
                Expanded(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      "-392k",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.Danger),
                    )
                  ],
                )),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 13.0, top: 4),
            child: Row(
              children: [
                Text(
                  '*Numbers represent lot',
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyS_Regular,
                      color: FontColor.FontSecondary),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}

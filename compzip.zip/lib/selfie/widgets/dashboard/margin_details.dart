import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class MarginDetails extends StatefulWidget {
  String title1;
  String title2;
  double totalmarginavail;
  double todaymarginused;
  String totalPercentage;
  String todayPercentage;
  double height;
  double verticalDividerPadding;

  MarginDetails(
      {Key? key,
      required this.title1,
      required this.title2,
      required this.todaymarginused,
      required this.totalmarginavail,
      required this.totalPercentage,
      required this.todayPercentage,
      this.verticalDividerPadding = 9,
      required this.height})
      : super(key: key);

  @override
  State<MarginDetails> createState() => _MarginDetailsState();
}

class _MarginDetailsState extends State<MarginDetails> {
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Container(
      decoration: BoxDecoration(
        borderRadius: const BorderRadius.all(Radius.circular(4)),
        color: customColors().backgroundSecondary,
      ),
      height: widget.height,
      width: MediaQuery.of(context).size.width,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Expanded(child: SizedBox()),
          SizedBox(
            width: screenSize.width * 0.3,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  widget.title1.toUpperCase(),
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontSecondary),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 4.0),
                  child: Text(
                      ((widget.totalPercentage == "") ? "₹ " : "") +
                          Formats.valueFormatIndian2
                              .format(widget.todaymarginused),
                      style: customTextStyle(
                          fontStyle: FontStyle.HeaderXS_Bold,
                          color: FontColor.FontPrimary)),
                ),
                Visibility(
                  visible: widget.totalPercentage != "" ? true : false,
                  child: Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(
                      "+${widget.totalPercentage}%",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyS_SemiBold,
                          color: FontColor.Success),
                    ),
                  ),
                )
              ],
            ),
          ),
          const Expanded(child: SizedBox()),
          // Container(
          //   width: 1,
          //   color: customColors().backgroundTertiary,
          //   height: double.maxFinite,
          // ),
          Padding(
            padding: EdgeInsets.only(
                top: widget.verticalDividerPadding,
                bottom: widget.verticalDividerPadding),
            child: VerticalDivider(
              width: 1.0,
              thickness: 1.0,
              color: Color.fromRGBO(213, 217, 223, 1),
            ),
          ),

          const Expanded(child: SizedBox()),
          SizedBox(
            width: screenSize.width * 0.3,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  widget.title2.toUpperCase(),
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontSecondary),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 4.0),
                  child: Text(
                      ((widget.totalPercentage == "") ? "₹ " : "") +
                          Formats.valueFormatIndian2
                              .format(widget.totalmarginavail),
                      style: customTextStyle(
                          fontStyle: FontStyle.HeaderXS_Bold,
                          color: FontColor.FontPrimary)),
                ),
                Visibility(
                  visible: widget.totalPercentage != "" ? true : false,
                  child: Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(
                      "${widget.todayPercentage}%",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyS_SemiBold,
                          color: FontColor.Success),
                    ),
                  ),
                )
              ],
            ),
          ),
          const Expanded(child: SizedBox()),
        ],
      ),
    );
  }
}

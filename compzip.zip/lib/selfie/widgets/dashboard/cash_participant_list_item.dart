import 'package:flutter/material.dart';

import '../../../theme/styles.dart';

class CashParticipantlistItem_ extends StatelessWidget {
  int index;
  List<Map<String, dynamic>> cashpartdata;
  CashParticipantlistItem_(
      {Key? key, required this.index, required this.cashpartdata})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: index == cashpartdata.length - 1
          ? const EdgeInsets.only(bottom: 19.0)
          : const EdgeInsets.only(bottom: 28.0),
      child: Container(
        padding: const EdgeInsets.only(left: 12.0, right: 12.0),
        child: Row(
          children: [
            Expanded(
                child: Row(
              children: [
                Text(
                  cashpartdata[index]['day'],
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontPrimary),
                )
              ],
            )),
            Expanded(
                child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  cashpartdata[index]['fii'],
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.Success),
                )
              ],
            )),
            Expanded(
                child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  cashpartdata[index]['dii'],
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.Danger),
                )
              ],
            )),
            Expanded(
                child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  cashpartdata[index]['net'],
                  style: cashpartdata[index]['net'].toString().contains("+")
                      ? customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.Success)
                      : customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.Danger),
                )
              ],
            )),
          ],
        ),
      ),
    );
  }
}

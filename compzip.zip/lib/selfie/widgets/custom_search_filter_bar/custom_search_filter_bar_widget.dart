import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CustomSearchFilterBar extends StatefulWidget {
  final VoidCallback? onSearchPress;
  final VoidCallback? onFilterPress;
  final bool showFilter;
  final bool showBubble;
  //final VoidCallback? ononSortPress;
  //final bool sortBubble;
  // final bool showInsights;

  const CustomSearchFilterBar({
    Key? key,
    this.onFilterPress,
    this.onSearchPress,
    this.showFilter = true,
    this.showBubble = true,
    //this.sortBubble = true,
    // this.showInsights = true,
    // this.ononSortPress,
  }) : super(key: key);
  @override
  State<CustomSearchFilterBar> createState() => _CustomSearchFilterBar();
}

class _CustomSearchFilterBar extends State<CustomSearchFilterBar> {
  @override
  Widget build(BuildContext context) {
    TextStyle styles = customTextStyle(
        fontStyle: FontStyle.BodyL_Regular, color: FontColor.FontSecondary);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          InkWell(
            onTap: widget.onSearchPress,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                CUstomSerchBarImages(
                    imagPath: "assets/search.png", context: context),
                const SizedBox(
                  width: 6,
                ),
                Text(
                  "Search",
                  style: styles,
                ),
              ],
            ),
          ),
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.13,
            height: 5,
          ),
          InkWell(
            onTap: widget.onFilterPress,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Stack(
                  alignment: Alignment.topRight,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 1, right: 1),
                      child: CUstomSerchBarImages(
                          imagPath: "assets/filter.png", context: context),
                    ),
                    if (widget.showBubble)
                      Container(
                          width: 8,
                          height: 8,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: customColors().accent)),
                  ],
                ),
                const SizedBox(
                  width: 6,
                ),
                Text(
                  "Filter",
                  style: styles,
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}

class CUstomSerchBarImages extends StatelessWidget {
  CUstomSerchBarImages({
    Key? key,
    required this.imagPath,
    required this.context,
    this.height = 16.6,
    this.width = 17.6,
  }) : super(key: key);

  final String imagPath;
  final BuildContext context;
  double height;
  double width;

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      imagPath,
      color: customColors().fontPrimary,
      height: height,
      width: width,
    );
  }
}

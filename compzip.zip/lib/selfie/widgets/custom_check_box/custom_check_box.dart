import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

// class CustomCustomCheckBox extends StatefulWidget {
//   Function(bool) callback;
//   bool isSelect;
//   CustomCustomCheckBox(
//       {Key? key, required this.callback, this.isSelect = false})
//       : super(key: key);
//   @override
//   State<CustomCustomCheckBox> createState() => _CustomCustomCheckBoxState();
// }

// class _CustomCustomCheckBoxState extends State<CustomCustomCheckBox> {
//   ontap() {
//     setState(() {

//       widget.callback(!widget.isSelect);
//     });
//   }

//   @override
//   void initState() {
//     super.initState();
//     setState(() {});
//   }

//   @override
//   Widget build(BuildContext context) {
//     return InkWell(
//         splashColor: customColors().primary,
//         onTap: ontap,
//         child: SizedBox(
//           height: 24,
//           width: 24,
//           child: widget.isSelect
//               ? Image.asset(
//                   "assets/ic_checkbox_checked.png",fit: BoxFit.fill,
//                 )
//               : Image.asset("assets/emptycheckbox.png",
//                   color: customColors().fontSecondary),
//         ));
//   }
// }

class CustomCustomCheckBox extends StatelessWidget {
  Function(bool) onCheckPress;
  bool isSelect;
  CustomCustomCheckBox(
      {required this.onCheckPress, this.isSelect = false, Key? key})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
        splashColor: customColors().primary,
        onTap: () => onCheckPress(!isSelect),
        child: SizedBox(
          height: 24,
          width: 24,
          child: isSelect
              ? Image.asset(
                  "assets/ic_checkbox_checked.png",
                  fit: BoxFit.fill,
                )
              : Image.asset("assets/emptycheckbox.png",
                  fit: BoxFit.fill, color: customColors().fontSecondary),
        ));
  }
}

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

enum TagSize { large, small }

Widget customTag({required String value, TagSize? size = TagSize.small}) {
  switch (value.toUpperCase()) {
    case "":
      return const SizedBox();
    case "AAA":
      return (size == TagSize.large)
          ? CustomTagLarge(
              text: "AAA",
              textColor: FontColor.White,
              boxColor: customColors().success)
          : CustomTagSmall(
              text: "AAA",
              textColor: FontColor.White,
              boxColor: customColors().success);
    case "AA+":
      return (size == TagSize.large)
          ? const CustomTagLarge(
              text: "AA+",
              textColor: FontColor.White,
              boxColor: Color(0xff1A9B4E))
          : const CustomTagSmall(
              text: "AA+",
              textColor: FontColor.White,
              boxColor: Color(0xff1A9B4E));
    case "A+":
      return (size == TagSize.large)
          ? const CustomTagLarge(
              text: "A+",
              textColor: FontColor.White,
              boxColor: Color(0xff357E2D))
          : const CustomTagSmall(
              text: "A+",
              textColor: FontColor.White,
              boxColor: Color(0xff357E2D));
    case "AA":
      return (size == TagSize.large)
          ? const CustomTagLarge(
              text: "AA",
              textColor: FontColor.White,
              boxColor: Color(0xff608625))
          : const CustomTagSmall(
              text: "AA",
              textColor: FontColor.White,
              boxColor: Color(0xff608625));
    case "A":
      return (size == TagSize.large)
          ? const CustomTagLarge(
              text: "A",
              textColor: FontColor.White,
              boxColor: Color(0xff608625))
          : const CustomTagSmall(
              text: "A",
              textColor: FontColor.White,
              boxColor: Color(0xff608625));
    case "AA-":
      return (size == TagSize.large)
          ? const CustomTagLarge(
              text: "AA-",
              textColor: FontColor.White,
              boxColor: Color(0xff94921D))
          : const CustomTagSmall(
              text: "AA-",
              textColor: FontColor.White,
              boxColor: Color(0xff94921D));
    case "BBB":
      return (size == TagSize.large)
          ? const CustomTagLarge(
              text: "BBB",
              textColor: FontColor.White,
              boxColor: Color(0xffB49A19))
          : const CustomTagSmall(
              text: "BBB",
              textColor: FontColor.White,
              boxColor: Color(0xffB49A19));
    case "BB+":
      return (size == TagSize.large)
          ? const CustomTagLarge(
              text: "BB+",
              textColor: FontColor.White,
              boxColor: Color(0xffCFA015))
          : const CustomTagSmall(
              text: "BB+",
              textColor: FontColor.White,
              boxColor: Color(0xffCFA015));
    case "BBB-":
      return (size == TagSize.large)
          ? const CustomTagLarge(
              text: "BBB-",
              textColor: FontColor.White,
              boxColor: Color(0xffE68A23))
          : const CustomTagSmall(
              text: "BBB-",
              textColor: FontColor.White,
              boxColor: Color(0xffE68A23));
    case "BB-":
      return (size == TagSize.large)
          ? const CustomTagLarge(
              text: "BB-",
              textColor: FontColor.White,
              boxColor: Color(0xffEA7B2D))
          : const CustomTagSmall(
              text: "BB-",
              textColor: FontColor.White,
              boxColor: Color(0xffEA7B2D));
    case "B":
      return (size == TagSize.large)
          ? const CustomTagLarge(
              text: "B",
              textColor: FontColor.White,
              boxColor: Color(0xffF1623E))
          : const CustomTagSmall(
              text: "B",
              textColor: FontColor.White,
              boxColor: Color(0xffF1623E));
    case "D":
      return (size == TagSize.large)
          ? const CustomTagLarge(
              text: "D",
              textColor: FontColor.White,
              boxColor: Color(0xffF64E4B))
          : const CustomTagSmall(
              text: "D",
              textColor: FontColor.White,
              boxColor: Color(0xffF64E4B));
    default:
      return (size == TagSize.large)
          ? CustomTagLarge(
              text: "NO Badge",
              textColor: FontColor.DodgerBlue,
              boxColor: customColors().dodgerBlue)
          : CustomTagSmall(
              text: "NO Badge",
              textColor: FontColor.DodgerBlue,
              boxColor: customColors().dodgerBlue);
  }
}

class CustomTagLarge extends StatelessWidget {
  final String text;
  final FontColor textColor;
  final Color boxColor;
  final FontStyle textStyle;
  const CustomTagLarge(
      {Key? key,
      required this.text,
      required this.textColor,
      this.textStyle = FontStyle.TagNameL_SemiBold,
      required this.boxColor})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return FittedBox(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 8.0),
        decoration: BoxDecoration(
          color: boxColor,
          borderRadius: BorderRadius.circular(2),
        ),
        child: Center(
            child: Text(
          "$text",
          textAlign: TextAlign.center,
          style: customTextStyle(fontStyle: textStyle, color: textColor),
        )),
      ),
    );
  }
}

class CustomTagSmall extends StatelessWidget {
  final String text;
  final FontColor textColor;
  final Color boxColor;
  final FontStyle textStyle;
  const CustomTagSmall(
      {Key? key,
      required this.text,
      required this.textColor,
      this.textStyle = FontStyle.TagNameL_SemiBold,
      required this.boxColor})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return FittedBox(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 6.0, vertical: 6.0),
        decoration: BoxDecoration(
          color: boxColor,
          borderRadius: BorderRadius.circular(2),
        ),
        child: Center(
            child: Text(
          "$text",
          textAlign: TextAlign.center,
          style: customTextStyle(fontStyle: textStyle, color: textColor),
        )),
      ),
    );
  }
}

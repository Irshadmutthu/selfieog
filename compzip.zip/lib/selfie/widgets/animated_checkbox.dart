import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class AnimatedCheckBox extends StatelessWidget {
  bool value;
  bool loading;
  Function(bool) onTap;
  AnimatedCheckBox(
      {Key? key,
      required this.value,
      required this.onTap,
      required this.loading})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return (loading)
        ? Container(
            height: 24.0,
            width: 24.0,
            decoration: BoxDecoration(
                color: customColors().primary,
                borderRadius: BorderRadius.circular(2)),
            padding: const EdgeInsets.all(4.0),
            child:
                const CircularProgressIndicator(color: white, strokeWidth: 2.5))
        : SizedBox(
            height: 24.0,
            width: 24.0,
            child: InkWell(
              splashColor: customColors().primary,
              onTap: () => onTap(value),
              child: Image.asset(
                  value
                      ? "assets/ic_checkbox_checked.png"
                      : "assets/ic_checkbox_plus.png",
                  height: 24,
                  width: 24,
                  fit: BoxFit.fill),
            ),
          );
  }
}

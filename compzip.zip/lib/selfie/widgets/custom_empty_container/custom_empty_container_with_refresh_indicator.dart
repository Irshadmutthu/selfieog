import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/empty_container.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CustomEmptyContainerWithRefreshIndicator extends StatelessWidget {
  const CustomEmptyContainerWithRefreshIndicator({
    Key? key,
    required this.screenSize,
    required this.onRefress,
    required this.title,
    required this.subTitle,
  }) : super(key: key);

  final Size screenSize;
  final Function onRefress;
  final String title;
  final String subTitle;

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
        backgroundColor: customColors().primary,
        onRefresh: () async {
          onRefress();
        },
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Padding(
            padding: EdgeInsets.only(top: screenSize.height * .25),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                EmptyContainer(
                    height: 160,
                    width: 160,
                    color: customColors().backgroundSecondary),
                Padding(
                  padding: const EdgeInsets.only(top: 20.0),
                  child: Align(
                      alignment: Alignment.center,
                      child: Text(
                        title,
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_SemiBold,
                            color: FontColor.FontPrimary),
                      )),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Align(
                      alignment: Alignment.center,
                      child: Text(
                        subTitle,
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_Regular,
                            color: FontColor.FontSecondary),
                      )),
                )
              ],
            ),
          ),
        ));
  }
}

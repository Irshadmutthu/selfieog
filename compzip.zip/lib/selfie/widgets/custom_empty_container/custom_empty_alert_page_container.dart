import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CustomEmptyAlertContainer extends StatelessWidget {
  const CustomEmptyAlertContainer({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 59.0),
          child: Center(child: Image.asset('assets/circles_confirm.png')),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 60.0),
          child: Text(
            "No Alerts",
            style: customTextStyle(
                fontStyle: FontStyle.HeaderS_SemiBold,
                color: FontColor.FontPrimary),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 20.0),
          child: Text(
            "You Currently have not active alert.",
            style: customTextStyle(
                fontStyle: FontStyle.BodyL_Regular,
                color: FontColor.FontPrimary),
          ),
        )
      ],
    );
  }
}

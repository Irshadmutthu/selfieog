import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/texts.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CustomBottomNavigationBar extends StatefulWidget {
  final int selectedIndex;
  final BuildContext context;
  final Function(int) onTap;

  CustomBottomNavigationBar({
    this.selectedIndex = 0,
    required this.context,
    required this.onTap,
  });

  @override
  _CustomBottomNavigationBarState createState() =>
      _CustomBottomNavigationBarState();
}

class _CustomBottomNavigationBarState extends State<CustomBottomNavigationBar> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(width: 1, color: customColors().backgroundTertiary),
        ),
      ),
      child: BottomNavigationBar(
        backgroundColor: customColors().backgroundPrimary,
        elevation: 0,
        unselectedFontSize: 10,
        selectedFontSize: 10,
        enableFeedback: true,
        type: BottomNavigationBarType.fixed,
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            activeIcon: const ImageIcon(
              AssetImage("assets/watchlist_active.png"),
            ),
            icon: const ImageIcon(
              AssetImage("assets/watchlist_inactive.png"),
            ),
            label: Texts.bottomBarItem1,
          ),
          BottomNavigationBarItem(
            activeIcon: const ImageIcon(
              AssetImage("assets/portfolio_active.png"),
            ),
            icon: const ImageIcon(
              AssetImage("assets/portfolio_inactive.png"),
            ),
            label: Texts.bottomBarItem2,
          ),
          BottomNavigationBarItem(
            activeIcon: const ImageIcon(
              AssetImage("assets/order_active.png"),
            ),
            icon: const ImageIcon(
              AssetImage("assets/order_inactive.png"),
            ),
            label: Texts.bottomBarItem3,
          ),
          BottomNavigationBarItem(
            activeIcon: const ImageIcon(
              AssetImage("assets/idea_inactive.png"),
            ),
            icon: const ImageIcon(
              AssetImage("assets/idea_inactive.png"),
            ),
            label: Texts.bottomBarItem4,
          ),
          BottomNavigationBarItem(
            activeIcon: const ImageIcon(
              AssetImage("assets/more_active.png"),
            ),
            icon: const ImageIcon(
              AssetImage("assets/more_inactive.png"),
            ),
            label: Texts.bottomBarItem5,
          ),
        ],
        currentIndex: widget.selectedIndex,
        iconSize: 24,
        onTap: widget.onTap,
        selectedItemColor: customColors().primary,
        unselectedItemColor: customColors().fontSecondary,
        unselectedLabelStyle: customTextStyle(
            fontStyle: FontStyle.BodyS_Regular, color: FontColor.FontSecondary),
        selectedLabelStyle: customTextStyle(
            fontStyle: FontStyle.BodyS_Regular, color: FontColor.FontSecondary),
        showSelectedLabels: true,
        showUnselectedLabels: true,
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';
import 'package:webview_flutter/webview_flutter.dart';

class CustomWebviewPage extends StatefulWidget {
  String urlAddress;
  String title;
  CustomWebviewPage({Key? key, required this.urlAddress, this.title = "back"})
      : super(key: key);

  @override
  State<CustomWebviewPage> createState() => _CustomWebviewPageState();
}

class _CustomWebviewPageState extends State<CustomWebviewPage>
    with TickerProviderStateMixin {
  bool loadingStatus = true;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: Column(
        children: [
          CustomAppBarInner(
              title: widget.title,
              onBackPressed: () {
                context.gNavigationService.back(context);
              }),
          Expanded(
            child: Stack(
              children: [
                WebView(
                  initialUrl: widget.urlAddress,
                  javascriptMode: JavascriptMode.unrestricted,
                  javascriptChannels: <JavascriptChannel>{
                    JavascriptChannel(
                        name: 'MessageInvoker',
                        onMessageReceived: (s) {
                          ScaffoldMessenger.of(context).showSnackBar(
                              showErrorDialogue(
                                  errorMessage: s.message.toString()));
                        }),
                  },
                  onPageFinished: (val) {
                    setState(() {
                      loadingStatus = false;
                    });
                  },
                  onProgress: (val) {},
                  onWebViewCreated: (val) {},
                ),
                if (loadingStatus)
                  Container(
                    color: customColors().backgroundPrimary,
                    child: Center(
                        child: CircularProgressIndicator(
                      color: customColors().primary,
                    )),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

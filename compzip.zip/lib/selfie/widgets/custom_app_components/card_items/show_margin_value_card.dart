import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class ShowMarginValueWidget extends StatelessWidget {
  String title;
  String value;
  ShowMarginValueWidget({Key? key, required this.title, required this.value})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 82,
      decoration: BoxDecoration(
        color: customColors().backgroundSecondary,
        borderRadius: BorderRadius.circular(4),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            title,
            style: customTextStyle(
              fontStyle: FontStyle.BodyM_SemiBold,
              color: FontColor.FontSecondary,
            ),
          ),
          const SizedBox(
            height: 8,
          ),
          Text(
            value,
            // Formats.valueFormatIndian.format(
            //     double.tryParse((state
            //                 .buyingPowerResponse
            //                 .result2!
            //                 .length >
            //             0)
            //         ? state.buyingPowerResponse
            //             .result2![0].bp
            //             .toString()
            //         : "0")),
            style: customTextStyle(
              fontStyle: FontStyle.HeaderS_Bold,
              color: FontColor.FontPrimary,
            ),
          ),
        ],
      ),
    );
  }
}

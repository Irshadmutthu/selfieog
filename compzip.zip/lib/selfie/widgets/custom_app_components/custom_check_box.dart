import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CustomCheckBox extends StatefulWidget {
  bool isChecked;
  CustomCheckBox({this.isChecked = false});

  @override
  _CustomCheckBoxState createState() => _CustomCheckBoxState();
}

class _CustomCheckBoxState extends State<CustomCheckBox> {
  ontap() {
    setState(() {
      widget.isChecked ? widget.isChecked = false : widget.isChecked = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return widget.isChecked
        ? InkWell(
            splashColor: customColors().primary,
            onTap: ontap,
            child: Image.asset(
              "assets/ic_checkbox_checked.png",
              height: 24,
              width: 24,
              fit: BoxFit.fill,
            ),
          )
        : InkWell(
            splashColor: customColors().primary,
            onTap: ontap,
            child: Image.asset(
              "assets/ic_checkbox_plus.png",
              height: 24,
              width: 24,
              fit: BoxFit.fill,
            ));
  }
}

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class ButtonWithIcon extends StatelessWidget {
  String? text;
  VoidCallback? onpress;
  Color? bgcolor;
  TextStyle? style;
  Color? bordercolor;
  String? icon1;
  String? icon2;
  double? buttonwidth;
  double? height;
  ButtonWithIcon({
    Key? key,
    this.text,
    this.style,
    this.onpress,
    this.bgcolor,
    this.bordercolor,
    this.icon1,
    this.icon2,
    this.buttonwidth,
    this.height,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double mheight = MediaQuery.of(context).size.height * .055;

    return InkWell(
      onTap: onpress,
      child: Container(
        height: height ?? mheight,
        width: buttonwidth ?? MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(3.54),
            color: bgcolor,
            border: Border.all(color: bordercolor!)),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.only(left: 8.0, right: 8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  icon1!,
                  color: customColors().primary,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 10.0),
                  child: Text(
                    text!,
                    style: style,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

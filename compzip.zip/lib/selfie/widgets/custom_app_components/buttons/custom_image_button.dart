import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CustomImageButton extends StatefulWidget {
  final String imagePath;
  final Color? color;
  final double height;
  final double width;
  final Function() onTap;
  bool showBubble;
  CustomImageButton(
      {required this.imagePath,
      this.color,
      this.height = 48,
      required this.onTap,
      this.width = 48,
      this.showBubble = false,});

  @override
  _CustomImageButtonState createState() => _CustomImageButtonState();
}

class _CustomImageButtonState extends State<CustomImageButton> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      child: Container(
        height: widget.height,
        width: widget.width,
        decoration: BoxDecoration(
            border: Border.all(color: customColors().backgroundTertiary), 
            borderRadius: const BorderRadius.all(Radius.circular(4.0))),
        child: Center(
          child: Stack(
            alignment: Alignment.topRight,
            children: [
              Image.asset(widget.imagePath, color: widget.color ?? customColors().fontPrimary),
              if(widget.showBubble)
              Container(width: 10, height: 10, decoration: BoxDecoration(shape: BoxShape.circle, color: customColors().accent))
            ],
          ),
        ),
      ),
    );
  }
}

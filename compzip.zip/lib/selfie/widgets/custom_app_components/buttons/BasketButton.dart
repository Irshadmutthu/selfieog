import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class BasketButton extends StatelessWidget {
  String? text;
  VoidCallback? onpress;
  Color? bgcolor;
  TextStyle textStyle;
  Color bordercolor;
  double? buttonwidth;
  bool enabled;
  double? verticalPadding;
  bool loading;
  BasketButton({
    Key? key,
    this.text,
    this.onpress,
    this.bgcolor,
    required this.textStyle,
    this.bordercolor = transparent,
    this.buttonwidth,
    this.enabled = true,
    this.verticalPadding,
    this.loading = false,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return InkWell(
      splashColor: transparent,
      highlightColor: transparent,
      enableFeedback: enabled,
      onTap: enabled ? onpress : () {},
      child: Container(
        padding: EdgeInsets.symmetric(vertical: verticalPadding ?? 14.0),
        width: buttonwidth ?? screenSize.width,
        decoration: BoxDecoration(
            color: enabled ? bgcolor : bgcolor!.withOpacity(0.5),
            borderRadius: BorderRadius.circular(3.54),
            border: Border.all(color: bordercolor)),
        child: Center(
          child: loading
              ? const CupertinoActivityIndicator(
                  animating: true,
                  color: white,
                )
              : Text(text.toString(), style: textStyle),
        ),
      ),
    );
  }
}

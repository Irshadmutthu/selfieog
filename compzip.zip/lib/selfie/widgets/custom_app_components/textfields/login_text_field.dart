import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:flutter/services.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/formatters.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class LoginTextField extends StatefulWidget {
  final String hintText;
  final String label;
  final Color? bordercolor;
  TextEditingController idcontroller;
  LoginTextField(
      {Key? key,
      required this.hintText,
      required this.label,
      this.bordercolor,
      required this.idcontroller})
      : super(key: key);

  @override
  _LoginTextFieldState createState() => _LoginTextFieldState();
}

class _LoginTextFieldState extends State<LoginTextField> {
  bool val = false;

  @override
  Widget build(BuildContext context) {
    double mheight = MediaQuery.of(context).size.height * 1.22;

    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                widget.label,
                style: customTextStyle(
                    fontStyle: FontStyle.BodyL_Regular,
                    color: FontColor.FontPrimary),
              ),
            ],
          ),
          Padding(
            padding: EdgeInsets.only(top: mheight * .006),
            child: TextFormField(
              autofocus: true,
              textCapitalization: TextCapitalization.characters,
              textAlignVertical: TextAlignVertical.center,
              controller: widget.idcontroller,
              inputFormatters: [UpperCaseTextFormatter()],
              cursorColor: customColors().fontPrimary,
              validator: (v) {
                if (v == "") {
                  val = true;
                  return "Account ID required";
                } 
                // else if (v != "ADMIN") {
                //   return "Account doesnot exist";
                // }
              },
              style: customTextStyle(
                  fontStyle: FontStyle.BodyL_Regular,
                  color: FontColor.FontPrimary),
              decoration: InputDecoration(
                border: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: widget.bordercolor!, width: 1.1),
                    borderRadius: BorderRadius.circular(4.0)),
                hintText: widget.hintText,
                hintStyle: customTextStyle(
                    fontStyle: FontStyle.BodyL_Regular,
                    color: FontColor.FontTertiary),
                focusedBorder: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: widget.bordercolor!, width: 1),
                    borderRadius: BorderRadius.circular(4.0)),
                contentPadding:
                    EdgeInsets.symmetric(vertical: 15, horizontal: 10),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

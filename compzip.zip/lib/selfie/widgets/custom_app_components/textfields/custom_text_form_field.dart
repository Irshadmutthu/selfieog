import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:selfie_mobile_flutter/constants/general_methods.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';

class CustomTextFormField extends StatefulWidget {
  final bool enabled;
  final dynamic textCapitalization;
  final TextEditingController controller;
  final List<TextInputFormatter>? inputFormatter;
  final Color? bordercolor;
  final Color? bgColor;
  final String fieldName;
  final String? hintText;
  final String defaultErrorMessage;

  final Widget? maxLengthEnforcement;
  final TextInputType? keyboardType;
  // final ValueChanged<String>? onchangedAction;
  final int? maxLength;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final Validator? validator;
  final int? width;
  final double? height;
  final double? labelBottomPadding;
  final bool obscureTextStatus;
  final bool readonlyState;
  final Function? keyboardAction;
  final bool isInputaction;
  final bool autoFocus;
  final bool obscureIcon;
  TextInputAction? textInputAction;
  final Color? fillColor;
  final Widget? topEndWidget;
  final Widget? bottomStartWidget;
  final Widget? bottomEndWidget;
  final Function(String)? onFieldSubmit;
  final Function(String)? onChange;
  final int? maxLines;
  FocusNode? focusNode;
  final String? suffixtext;
  final Widget? prefixWidget;
  final int? minimumValueLimit;
  final double? minimumDecimalValueLimit;
  final TextAlign textAlign;
  Widget? sufixWidget;

  CustomTextFormField(
      {Key? key,
      this.autoFocus = false,
      this.enabled = true,
      this.obscureIcon = false,
      this.textCapitalization = TextCapitalization.none,
      required this.controller,
      this.inputFormatter,
      this.bordercolor,
      this.bgColor,
      required this.fieldName,
      this.hintText = " ",
      this.defaultErrorMessage = "Please fill valid data",
      this.maxLength,
      this.validator,
      this.prefixIcon,
      this.suffixIcon,
      this.obscureTextStatus = false,
      this.width,
      this.height = 69,
      this.maxLengthEnforcement,
      this.keyboardType,
      // this.onchangedAction,
      this.readonlyState = false,
      this.labelBottomPadding,
      this.keyboardAction,
      this.isInputaction = false,
      this.textInputAction,
      this.fillColor,
      this.topEndWidget,
      this.bottomStartWidget,
      this.bottomEndWidget,
      this.onFieldSubmit,
      this.onChange,
      this.focusNode,
      this.maxLines,
      this.suffixtext,
      this.prefixWidget,
      this.minimumValueLimit,
      this.minimumDecimalValueLimit,
      this.textAlign = TextAlign.start,
      this.sufixWidget})
      : super(key: key);
  @override
  State<CustomTextFormField> createState() => _CustomTextFormFieldState();
}

class _CustomTextFormFieldState extends State<CustomTextFormField> {
  bool contentVisibility = false;
  // final phoneValidator = MultiValidator();
  @override
  void initState() {
    // TODO: implement initState
    contentVisibility = widget.obscureTextStatus;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    double mheight = MediaQuery.of(context).size.height * 1.22;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (widget.fieldName != "")
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                widget.fieldName,
                style: customTextStyle(
                    fontStyle: FontStyle.BodyL_Regular,
                    color: FontColor.FontPrimary),
              ),
              widget.topEndWidget ?? Container(),
            ],
          ),
        Padding(
          padding: EdgeInsets.only(top: widget.labelBottomPadding ?? 4.0),
          child: TextFormField(
            readOnly: widget.readonlyState,
            textAlign: widget.textAlign,
            //    enableInteractiveSelection: false,
            //    textInputAction: widget.textInputAction ?? TextInputAction.none,
            // onFieldSubmitted: (value) {
            //   //     if (widget.keyboardAction != null) widget.keyboardAction!();
            // },
            keyboardType: widget.keyboardType,
            minLines: widget.maxLines ?? 1,
            maxLines: widget.maxLines ?? 1,
            maxLength: widget.maxLength,
            cursorRadius: const Radius.circular(4.0),
            showCursor: true,
            onFieldSubmitted: widget.onFieldSubmit,
            onChanged: widget.onChange,
            obscureText: contentVisibility,
            obscuringCharacter: "●",
            autofocus: widget.autoFocus,
            textCapitalization: widget.textCapitalization,
            textAlignVertical: TextAlignVertical.center,
            controller: widget.controller,
            focusNode: widget.focusNode,
            inputFormatters: widget.inputFormatter,
            cursorColor: customColors().fontPrimary,
            validator: (value) {
              switch (widget.validator) {
                case Validator.none:
                  return noValidation(value.toString());
                case Validator.defaultValidator:
                  return emptyValidation(
                      value.toString(), widget.defaultErrorMessage);
                case Validator.account:
                  return accountValidation(value.toString());
                case Validator.password:
                  return passwordValidation(value.toString());
                case Validator.upi:
                  return upiValidation(value.toString());
                case Validator.price:
                  return priceValidation(value.toString());
                case Validator.date:
                  return dateValidation(value.toString());
                case Validator.minimumValueLimit:
                  return minimumValueValidation(
                      value.toString(), widget.minimumValueLimit);
                case Validator.minimumDecimalValueLimit:
                  return minimumDecimalValueValidation(
                      value.toString(), widget.minimumDecimalValueLimit);
                case Validator.watchlistValidator:
                  return charecterValidation(
                      value.toString(), widget.defaultErrorMessage);
                case Validator.editWatchlistValidator:
                  return editWatchNameValidation(
                      value.toString(), widget.defaultErrorMessage);
                default:
                  return emptyValidation(widget.controller.value.toString(),
                      widget.defaultErrorMessage);
              }
            },
            enabled: widget.enabled,
            style: customTextStyle(
                fontStyle: FontStyle.BodyL_Regular,
                color: FontColor.FontPrimary),
            decoration: InputDecoration(
              prefix: widget.prefixWidget,
              filled: true,
              helperText: '',
              suffix: widget.sufixWidget,
              suffixText: widget.suffixtext,
              fillColor: widget.enabled
                  ? widget.fillColor ?? customColors().backgroundPrimary
                  : customColors().backgroundSecondary,
              border: OutlineInputBorder(
                  borderSide: BorderSide(
                      color: widget.bordercolor ??
                          customColors().backgroundTertiary,
                      width: 1),
                  borderRadius: BorderRadius.circular(4.0)),
              hintText: widget.hintText,
              hintStyle: customTextStyle(
                  fontStyle: FontStyle.BodyL_Regular,
                  color: FontColor.FontTertiary),
              focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      color: widget.bordercolor ??
                          customColors().backgroundTertiary,
                      width: 1),
                  borderRadius: BorderRadius.circular(4.0)),
              enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      color: widget.bordercolor ??
                          customColors().backgroundTertiary,
                      width: 1),
                  borderRadius: BorderRadius.circular(4.0)),
              errorBorder: OutlineInputBorder(
                  borderSide:
                      BorderSide(color: customColors().danger, width: 1),
                  borderRadius: BorderRadius.circular(4.0)),
              disabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      color: customColors().backgroundTertiary, width: 1),
                  borderRadius: BorderRadius.circular(4.0)),
              focusedErrorBorder: OutlineInputBorder(
                  borderSide:
                      BorderSide(color: customColors().danger, width: 1),
                  borderRadius: BorderRadius.circular(4.0)),
              suffixIcon: widget.suffixIcon ??
                  ((widget.obscureIcon)
                      ? GestureDetector(
                          onTap: () {
                            setState(() {
                              contentVisibility = !contentVisibility;
                            });
                          },
                          child: contentVisibility
                              ? Image.asset('assets/vector_eye_cross.png')
                              : Image.asset('assets/vector_eye.png'))
                      : null),
              contentPadding:
                  const EdgeInsets.symmetric(vertical: 15, horizontal: 10),
            ),
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            widget.bottomStartWidget ?? Container(),
            widget.bottomEndWidget ?? Container(),
          ],
        ),
      ],
    );
  }
}

dynamic emptyValidation(String value, String errorString) {
  if (value.isEmpty || value == "") {
    return errorString;
  }
  return null;
}

dynamic noValidation(String value) {
  // return null;
}

dynamic dateValidation(String value) {
  if (value == "") {
    return "Date is required";
  } else if (value.length != 8 || !RegExp(r'^[0-9]+$').hasMatch(value)) {
    return "Incorrect date format";
  }
}

dynamic accountValidation(String value) {
  if (value == "") {
    return "Trade Code/CIN required";
  }
  // else if (value != "ADMIN") {
  //   return "Account doesnot exist";
  // }
}

dynamic passwordValidation(String value) {
  if (value == "") {
    return "Password required";
  }
  // else if (value != "admin") {
  //   return "Incorrect Password";
  // }
}

dynamic upiValidation(String value) {
  if (value.isEmpty) {
    return "UPI ID Required";
  }
}

dynamic priceValidation(String value) {
  if (value.isEmpty) {
    return "";
  }
}

dynamic minimumValueValidation(String value, int? minimumValue) {
  if (value.isEmpty ||
      (int.tryParse(value.replaceAll(",", ""))! < minimumValue!)) {
    return "minimum value is $minimumValue";
  }
}

dynamic minimumDecimalValueValidation(String value, double? minimumValue) {
  if (value.isEmpty ||
      (double.tryParse(value.replaceAll(",", ""))! < minimumValue!)) {
    return "Invalid value";
  }
}

dynamic charecterValidation(String value, String errorString) {
  if (value.isEmpty || value == "") {
    return errorString;
  } else if (UserController.userController.watchlists.any((element) =>
      element.watchlistData.watchname.toUpperCase() == value.toUpperCase())) {
    return errorString = "Already Existing Watch Name";
  }
  return null;
}

dynamic editWatchNameValidation(String value, String errorString) {
  if (value.isEmpty || value == "") {
    return errorString;
  } else if (GeneralMethods.checkWatchNameDuplication(watchname: value)) {
    return errorString = "Already Existing Watch Name";
  }
  return null;
}

enum Validator {
  none,
  defaultValidator,
  password,
  account,
  upi,
  price,
  date,
  minimumValueLimit,
  minimumDecimalValueLimit,
  watchlistValidator,
  editWatchlistValidator
}

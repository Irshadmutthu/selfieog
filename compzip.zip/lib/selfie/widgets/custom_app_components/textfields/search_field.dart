import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CommonSearchField extends StatefulWidget {
  final double width;
  final int count;
  final String hintText;
  final bool countVisibility;
  final void Function()? onTap;
  const CommonSearchField(
      {required this.width,
      this.count = 20,
      this.hintText = "Search & Add",
      this.countVisibility = true,
      this.onTap,
      Key? key})
      : super(key: key);

  @override
  _CommonSearchFieldState createState() => _CommonSearchFieldState();
}

class _CommonSearchFieldState extends State<CommonSearchField> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.width,
      height: 48,
      child: TextFormField(
        onTap: () => widget.onTap,
        autocorrect: true,
        decoration: InputDecoration(
          prefixIcon: ImageIcon(
            const AssetImage("assets/searchicon.png"),
            color: customColors().fontPrimary,
          ),
          suffixIcon: Visibility(
            visible: widget.countVisibility,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(0, 17, 11, 0),
              child: Text(
                "${widget.count.toString()}/50",
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: customColors().fontSecondary, fontSize: 12),
              ),
            ),
          ),
          hintText: widget.hintText,
          hintStyle:
              TextStyle(color: customColors().fontSecondary, fontSize: 12),
          filled: true,
          fillColor: customColors().backgroundSecondary,
          enabledBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(4.0)),
            borderSide: BorderSide(color: transparent, width: 0),
          ),
          focusedBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(4.0)),
            borderSide: BorderSide(color: transparent, width: 0),
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SymbolSearchField extends StatefulWidget {
  final String hintText;

  final _controller = TextEditingController();
  final void Function() onBackPressed;

  SymbolSearchField(
      {Key? key,
      this.hintText = " Search Eg: Nifty, Infy",
      required this.onBackPressed})
      : super(key: key);

  @override
  _SymbolSearchFieldState createState() => _SymbolSearchFieldState();
}

class _SymbolSearchFieldState extends State<SymbolSearchField> {
  bool _clearbtn = false;
  _enableClose() {
    setState(() {
      _clearbtn = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          IconButton(
            icon: ImageIcon(
              const AssetImage("assets/arrowleft.png"),
              color: customColors().fontPrimary,
            ),
            onPressed: widget.onBackPressed,
          ),
          Expanded(
            child: SizedBox(
              width: double.maxFinite,
              child: TextFormField(
                controller: widget._controller,
                decoration: InputDecoration(
                  hintText: widget.hintText,
                  hintStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_Regular,
                      color: FontColor.FontTertiary),
                  filled: true,
                  fillColor: customColors().backgroundPrimary,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                ),
                autocorrect: true,
                showCursor: true,
                cursorColor: customColors().fontPrimary,
                onTap: () => _enableClose(),
                style: customTextStyle(
                    fontStyle: FontStyle.BodyL_Regular,
                    color: FontColor.FontPrimary),
              ),
            ),
          ),
          Visibility(
            visible: _clearbtn,
            child: IconButton(
              icon: ImageIcon(const AssetImage("assets/close.png"),
                  color: customColors().fontPrimary),
              onPressed: () => widget._controller.clear(),
            ),
          ),
        ],
      ),
    );
  }
}

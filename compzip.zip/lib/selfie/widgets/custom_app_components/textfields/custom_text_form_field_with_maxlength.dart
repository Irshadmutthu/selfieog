import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CustomTextFormFieldWithMaxLength extends StatelessWidget {
  final int maxLength;
  final String? hintText;
  final TextEditingController controller;

  CustomTextFormFieldWithMaxLength({
    Key? key,
    required this.maxLength,
    this.hintText,
    required this.controller,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        padding: const EdgeInsets.only(left: 12.0, right: 14.0, bottom: 14.0),
        decoration: BoxDecoration(
            border:
                Border.all(width: 1, color: customColors().backgroundTertiary),
            borderRadius: BorderRadius.circular(4.0)),
        child: TextFormField(
            maxLength: maxLength,
            maxLines: 4,
            controller: controller,
            decoration:
                InputDecoration(border: InputBorder.none, hintText: hintText)));
  }
}

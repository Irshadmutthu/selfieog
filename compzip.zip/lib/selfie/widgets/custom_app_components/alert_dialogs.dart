import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

Future<dynamic> showAlertDilogue(
    {required BuildContext context,
    required String content,
    String? positiveButtonName,
    String? negativeButtonName,
    VoidCallback? onPositiveButtonClick,
    VoidCallback? onNegativeButtonClick}) async {
  return showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: customColors().backgroundPrimary,
          content: Text(
            content,
            style: customTextStyle(
                fontStyle: FontStyle.BodyM_SemiBold,
                color: FontColor.FontSecondary),
          ),
          actions: [
            if (negativeButtonName != null)
              TextButton(
                child: Text(
                  negativeButtonName,
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.Danger),
                ),
                onPressed: onNegativeButtonClick,
              ),
            TextButton(
              child: Text(
                positiveButtonName ?? "Ok",
                style: customTextStyle(
                    fontStyle: FontStyle.BodyM_SemiBold, color: FontColor.Info),
              ),
              onPressed: onPositiveButtonClick,
            ),
          ],
        );
      });
}

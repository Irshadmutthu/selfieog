import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CustomAppBarMain extends StatelessWidget {
  final String title;
  Function onTapTitle;
  final bool showTitleButton;
  final Widget? endIcon;
  CustomAppBarMain(
      {Key? key,
      required this.title,
      required this.onTapTitle,
      this.showTitleButton = false,
      this.endIcon})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 58,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: InkWell(
              highlightColor: transparent,
              splashColor: transparent,
              onTap: () {
                onTapTitle();
              },
              child: Padding(
                padding: const EdgeInsets.only(left: 16, right: 16),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(title,
                        textAlign: TextAlign.center,
                        style: customTextStyle(
                            fontStyle: FontStyle.HeaderS_Bold,
                            color: FontColor.FontPrimary)),
                    showTitleButton
                        ? Padding(
                            padding: const EdgeInsets.all(4),
                            child: ImageIcon(
                              const AssetImage("assets/filled_arrow.png"),
                              size: 24,
                              color: customColors().primary,
                            ),
                          )
                        : Container(),
                  ],
                ),
              ),
            ),
          ),
          endIcon ?? Container(),
        ],
      ),
    );
  }
}

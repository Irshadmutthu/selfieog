import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/watchlist/custom_watchlist_content/custom_watchlist_content.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CustomStockAppBar extends StatelessWidget {
  final String title;
  final String exchangeName;
  final isVisibleCahrtOption;
  final void Function() onBackPressed;
  final void Function()? onMoreActionPressed;
  final void Function()? onMarketOverviewPressed;
  CustomStockAppBar(
      {Key? key,
      required this.title,
      required this.exchangeName,
      this.isVisibleCahrtOption = true,
      required this.onBackPressed,
      this.onMoreActionPressed,
      this.onMarketOverviewPressed})
      : super(key: key);

  // Map<String,dynamic> actionColors(String action) {
  //   switch (action) {
  //     case 'NSE':
  //       {
  //         return {"textColor":FontColor.Purple,"boxColor":customColors().mattPurple};
  //       }

  //     case 'INDEX':
  //       {
  //         return  {"textColor":FontColor.FontSecondary,"boxColor":customColors().silverDust}; //const Color.fromRGBO(122, 130, 143, 1);
  //       }

  //     default:
  //       {
  //         return {"textColor":FontColor.Purple,"boxColor":customColors().mattPurple};
  //       }
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: customColors().backgroundPrimary,
      padding: const EdgeInsets.only(top: 15, bottom: 15, left: 5, right: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Padding(
                    padding: const EdgeInsets.only(right: 0),
                    child: IconButton(
                        onPressed: onBackPressed,
                        icon: const ImageIcon(
                            AssetImage("assets/arrow_left.png"),
                            size: 24))),
                if (title.contains("|"))
                  Column(
                    children: [
                      Row(
                        children: [
                          SymbolNameWidget(title),
                        ],
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      getProductTypeWidget(exchangeName),
                    ],
                  ),
                if (!title.contains("|"))
                  Expanded(
                    child: Row(
                      children: [
                        Flexible(
                          child: Text(title,
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary)),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        getProductTypeWidget(exchangeName),
                      ],
                    ),
                  ),
                const SizedBox(
                  width: 10,
                ),
                // Expanded(
                //   child: Column(
                //     crossAxisAlignment: CrossAxisAlignment.start,
                //     children: [
                //       Row(
                //         children: [
                //         ],
                //       ),

                //     ],
                //   ),
                // ),

                // Container(
                //   padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                //   decoration: BoxDecoration(
                //       color: actionColors(exchangeName).withOpacity(0.15),
                //       borderRadius: BorderRadius.circular(2)),
                //   child: Text(exchangeName,
                //       style: customTextStyle(
                //               fontStyle: FontStyle.TagNameL_SemiBold,
                //               color: FontColor.FontSecondary)
                //           .copyWith(color: actionColors(exchangeName))),
                // ),
              ],
            ),
          ),
          Row(
            children: [
              SizedBox(
                width: 30,
                child: IconButton(
                    padding: const EdgeInsets.all(0),
                    onPressed: onMoreActionPressed,
                    icon: const ImageIcon(AssetImage("assets/marketwatch.png"),
                        size: 24)),
              ),
              const SizedBox(width: 5),
              isVisibleCahrtOption
                  ? SizedBox(
                      width: 30,
                      child: IconButton(
                          padding: const EdgeInsets.all(0),
                          onPressed: onMarketOverviewPressed,
                          icon: const ImageIcon(AssetImage("assets/frame.png"),
                              size: 24)),
                    )
                  : const SizedBox(),
            ],
          ),
        ],
      ),
    );
  }
}

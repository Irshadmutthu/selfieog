import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class IpoAppBar extends StatelessWidget {
  String? title;
  Function()? iconPress;

  IpoAppBar({
    Key? key,
    this.iconPress,
    this.title,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: customColors().backgroundPrimary,
      height: 56,
      width: MediaQuery.of(context).size.width,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Padding(
              padding: const EdgeInsets.only(right: 12),
              child: IconButton(
                  onPressed: iconPress,
                  icon: const ImageIcon(AssetImage("assets/arrow_left.png"),
                      size: 24))),
          Text(
            title!,
            textAlign: TextAlign.center,
            style: customTextStyle(
                fontStyle: FontStyle.HeaderXS_SemiBold,
                color: FontColor.FontPrimary),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/watchlist/custom_watchlist_content/custom_watchlist_content.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

enum EndIcon { Save, Edit, Settings, Empty }

class CustomAppBarInner extends StatelessWidget {
  final String title;
  final void Function() onBackPressed;
  final void Function()? onEndIconPressed;
  final Widget? extraWidget;
  final EndIcon? endIcon;
  CustomAppBarInner(
      {Key? key,
      required this.title,
      required this.onBackPressed,
      this.extraWidget,
      this.endIcon,
      this.onEndIconPressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: IconButton(
                onPressed: onBackPressed,
                icon: const ImageIcon(AssetImage("assets/arrow_left.png"),
                    size: 24)),
            // child: ,
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    SymbolNameWidget(
                      title,
                    ),
                  ],
                ),
                if (extraWidget != null)
                  const SizedBox(
                    height: 8,
                  ),
                extraWidget ?? Container()
              ],
            ),
          ),

          endIcon == null || onEndIconPressed == null
              ? Container()
              : AppBarEndIcon(context, endIcon!, onEndIconPressed!),

          // SvgPicture.asset("assets/icons/app_bar/frame.svg", height: 24, width: 24,),
        ],
      ),
    );
  }
}

Widget AppBarEndIcon(
    BuildContext context, EndIcon endIcon, void Function() iconTrigger) {
  switch (endIcon) {
    case EndIcon.Save:
      return GestureDetector(
        onTap: iconTrigger,
        child: Padding(
          padding: const EdgeInsets.only(right: 16),
          child: Text("Save",
              style: customTextStyle(
                  fontStyle: FontStyle.HeaderXS_SemiBold,
                  color: FontColor.Primary)),
        ),
      );
    case EndIcon.Edit:
      return IconButton(
          onPressed: iconTrigger,
          icon: const ImageIcon(AssetImage("assets/icon.png"), size: 24));
    case EndIcon.Settings:
      return IconButton(
          onPressed: iconTrigger,
          icon: const ImageIcon(AssetImage("assets/settings.png"), size: 24));
    case EndIcon.Empty:
    default:
      return Container();
  }
}

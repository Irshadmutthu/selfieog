import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

enum EndIcon { Save, Edit, Settings, Empty }

class CustomAppBarOptionChain extends StatelessWidget {
  final String title, subtitle;
  final void Function() onBackPressed;
  final void Function()? onEndIconPressed;
  final void Function()? onEndIconPressedsecond;
  final Widget? extraWidget;
  final EndIcon? endIcon;
  final FontColor? fontColor;
  CustomAppBarOptionChain(
      {Key? key,
      required this.title,
      required this.subtitle,
      required this.onBackPressed,
      this.extraWidget,
      this.endIcon,
      this.onEndIconPressed,
      this.fontColor,
      this.onEndIconPressedsecond})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.only(right: 12),
                child: IconButton(
                    onPressed: onBackPressed,
                    icon: const ImageIcon(AssetImage("assets/arrow_left.png"),
                        size: 24)),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      textAlign: TextAlign.center,
                      style: customTextStyle(
                          fontStyle: FontStyle.HeaderXS_SemiBold,
                          color: FontColor.FontPrimary)),
                  Text(subtitle,
                      textAlign: TextAlign.center,
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: fontColor)),
                ],
              ),
            ],
          ),

          AppBarEndIcon(context, onEndIconPressed!, onEndIconPressed!),

          // SvgPicture.asset("assets/icons/app_bar/frame.svg", height: 24, width: 24,),
        ],
      ),
    );
  }
}

Widget AppBarEndIcon(BuildContext context, void Function() iconTriggercalender,
    void Function() iconTriggerchart) {
  return Container(
    child: Row(
      children: [
        IconButton(
            onPressed: iconTriggercalender,
            icon: const ImageIcon(AssetImage("assets/calendar.png"), size: 24)),
        IconButton(
            onPressed: iconTriggerchart,
            icon: const ImageIcon(AssetImage("assets/frame.png"), size: 24))
      ],
    ),
  );
}

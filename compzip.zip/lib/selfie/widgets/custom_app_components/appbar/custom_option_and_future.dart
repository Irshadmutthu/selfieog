import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/watchlist/custom_watchlist_content/custom_watchlist_content.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CustomOptionAndFutureAppBar extends StatelessWidget {
  final String title;
  final String exchangeName;

  final void Function() onBackPressed;
  final void Function()? onMoreActionPressed;

  CustomOptionAndFutureAppBar({
    Key? key,
    required this.title,
    required this.exchangeName,
    required this.onBackPressed,
    this.onMoreActionPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: customColors().backgroundPrimary,
      padding: const EdgeInsets.only(top: 15, bottom: 15, right: 16, left: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Padding(
              padding: const EdgeInsets.only(right: 12),
              child: IconButton(
                  onPressed: onBackPressed,
                  icon: const ImageIcon(AssetImage("assets/arrow_left.png"),
                      size: 24))),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    SymbolNameWidget(title),
                  ],
                ),
                const SizedBox(height: 2),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(right: 8.0),
                      child: getProductTypeWidget(exchangeName),
                    ),
                  ],
                )
              ],
            ),
          ),
          const SizedBox(width: 10),
          SizedBox(
            width: 30,
            child: IconButton(
                padding: EdgeInsets.all(0),
                onPressed: onMoreActionPressed,
                icon: const ImageIcon(AssetImage("assets/marketwatch.png"),
                    size: 24)),
          ),
        ],
      ),
    );
  }
}

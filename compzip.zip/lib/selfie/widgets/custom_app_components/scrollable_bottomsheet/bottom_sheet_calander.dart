import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_calander/table_basic.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CustommCalandarWithFromAndToDateSheet extends StatefulWidget {
  final void Function(DateTime from, DateTime toDate)? onDone;
  CustommCalandarWithFromAndToDateSheet(
      {Key? key,
      required this.onDone})
      : super(key: key);
  @override
  State<CustommCalandarWithFromAndToDateSheet> createState() => _CustommCalandarWithFromAndToDateSheetState();
}

class _CustommCalandarWithFromAndToDateSheetState extends State<CustommCalandarWithFromAndToDateSheet> {
  int selection = 1;
  DateTime? fromDate;
  DateTime? toDate;
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              Expanded(
                  child: GestureDetector(
                onTap: () {
                  setState(() {
                    selection = 1;
                  });
                },
                child: Container(
                  alignment: Alignment.center,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
                  decoration: BoxDecoration(
                    border: selection == 1
                        ? Border.all(width: 1.5, color: customColors().primary)
                        : Border.all(
                            width: 1, color: customColors().backgroundTertiary),
                    borderRadius: const BorderRadius.horizontal(
                        left: Radius.circular(4.0)),
                  ),
                  child: Row(
                    children: [
                      Row(
                        children: [
                          Text("From",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyS_Regular,
                                  color: FontColor.FontSecondary)),
                          const SizedBox(
                            width: 8,
                          ),
                          Text("-",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontSecondary))
                        ],
                      ),
                      Expanded(
                        child: Center(
                          child: Text(
                              fromDate == null
                                  ? ""
                                  :DateFormat("dd/MM/yyyy").format(fromDate!),
                                  //  fromDate!.day.toString() +" / "+
                                  //     fromDate!.month.toString() +" / "+
                                  //     fromDate!.year.toString(),
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyS_Regular,
                                  color: FontColor.FontSecondary)),
                        ),
                      )
                    ],
                  ),
                ),
              )),
              Expanded(
                  child: GestureDetector(
                onTap: () {
                  setState(() {
                    selection = 2;
                  });
                },
                child: Container(
                  alignment: Alignment.center,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
                  decoration: BoxDecoration(
                    border: selection == 2
                        ? Border.all(width: 1.5, color: customColors().primary)
                        : Border.all(
                            width: 1, color: customColors().backgroundTertiary),
                    borderRadius: const BorderRadius.horizontal(
                        right: Radius.circular(4.0)),
                  ),
                  child: Row(
                    children: [
                      Row(
                        children: [
                          Text("To",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyS_Regular,
                                  color: FontColor.FontSecondary)),
                          const SizedBox(
                            width: 8,
                          ),
                          Text("-",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontSecondary))
                        ],
                      ),
                      Expanded(
                        child: Center(
                          child: Text(
                              toDate == null
                                  ? ""
                                  :DateFormat("dd/MM/yyyy").format(toDate!),
                                  //  toDate!.day.toString() +" / "+
                                  //     toDate!.month.toString() +" / "+
                                  //     toDate!.year.toString(),
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyS_Regular,
                                  color: FontColor.FontSecondary)),
                        ),
                      )
                    ],
                  ),
                ),
              )),
            ],
          ),
        ),
        Container(
          height: 1,
          color: customColors().backgroundTertiary,
        ),
        TableBasicSelection(
          onDateSelected: (DateTime selectedDate) {
              if (selection == 1) {
                fromDate = selectedDate;
              } else if (selection == 2) {
                toDate = selectedDate;
              }
            setState(() {});
          },
        ),
        Container(
          height: 1,
          color: customColors().backgroundTertiary,
        ),
        Padding(
          padding: const EdgeInsets.only(
              left: 16.0, bottom: 9.0, top: 11.0, right: 16.0),
          child: Row(
            children: [
              Expanded(
                child: BasketButton(
                  bordercolor: customColors().primary,
                  text: "Cancel",
                  textStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_Bold,
                      color: FontColor.Primary),
                  onpress: () {
                    Navigator.of(context).pop(true);
                  },
                ),
              ),
              SizedBox(
                width: 8,
              ),
              Expanded(
                child: BasketButton(
                  bordercolor: transparent,
                  bgcolor: fromDate != null && toDate != null ? customColors().primary : customColors().primary.withOpacity(0.4),
                  text: "Done",
                  textStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
                  onpress: () {
                      if (fromDate != null && toDate != null) {
                        widget.onDone!(fromDate!, toDate!);
                        Navigator.of(context).pop(true);
                      }
                    
                  },
                ),
              )
            ],
          ),
        )
      ],
    );
  }
}

class CustommCalandarSheet extends StatefulWidget {
  final void Function(DateTime date) onDone;
  CustommCalandarSheet(
      {Key? key,
      required this.onDone})
      : super(key: key);
  @override
  State<CustommCalandarSheet> createState() => _CustommCalandarSheetState();
}

class _CustommCalandarSheetState extends State<CustommCalandarSheet> {
  DateTime? date;
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TableBasicSelection(
          onDateSelected: (DateTime selectedDate) {
            date = selectedDate;
            setState(() {});
          },
        ),
        Container(
          height: 1,
          color: customColors().backgroundTertiary,
        ),
        Padding(
          padding: const EdgeInsets.only(
              left: 16.0, bottom: 9.0, top: 11.0, right: 16.0),
          child: Row(
            children: [
              Expanded(
                child: BasketButton(
                  bordercolor: customColors().primary,
                  text: "Cancel",
                  textStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_Bold,
                      color: FontColor.Primary),
                  onpress: () {
                    Navigator.of(context).pop(true);
                  },
                ),
              ),
              SizedBox(
                width: 8,
              ),
              Expanded(
                child: BasketButton(
                  bordercolor: transparent,
                  bgcolor: date != null ? customColors().primary : customColors().primary.withOpacity(0.4),
                  text: "Done",
                  textStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
                  onpress: () {
                      if (date != null) {
                        widget.onDone(date!);
                        Navigator.of(context).pop(true);
                      }
                  },
                ),
              )
            ],
          ),
        )
      ],
    );
  }
}

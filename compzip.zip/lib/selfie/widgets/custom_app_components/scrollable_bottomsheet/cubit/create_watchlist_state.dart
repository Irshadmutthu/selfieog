part of 'create_watchlist_cubit.dart';

@immutable
abstract class CreateWatchlistState {}

class CreateWatchlistInitial extends CreateWatchlistState {}

class CreateWatchlistError extends CreateWatchlistState {
  final int errorCode;
  final String errorMessage;

  CreateWatchlistError({required this.errorCode, required this.errorMessage});
}

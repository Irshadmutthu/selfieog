import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_all_watchlist/bloc/my_watch_list/my_watchlist_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/cubit/create_watchlist_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/formatters.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/watchlist/bottom_sheet/watchlist_bottomsheet.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';
import 'package:trading_api/responses/error_response.dart';

class CreateWatchlist extends StatefulWidget {
  final ServiceLocator serviceLocator;
  Function(int?)? onViewWatchlistPressed;
  CreateWatchlist(
      {Key? key, required this.serviceLocator, this.onViewWatchlistPressed})
      : super(key: key);

  @override
  State<CreateWatchlist> createState() => _CreateWatchlistState();
}

class _CreateWatchlistState extends State<CreateWatchlist> {
  TextEditingController watchlistController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text("Set name for your watchlist",
                style: customTextStyle(
                    fontStyle: FontStyle.HeaderXS_SemiBold,
                    color: FontColor.FontPrimary)),
          ),
          Divider(
            thickness: 1,
            color: customColors().backgroundTertiary,
          ),
          Padding(
            padding: const EdgeInsets.only(
                left: 16.0, right: 16, bottom: 0, top: 15),
            child: SizedBox(
              height: 98,
              child: CustomTextFormField(
                keyboardType: TextInputType.name,
                textCapitalization: TextCapitalization.sentences,
                controller: watchlistController,
                autoFocus: true,
                fieldName: "Watchlist Name",
                hintText: " Enter watchlist name",
                bordercolor: customColors().backgroundTertiary,
                validator: Validator.watchlistValidator,
                defaultErrorMessage: " Watchlist name cannot be empty",
                labelBottomPadding: 8,
                inputFormatter: [
                  LengthLimitingTextInputFormatter(20),
                ],
                topEndWidget: Text(
                  "${watchlistController.text.length}/20",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_Regular,
                      color: FontColor.FontTertiary),
                ),
                onChange: (value) {
                  setState(() {});
                  if (_formKey.currentState!.validate()) return;
                },
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(
                left: 16.0, bottom: 9.0, top: 9.0, right: 16.0),
            child: Row(
              children: [
                Expanded(
                  child: BasketButton(
                    bordercolor: customColors().primary,
                    text: "Cancel",
                    textStyle: customTextStyle(
                        fontStyle: FontStyle.BodyL_Bold,
                        color: FontColor.Primary),
                    onpress: () {
                      Navigator.of(context).pop(true);
                    },
                  ),
                ),
                const SizedBox(width: 8),
                BlocProvider(
                  create: (context) => CreateWatchlistCubit(
                      serviceLocator: widget.serviceLocator),
                  child:
                      BlocBuilder<CreateWatchlistCubit, CreateWatchlistState>(
                    builder: (context, state) {
                      return Expanded(
                        child: BasketButton(
                          bordercolor: transparent,
                          bgcolor: customColors().primary,
                          text: "Create",
                          textStyle: customTextStyle(
                              fontStyle: FontStyle.BodyL_Bold,
                              color: FontColor.White),
                          onpress: () async {
                            watchlistController.text =
                                watchlistController.text.trim();
                            // if (UserController.userController.watchlists.any(
                            //     (element) =>
                            //         element.watchlistData.watchname ==
                            //         watchlistController.text)) {
                            //   ScaffoldMessenger.of(context).clearSnackBars();
                            //   ScaffoldMessenger.of(context).showSnackBar(
                            //       showWaringDialogue(
                            //           errorMessage:
                            //               "Already Existing Watch Name"));
                            //   return;
                            // }

                            if (_formKey.currentState!.validate()) {
                              watchlistController.text =
                                  watchlistController.text.replaceFirst(
                                      watchlistController.text[0],
                                      watchlistController.text[0]
                                          .toUpperCase());
                              int newSortorder = generateSortOrder();
                              ErrorResponse watchlistResponse =
                                  await BlocProvider.of<CreateWatchlistCubit>(
                                          context)
                                      .sendWatchlistCreateRequest(
                                          context: context,
                                          watchlistName:
                                              watchlistController.text,
                                          sortOrder: newSortorder);

                              if (watchlistResponse.errorCode == null) {
                                return;
                              } else if (watchlistResponse
                                      .result2!.isNotEmpty &&
                                  watchlistResponse.result2![0].errorcode ==
                                      "0") {
                                Navigator.of(context).pop(true);
                                customCreateModalBottomSheet(
                                  context: context,
                                  inputWidget: SavedWatchlist(
                                    serviceLocator: widget.serviceLocator,
                                    updateIndex: newSortorder - 1,
                                    // onViewWatchlistPressed: widget.onViewWatchlistPressed!(newSortorder-1),
                                    viewWatchlistStatus: (status) {
                                      if (status == true) {
                                        widget.onViewWatchlistPressed!(
                                            UserController.userController
                                                    .watchlists.length -
                                                1);
                                      }
                                    },
                                  ),
                                );
                              } else {}
                            }
                          },
                        ),
                      );
                    },
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  generateSortOrder() {
    return int.parse(UserController.userController.watchlists
            .reduce((a, b) => int.parse(a.watchlistData.sortorder) >
                    int.parse(b.watchlistData.sortorder)
                ? a
                : b)
            .watchlistData
            .sortorder) +
        1;
  }
}

class SavedWatchlist extends StatelessWidget {
  final ServiceLocator serviceLocator;
  int updateIndex;
  Function(bool?)? viewWatchlistStatus;
  SavedWatchlist(
      {Key? key,
      required this.serviceLocator,
      required this.updateIndex,
      this.viewWatchlistStatus})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        SizedBox(
          height: 40,
        ),
        Image.asset("assets/Tick.png"),
        SizedBox(
          height: 20,
        ),
        Text(
          "Watchlist Saved!",
          style: customTextStyle(
              fontStyle: FontStyle.HeaderS_SemiBold,
              color: FontColor.FontPrimary),
        ),
        SizedBox(
          height: 20,
        ),
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              Expanded(
                child: BasketButton(
                  bordercolor: customColors().primary,
                  text: "Done",
                  textStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_Bold,
                      color: FontColor.Primary),
                  onpress: () {
                    Navigator.of(context).pop();
                  },
                ),
              ),
              SizedBox(
                width: 8,
              ),
              BlocProvider(
                create: (context) =>
                    MyWatchlistCubit(serviceLocator: serviceLocator),
                child: BlocBuilder<MyWatchlistCubit, MyWatchlistState>(
                  builder: (context, state) {
                    return Expanded(
                      child: BasketButton(
                        bordercolor: transparent,
                        bgcolor: customColors().primary,
                        text: "View Watchlist",
                        textStyle: customTextStyle(
                            fontStyle: FontStyle.BodyL_Bold,
                            color: FontColor.White),
                        onpress: () {
                          viewWatchlistStatus!(true);
                          //   BlocProvider.of<MyWatchlistCubit>(context)
                          //       .updatelist(updateIndex);
                          //   Navigator.of(context).pop(true);
                        },
                      ),
                    );
                  },
                ),
              )
            ],
          ),
        )
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SelectBasketWidget extends StatelessWidget {
  List<Map<String, dynamic>> basketList;
  String title;
  AnimationController? controller;
  FontStyle basketnameFont;
  FontColor basketnameFontColor;
  final VoidCallback? onButtonPressAction;

  SelectBasketWidget(
      {Key? key,
      required this.basketList,
      this.title = "Select a Basket",
      this.controller,
      this.basketnameFont = FontStyle.BodyL_Regular,
      this.basketnameFontColor = FontColor.FontPrimary,
      this.onButtonPressAction})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 16.0, bottom: 12, top: 12),
          child: Text("$title",
              style: customTextStyle(
                  fontStyle: FontStyle.HeaderXS_SemiBold,
                  color: FontColor.FontPrimary)),
        ),
        Divider(
          height: 0,
          thickness: 1,
          color: customColors().backgroundTertiary,
        ),
        for (int index = 0; index < basketList.length; index++)
          TextButton(
              // padding: EdgeInsets.only(left: 16,top: 14,bottom: 14),
              onPressed: () {
                Navigator.of(context).pop(true);
                customShowModalBottomSheet(
                    context: context,
                    // inputWidget: addedBasketWidget(),
                    inputWidget: AddedBasketWidget(),
                    controller: controller);
              },
              child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    "${basketList[index]["name"]}",
                    style: customTextStyle(
                        fontStyle: basketnameFont, color: basketnameFontColor),
                  ))),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: InkWell(
            onTap: () {
              // Navigator.of(context).pop(true);
              onButtonPressAction;
              customShowModalBottomSheet(
                  context: context,
                  inputWidget: CreateBasketWidget(
                      controller: controller, title: "Create Basket"),
                  // inputWidget: createBasketWidget(),
                  controller: controller);
            },
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Icon(
                  Icons.add,
                  size: 20,
                  color: customColors().primary,
                ),
                Text(
                  " Create Custom",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyL_SemiBold,
                      color: FontColor.Primary),
                )
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class CreateBasketWidget extends StatelessWidget {
  AnimationController? controller;
  String title;
  CreateBasketWidget(
      {Key? key, this.controller, this.title = "Create Custom Basket"})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    TextEditingController basketController = new TextEditingController();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text("$title",
              style: customTextStyle(
                  fontStyle: FontStyle.HeaderXS_SemiBold,
                  color: FontColor.FontPrimary)),
        ),
        Divider(
          height: 0,
          thickness: 1,
          color: customColors().backgroundTertiary,
        ),
        Padding(
          padding: EdgeInsets.only(left: 16.0, right: 16, bottom: 14, top: 16),
          child: CustomTextFormField(
            controller: basketController,
            fieldName: "Basket Name",
            hintText: " Enter Basket name",
            bordercolor: customColors().backgroundTertiary,
            validator: Validator.none,
            labelBottomPadding: 8,
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(
              left: 16.0, bottom: 9.0, top: 14, right: 16.0),
          child: BasketButton(
            bordercolor: transparent,
            bgcolor: customColors().primary,
            text: "Create",
            textStyle: customTextStyle(
                fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
            onpress: () {
              Navigator.of(context).pop(true);
              customShowModalBottomSheet(
                  context: context,
                  inputWidget: SavedBasketWidget(),
                  // inputWidget: savedBasketWidget(),
                  controller: controller);
            },
          ),
        ),
      ],
    );
  }
}

class SavedBasketWidget extends StatelessWidget {
  const SavedBasketWidget({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        SizedBox(
          height: 40,
        ),
        Image.asset("assets/Tick.png"),
        SizedBox(
          height: 16,
        ),
        Text(
          "Basket Saved",
          style: customTextStyle(
              fontStyle: FontStyle.HeaderS_SemiBold,
              color: FontColor.FontPrimary),
        ),
        SizedBox(
          height: 16,
        ),
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              Expanded(
                child: BasketButton(
                  bordercolor: customColors().primary,
                  text: "Done",
                  textStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_SemiBold,
                      color: FontColor.Primary),
                  onpress: () {
                    Navigator.of(context).pop(true);
                  },
                ),
              ),
              SizedBox(
                width: 8,
              ),
              Expanded(
                child: BasketButton(
                  bordercolor: transparent,
                  bgcolor: customColors().primary,
                  text: "View Basket",
                  textStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
                  onpress: () {
                    Navigator.of(context).pop(true);
                  },
                ),
              )
            ],
          ),
        ),
      ],
    );
  }
}

class AddedBasketWidget extends StatelessWidget {
  const AddedBasketWidget({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        SizedBox(
          height: 40,
        ),
        Image.asset("assets/Tick.png"),
        SizedBox(
          height: 16,
        ),
        Text(
          "Added to Basket",
          style: customTextStyle(
              fontStyle: FontStyle.HeaderS_SemiBold,
              color: FontColor.FontPrimary),
        ),
        SizedBox(
          height: 16,
        ),
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              Expanded(
                child: BasketButton(
                  bordercolor: customColors().primary,
                  text: "Done",
                  textStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_SemiBold,
                      color: FontColor.Primary),
                  onpress: () {
                    Navigator.of(context).pop(true);
                  },
                ),
              ),
              SizedBox(
                width: 8,
              ),
              Expanded(
                child: BasketButton(
                  bordercolor: transparent,
                  bgcolor: customColors().primary,
                  text: "View Basket",
                  textStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
                  onpress: () {
                    Navigator.of(context).pop(true);
                  },
                ),
              )
            ],
          ),
        )
      ],
    );
  }
}

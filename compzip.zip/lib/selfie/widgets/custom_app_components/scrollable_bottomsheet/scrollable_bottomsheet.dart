import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/portfolio_model/Portfolio.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_option_chain/components/edit_present_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/my_portfolio/bloc/my_position_screen_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/my_portfolio/bloc/position_screen_state.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/my_portfolio/tab_component_holdings/bloc/holdings_component_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/stock_bottom_sheet_header.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

customBottomSheet(
    {required BuildContext context,
    required Widget inputWidget,
    double? height,
    AnimationController? controller,
    bool ifport = false,
    Widget? fixedBottomWidget,
    double? minimumHeight,
    double? maxHeight,
    Map<String, dynamic>? portfoliolist,
    List<HoldingModel> holdinglist = const [],
    int index = 0,
    double ltp = 0.0,
    double percentage = 0.0,
    double change = 0.0}) {
  return showModalBottomSheet(
      transitionAnimationController: controller,
      isDismissible: true,
      isScrollControlled: true,
      clipBehavior: Clip.antiAlias,
      backgroundColor: customColors().backgroundPrimary,
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(8.0),
          topRight: Radius.circular(8.0),
        ),
      ),
      builder: (BuildContext buildContext) {
        return DraggableScrollableSheet(
          initialChildSize:
              height ?? .4, // you can add height between 0.4 - 0.97
          maxChildSize: maxHeight ?? .95,
          minChildSize: minimumHeight ?? .4,
          expand: false,
          builder:
              (BuildContext buildContext, ScrollController scrollController) {
            return Scaffold(
              appBar: PreferredSize(
                  preferredSize: Size.fromHeight(0.0),
                  child: AppBar(
                    elevation: 0,
                  )),
              body: SizedBox(
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 9),
                  child: Column(
                    children: [
                      ifport
                          ? Stack(
                              children: [
                                BlocProvider.value(
                                  value:
                                      BlocProvider.of<HoldingsComponentCubit>(
                                          context),
                                  child: BlocBuilder<HoldingsComponentCubit,
                                          HoldingsComponentState>(
                                      builder: (context, state) {
                                    if (state is HoldingsComponentInitial) {
                                      return Stock_Sheet_Header(
                                        bgcolor:
                                            customColors().backgroundSecondary,
                                        ltp: state.myholdinglist[index]
                                            .instrument.lastTrdPrice
                                            .toStringAsFixed(state
                                                .myholdinglist[index]
                                                .instrument
                                                .precision),
                                        producttype:
                                            holdinglist[index].producttype,
                                        symbol: holdinglist[index]
                                            .instrument
                                            .securityCode,
                                        per_change: state.myholdinglist[index]
                                            .instrument.changePrice
                                            .toStringAsFixed(state
                                                .myholdinglist[index]
                                                .instrument
                                                .precision),
                                        change_per: state.myholdinglist[index]
                                            .instrument.percChange
                                            .toStringAsFixed(state
                                                .myholdinglist[index]
                                                .instrument
                                                .precision),
                                        net_pos: "",
                                        exchange: state.myholdinglist[index]
                                            .instrument.venuecode,
                                      );
                                    }
                                    return Container();
                                  }),
                                ),
                                Align(
                                  alignment: Alignment.topCenter,
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 11),
                                    child: Container(
                                      decoration: BoxDecoration(
                                          color: customColors().fontTertiary,
                                          borderRadius:
                                              BorderRadius.circular(100)),
                                      height: 5,
                                      width: 64,
                                    ),
                                  ),
                                )
                              ],
                            )
                          : Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Padding(
                                  padding:
                                      const EdgeInsets.only(top: 10, bottom: 5),
                                  child: Container(
                                    decoration: BoxDecoration(
                                        color:
                                            customColors().backgroundTertiary,
                                        borderRadius:
                                            BorderRadius.circular(100)),
                                    height: 4,
                                    width: 64,
                                  ),
                                ),
                              ],
                            ),
                      Expanded(
                        child: SizedBox(
                          child: ListView(
                            controller: scrollController,
                            children: [
                              inputWidget,
                            ],
                          ),
                        ),
                      ),
                      fixedBottomWidget ?? const SizedBox(),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      });
}

PositionShowModalBottomSheet({
  required BuildContext context,
  required Widget inputWidget,
  AnimationController? controller,
  bool ifport = false,
  int index = 0,
  String? stock,
  String? productType,
  String? ltp,
  String? symbolname,
  String? pl,
  String? change_percentage,
  String? net_pos,
}) {
  return showModalBottomSheet<void>(
      isScrollControlled: true,
      context: context,
      transitionAnimationController: controller,
      enableDrag: true,
      constraints:
          BoxConstraints(maxHeight: MediaQuery.of(context).size.height * .9),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(8.0),
          topRight: Radius.circular(8.0),
        ),
      ),
      builder: (BuildContext buildcontext) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.only(bottom: 0),
            child: SingleChildScrollView(
              child: AnimatedPadding(
                  padding: MediaQuery.of(context).viewInsets,
                  duration: const Duration(milliseconds: 100),
                  curve: Curves.decelerate,
                  child: Column(
                    children: [
                      Stack(
                        children: [
                          BlocProvider.value(
                            value:
                                BlocProvider.of<MyPositionScreenCubit>(context),
                            child: BlocBuilder<MyPositionScreenCubit,
                                PositionScreenState>(builder: (context, state) {
                              if (state is MyPositionScreenInitial) {
                                return Stock_Sheet_Header(
                                  bgcolor: customColors().backgroundSecondary,
                                  ltp: state.positionlist[index].instrument
                                      .lastTrdPrice
                                      .toStringAsFixed(state.positionlist[index]
                                          .instrument.precision),
                                  producttype: productType ?? "",
                                  symbol: symbolname.toString(),
                                  per_change: state.positionlist[index]
                                      .instrument.changePrice
                                      .toString(),
                                  net_pos: net_pos.toString(),
                                  change_per: double.parse(state
                                              .positionlist[index]
                                              .instrument
                                              .percChange
                                              .toString())
                                          .isNaN
                                      ? "0.00"
                                      : double.parse(state.positionlist[index]
                                              .instrument.percChange
                                              .toString())
                                          .toStringAsFixed(state
                                              .positionlist[index]
                                              .instrument
                                              .precision)
                                          .toString(),
                                  exchange: state
                                      .positionlist[index].instrument.venuecode
                                      .toString(),
                                );
                              } else {
                                return Container();
                              }
                            }),
                          ),
                          Align(
                            alignment: Alignment.topCenter,
                            child: Padding(
                              padding: const EdgeInsets.symmetric(vertical: 11),
                              child: Container(
                                decoration: BoxDecoration(
                                    color: customColors().backgroundTertiary,
                                    borderRadius: BorderRadius.circular(100)),
                                height: 4,
                                width: 64,
                              ),
                            ),
                          )
                        ],
                      ),
                      inputWidget,
                    ],
                  )),
            ),
          ),
        );
      });
}

customShowModalBottomSheet({
  required BuildContext context,
  required Widget inputWidget,
  AnimationController? controller,
  bool ifport = false,
  int index = 0,
  String? stock,
  String? productType,
  String? ltp,
  String? symbolname,
  String? pl,
  String? change_percentage,
  String? net_pos,
}) {
  return showModalBottomSheet<void>(
      isScrollControlled: true,
      context: context,
      transitionAnimationController: controller,
      enableDrag: true,
      constraints:
          BoxConstraints(maxHeight: MediaQuery.of(context).size.height * .9),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(8.0),
          topRight: Radius.circular(8.0),
        ),
      ),
      builder: (BuildContext buildcontext) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.only(bottom: 0),
            child: SingleChildScrollView(
              child: AnimatedPadding(
                  padding: MediaQuery.of(context).viewInsets,
                  duration: const Duration(milliseconds: 100),
                  curve: Curves.decelerate,
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 11),
                        child: Container(
                          decoration: BoxDecoration(
                              color: customColors().backgroundTertiary,
                              borderRadius: BorderRadius.circular(100)),
                          height: 4,
                          width: 64,
                        ),
                      ),
                      inputWidget,
                    ],
                  )),
            ),
          ),
        );
      });
}

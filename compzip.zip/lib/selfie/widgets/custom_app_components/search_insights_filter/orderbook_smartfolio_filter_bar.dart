import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SearchFilterHoldings extends StatefulWidget {
  final VoidCallback? onSearchPress;
  final VoidCallback? onFilterPress;
  // final bool showBubble;
  // final bool showFilter;
  // final bool showInsights;

  const SearchFilterHoldings({
    Key? key,
    // this.showBubble = false,
    // this.showFilter = true,
    // this.showInsights = true,
    this.onSearchPress,
    this.onFilterPress,
  }) : super(key: key);
  @override
  State<SearchFilterHoldings> createState() => _SearchFilterHoldingsState();
}

class _SearchFilterHoldingsState extends State<SearchFilterHoldings> {
  @override
  Widget build(BuildContext context) {
    TextStyle styles = customTextStyle(
        fontStyle: FontStyle.BodyL_Regular, color: FontColor.FontSecondary);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          InkWell(
            onTap: widget.onSearchPress,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                CUstomSerchBarImages(imagPath: "assets/search.png", context: context),
                // Image.asset(
                //   "assets/search.png",
                //   color: customColors().fontPrimary,
                //   height: 20,
                //   width: 20,
                // ),
                const SizedBox(
                  width: 6,
                ),
                Text(
                  "Search",
                  style: styles,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class CUstomSerchBarImages extends StatelessWidget {
  const CUstomSerchBarImages({
    Key? key,
    required this.imagPath,
    required this.context,
  }) : super(key: key);

  final String imagPath;
  final BuildContext context;

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      imagPath,
      color: customColors().fontPrimary,
      height: 16,
      width: 16,
    );
  }
}



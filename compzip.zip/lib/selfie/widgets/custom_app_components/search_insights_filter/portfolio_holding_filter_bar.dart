import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/custom_image_icon.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/order_book_open_filter_bar.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SearchFilterHoldings extends StatefulWidget {
  final VoidCallback? onSearchPress;
  final VoidCallback? onFilterPress;
  final VoidCallback? onSortPress;
  final VoidCallback? onInsights;
  final bool showBubble;
  final bool showFilter;
  final bool showInsights;
  final bool showBubbleSort;
  const SearchFilterHoldings({
    Key? key,
    this.showBubble = false,
    this.showFilter = true,
    this.showInsights = true,
    this.showBubbleSort = false,
    this.onSearchPress,
    this.onFilterPress,
    this.onSortPress,
    this.onInsights,
  }) : super(key: key);
  @override
  State<SearchFilterHoldings> createState() => _SearchFilterHoldingsState();
}

class _SearchFilterHoldingsState extends State<SearchFilterHoldings> {
  @override
  Widget build(BuildContext context) {
    TextStyle styles = customTextStyle(
        fontStyle: FontStyle.BodyL_Regular, color: FontColor.FontSecondary);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          InkWell(
            onTap: widget.onSearchPress,
            child: Container(
              width: 160.0,
              height: 35.0,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Expanded(
                      child: Row(
                    children: [
                      CustomImageIcon(imagPath: "assets/search.png"),
                      const SizedBox(
                        width: 6,
                      ),
                      Text(
                        "Search",
                        style: styles,
                      ),
                      const SizedBox(
                        width: 4,
                      ),
                    ],
                  )),
                ],
              ),
            ),
          ),

          // Expanded(
          //   child: InkWell(
          //     onTap: widget.onSearchPress,
          //     child: Container(
          //       width: 250.0,
          //       height: 35.0,
          //       color: Colors.amber,
          //       child: Row(
          //         mainAxisAlignment: MainAxisAlignment.start,
          //         children: [
          //           Expanded(
          //               child: Row(
          //             children: [
          //               CustomImageIcon(imagPath: "assets/search.png"),
          //               const SizedBox(
          //                 width: 6,
          //               ),
          //               Text(
          //                 "Search",
          //                 style: styles,
          //               ),
          //               const SizedBox(
          //                 width: 4,
          //               ),
          //             ],
          //           )),
          //         ],
          //       ),
          //     ),
          //   ),

          // ),
          Expanded(
            child: widget.showInsights
                ? Visibility(
                    visible: widget.showInsights,
                    child: InkWell(
                        onTap: widget.onInsights,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            CustomImageIcon(imagPath: "assets/graph.png"),
                            const SizedBox(
                              width: 6,
                            ),
                            Text(
                              "Insights",
                              style: styles,
                            ),
                          ],
                        )),
                  )
                : SizedBox(
                    width: MediaQuery.of(context).size.width * 0.13,
                    height: 5,
                  ),
          ),
          Expanded(
            child: InkWell(
              onTap: widget.onFilterPress,
              child: Container(
                width: 70.0,
                height: 35.0,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Stack(
                        alignment: Alignment.topRight,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(top: 1, right: 1),
                            child: CUstomSerchBarImages(
                                imagPath: "assets/filter_new.png",
                                context: context),
                          ),
                          if (widget.showBubble)
                            Container(
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: customColors().accent)),
                        ],
                      ),
                    ),
                    const SizedBox(
                      width: 6,
                    ),
                    Text(
                      "Filter",
                      style: styles,
                    ),
                  ],
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 12.0),
            child: Container(
              width: 70.0,
              height: 35.0,
              child: InkWell(
                onTap: widget.onSortPress,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Stack(
                      alignment: Alignment.topRight,
                      children: [
                        Container(
                            height: 20.0,
                            child:
                                CustomImageIcon(imagPath: "assets/sort.png")),
                        if (widget.showBubbleSort)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 5, left: 17),
                            child: Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: customColors().accent),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(
                      width: 4,
                    ),
                    Text(
                      "Sort",
                      style: styles,
                    ),
                  ],
                ),
              ),
            ),
          ),

          // widget.showFilter
          //     ? Visibility(
          //         visible: widget.showFilter,
          //         child: InkWell(
          //           onTap: widget.onFilterPress,
          //           child: Row(
          //             mainAxisAlignment: MainAxisAlignment.start,
          //             children: [
          //               Stack(
          //                 alignment: Alignment.topRight,
          //                 children: [
          //                   Container(
          //                     height: 20.0,
          //                     child: CustomImageIcon(
          //                         imagPath: "assets/filter_new.png"),
          //                   ),
          //                   if (widget.showBubble)
          //                     Padding(
          //                       padding:
          //                           const EdgeInsets.only(bottom: 8, left: 17),
          //                       child: Container(
          //                         width: 7.4,
          //                         height: 7.4,
          //                         decoration: BoxDecoration(
          //                             shape: BoxShape.circle,
          //                             color: customColors().accent),
          //                       ),
          //                     ),
          //                 ],
          //               ),
          //               const SizedBox(
          //                 width: 6,
          //               ),
          //               Text(
          //                 "Filter",
          //                 style: styles,
          //               ),
          //             ],
          //           ),
          //         ),
          //       )
          //     : SizedBox(
          //         width: MediaQuery.of(context).size.width * 0.13,
          //         height: 5,
          //       ),
        ],
      ),
    );
  }
}

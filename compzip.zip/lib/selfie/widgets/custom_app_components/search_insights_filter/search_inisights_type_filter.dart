import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SearchFilterItems extends StatefulWidget {
  final bool showBubble;
  final bool showFilter;
  final VoidCallback? onSearch;
  final VoidCallback? onFilter;
  final VoidCallback? onSort;
  const SearchFilterItems({
    Key? key,
    this.showBubble = false,
    required this.showFilter,
    this.onFilter,
    this.onSearch,
    this.onSort,
  }) : super(key: key);

  @override
  State<SearchFilterItems> createState() => _SearchFilterItemsState();
}

class _SearchFilterItemsState extends State<SearchFilterItems> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          InkWell(
            onTap: widget.onSearch,
            child: Expanded(
              flex: 1,
              child: SizedBox(
                child: items(
                    context: context,
                    image: "assets/search.png",
                    title: "Search"),
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              widget.showFilter
                  ? InkWell(
                      onTap: widget.onFilter,
                      child: InkWell(
                        onTap: widget.onFilter,
                        child: items(
                          context: context,
                          title: "Filter",
                          image: "assets/filter.png",
                        ),
                      ),
                    )
                  : const SizedBox(),
              const SizedBox(
                width: 15,
              ),
              InkWell(
                onTap: widget.onSort,
                child: items(
                  context: context,
                  title: "Sort",
                  image: "assets/sort.png",
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget items({
    required BuildContext context,
    required String image,
    required String title,
    Widget? bubble,
  }) =>
      Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          widget.showFilter
              ? Stack(
                  alignment: Alignment.topRight,
                  children: [
                    Image.asset(
                      image,
                      color: customColors().fontPrimary,
                      height: 20,
                      width: 20,
                    ),
                    if (widget.showBubble)
                      Container(
                        width: 5,
                        height: 5,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: customColors().accent),
                      ),
                  ],
                )
              : Image.asset(
                  image,
                  height: 20,
                  width: 20,
                  color: customColors().fontPrimary,
                ),
          const SizedBox(
            width: 4,
          ),
          Text(
            title,
            style: customTextStyle(
                fontStyle: FontStyle.BodyL_Regular,
                color: FontColor.FontSecondary),
          ),
        ],
      );
}

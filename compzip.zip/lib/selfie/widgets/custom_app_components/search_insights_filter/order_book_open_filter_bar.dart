import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SearchFilterHoldings extends StatefulWidget {
  final VoidCallback? onSearchPress;
  final VoidCallback? onFilterPress;
  final VoidCallback? ononSortPress;
  final bool showBubble;
  final bool sortBubble;

  const SearchFilterHoldings({
    Key? key,
    this.showBubble = true,
    this.sortBubble = true,
    this.onSearchPress,
    this.ononSortPress,
    this.onFilterPress,
  }) : super(key: key);
  @override
  State<SearchFilterHoldings> createState() => _SearchFilterHoldingsState();
}

class _SearchFilterHoldingsState extends State<SearchFilterHoldings> {
  @override
  Widget build(BuildContext context) {
    TextStyle styles = customTextStyle(
        fontStyle: FontStyle.BodyL_Regular, color: FontColor.FontSecondary);
    return Padding(
      padding: const EdgeInsets.only(left: 16, right: 16, top: 10, bottom: 9),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: InkWell(
              onTap: widget.onSearchPress,
              child: SizedBox(
                width: 160.0,
                height: 35.0,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        CUstomSerchBarImages(
                          imagPath: "assets/search.png",
                          context: context,
                        ),
                        const SizedBox(
                          width: 6,
                        ),
                        Text(
                          "Search",
                          style: styles,
                        ),
                        const SizedBox(
                          width: 4,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              InkWell(
                onTap: widget.onFilterPress,
                child: SizedBox(
                  width: 80.0,
                  height: 35.0,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Stack(
                        alignment: Alignment.topRight,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(top: 1, right: 1),
                            child: CUstomSerchBarImages(
                                imagPath: "assets/filter_new.png",
                                context: context),
                          ),
                          if (widget.showBubble)
                            Container(
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: customColors().accent)),
                        ],
                      ),
                      const SizedBox(
                        width: 6,
                      ),
                      Text(
                        "Filter",
                        style: styles,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                width: 80.0,
                height: 35.0,
                child: InkWell(
                  onTap: widget.ononSortPress,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Stack(
                        alignment: Alignment.topRight,
                        children: [
                          CUstomSerchBarImages(
                            imagPath: "assets/sort.png",
                            context: context,
                            height: 24,
                            width: 24,
                          ),
                          if (widget.sortBubble)
                            Padding(
                              padding: const EdgeInsets.only(right: 2, top: 2),
                              child: Container(
                                  width: 8,
                                  height: 8,
                                  decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: customColors().accent)),
                            ),
                        ],
                      ),
                      const SizedBox(
                        width: 4,
                      ),
                      Text(
                        "Sort",
                        style: styles,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class CUstomSerchBarImages extends StatelessWidget {
  CUstomSerchBarImages({
    Key? key,
    required this.imagPath,
    required this.context,
    this.height = 16.6,
    this.width = 17.6,
  }) : super(key: key);

  final String imagPath;
  final BuildContext context;
  double height;
  double width;

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      imagPath,
      color: customColors().fontPrimary,
      height: height,
      width: width,
    );
  }
}

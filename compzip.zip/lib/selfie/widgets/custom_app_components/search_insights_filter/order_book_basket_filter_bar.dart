import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/order_book_open_filter_bar.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class BasketSearchFilterHoldings extends StatefulWidget {
  final VoidCallback? onSearchPress;
  final VoidCallback? onFilterPress;
  // final bool showBubble;
  // final bool showFilter;
  // final bool showInsights;

  const BasketSearchFilterHoldings({
    Key? key,
    // this.showBubble = false,
    // this.showFilter = true,
    // this.showInsights = true,
    this.onSearchPress,
    this.onFilterPress,
  }) : super(key: key);
  @override
  State<BasketSearchFilterHoldings> createState() => _BasketSearchFilterHoldingsState();
}

class _BasketSearchFilterHoldingsState extends State<BasketSearchFilterHoldings> {
  @override
  Widget build(BuildContext context) {
    TextStyle styles = customTextStyle(
        fontStyle: FontStyle.BodyL_Regular, color: FontColor.FontSecondary);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          InkWell(
            onTap: widget.onSearchPress,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                CUstomSerchBarImages(imagPath: "assets/search.png", context: context),
                
                const SizedBox(
                  width: 6,
                ),
                Text(
                  "Search",
                  style: styles,
                ),
              ],
            ),
          ),
          
           InkWell(
             onTap: widget.onFilterPress,
             child: RichText(text: TextSpan(text: "+",style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.Primary),
                 children: [
                   TextSpan(text:" Create Basket",style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.Primary),)
                 ]))
           )
              
          
        ],
      ),
    );
  }}
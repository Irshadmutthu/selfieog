import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'navigation_state.dart';

class NavigationCubit extends Cubit<NavigationState> {
  NavigationCubit() : super(WatchlistIndexState());

  StreamController<int> adcontroller = StreamController<int>.broadcast();

  updateWatchList(int index, {Map<String, dynamic>? args}) {
    if (index == 6) {
      emit(WatchlistIndexState(index: index, args: args!));
    } else {
      emit(WatchlistIndexState(index: index));
    }

    adcontroller.add(index);
  }
}

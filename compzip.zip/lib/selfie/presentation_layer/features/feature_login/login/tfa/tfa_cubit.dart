import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/constants/error_mapper.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/common/dto_header.dart';
import 'package:trading_api/responses/login_response.dart';

import '../../../../../../utils/user_settings.dart';
import '../../../feature_order/conversions/conversions.dart';

part 'tfa_state.dart';

class TfacomponentCubit extends Cubit<TfaState> {
  String userId;
  String password;
  final ServiceLocator serviceLocator;
  TfacomponentCubit(
      {required this.userId,
      required this.password,
      required this.serviceLocator})
      : super(TfaInitial(userId: userId, password: password));

  ///handles 2 factor authentication
  ///```dart
  ///sendTfaRequest(context: context, tfaToken: "24/04/1979")
  ///```
  ///will return an error code in dto header
  ///
  ///or Error-Code equals 0 then 2 factor login success
  sendTfaRequest({required context, required String tfaToken}) async {
    emit(TfaLoading());
    tfaToken = tfaToken.substring(0, 2) +
        "/" +
        tfaToken.substring(2, 4) +
        "/" +
        tfaToken.substring(4);
    try {
      LoginResponse loginResponse = await serviceLocator.tradingApi
          .tfaRequest(userId: userId, password: password, tfaToken: tfaToken);
      if (loginResponse.errorCode == 0) {
        Dtoheader dtoheader = loginResponse.intReqObj!.dtoheader!;
        if (dtoheader.errorCode == 0) {
          UserController().password = password;
          UserController().tfa = tfaToken;
          // UserController().loginResponse = loginResponse;
          // UserController().sessionKey = dtoheader.sessionKey!;
          // UserController().userName = loginResponse.intReqObj!.userName!;
          UserSettings.userSettings.otherSettings.passwordExpirydays =
              passwordExpiryDays(loginResponse.intReqObj!.passwordExpiryDate!);
          try {
            if (loginResponse.intReqObj!.appCategory != null) {
              List<String> seperated =
                  loginResponse.intReqObj!.appCategory!.split("|");
              UserController().isNonPoa = seperated.length > 9
                  ? (seperated.elementAt(9) == "N")
                  : false;
              UserController().crmid =
                  seperated.length > 11 ? (seperated.elementAt(11)) : "";

              // ignore: empty_catches
            }
          } catch (e) {}
          serviceLocator.navigationService.openWorkspacePage(context);
        } else if (errorMap.containsKey(dtoheader.errorCode)) {
          emit(TfaError(
              errorMessage: errorMap[dtoheader.errorCode.toString()]!));
        } else {
          emit(TfaError(errorMessage: "Login failed"));
        }
      } else {
        emit(TfaError(errorMessage: "Login failed"));
      }
    } on SocketException {
      emit(TfaError(errorMessage: "Network Exception"));
    } catch (e) {
      emit(TfaError(errorMessage: e.toString()));
    }
  }
}

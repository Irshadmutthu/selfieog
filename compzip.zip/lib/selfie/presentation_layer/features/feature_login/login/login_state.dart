part of 'login_cubit.dart';

@immutable
abstract class LoginState {}

class LoginInitial extends LoginState {
  final String errorMessage;
  final bool loading;
  LoginInitial({this.errorMessage = "", this.loading = false});

  LoginInitial copyWith({String? error, bool loading = false}) {
    return LoginInitial(errorMessage: error ?? "", loading: loading);
  }
}

// class TFA_Initial extends LoginState {
//   int tfaTokenType = 0;
//   String userId;
//   String password;
//   TFA_Initial({this.tfaTokenType = 0, required this.userId, required this.password});
// }

// class TFA_Error extends LoginState {
//   final int errorCode;
//   final String errorMessage;

//   TFA_Error({required this.errorCode, required this.errorMessage});
// }

// class NetworkError extends LoginState {}

// class Error extends LoginState {
//   final int errorCode;
//   final String errorMessage;

//   Error({required this.errorCode, required this.errorMessage});
// }



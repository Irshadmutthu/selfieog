import 'dart:io';
import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/constants/error_mapper.dart';
import 'package:selfie_mobile_flutter/constants/prefefence_utils.dart';
import 'package:selfie_mobile_flutter/main.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/conversions/conversions.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/cryptography/crypto_operations.dart';
import 'package:selfie_mobile_flutter/utils/server_time_calculator.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';
import 'package:trading_api/common/dto_header.dart';
import 'package:trading_api/responses/login_response.dart';

part 'login_state.dart';

class LoginCubit extends Cubit<LoginState> {
  final ServiceLocator serviceLocator;
  LoginCubit({required this.serviceLocator}) : super(LoginInitial()) {
    getUserCode();
  }
  getUserCode() async {
    if (UserController().userId.isEmpty ||
        UserSettings().userPersonalSettings.username == null) {
      if (await PreferenceUtils.preferenceHasKey("userCode")) {
        UserController().userId =
            (await PreferenceUtils.getDataFromShared("userCode"))!;
      }
    }
    if (!isClosed) emit(LoginInitial());
  }

  ///handles selfie user login
  ///```dart
  ///sendLoginRequest(context: context, userName: "VYJ252", password: "Lion1234")
  ///```
  ///will return an error code in dto header
  ///
  ///if Error-Code equals 1522 then handle 2 factor authentication
  ///
  ///or Error-Code equals 0 then LOGIN Success
  Future<bool> sendLoginRequest(
      {required context,
      required String userId,
      required String password}) async {
    UserController().userId = userId;
    if (!isClosed) {
      emit((state as LoginInitial).copyWith(loading: true));
    }
    try {
      DateTime requestTime = DateTime.now();
      LoginResponse loginResponse = await serviceLocator.tradingApi
          .loginRequest(userId: userId, password: password);
      DateTime responseTime = DateTime.now();

      if (loginResponse.errorCode == 0) {
        List<String> appCategory =
            loginResponse.intReqObj!.appCategory!.split("|");
        String mdsDomain = appCategory[10];
        String mdsUrl = getMdsUrl(mdsDomain);
        MDS_Controller(url: mdsUrl);
        Dtoheader dtoheader = loginResponse.intReqObj!.dtoheader!;
        UserController().serverTimeDifference = secondDifference(
            serverTimeString: loginResponse.intReqObj!.serverTime.toString(),
            requestStartTime: requestTime,
            requestEndTime: responseTime);

        if (dtoheader.errorCode == 1522 || dtoheader.errorCode == 1523) {
          //handle Two factor auth
          await MDS_Controller()
              .mdsLogin(tradecode: userId, password: password);
          try {
            if (loginResponse.intReqObj!.appCategory != null) {
              List<String> seperated =
                  loginResponse.intReqObj!.appCategory!.split("|");
              UserController().isNonPoa = seperated.length > 9
                  ? (seperated.elementAt(9) == "N")
                  : false;
              UserController().crmid =
                  seperated.length > 11 ? (seperated.elementAt(11)) : "";

              // ignore: empty_catches
            }
          } catch (e) {}
          serviceLocator.navigationService.openTfaAuthPage(
              context, {"userId": userId, "password": password});
          updateUserController(
              sessionKey: dtoheader.sessionKey,
              userId: userId,
              username: loginResponse.intReqObj!.userName!);
          return true;
        } else if (dtoheader.errorCode == 0) {
          //handle login
          UserSettings.userSettings.otherSettings.passwordExpirydays =
              passwordExpiryDays(loginResponse.intReqObj!.passwordExpiryDate!);
          try {
            if (loginResponse.intReqObj!.appCategory != null) {
              List<String> seperated =
                  loginResponse.intReqObj!.appCategory!.split("|");
              UserController().isNonPoa = seperated.length > 9
                  ? (seperated.elementAt(9) == "N")
                  : false;

              // ignore: empty_catches
            }
          } catch (e) {}
          await MDS_Controller()
              .mdsLogin(tradecode: userId, password: password);
          serviceLocator.navigationService.openWorkspacePage(context);
          updateUserController(
              sessionKey: dtoheader.sessionKey,
              userId: userId,
              username: loginResponse.intReqObj!.userName!);
          return true;
        } else if (errorMap.containsKey(dtoheader.errorCode.toString())) {
          if (!isClosed) {
            emit((state as LoginInitial)
                .copyWith(error: errorMap[dtoheader.errorCode.toString()]!));
          }
          return false;
        } else {
          emit((state as LoginInitial).copyWith(error: "Login failed"));
          return false;
        }
      } else {
        emit((state as LoginInitial).copyWith(error: "Login failed"));
        return false;
      }
    } on SocketException {
      emit((state as LoginInitial)
          .copyWith(error: "Network connectivity error"));
      return false;
    } catch (e) {
      emit((state as LoginInitial).copyWith(error: e.toString()));
      return false;
    }
  }

  Future<bool> sendOneTouchLoginRequest(
      {required context,
      required String userId,
      required String password,
      required String tfaTocken}) async {
    UserController().userId = userId;
    emit((state as LoginInitial).copyWith(loading: true));
    try {
      DateTime requestTime = DateTime.now();
      LoginResponse loginResponse = await serviceLocator.tradingApi
          .oneTouchRequest(
              userId: userId, password: password, tfaToken: tfaTocken);
      DateTime responseTime = DateTime.now();

      if (loginResponse.errorCode == 0) {
        Dtoheader dtoheader = loginResponse.intReqObj!.dtoheader!;
        UserController().password = password;
        UserController().tfa = tfaTocken;
        UserController().serverTimeDifference = secondDifference(
            serverTimeString: loginResponse.intReqObj!.serverTime.toString(),
            requestStartTime: requestTime,
            requestEndTime: responseTime);
        if (dtoheader.errorCode == 1522 || dtoheader.errorCode == 1523) {
          //handle Two factor auth
          await MDS_Controller()
              .mdsLogin(tradecode: userId, password: password);
          serviceLocator.navigationService.openTfaAuthPage(
              context, {"userId": userId, "password": password});
          updateUserController(
              sessionKey: dtoheader.sessionKey,
              userId: userId,
              username: loginResponse.intReqObj!.userName!);
          return true;
        } else if (dtoheader.errorCode == 0) {
          //handle login
          UserSettings.userSettings.otherSettings.passwordExpirydays =
              passwordExpiryDays(loginResponse.intReqObj!.passwordExpiryDate!);
          await PreferenceUtils.storeDataToShared(
              UserController.userController.userId,
              UserSettings.userSettings.toJsonString());
          await MDS_Controller()
              .mdsLogin(tradecode: userId, password: password);
          serviceLocator.navigationService.openWorkspacePage(context);
          updateUserController(
              sessionKey: dtoheader.sessionKey,
              userId: userId,
              username: loginResponse.intReqObj!.userName!);
          return true;
        } else if (errorMap.containsKey(dtoheader.errorCode.toString())) {
          emit((state as LoginInitial)
              .copyWith(error: errorMap[dtoheader.errorCode.toString()]!));
          return false;
        } else {
          emit((state as LoginInitial).copyWith(error: "Login failed"));
          return false;
        }
      } else {
        emit((state as LoginInitial).copyWith(error: "Login failed"));
        return false;
      }
    } on SocketException {
      emit((state as LoginInitial)
          .copyWith(error: "Network connectivity error"));
      return false;
    } catch (e) {
      emit((state as LoginInitial).copyWith(error: e.toString()));
      return false;
    }
  }

  updateUserController({
    required String sessionKey,
    required String userId,
    required String username,
  }) {
    UserController().sessionKey = sessionKey;
    UserController().userName = username;
    UserController.userController.userShortName = username
        .split(" ")
        .map((el) => el.substring(0, 1))
        .join("")
        .toUpperCase();
    UserController.userController.userShortName =
        UserController.userController.userShortName.substring(
            0, UserController.userController.userShortName.length > 1 ? 2 : 1);
    UserController().userId = userId;
    updateUserData(username: username, userId: userId);
  }

  updateUserData({
    required String username,
    required String userId,
  }) async {
    await PreferenceUtils.storeDataToShared("userCode", userId);
    if (!(await PreferenceUtils.preferenceHasKey(userId))) {
      UserSettings.userSettings.fromJson({});
      await PreferenceUtils.storeDataToShared(
          userId, UserSettings.userSettings.toJsonString());
    }
    String? userData = await PreferenceUtils.getDataFromShared(userId);
    UserSettings.userSettings.fromJsonString(userData!);
    UserSettings.userSettings.userPersonalSettings.username = username;
    UserSettings.userSettings.userPersonalSettings.tradecode = userId;
    PreferenceUtils.storeDataToShared(
        userId, UserSettings.userSettings.toJsonString());
  }
}

String getMdsUrl(String domain) {
  // switch (domain.toLowerCase()) {
  //   case "flair.geojit.com":
  //     return "http://flair.geojit.com:443/m/r";
  //   case "flair.geojit.net":
  //     return "http://flair.geojit.net:443/m/r";
  //   case "freeflair.geojit.com":
  //     return "http://freeflair.geojit.com:443/m/r";
  //   case "freeflair.geojit.net":
  //     return "http://freeflair.geojit.net:443/m/r";
  //   default:
  //     return "http://freeflair.geojit.net:443/m/r";
  // }
  return mdsUrl;
}

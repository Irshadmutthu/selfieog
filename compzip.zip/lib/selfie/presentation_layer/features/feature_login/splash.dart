import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/constants/prefefence_utils.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';

class SplashScreen extends StatefulWidget {
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    getUserCode(context);
  }

  getUserCode(BuildContext context) async {
    if (await PreferenceUtils.preferenceHasKey("userCode")) {
      UserController().userId =
          (await PreferenceUtils.getDataFromShared("userCode"))!;
    }
    await Future.delayed(Duration(seconds: 2));
    context.gNavigationService.openLoginPage(context);
  }

  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: customColors().backgroundPrimary,
      body: Center(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.asset(
                "assets/selfie_logo.png",
                height: 100,
              ),
              // const SizedBox(height: 15),
              SizedBox(
                width: 150,
                child: LinearProgressIndicator(
                  color: customColors().primary,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

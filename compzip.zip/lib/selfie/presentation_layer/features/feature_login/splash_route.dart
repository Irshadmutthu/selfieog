import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_login/splash.dart';

class SplashRouteBuilder {
  Widget call(BuildContext context) {
    return SplashScreen();
  }
}

import 'dart:io';

import 'package:biometric_storage/biometric_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/constants/urls.dart';
import 'package:selfie_mobile_flutter/main.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/page_bond_details/components/widgets/returns_tile_widget.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_login/login/login_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/webview/webview_page.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/formatters.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_login/login_components.dart/switch_account_inner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/network/network_service_status.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';
import 'package:trading_api/trading_api.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';

import '../../../../utils/user_settings.dart';
import 'login_components.dart/login_alert_component.dart';
import 'login_components.dart/login_alert_component2.dart';

class LoginPage extends StatefulWidget {
  final ServiceLocator serviceLocator;
  const LoginPage({Key? key, required this.serviceLocator}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  // late GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late GlobalKey<FormState> idFormKey = GlobalKey<FormState>();
  late GlobalKey<FormState> passFormKey = GlobalKey<FormState>();
  Key idKey = UniqueKey();
  Key passKey = UniqueKey();
  bool _showBio = false;
  BiometricStorageFile? _customPrompt;
  TextEditingController idcontroller = TextEditingController();
  TextEditingController passwordcontroller = TextEditingController();
  final focus1 = FocusNode();
  final focus2 = FocusNode();
  final focus3 = FocusNode();
  // final emptyFocus = FocusNode();
  final Stream<NetworkStatus> _stream =
      NetworkStatusService.networkStatusController.stream;

  Widget userNameAndTradeCode(String username, String tradeCode) {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.only(top: 35.0, right: 16.0, left: 16.0),
      child: Column(
        children: [
          Text(
            username,
            textAlign: TextAlign.center,
            style: customTextStyle(
                fontStyle: FontStyle.HeaderS_SemiBold,
                color: FontColor.FontPrimary),
          ),
          const SizedBox(
            height: 8.0,
          ),
          Text(
            tradeCode,
            style: customTextStyle(
                fontStyle: FontStyle.BodyM_Regular,
                color: FontColor.FontSecondary),
          )
        ],
      ),
    );
  }

  @override
  initState() {
    super.initState();
    _stream.listen((NetworkStatus status) {
      if (status == NetworkStatus.Online) {
        ScaffoldMessenger.of(context).showSnackBar(
            showSuccessDialogue(errorMessage: "Inernet connection restored"));
      } else if (status == NetworkStatus.Offline) {
        ScaffoldMessenger.of(context).showSnackBar(
            showErrorDialogue(errorMessage: "Inernet connection lost"));
      }
    });
    checkInternetConnection(context);
    chekBiometirc();
  }

  @override
  dispose() {
    super.dispose();
  }

  checkInternetConnection(BuildContext context) async {
    try {
      final result = await InternetAddress.lookup('google.com');
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) return;
    } on SocketException catch (_) {
      ScaffoldMessenger.of(context).showSnackBar(
          showErrorDialogue(errorMessage: "No internet connection"));
    }
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    double mheight = MediaQuery.of(context).size.height * 1.22;
    return Scaffold(
        appBar: PreferredSize(
            preferredSize: const Size.fromHeight(0.0),
            child: AppBar(
              elevation: 0,
              backgroundColor: customColors().backgroundPrimary,
            )),
        resizeToAvoidBottomInset: true,
        body: BlocConsumer<LoginCubit, LoginState>(
          listener: (context, state) {
            if (state is LoginInitial) {
              idcontroller.text = UserController().userId;
              if (state.loading) return;
              if (UserController().userId != "") {
                focus2.requestFocus();
              } else {
                //    focus1.requestFocus();
                // print(UserController().userId);

                FocusScope.of(context).requestFocus(new FocusNode());
              }
            }
            // if (state is LoginInitial && state.errorMessage != "") {
            // ScaffoldMessenger.of(context).showSnackBar(
            //     showErrorDialogue(errorMessage: state.errorMessage));
            // }
          },
          builder: (context, state) {
            if (state is LoginInitial) {
              return GestureDetector(
                onTap: () {
                  FocusScope.of(context).requestFocus(new FocusNode());
                },
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      if (state.loading)
                        LinearProgressIndicator(
                          minHeight: 6.0,
                          color: customColors().primary.withOpacity(0.8),
                          backgroundColor:
                              customColors().primary.withOpacity(0.2),
                          // value: controller.value,
                        ),
                      if (!state.loading)
                        const SizedBox(
                          height: 6,
                        ),
                      // Form(
                      //   key: _formKey,
                      //   child:
                      ConstrainedBox(
                        constraints: const BoxConstraints(),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(top: 80),
                              child: Image.asset("assets/selfie_logo.png"),
                            ),
                            if (UserController().userId != "" &&
                                UserController().userName != "")
                              userNameAndTradeCode(UserController().userName,
                                  UserController().userId),
                            Padding(
                              padding: const EdgeInsets.only(top: 10.0),
                              child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16),
                                  child: (state.errorMessage != "")
                                      ? Container(
                                          height: 30.0,
                                          padding: const EdgeInsets.all(4.0),
                                          alignment: Alignment.center,
                                          width: screenSize.width,
                                          decoration: BoxDecoration(
                                              color: customColors()
                                                  .danger
                                                  .withOpacity(0.15)),
                                          child: Text(
                                            state.errorMessage,
                                            textAlign: TextAlign.center,
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyM_SemiBold,
                                                color: FontColor.Danger),
                                          ),
                                        )
                                      : Container(
                                          height: 30.0,
                                        )),
                            ),
                            if (UserController().userId == "" ||
                                UserController().userName == "")
                              Form(
                                key: idFormKey,
                                child: Padding(
                                    padding: const EdgeInsets.only(
                                        top: 40.0, left: 16.0, right: 16.0),
                                    child: CustomTextFormField(
                                      key: idKey,
                                      controller: idcontroller,
                                      fieldName: "Trade Code/CIN",
                                      hintText: " Enter Trade Code",
                                      validator: Validator.account,
                                      onChange: (val) {
                                        // BlocProvider.of<LoginCubit>(context)
                                        //     .emit(LoginInitial());
                                        idFormKey.currentState!.validate();
                                      },
                                      bordercolor:
                                          customColors().backgroundTertiary,
                                      inputFormatter: [
                                        UpperCaseTextFormatter()
                                      ],
                                      // autoFocus: true,
                                      // focusNode: focus1,
                                      onFieldSubmit: (value) async {
                                        if (idFormKey.currentState!
                                                .validate() &&
                                            passwordcontroller
                                                .text.isNotEmpty) {
                                          // emptyFocus.requestFocus();
                                          BlocProvider.of<LoginCubit>(context)
                                              .sendLoginRequest(
                                            context: context,
                                            userId: idcontroller.text.isEmpty
                                                ? UserController().userId
                                                : idcontroller.text,
                                            password: passwordcontroller.text,
                                          );
                                        } else if (idcontroller
                                            .text.isNotEmpty) {
                                          //   focus2.requestFocus();
                                        } else {
                                          //   focus1.requestFocus();
                                        }
                                      },
                                      keyboardAction: () async {
                                        if (idFormKey.currentState!
                                                .validate() &&
                                            passwordcontroller
                                                .text.isNotEmpty) {
                                          // emptyFocus.requestFocus();
                                          BlocProvider.of<LoginCubit>(context)
                                              .sendLoginRequest(
                                                  context: context,
                                                  userId: idcontroller
                                                          .text.isEmpty
                                                      ? UserController().userId
                                                      : idcontroller.text,
                                                  password:
                                                      passwordcontroller.text);
                                        } else if (idcontroller
                                            .text.isNotEmpty) {
                                          focus2.requestFocus();
                                        } else {
                                          focus1.requestFocus();
                                        }
                                      },
                                    )),
                              ),

                            // ============= login START ==============

                            Form(
                              key: passFormKey,
                              child: Padding(
                                padding: const EdgeInsets.only(
                                    top: 10, left: 16.0, right: 16.0),
                                child: CustomTextFormField(
                                  //   autoFocus: true,
                                  controller: passwordcontroller,
                                  fieldName: "Password",
                                  hintText: " Enter Password",
                                  topEndWidget: !(UserController().userId ==
                                              "" ||
                                          UserController().userName == "")
                                      ? (UserSettings.userSettings.otherSettings
                                                  .passwordExpirydays <
                                              0)
                                          ? Text(
                                              "Password Expires Today",
                                              style: customTextStyle(
                                                  fontStyle:
                                                      FontStyle.BodyM_Regular,
                                                  color: FontColor.Danger),
                                            )
                                          : (UserSettings
                                                      .userSettings
                                                      .otherSettings
                                                      .passwordExpirydays <
                                                  11)
                                              ? Text(
                                                  "Password Expires in " +
                                                      UserSettings
                                                          .userSettings
                                                          .otherSettings
                                                          .passwordExpirydays
                                                          .toString() +
                                                      " days",
                                                  style: customTextStyle(
                                                      fontStyle: FontStyle
                                                          .BodyM_Regular,
                                                      color: FontColor.Danger),
                                                )
                                              : (UserSettings
                                                          .userSettings
                                                          .otherSettings
                                                          .passwordExpirydays <
                                                      0)
                                                  ? Text(
                                                      "Password Expired",
                                                      style: customTextStyle(
                                                          fontStyle: FontStyle
                                                              .BodyM_Regular,
                                                          color:
                                                              FontColor.Danger),
                                                    )
                                                  : null
                                      : null,
                                  validator: Validator.password,
                                  obscureTextStatus: true,
                                  obscureIcon: true,
                                  focusNode: focus2,
                                  onChange: (val) {
                                    passFormKey.currentState!.validate();
                                  },
                                  onFieldSubmit: (value) async {
                                    if (passFormKey.currentState!.validate()) {
                                      // emptyFocus.requestFocus();
                                      BlocProvider.of<LoginCubit>(context)
                                          .sendLoginRequest(
                                              context: context,
                                              userId: idcontroller.text.isEmpty
                                                  ? UserController().userId
                                                  : idcontroller.text,
                                              password:
                                                  passwordcontroller.text);
                                    } else {
                                      //     focus2.requestFocus();
                                    }
                                  },
                                  keyboardAction: () async {
                                    if (passFormKey.currentState!.validate()) {
                                      // emptyFocus.requestFocus();
                                      BlocProvider.of<LoginCubit>(context)
                                          .sendLoginRequest(
                                              context: context,
                                              userId: idcontroller.text.isEmpty
                                                  ? UserController().userId
                                                  : idcontroller.text,
                                              password:
                                                  passwordcontroller.text);
                                    } else {
                                      focus2.requestFocus();
                                    }
                                  },
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                  top: 10, right: 16.0, left: 16.0),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  GestureDetector(
                                      onTap: () {
                                        customBottomSheet(
                                          context: context,
                                          inputWidget: SwitchAccountInner(),
                                        );
                                      },
                                      child: Wrap(
                                        children: [
                                          if (UserController().userId != "" &&
                                              UserController().userName != "")
                                            InkWell(
                                              onTap: () {
                                                passwordcontroller.text = " ";
                                                passFormKey.currentState!
                                                    .validate();
                                                passwordcontroller.text = "";
                                                UserController().userId = "";
                                                UserController().userName = "";
                                                context
                                                    .read<LoginCubit>()
                                                    .emit(state.copyWith());
                                              },
                                              child: Text(
                                                "Switch Account",
                                                style: customTextStyle(
                                                    fontStyle: FontStyle
                                                        .BodyM_SemiBold,
                                                    color: FontColor.Primary),
                                              ),
                                            )
                                        ],
                                      )),
                                  InkWell(
                                    onTap: () {
                                      Navigator.push(
                                          context,
                                          PageRouteBuilder(
                                              transitionDuration:
                                                  const Duration(seconds: 1),
                                              pageBuilder: (BuildContext
                                                      context,
                                                  Animation<double> animation,
                                                  Animation<double>
                                                      secondAnimation) {
                                                return SlideTransition(
                                                    position: Tween<Offset>(
                                                      begin: const Offset(
                                                          100, 0.0),
                                                      end: Offset.zero,
                                                    ).animate(animation),
                                                    child: CustomWebviewPage(
                                                        title:
                                                            "Forgot Password",
                                                        urlAddress: CommonUrls
                                                            .forgotPasswordUrl));
                                              }));
                                    },
                                    child: Text(
                                      "Forgot Password",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_SemiBold,
                                          color: FontColor.Primary),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                  top: mheight * .040, left: 16.0, right: 16.0),
                              child: BasketButton(
                                bgcolor: state.loading
                                    ? customColors().primary.withOpacity(0.4)
                                    : customColors().primary,
                                text: "Login",
                                enabled: !state.loading,
                                textStyle: customTextStyle(
                                    fontStyle: FontStyle.BodyL_Bold,
                                    color: FontColor.White),
                                onpress: () async {
                                  if ((idcontroller.text.isNotEmpty ||
                                          UserController().userId.isNotEmpty) &&
                                      passFormKey.currentState!.validate() &&
                                      !state.loading) {
                                    // emptyFocus.requestFocus();
                                    FocusManager.instance.primaryFocus
                                        ?.unfocus();
                                    BlocProvider.of<LoginCubit>(context)
                                        .sendLoginRequest(
                                            context: context,
                                            userId: idcontroller.text.isEmpty
                                                ? UserController().userId
                                                : idcontroller.text,
                                            password: passwordcontroller.text);
                                  }
                                },
                              ),
                            ),
                            InkWell(
                              onTap: () async {
                                // customShowModalBottomSheet(
                                //     context: context,
                                //     inputWidget: (true)
                                //         ? const LoginAlertComponent()
                                //         : const LoginAlertComponent2());

                                // if (supportsAuthenticated) {
                                _customPrompt = await BiometricStorage()
                                    .getStorage('SelfiePro',
                                        options: StorageFileInitOptions(),
                                        promptInfo: const PromptInfo(
                                          iosPromptInfo: IosPromptInfo(
                                            saveTitle: 'Login to Selfie',
                                          ),
                                          androidPromptInfo: AndroidPromptInfo(
                                            title: 'Login to Selfie',
                                            negativeButton: 'Cancel',
                                          ),
                                        ));

                                try {
                                  final data = await _customPrompt!.read();

                                  decodeAndCallOnetouch(data);
                                } on AuthException catch (e) {
                                  if (e.code ==
                                      AuthExceptionCode.userCanceled) {
                                    return;
                                  }
                                  rethrow;
                                }
                                // }
                              },
                              child: Padding(
                                padding: const EdgeInsets.only(
                                    left: 16, right: 16.0, top: 10.0),
                                child: !(UserController().userId == "" ||
                                            UserController().userName == "") &&
                                        (UserSettings.userSettings.otherSettings
                                            .fingerPrint) &&
                                        _showBio
                                    ? Container(
                                        height: 48.0,
                                        alignment: Alignment.center,
                                        width: screenSize.width,
                                        decoration: BoxDecoration(
                                          border: Border.all(
                                              color: customColors().green4),
                                          borderRadius:
                                              BorderRadius.circular(4.0),
                                        ),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            SizedBox(
                                              width: 15.0,
                                              height: 17.0,
                                              child: Image.asset(
                                                  "assets/fingerprint.png"),
                                            ),
                                            const SizedBox(
                                              width: 10.0,
                                            ),
                                            Text(
                                              "Login with Fingerprint",
                                              style: customTextStyle(
                                                  fontStyle:
                                                      FontStyle.BodyL_SemiBold,
                                                  color: FontColor.Primary),
                                            ),
                                          ],
                                        ),
                                      )
                                    // ignore: dead_code
                                    : (false)
                                        ? Container(
                                            height: 48.0,
                                            alignment: Alignment.center,
                                            width: screenSize.width,
                                            decoration: BoxDecoration(
                                              border: Border.all(
                                                  color: customColors().green4),
                                              borderRadius:
                                                  BorderRadius.circular(4.0),
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Image.asset(
                                                    "assets/pattern.png"),
                                                const SizedBox(
                                                  width: 10.0,
                                                ),
                                                Text(
                                                  "Login with Pattern",
                                                  style: customTextStyle(
                                                      fontStyle: FontStyle
                                                          .BodyL_SemiBold,
                                                      color: FontColor.Primary),
                                                ),
                                              ],
                                            ),
                                          )
                                        : Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 16.0),
                                            child: Container(
                                              height: 48,
                                            ),
                                          ),
                              ),
                            ),

                            Padding(
                              padding: const EdgeInsets.only(top: 20),
                              child: InkWell(
                                onTap: () {
                                  showSnackBar(
                                      context: context,
                                      snackBar: showSuccessDialogue(
                                          errorMessage:
                                              "Url : $baseUrl \nPath : $applicationPath \nFlair Url : $mdsUrl"));
                                },
                                child: Text(
                                  "Practice Simulator",
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_SemiBold,
                                      color: FontColor.Primary),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      // ),
                    ],
                  ),
                ),
              );
            }
            return Container();
          },
        ),
        bottomNavigationBar: SizedBox(
          height: 100,
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Not registered yet?",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontPrimary),
                  ),
                  const SizedBox(
                    width: 4.0,
                  ),
                  Text(
                    "Open an account",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_Bold,
                        color: FontColor.Primary),
                  )
                ],
              ),
              const Padding(
                padding: EdgeInsets.only(top: 12.0, bottom: 8.0),
                child: Divider(
                  height: 1.0,
                  thickness: 1.0,
                  indent: 16.0,
                  endIndent: 16.0,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16.0,
                ),
                child: Text(
                  "NSE & BSE-SEBI Registration no.: INZ000031633 MCX - SEBI Registration no.: INZ000038238 | CDSL - SEBI Registration no.: IN- DP-431-2019",
                  textAlign: TextAlign.center,
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyS_Regular,
                      color: FontColor.FontSecondary),
                ),
              ),
            ],
          ),
        ));
  }

  Future<CanAuthenticateResponse> _checkAuthenticate() async {
    final response = await BiometricStorage().canAuthenticate();
    return response;
  }

  void decodeAndCallOnetouch(String? data) {
    BlocProvider.of<LoginCubit>(context).sendOneTouchLoginRequest(
        context: context,
        userId: data!.split("|").elementAt(0),
        password: data.split("|").elementAt(2),
        tfaTocken: data.split("|").elementAt(1));
  }

  Future<bool> doesSupportBio() async {
    final authenticate = await _checkAuthenticate();
    if (authenticate == CanAuthenticateResponse.unsupported) {
      return false;
    }
    final supportsAuthenticated =
        authenticate == CanAuthenticateResponse.success;
    return supportsAuthenticated;
  }

  void chekBiometirc() async {
    _showBio = await doesSupportBio();
  }
}

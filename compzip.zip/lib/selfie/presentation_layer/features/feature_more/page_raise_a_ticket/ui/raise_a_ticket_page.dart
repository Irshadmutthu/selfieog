import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_get_a_callback/ui/get_a_callback_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_raise_a_ticket/cubit/raise_a_ticket_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/more_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/more/bottomsheet_call_confirmed_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/more/bottomsheet_selection_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/more/bottomsheet_ticket_raised_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/dotted_border_upload_image.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class RaiseATicketPage extends StatefulWidget {
  RaiseATicketPage({ Key? key }) : super(key: key);

  @override
  State<RaiseATicketPage> createState() => _RaiseATicketPageState();
}

class _RaiseATicketPageState extends State<RaiseATicketPage> {
  TextEditingController messageController = TextEditingController();

  int currentTopicIndex = 0;

  int screenCount =1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
          )),
      body: Stack(
        children: [
          SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomAppBarInner(
                    title: "Raise a ticket",
                    onBackPressed: () {
                      BlocProvider.of<RaiseATicketCubit>(context)
                          .onBackPressed(context);
                    }),
                Padding(
                  padding:
                      const EdgeInsets.only(left: 16.0, right: 16, bottom: 4),
                  child: Text(
                    "Topic*",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_Regular,
                        color: FontColor.FontPrimary),
                  ),
                ),
                Padding(
                  padding:
                      const EdgeInsets.only(left: 16.0, right: 16, bottom: 16),
                  child: InkWell(
                      onTap: () {
                        customShowModalBottomSheet(
                            context: context,
                            inputWidget: BottomsheetMultiSelectionWidget(
                              selectionList: raiseATicketTopicList,
                              onfilterpress: (val) {},
                              currentval: currentTopicIndex,
                              title: "Topics",
                            ));
                      },
                      child: CustomDropDownWithBottomSheetWidget(
                          text: "Ex. Funds",
                          fontColor: FontColor.FontTertiary,)),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 16.0, right: 16,bottom: 20),
                  child: CustomTextFormField(controller: messageController, fieldName: "Message",maxLines: 7,hintText: "Let us know how can we help you."),
                  ),
                
                Padding(
                  padding:
                      const EdgeInsets.only(left: 16.0, right: 16, bottom: 4),
                  child: DottedBorderUploadImage(),
                )
              ],
            ),
          ),
          
          Align(
            alignment: Alignment.bottomCenter,
            child: skipButton(context, "$screenCount/2", () {
              if (screenCount > 1) {
                setState(() {
                  messageController.text ="";

                  screenCount--;
                });
              }
            }, () {
              if (screenCount < 2) {
                setState(() {
                  messageController.text ="Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. ";

                  screenCount++;
                });
              }
            }),
          ),
        ],
      ),
      
      bottomNavigationBar:Column(
        mainAxisSize: MainAxisSize.min,
        children:[
          Padding(
                padding: const EdgeInsets.all( 16.0),
                child: Row(
                  children: [
                    Container(
                                    height: 16.0,
                                    width: 16.0,
                                    decoration: BoxDecoration(
                                      image: DecorationImage(
                                        image: AssetImage(
                                            "assets/info.png"),
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ),
                    // Image.asset("assets/info.png"),
                    SizedBox(width: 10,),
                    Expanded(
                      child: Text(
                        "Once you raise a ticket we will get back to you within 24 hours.",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyS_Regular,
                            color: FontColor.FontPrimary),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
        padding: const EdgeInsets.only(left:16.0,right: 16,bottom: 16),
        child:(messageController.text == "")?
         BasketButton(
            textStyle: customTextStyle(
                fontStyle: FontStyle.BodyL_Bold,
                color: FontColor.White),
            text: "Submit",
            bgcolor:customColors().primary.withOpacity(0.4),
                  bordercolor:customColors().primary.withOpacity(0.1)
            ):
            BasketButton(
            textStyle: customTextStyle(
                fontStyle: FontStyle.BodyL_Bold,
                color: FontColor.White),
            text: "Submit",
            bgcolor: customColors().primary,
                  bordercolor:customColors().primary,
            onpress: (){
              customShowModalBottomSheet(
      context: context,
      inputWidget: TicketRaisedBottosheetWidget(),
      );
              
            }),
      )
      
      ])
    );
  }
}

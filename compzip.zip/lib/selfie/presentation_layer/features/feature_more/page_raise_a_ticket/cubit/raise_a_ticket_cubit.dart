import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

part 'raise_a_ticket_state.dart';

class RaiseATicketCubit extends Cubit<RaiseATicketState> {
  final ServiceLocator serviceLocator;
  RaiseATicketCubit({required this.serviceLocator}) : super(RaiseATicketInitial());
  onBackPressed(BuildContext context){
      serviceLocator.navigationService.back(context);
  }
}

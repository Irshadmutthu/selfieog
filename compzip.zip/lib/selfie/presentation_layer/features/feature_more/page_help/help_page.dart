import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_support/support_page.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_help_appbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/Button_with_Icon.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class HelpPage extends StatelessWidget {
  ServiceLocator serviceLocator;

  HelpPage({Key? key, required this.serviceLocator}) : super(key: key);

  List<Map<String, dynamic>> item = [
    {"name": "Support", "icon": "assets/support.png"},
    {"name": "About Us", "icon": "assets/about.png"},
    {"name": "Licences", "icon": "assets/license.png"},
    {"name": "Invite a Friend", "icon": "assets/invitefriend.png"},
    {"name": "Become a partner", "icon": "assets/partner.png"},
  ];

  pageNavigation({required int index, required BuildContext context}) {
    switch (index) {
      case 0:
        {
          serviceLocator.navigationService.openSupportPage(context);
        }
        break;
      case 1:
        {
          serviceLocator.navigationService.openAboutUsPage(context);
        }
        break;
      case 2:
        {
          serviceLocator.navigationService.openLicencePage(context);
        }
        break;
      case 3:
        {
          serviceLocator.navigationService.openInviteFriendPage(context);
        }
        break;
      case 4:
        {
          serviceLocator.navigationService.openBecomePartnerPage(context);
        }
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: Stack(
        children: [
          CustomHelpAppbar(
            iconPress: () {
              Navigator.pop(context);
            },
            title: "Help",
          ),
          Stack(
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 60),
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: item.length,
                  itemBuilder: (context, index) => InkWell(
                    onTap: () => pageNavigation(context: context, index: index),
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 25, vertical: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Image.asset(
                                    item[index]["icon"],
                                    height: 16,
                                    width: 16,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 16),
                                    child: Text(
                                      item[index]["name"],
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyL_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                  )
                                ],
                              ),
                              Row(
                                children: [
                                  InkWell(
                                    onTap: () {
                                      pageNavigation(
                                        context: context,
                                        index: index,
                                      );
                                    },
                                    child: SizedBox(
                                      child: Image.asset(
                                        "assets/arrowright.png",color: customColors().fontPrimary,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 16, right: 16,bottom: 4),
                          child: SizedBox(
                            height: 0,
                            child: Divider(
                              // height: 1,
                              thickness: 1,
                              color: customColors().backgroundTertiary,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 80),
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: Text(
                    "Toll free Number",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontPrimary),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 20),
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Expanded(
                        flex: 1,
                        child: ButtonWithIcon(
                          height: 40,
                          bgcolor: customColors().backgroundPrimary,
                          text: "1800 425 5501",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary),
                          icon1: "assets/Call.png",
                          bordercolor: Colors.transparent,
                        ),
                      ),
                      const SizedBox(
                        width: 8,
                      ),
                      Expanded(
                        flex: 1,
                        child: ButtonWithIcon(
                          height: 40,
                          bgcolor: customColors().backgroundPrimary,
                          text: "1800 425 5501",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary),
                          icon1: "assets/Call.png",
                          bordercolor: Colors.transparent,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}

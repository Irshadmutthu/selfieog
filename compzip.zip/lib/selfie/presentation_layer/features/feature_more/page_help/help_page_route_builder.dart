import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_help/help_page.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class HelpPageRouteBuilder {
  final ServiceLocator serviceLocator;

  HelpPageRouteBuilder(this.serviceLocator);

  Widget call(BuildContext context) {
    return MultiRepositoryProvider(
      providers: [
        RepositoryProvider.value(value: serviceLocator.navigationService),
        RepositoryProvider<CubitsLocator>.value(value: serviceLocator),
      ],
      child: HelpPage(
        serviceLocator: serviceLocator,
      ),
    );
  }
}

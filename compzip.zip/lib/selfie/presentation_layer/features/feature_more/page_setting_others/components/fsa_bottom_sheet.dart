import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_title_component.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/custom_radio_button.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class FsaBottomSheet extends StatefulWidget {
  List<dynamic> itemList;
  final Function(int) onChanged;
  int? selectedItem;
  String title;
  FsaBottomSheet(
      {Key? key,
      required this.onChanged,
      required this.itemList,
      this.selectedItem,
      required this.title})
      : super(key: key);

  @override
  State<FsaBottomSheet> createState() => _FsaBottomSheetState();
}

class _FsaBottomSheetState extends State<FsaBottomSheet> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Text(
            widget.title,
            style: customTextStyle(
                fontStyle: FontStyle.HeaderXS_SemiBold,
                color: FontColor.FontPrimary),
          ),
        ),
        Container(
          height: 1,
          color: customColors().backgroundTertiary,
        ),
        const SizedBox(
          height: 10,
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 0, 10),
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: widget.itemList.length,
            itemBuilder: ((context, index) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 16.0),
                child: InkWell(
                  highlightColor: Colors.transparent,
                  focusColor: Colors.transparent,
                  onTap: () {
                    buttonOnchange(index);
                  },
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      CustomRadioButton(
                          noLabel: true,
                          value: index,
                          groupValue: widget.selectedItem!,
                          onChanged: buttonOnchange),
                      Padding(
                        padding: const EdgeInsets.only(left: 10.0),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(widget.itemList[index],
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_Regular,
                                    color: FontColor.FontPrimary)),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
        const SizedBox(
          height: 20,
        ),
      ],
    );
  }

  buttonOnchange(int val) {
    setState(() {
      widget.selectedItem = val;
    });
    widget.onChanged(val);
    Navigator.of(context).pop();
  }
}

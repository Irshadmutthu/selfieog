import 'dart:io';
import 'package:biometric_storage/biometric_storage.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/prefefence_utils.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_setting_others/components/fsa_bottom_sheet.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_setting_others/components/list_of_items_tile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_help_appbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';

class SettingOthersPage extends StatefulWidget {
  const SettingOthersPage({Key? key}) : super(key: key);

  @override
  State<SettingOthersPage> createState() => _SettingOthersPageState();
}

class _SettingOthersPageState extends State<SettingOthersPage> {
  bool fingerprint = UserSettings.userSettings.otherSettings.fingerPrint;
  bool faceUnclock = UserSettings.userSettings.otherSettings.faceUnclock;
  bool passwordUnlock = UserSettings.userSettings.otherSettings.passwordUnloack;
  bool patternUnlock = UserSettings.userSettings.otherSettings.patternUnloack;
  bool _support = false;
  bool indexVisibility =
      UserSettings.userSettings.otherSettings.indexVisibility;
  int selectedLoginTimeOut =
      UserSettings.userSettings.otherSettings.loginTimeout;
  int authType = UserSettings.userSettings.otherSettings.fsa;
  List<String> fsaListItem = [
    'DOB',
    'PAN CARD',
    'SECURE CODE',
    'OTP',
  ];
  List<String> logoutListItem = [
    '2 hours',
    '4 hours',
    '8 hours',
  ];
  @override
  void initState() {
    checkBioAuthSupport();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(0.0),
        child: AppBar(
          elevation: 0,
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            CustomHelpAppbar(
              iconPress: () {
                Navigator.pop(context);
              },
              title: "Others",
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
              child: Column(
                children: [
                  if (Platform.isAndroid) ...[
                    InkWell(
                      onTap: () async {
                        setState(() {
                          passwordUnlock = !passwordUnlock;
                        });
                        UserSettings.userSettings.otherSettings.patternUnloack =
                            passwordUnlock;
                        await PreferenceUtils.storeDataToShared(
                            UserController.userController.userId,
                            UserSettings.userSettings.toJsonString());
                      },
                      child: Padding(
                        padding: const EdgeInsets.only(top: 0, bottom: 20),
                        child: ListOfItemTile(
                          change: passwordUnlock,
                          title: "Password Unlock",
                          onChange: (bool val) async {
                            setState(() {
                              passwordUnlock = !passwordUnlock;
                            });
                            UserSettings.userSettings.otherSettings
                                .passwordUnloack = passwordUnlock;
                            await PreferenceUtils.storeDataToShared(
                                UserController.userController.userId,
                                UserSettings.userSettings.toJsonString());
                          },
                        ),
                      ),
                    ),
                    Divider(
                      height: 1,
                      color: customColors().backgroundTertiary,
                    ),
                    InkWell(
                      onTap: () {
                        setState(() async {
                          UserSettings.userSettings.otherSettings
                              .patternUnloack = patternUnlock = !patternUnlock;
                          await PreferenceUtils.storeDataToShared(
                              UserController.userController.userId,
                              UserSettings.userSettings.toJsonString());
                        });
                      },
                      child: Padding(
                        padding: const EdgeInsets.only(top: 20, bottom: 20),
                        child: ListOfItemTile(
                          change: patternUnlock,
                          title: "Pattern Unlock",
                          onChange: (bool val) async {
                            setState(() {
                              UserSettings.userSettings.otherSettings
                                      .patternUnloack =
                                  patternUnlock = !patternUnlock;
                            });
                            await PreferenceUtils.storeDataToShared(
                                UserController.userController.userId,
                                UserSettings.userSettings.toJsonString());
                          },
                        ),
                      ),
                    ),
                    Divider(
                      height: 1,
                      color: customColors().backgroundTertiary,
                    ),
                  ] else if (Platform.isIOS) ...[
                    InkWell(
                      onTap: () {
                        setState(() async {
                          // faceUnclock = !faceUnclock;
                          UserSettings.userSettings.otherSettings.faceUnclock =
                              faceUnclock = !faceUnclock;
                          await PreferenceUtils.storeDataToShared(
                              UserController.userController.userId,
                              UserSettings.userSettings.toJsonString());
                        });
                      },
                      child: Padding(
                        padding: const EdgeInsets.only(top: 20, bottom: 20),
                        child: ListOfItemTile(
                          change: faceUnclock,
                          title: "Face Unlock",
                          onChange: (bool val) async {
                            setState(() {
                              UserSettings.userSettings.otherSettings
                                  .faceUnclock = faceUnclock = !faceUnclock;
                            });
                            await PreferenceUtils.storeDataToShared(
                                UserController.userController.userId,
                                UserSettings.userSettings.toJsonString());
                          },
                        ),
                      ),
                    ),
                    Divider(
                      height: 1,
                      color: customColors().backgroundTertiary,
                    ),
                  ],
                  InkWell(
                    onTap: () async {
                      if (_support) {
                        _fingerClick(!fingerprint);
                      }
                    },
                    child: Padding(
                      padding: const EdgeInsets.only(top: 20, bottom: 20),
                      child: ListOfItemTile(
                        change: fingerprint && _support,
                        title: "Finger Print",
                        onChange: (bool val) async {
                          if (!_support) return;
                          _fingerClick(val);
                        },
                      ),
                    ),
                  ),
                  Divider(
                    height: 1,
                    color: customColors().backgroundTertiary,
                  ),
                  InkWell(
                    onTap: () async {
                      setState(() {
                        UserSettings
                                .userSettings.otherSettings.indexVisibility =
                            indexVisibility = !indexVisibility;
                      });
                      await PreferenceUtils.storeDataToShared(
                          UserController.userController.userId,
                          UserSettings.userSettings.toJsonString());
                    },
                    child: Padding(
                      padding: const EdgeInsets.only(top: 20, bottom: 20),
                      child: ListOfItemTile(
                        change: indexVisibility,
                        title: "Index Visibility",
                        onChange: (bool val) async {
                          setState(() {
                            UserSettings.userSettings.otherSettings
                                    .indexVisibility =
                                indexVisibility = !indexVisibility;
                          });
                          await PreferenceUtils.storeDataToShared(
                              UserController.userController.userId,
                              UserSettings.userSettings.toJsonString());
                        },
                      ),
                    ),
                  ),
                  Divider(
                    height: 1,
                    color: customColors().backgroundTertiary,
                  ),
                  InkWell(
                    onTap: () {
                      customShowModalBottomSheet(
                          context: context,
                          inputWidget: FsaBottomSheet(
                            title: "Flip Secure Authentication",
                            itemList: fsaListItem,
                            onChanged: AuthenticationType,
                            selectedItem: authType,
                          ));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 30, bottom: 30),
                          child: Text(
                            "Flip Secure Authentication",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                        ),
                        Image.asset(
                          "assets/arrow_down.png",
                          color: customColors().primary,
                        )
                      ],
                    ),
                  ),
                  Divider(
                    height: 1,
                    color: customColors().backgroundTertiary,
                  ),
                  InkWell(
                    onTap: () {
                      customShowModalBottomSheet(
                          context: context,
                          inputWidget: FsaBottomSheet(
                            title: "Login Time Out",
                            itemList: logoutListItem,
                            onChanged: loginTimeoutChange,
                            selectedItem: selectedLoginTimeOut,
                          ));
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 30, bottom: 30),
                          child: Text(
                            "Login Time Out",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                        ),
                        Row(
                          children: [
                            Text(
                              logoutListItem[selectedLoginTimeOut],
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.Primary),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: Image.asset(
                                "assets/arrow_down.png",
                                color: customColors().primary,
                              ),
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                  Divider(
                    height: 1,
                    color: customColors().backgroundTertiary,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void AuthenticationType(int auth) async {
    setState(() {
      UserSettings.userSettings.otherSettings.fsa = authType = auth;
    });
    await PreferenceUtils.storeDataToShared(
        UserController.userController.userId,
        UserSettings.userSettings.toJsonString());
  }

  loginTimeoutChange(val) async {
    setState(() {
      UserSettings.userSettings.otherSettings.loginTimeout =
          selectedLoginTimeOut = val;
    });
    await PreferenceUtils.storeDataToShared(
        UserController.userController.userId,
        UserSettings.userSettings.toJsonString());
  }

  checkBioAuthSupport() async {
    final authenticate = await _checkAuthenticate();
    if (authenticate == CanAuthenticateResponse.unsupported) {
      _support = false;
      return;
    }
    final supportsAuthenticated =
        authenticate == CanAuthenticateResponse.success;
    _support = supportsAuthenticated;
  }

  Future<CanAuthenticateResponse> _checkAuthenticate() async {
    final response = await BiometricStorage().canAuthenticate();
    return response;
  }

  void _fingerClick(bool val) async {
    if (val) {
      BiometricStorageFile _customPrompt = await BiometricStorage().getStorage(
          'SelfiePro',
          options:
              StorageFileInitOptions(authenticationValidityDurationSeconds: 10),
          promptInfo: const PromptInfo(
            iosPromptInfo: IosPromptInfo(
              saveTitle: 'Confirm Biometric',
            ),
            androidPromptInfo: AndroidPromptInfo(
              title: 'Confirm Fingerprint',
              negativeButton: 'Cancel',
            ),
            macOsPromptInfo: IosPromptInfo(
              saveTitle: 'Confirm Biometric',
            ),
          ));
      _customPrompt.delete();
      // print('reading from ${_customPrompt.name}');
      try {
        // print(UserController().userId +
        //     "|" +
        //     UserController().tfa +
        //     "|" +
        //     UserController().password);
        await _customPrompt.write(UserController().userId +
            "|" +
            UserController().tfa +
            "|" +
            UserController().password);
        setState(() {
          UserSettings.userSettings.otherSettings.fingerPrint =
              fingerprint = !fingerprint;
        });
        await PreferenceUtils.storeDataToShared(
            UserController.userController.userId,
            UserSettings.userSettings.toJsonString());
      } on AuthException catch (e) {
        if (e.code == AuthExceptionCode.userCanceled) {
          return;
        }
        rethrow;
      }
    } else {
      setState(() {
        UserSettings.userSettings.otherSettings.fingerPrint =
            fingerprint = !fingerprint;
      });
      await PreferenceUtils.storeDataToShared(
          UserController.userController.userId,
          UserSettings.userSettings.toJsonString());
    }
  }
}

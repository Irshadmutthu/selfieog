import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_alerts/components/bottomsheets/create_alert_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_alerts/components/preferences_card.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/settingsAppbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/bottom_sheet_calander.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field_with_maxlength.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/default_order_settings_values.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/order_window_settings_bottom_sheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/settings_list_panel.dart';

import '../../../../../theme/styles.dart';

class CreateAlertsPage extends StatefulWidget {
  String title;
  String symbolname;
  String ltp;
  CreateAlertsPage(
      {Key? key,
      required this.title,
      required this.symbolname,
      required this.ltp})
      : super(key: key);

  @override
  State<CreateAlertsPage> createState() => _CreateAlertsPageState();
}

class _CreateAlertsPageState extends State<CreateAlertsPage> {
  TextEditingController valucontroller = TextEditingController();
  TextEditingController dateController = TextEditingController();

  DateTime? date;
  @override
  Widget build(BuildContext context) {
    TextEditingController controller =
        TextEditingController(text: widget.symbolname);
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: SafeArea(
        child: Column(
          children: [
            SettingsAppbar(
              title: widget.title,
              onBackPressed: () {
                Navigator.pop(context);
              },
              buttonname: "Clear",
              onResetPressed: () {
                setState(() {
                  // ordersdropdownlist = optionorderlist;
                });
              },
            ),
            Expanded(
              child: SingleChildScrollView(
                child: Padding(
                  padding:
                      const EdgeInsets.only(left: 16.0, right: 16.0, top: 26.0),
                  child: Column(
                    children: [
                      CustomTextFormField(
                        controller: controller,
                        fieldName: 'Symbol Name',
                        hintText: 'Search',
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 20.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Last Traded Price',
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary),
                            ),
                            Text(
                              widget.ltp,
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary),
                            )
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 16.0),
                        child: Divider(
                          color: customColors().backgroundTertiary,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 20.0),
                        child: Row(
                          children: [
                            Text(
                              'Alert Condition',
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary),
                            )
                          ],
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          customShowModalBottomSheet(
                            context: context,
                            inputWidget: OrderSettingsSheetComponent(
                                orderSettingsSheetType:
                                    OrderSettingsSheetType.CONDITION,
                                selected: timeCondition,
                                onChanged: (int val) {
                                  setState(() {
                                    timeCondition = val;
                                  });
                                  Navigator.pop(context);
                                },
                                list: conditionalSettingsList),
                          );
                        },
                        child: Padding(
                          padding: const EdgeInsets.only(top: 12.0),
                          child: SettongsListPanel(
                            title: 'Last Traded Price is',
                            optionName: conditionalSettingsList[timeCondition]
                                ["name"],
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 20.0),
                        child: CustomTextFormField(
                          controller: valucontroller,
                          fieldName: 'Value',
                          hintText: 'Enter text here',
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 20.0),
                        child: CustomTextFormField(
                          controller: dateController,
                          fieldName: 'Valid Till',
                          hintText: 'DD/MM/YY',
                          suffixIcon: InkWell(
                            onTap: () {
                              customShowModalBottomSheet(
                                context: context,
                                inputWidget: CustommCalandarSheet(
                                  onDone: (_date) {
                                    date = _date;
                                    setState(() {
                                      dateController.text = (date == null)
                                          ? ""
                                          : DateFormat("dd/MM/yyyy")
                                              .format(date!)
                                              .toString();
                                    });
                                  },
                                ),
                              );
                            },
                            child: Image.asset(
                              'assets/calendar.png',
                              color: customColors().fontSecondary,
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 20.0),
                        child: Row(
                          children: [
                            Text(
                              'Note (Optional)',
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_Regular,
                                  color: FontColor.FontPrimary),
                            )
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 4.0),
                        child: CustomTextFormFieldWithMaxLength(
                            hintText: 'Enter text here',
                            maxLength: 50,
                            controller: controller),
                      ),
                      PreferenceCard(
                        title: 'Notification Preferences',
                      )
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: InkWell(
        onTap: () {
          customShowModalBottomSheet(
            context: context,
            inputWidget: CreateAlertBottomShett(
                alert: (widget.title == 'Modify Alert') ? false : true),
          );
        },
        child: Padding(
          padding: const EdgeInsets.only(bottom: 20.0, left: 16.0, right: 16.0),
          child: Container(
            height: 48.0,
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
                color: customColors().primary,
                borderRadius: BorderRadius.circular(4.0)),
            child: Center(
                child: Text(
              widget.title == 'Modify Alert'
                  ? ' Modify Alert'
                  : widget.title == 'Reactivate Alert'
                      ? 'Reactivate Alert'
                      : 'Create New Alert',
              style: customTextStyle(
                  fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
            )),
          ),
        ),
      ),
    );
  }
}

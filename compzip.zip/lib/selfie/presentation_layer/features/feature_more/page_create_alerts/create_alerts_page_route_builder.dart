import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_create_alerts/create_alerts_page.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class CreateAlertsPageRouteBuilder {
  final ServiceLocator serviceLocator;
  String title;
  String symbol;
  String ltp;
  CreateAlertsPageRouteBuilder(
      this.serviceLocator, this.title, this.symbol, this.ltp);

  Widget call(BuildContext context) {
    return CreateAlertsPage(
      title: title,
      symbolname: symbol,
      ltp: ltp,
    );
  }
}

import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

part 'get_a_callback_state.dart';

class GetACallbackCubit extends Cubit<GetACallbackState> {
  final ServiceLocator serviceLocator;
  GetACallbackCubit({required this.serviceLocator}) : super(GetACallbackInitial());
  onBackPressed(BuildContext context){
      serviceLocator.navigationService.back(context);
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_alerts/components/alert_active_tab/alert_active_tab.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_alerts/components/alert_cancelled_tab/alert_cancelled_tab.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_alerts/components/alert_triggered_tab/alert_triggered_tab.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_alerts/cubit/alerts_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/settingsAppbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_empty_container/custom_empty_alert_page_container.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_shimmer/alerts_shimmer.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';

class AlertsPage extends StatefulWidget {
  const AlertsPage({Key? key}) : super(key: key);

  @override
  State<AlertsPage> createState() => _AlertsPageState();
}

class _AlertsPageState extends State<AlertsPage>
    with SingleTickerProviderStateMixin {
  int initialIndex = 0;
  String tabName = "Active";
  int index = 0;
  late TabController _controller;

  List<Widget> alertswidgets = [];

  List<Tab> tablist = [
    Tab(
      text: "Active",
    ),
    Tab(
      text: "Triggered",
    ),
    Tab(
      text: "Cancelled",
    )
  ];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initialIndex = 0;
    tabName = "Active";
    _controller = TabController(length: tablist.length, vsync: this);

    _controller.addListener(() {
      setState(() {
        initialIndex = _controller.index;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    alertswidgets = [
      const AlertActiveTab(),
      const AlertTriggeredTab(),
      const AlertCancelledTab(),
    ];

    return BlocConsumer<AlertsCubit, AlertsState>(
      listener: (context, state) {
        // TODO: implement listener
        if (state is AlertsError) {
          if (state.errorMessage != "") {
            ScaffoldMessenger.of(context).showSnackBar(
                showErrorDialogue(errorMessage: state.errorMessage));
          }
        }
      },
      builder: (context, state) {
        if (state is AlertsLoading) {
          return AlertsShimmer();
        } else if (state is AlertsInitial) {
          return Scaffold(
              backgroundColor: customColors().backgroundPrimary,
              appBar: PreferredSize(
                  preferredSize: const Size.fromHeight(0.0),
                  child: AppBar(
                    elevation: 0,
                    backgroundColor: customColors().backgroundPrimary,
                  )),
              body: Stack(
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SettingsAppbar(
                          title: "Alerts",
                          onBackPressed: () {
                            Navigator.pop(context);
                          },
                          onResetPressed: () {},
                          buttonname: ""),
                      Container(
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                          border: Border(
                              bottom: BorderSide(
                                  width: 1.0,
                                  color: customColors().backgroundTertiary)),
                        ),
                        child: MediaQuery.removePadding(
                          context: context,
                          removeTop: true,
                          child: TabBar(
                            controller: _controller,
                            tabs: tablist,
                            isScrollable: true,
                            labelStyle: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.Primary),
                            labelColor: customColors().primary,
                            indicatorSize: TabBarIndicatorSize.label,
                            indicatorColor: customColors().primary,
                            unselectedLabelStyle: customTextStyle(
                                fontStyle: FontStyle.BodyL_Regular,
                                color: FontColor.FontSecondary),
                            unselectedLabelColor: customColors().fontSecondary,
                          ),
                        ),
                      ),
                      Expanded(
                        child: TabBarView(
                          children: alertswidgets,
                          controller: _controller,
                        ),
                      ),
                    ],
                  )
                ],
              ));
        } else if (state is AlertsError) {
          return CustomEmptyAlertContainer();
        } else {
          return Container();
        }
      },
    );
  }
}

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_alerts/components/bottomsheets/alert_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_alerts/components/cancelled_model_data.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_alerts/components/search_field.dart';
// import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_more_alerts/components/bottomsheets/alert_bottomsheet.dart';
// import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_more_alerts/components/cancelled_model_data.dart';
// import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_more_alerts/components/search_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/more_alerts/listview.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class AlertCancelledTab extends StatefulWidget {
  const AlertCancelledTab({Key? key}) : super(key: key);

  @override
  State<AlertCancelledTab> createState() => _AlertCancelledTabState();
}

class _AlertCancelledTabState extends State<AlertCancelledTab> {
  int screenCount = 1;
  bool ischeck = false;
  List<int> checklist = [];
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      bottomNavigationBar: checklist.length > 0
          ? SizedBox(
              height: screenSize.height * 0.13,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(
                        left: 16.0, right: 16.0, top: 8.0, bottom: 16.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Expanded(
                          flex: 2,
                          child: BasketButton(
                              bgcolor: customColors().backgroundPrimary,
                              bordercolor: customColors().green4,
                              onpress: () {},
                              text: "Cancel",
                              textStyle: customTextStyle(
                                  fontStyle: FontStyle.BodyL_Bold,
                                  color: FontColor.Primary)),
                        ),
                        Expanded(
                          flex: 2,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 8.0),
                            child: BasketButton(
                                bgcolor: customColors().primary,
                                text: "Delete Alert",
                                textStyle: customTextStyle(
                                    fontStyle: FontStyle.BodyL_Bold,
                                    color: FontColor.White)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            )
          : InkWell(
              onTap: () {
                context.gNavigationService.openCreateAlertPage(
                    context, 'Reactivate Alert', 'NSE - HDFCBANK', '₹2,388.55');
              },
              child: SizedBox(
                width: MediaQuery.of(context).size.width,
                height: 60.0,
                child: Padding(
                  padding: const EdgeInsets.only(
                      left: 16.0, right: 16.0, bottom: 15.0),
                  child: Container(
                    height: 48,
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                        color: customColors().primary,
                        borderRadius: BorderRadius.circular(4.0)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.add,
                          color: customColors().backgroundPrimary,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 13.0),
                          child: Text(
                            "Create New Alert",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_Bold,
                                color: FontColor.White),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 10),
                child: AlertSearch(
                  hintText: "Search in alerts",
                  width: MediaQuery.of(context).size.width,
                ),
              ),
              Visibility(
                visible: ischeck,
                child: Padding(
                  padding: const EdgeInsets.only(left: 16.0, right: 18.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Text(
                            '${checklist.length}/${CancelledModel.searchResults.length}',
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 4.0),
                            child: Text(
                              'Selected',
                              style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                              ),
                            ),
                          )
                        ],
                      ),
                      Row(
                        children: [
                          Text(
                            'All',
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 6.0),
                            child: EmptyCustomCheckBox(callback: (v) {
                              List.generate(CancelledModel.searchResults.length,
                                  (index) {
                                setState(() {
                                  check(index);
                                  ischeck = true;
                                });
                              });
                            }),
                          )
                        ],
                      )
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                ),
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: CancelledModel.searchResults.length,
                  itemBuilder: (BuildContext context, int index) {
                    return InkWell(
                      onTap: () {
                        customShowModalBottomSheet(
                          context: context,
                          inputWidget: AlertBottomSheet(
                            alert: false,
                          ),
                        );
                      },
                      onLongPress: () {
                        setState(() {
                          ischeck = true;
                        });
                      },
                      child: ListViewModel(
                        exchange: CancelledModel.searchResults[index].exchange,
                        symbol: CancelledModel.searchResults[index].symbol,
                        ltp: CancelledModel.searchResults[index].ltp,
                        amount: CancelledModel.searchResults[index].amount,
                        date: CancelledModel.searchResults[index].date,
                        status: CancelledModel.searchResults[index].status,
                        statusColor:
                            CancelledModel.searchResults[index].statusColor,
                        ischeck: ischeck,
                        checklist: checklist,
                        check: check,
                        index: index,
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void check(int index) {
    setState(() {
      if (checklist.contains(index)) {
        checklist.remove(index);
      } else {
        checklist.add(index);
      }
    });
  }
}

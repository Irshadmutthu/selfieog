import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_alerts/components/alert_model_data.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_alerts/components/bottomsheets/alert_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_alerts/components/bottomsheets/alert_triggered_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_alerts/components/search_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_empty_container/custom_empty_alert_page_container.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/more_alerts/listview.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

import '../../../../../../widgets/custom_app_components/buttons/BasketButton.dart';

class AlertActiveTab extends StatefulWidget {
  const AlertActiveTab({Key? key}) : super(key: key);

  @override
  State<AlertActiveTab> createState() => _AlertActiveTabState();
}

class _AlertActiveTabState extends State<AlertActiveTab> {
  int screenCount = 1;
  bool ischeck = false;
  List<int> checklist = [];
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      bottomNavigationBar: checklist.length > 0
          ? SizedBox(
              height: screenSize.height * 0.13,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(
                        left: 16.0, right: 16.0, top: 8.0, bottom: 16.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Expanded(
                          flex: 2,
                          child: BasketButton(
                              bgcolor: customColors().backgroundPrimary,
                              bordercolor: customColors().green4,
                              onpress: () {},
                              text: "Cancel",
                              textStyle: customTextStyle(
                                  fontStyle: FontStyle.BodyL_Bold,
                                  color: FontColor.Primary)),
                        ),
                        Expanded(
                          flex: 2,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 8.0),
                            child: BasketButton(
                                onpress: () {
                                  customShowModalBottomSheet(
                                    context: context,
                                    inputWidget: AlertTriggeredBottomSheet(),
                                  );
                                },
                                bgcolor: customColors().primary,
                                text: "Delete Alert",
                                textStyle: customTextStyle(
                                    fontStyle: FontStyle.BodyL_Bold,
                                    color: FontColor.White)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            )
          : InkWell(
              onTap: () {
                context.gNavigationService.openCreateAlertPage(
                    context, 'Create New Alert', '', '0.00');
              },
              child: SizedBox(
                width: MediaQuery.of(context).size.width,
                height: 60.0,
                child: Padding(
                  padding: const EdgeInsets.only(
                      left: 16.0, right: 16.0, bottom: 15.0),
                  child: Container(
                    height: 48,
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                        color: customColors().primary,
                        borderRadius: BorderRadius.circular(4.0)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.add,
                          color: customColors().backgroundPrimary,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 13.0),
                          child: Text(
                            "Create New Alert",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_Bold,
                                color: FontColor.White),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),
      body: SafeArea(
        child: Stack(
          children: [
            screenCount == 1
                ? CustomEmptyAlertContainer()
                : SingleChildScrollView(
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16, 20, 16, 10),
                          child: AlertSearch(
                            hintText: "Search in alerts",
                            width: MediaQuery.of(context).size.width,
                          ),
                        ),
                        Visibility(
                          visible: ischeck,
                          child: Padding(
                            padding:
                                const EdgeInsets.only(left: 16.0, right: 18.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      '${checklist.length}/${AlertDetailsModel.searchResults.length}',
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 4.0),
                                      child: Text(
                                        'Selected',
                                        style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_SemiBold,
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                                Row(
                                  children: [
                                    Text(
                                      'All',
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 6.0),
                                      child: EmptyCustomCheckBox(callback: (v) {
                                        List.generate(
                                            AlertDetailsModel
                                                .searchResults.length, (index) {
                                          setState(() {
                                            check(index);
                                            ischeck = true;
                                          });
                                        });
                                      }),
                                    )
                                  ],
                                )
                              ],
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                          ),
                          child: ListView.builder(
                            shrinkWrap: true,
                            itemCount: AlertDetailsModel.searchResults.length,
                            itemBuilder: (BuildContext context, int index) {
                              return InkWell(
                                onTap: () {
                                  customShowModalBottomSheet(
                                    context: context,
                                    inputWidget: AlertBottomSheet(),
                                  );
                                  // customShowModalBottomSheet(
                                  //   context: context,
                                  //   inputWidget: CreateAlertBottomShett(),
                                  // );
                                },
                                onLongPress: () {
                                  setState(() {
                                    ischeck = true;
                                  });
                                },
                                child: ListViewModel(
                                  exchange: AlertDetailsModel
                                      .searchResults[index].exchange,
                                  symbol: AlertDetailsModel
                                      .searchResults[index].symbol,
                                  ltp: AlertDetailsModel
                                      .searchResults[index].ltp,
                                  amount: AlertDetailsModel
                                      .searchResults[index].amount,
                                  date: AlertDetailsModel
                                      .searchResults[index].date,
                                  status: AlertDetailsModel
                                      .searchResults[index].status,
                                  statusColor: AlertDetailsModel
                                      .searchResults[index].statusColor,
                                  ischeck: ischeck,
                                  checklist: checklist,
                                  check: check,
                                  index: index,
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
            Align(
              alignment: Alignment.bottomCenter,
              child: skipButton(context, "$screenCount/2", () {
                if (screenCount > 1) {
                  setState(() {
                    screenCount--;
                  });
                }
              }, () {
                if (screenCount < 2) {
                  setState(() {
                    screenCount++;
                  });
                }
              }),
            ),
          ],
        ),
      ),
    );
  }

  void check(int index) {
    setState(() {
      if (checklist.contains(index)) {
        checklist.remove(index);
      } else {
        checklist.add(index);
      }
    });
  }
}

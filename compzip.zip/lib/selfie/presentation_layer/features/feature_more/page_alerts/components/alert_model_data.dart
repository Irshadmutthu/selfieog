import 'package:selfie_mobile_flutter/theme/styles.dart';

class AlertDetailsModel {
  static final List<AlertDetailsModel> searchResults = [
    AlertDetailsModel(
      exchange: "BSE",
      amount: "2388.55",
      date: "28/01/2022",
      ltp: "2400.00",
      status: "ACTIVE",
      symbol: "HDFCBANK",
      statusColor: FontColor.Success,
    ),
    AlertDetailsModel(
      exchange: "NSE",
      amount: "2388.55",
      date: "28/01/2022",
      ltp: "2400.00",
      status: "ACTIVE",
      symbol: "AXISBANK",
      statusColor: FontColor.Success,
    ),
    AlertDetailsModel(
      exchange: "NSE",
      amount: "2388.55",
      date: "28/01/2022",
      ltp: "2400.00",
      status: "ACTIVE",
      symbol: "TCS",
      statusColor: FontColor.Success,
    ),
  ];

  AlertDetailsModel({
    required this.symbol,
    required this.date,
    required this.amount,
    required this.exchange,
    required this.ltp,
    required this.status,
    required this.statusColor,
  });
  String exchange;
  String date;
  String symbol;
  String ltp;
  String status;
  String amount;
  FontColor statusColor;
}

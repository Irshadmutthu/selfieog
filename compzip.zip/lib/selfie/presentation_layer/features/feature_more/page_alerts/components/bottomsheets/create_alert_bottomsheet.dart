import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CreateAlertBottomShett extends StatelessWidget {
  bool alert;
  CreateAlertBottomShett({
    this.alert = true,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        SizedBox(
          height: 40,
        ),
        Image.asset("assets/Tick.png"),
        SizedBox(
          height: 16,
        ),
        Text(
          "Success",
          style: customTextStyle(
              fontStyle: FontStyle.HeaderS_SemiBold,
              color: FontColor.FontPrimary),
        ),
        SizedBox(
          height: 10,
        ),
        Text(
          alert
              ? "Alert Successfully Created!"
              : "Alert Successfully Modified!",
          textAlign: TextAlign.center,
          style: customTextStyle(
              fontStyle: FontStyle.BodyL_Regular,
              color: FontColor.FontSecondary),
        ),
        SizedBox(
          height: 18,
        ),
        Padding(
          padding:
              const EdgeInsets.only(top: 12, bottom: 25, left: 16, right: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                width: 160,
                height: 48,
                child: BasketButton(
                  bordercolor: transparent,
                  bgcolor: customColors().primary,
                  text: "Done",
                  textStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
                  onpress: () {
                    Navigator.of(context).pop(true);
                  },
                ),
              )
            ],
          ),
        ),
      ],
    );
  }
}

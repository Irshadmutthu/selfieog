import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class PreferenceCard extends StatefulWidget {
  String title;
  PreferenceCard({Key? key, required this.title}) : super(key: key);

  @override
  State<PreferenceCard> createState() => _PreferenceCardState();
}

class _PreferenceCardState extends State<PreferenceCard> {
  List<Map<String, dynamic>> preflist = [
    {
      'title': 'Push Notification',
      'description':
          'You will receive a notification in the Selfie Trading\nApplication.'
    },
    {
      'title': 'SMS Notification',
      'description':
          'You will receive an SMS on your registered mobile\nnumber. Standard SMS charges apply.'
    },
    {
      'title': 'Email Notification',
      'description':
          'You will receive an emai on your registered email\nID. Standard Charges apply.'
    }
  ];

  @override
  Widget build(BuildContext context) {
    buildExpanded1() {
      return MediaQuery.removePadding(
          context: context,
          removeTop: true,
          child: SingleChildScrollView(
            child: Column(children: [
              SizedBox(height: 13,),
              ListView.builder(
                padding: EdgeInsets.zero,
                  itemCount: preflist.length,
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 24.0,left: 0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  
                                  Text(
                                    preflist[index]['title'],
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyL_Regular,
                                        color: FontColor.FontPrimary),
                                  )
                                ],
                              ),

                              Padding(
                                padding: const EdgeInsets.only(top: 6),
                                child: SizedBox(
                                  child: Text(
                                    preflist[index]['description'],
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_Regular,
                                        color: FontColor.FontSecondary),
                                  ),
                                ),
                              )
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 4),
                            child: SizedBox(
                              width: 20,
                              height: 20,
                              child: EmptyCustomCheckBox(
                                callback: (v) {},
                              ),
                            ),
                          )
                        ],
                      ),
                    );
                  }),
              Row(
                children: [
                  Text(
                    'WhatsApp Notification',
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_Regular,
                        color: FontColor.FontPrimary),
                  )
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                  'Connect your WhatsApp number and recive notifications in real time. Standard charges apply.',
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_Regular,
                      color: FontColor.FontSecondary),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 16.0),
                child: Row(
                  children: [
                    Container(
                      height: 40.0,
                      width: 194.0,
                      decoration: BoxDecoration(
                          border: Border.all(color: customColors().green4),
                          borderRadius: BorderRadius.circular(4.0)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset('assets/connect.png'),
                          Padding(
                            padding: const EdgeInsets.only(left: 13.0),
                            child: Text(
                              'Connect WhatsApp',
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.Primary),
                            ),
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 40.0,
              )
            ]),
          ));
    }

    return Padding(
      padding: const EdgeInsets.only(top: 40.0),
      child: ExpandableNotifier(
          child: ScrollOnExpand(
              child: Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Builder(builder: (context) {
              var controller =
                  ExpandableController.of(context, required: true)!;
              return InkWell(
                onTap: () {
                  controller.toggle();
                },
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(
                                  'Notification Preferences',
                                  style: customTextStyle(
                                      fontStyle: FontStyle.HeaderXS_SemiBold,
                                      color: FontColor.FontPrimary),
                                )
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                  top: 6, bottom: 8, left: 4),
                              child: Row(
                                children: [
                                  Text(
                                    'Choose the notifications you want to receive.',
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_Regular,
                                        color: FontColor.FontSecondary),
                                  )
                                ],
                              ),
                            ),
                          ],
                        ),
                        InkWell(
                          onTap: () {
                            controller.toggle();
                          },
                          child: controller.expanded
                              ? Icon(
                                  Icons.keyboard_arrow_up,
                                  color: customColors().fontPrimary,
                                )
                              : Icon(
                                  Icons.keyboard_arrow_down,
                                  color: customColors().fontPrimary,
                                ),
                        )
                      ],
                    ),
                    Divider(
                      color: customColors().backgroundTertiary,
                    )
                  ],
                ),
              );
            }),
            Expandable(collapsed: Container(), expanded: buildExpanded1())
          ],
        ),
      ))),
    );
  }
}

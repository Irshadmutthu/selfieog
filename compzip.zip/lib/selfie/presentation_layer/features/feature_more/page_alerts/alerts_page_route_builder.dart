import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_alerts/alerts_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_alerts/cubit/alerts_cubit.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class AlertsPageRouteBuilder {
  final ServiceLocator serviceLocator;

  AlertsPageRouteBuilder(this.serviceLocator);

  Widget call(BuildContext context) {
    return MultiBlocProvider(
        providers: [BlocProvider(create: (context) => AlertsCubit())],
        child: MultiRepositoryProvider(providers: [
          RepositoryProvider.value(value: serviceLocator.tradingApi)
        ], child: AlertsPage()));
  }
}

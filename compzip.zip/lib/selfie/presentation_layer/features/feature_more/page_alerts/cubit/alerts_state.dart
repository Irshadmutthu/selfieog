part of 'alerts_cubit.dart';

@immutable
abstract class AlertsState {}

class AlertsLoading extends AlertsState {}

class AlertsInitial extends AlertsState {}

class AlertsError extends AlertsState {
  final int errorCode;
  final String errorMessage;
  AlertsError({required this.errorCode, required this.errorMessage});
}

import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'alerts_state.dart';

class AlertsCubit extends Cubit<AlertsState> {
  AlertsCubit() : super(AlertsInitial()) {
    getAlertDataRequest();
  }

  getAlertDataRequest() {
    print("get alertData called");
  }

  createAlertRequest() {
    print("create alert request called");
  }

  updateAlertRequest() {
    print("update alert request called");
  }

  deleteAlertRequest() {
    print("delete alert request called");
  }
}

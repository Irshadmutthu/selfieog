import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_funds/ui/components/allocation_tab.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_funds/ui/components/funds_tab.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_funds/ui/components/pledge_tab.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_top_tab.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class FundsPage extends StatelessWidget {
  ServiceLocator serviceLocator;
  FundsPage({Key? key, required this.serviceLocator}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: Column(
        children: [
          CustomAppBarInner(
              title: "Funds",
              onBackPressed: () {
                context.gNavigationService.back(context);
              }),
          Expanded(
              child: CustomTabBar(
            isScrollable: true,
            indicatorSize: TabBarIndicatorSize.label,
            tabContent: ["Funds", "Allocation", "Pledge"],
            tabBarViewChildern: [
              FundsTab(serviceLocator: serviceLocator),
              AllocationTab(),
              PledgeTab(),
            ],
          )),
        ],
      ),
    );
  }
}

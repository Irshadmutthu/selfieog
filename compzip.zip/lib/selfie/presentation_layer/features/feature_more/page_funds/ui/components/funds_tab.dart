import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_funds/cubit/funds_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_profile/profile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/card_items/show_margin_value_card.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/mbp_status_list_item.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class FundsTab extends StatelessWidget {
  final ServiceLocator serviceLocator;
  const FundsTab({Key? key, required this.serviceLocator}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<FundsCubit, FundsState>(
      builder: (context, state) {
        if (state is FundsInitial) {
          return Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    // mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Padding(
                        padding:
                            const EdgeInsets.only(left: 16, right: 16, top: 16),
                        child: Row(
                          children: [
                            Expanded(
                              flex: 1,
                              child: ShowMarginValueWidget(
                                  title: "AVAILABLE MARGIN (CASH + COLLATERAL)",
                                  value: "₹ " +
                                      Formats.valueFormatIndian2
                                          .format(double.tryParse("1004123"))),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding:
                            const EdgeInsets.only(top: 12, left: 16, right: 16),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                                flex: 1,
                                child: ShowMarginValueWidget(
                                    title: "AVAILABLE CASH",
                                    value: "₹ " +
                                        Formats.valueFormatIndian2.format(
                                            double.tryParse("30104333")))),
                            const SizedBox(
                              width: 8,
                            ),
                            Expanded(
                                flex: 1,
                                child: ShowMarginValueWidget(
                                    title: "USED MARGIN",
                                    value: "₹ " +
                                        Formats.valueFormatIndian2
                                            .format(double.tryParse("43000")))),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 26,
                      ),
                      CustomDividerWithPadding(),
                      Padding(
                        padding: EdgeInsets.only(left: 16, right: 16, top: 22),
                        child: Row(
                          children: [
                            Text(
                              "Margin Balance",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary),
                            ),
                            SizedBox(
                              width: 4,
                            ),
                            Image.asset("assets/info.png",
                                color: customColors().fontPrimary),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      MBPStatusListItem(
                          title: "Equity Cash Segment",
                          index: 1,
                          data: "₹ " +
                              Formats.valueFormatIndian2
                                  .format((double.tryParse("12872.00")))),
                      MBPStatusListItem(
                          title: "Equity F&O",
                          index: 2,
                          data: "₹ " +
                              Formats.valueFormatIndian2
                                  .format(double.tryParse("123.12"))),
                      MBPStatusListItem(
                          title: "Currency",
                          index: 1,
                          data: "₹ " +
                              Formats.valueFormatIndian2
                                  .format(double.tryParse("891.11"))),
                      MBPStatusListItem(
                          title: "Commodity",
                          index: 2,
                          data: "₹ " +
                              Formats.valueFormatIndian2
                                  .format(double.tryParse("101219121"))),
                      SizedBox(
                        height: 26,
                      ),
                      ExpandableNotifier(
                          child: ScrollOnExpand(
                              child: Container(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 16.0),
                              child: Builder(builder: (context) {
                                var controller = ExpandableController.of(
                                    context,
                                    required: true)!;
                                return InkWell(
                                  onTap: () {
                                    controller.toggle();
                                  },
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          Text(
                                            "Margin Utilized",
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyL_SemiBold,
                                                color: FontColor.FontPrimary),
                                          ),
                                          SizedBox(
                                            width: 4,
                                          ),
                                          Image.asset("assets/info.png",
                                              color:
                                                  customColors().fontPrimary),
                                        ],
                                      ),
                                      InkWell(
                                        onTap: () {
                                          controller.toggle();
                                        },
                                        child: controller.expanded
                                            ? Icon(
                                                Icons.keyboard_arrow_up,
                                                color:
                                                    customColors().fontPrimary,
                                              )
                                            : Icon(
                                                Icons.keyboard_arrow_down,
                                                color:
                                                    customColors().fontPrimary,
                                              ),
                                      )
                                    ],
                                  ),
                                );
                              }),
                            ),
                            Expandable(
                                collapsed: Container(),
                                expanded: Column(
                                  children: [
                                    MBPStatusListItem(
                                        title: "Equity Cash Segment",
                                        index: 1,
                                        data: "₹ " +
                                            Formats.valueFormatIndian2.format(
                                                double.tryParse("12872.00"))),
                                    MBPStatusListItem(
                                        title: "Equity F&O",
                                        index: 2,
                                        data: "₹ " +
                                            Formats.valueFormatIndian2.format(
                                                double.tryParse("123.12"))),
                                    MBPStatusListItem(
                                        title: "Currency",
                                        index: 1,
                                        data: "₹ " +
                                            Formats.valueFormatIndian2.format(
                                                double.tryParse("891.11"))),
                                    MBPStatusListItem(
                                        title: "Commodity",
                                        index: 2,
                                        data: "₹ " +
                                            Formats.valueFormatIndian2.format(
                                                double.tryParse("101219121"))),
                                  ],
                                ))
                          ],
                        ),
                      ))),
                      SizedBox(
                        height: 22,
                      ),
                      ExpandableNotifier(
                          child: ScrollOnExpand(
                              child: Container(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 16.0),
                              child: Builder(builder: (context) {
                                var controller = ExpandableController.of(
                                    context,
                                    required: true)!;
                                return InkWell(
                                  onTap: () {
                                    controller.toggle();
                                  },
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          Text(
                                            "Blocked Margin",
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyL_SemiBold,
                                                color: FontColor.FontPrimary),
                                          ),
                                          SizedBox(
                                            width: 4,
                                          ),
                                          Image.asset("assets/info.png",
                                              color:
                                                  customColors().fontPrimary),
                                        ],
                                      ),
                                      InkWell(
                                        onTap: () {
                                          controller.toggle();
                                        },
                                        child: controller.expanded
                                            ? Icon(
                                                Icons.keyboard_arrow_up,
                                                color:
                                                    customColors().fontPrimary,
                                              )
                                            : Icon(
                                                Icons.keyboard_arrow_down,
                                                color:
                                                    customColors().fontPrimary,
                                              ),
                                      )
                                    ],
                                  ),
                                );
                              }),
                            ),
                            Expandable(
                                collapsed: Container(),
                                expanded: Column(
                                  children: [
                                    MBPStatusListItem(
                                        title: "Equity Cash Segment",
                                        index: 1,
                                        data: "₹ " +
                                            Formats.valueFormatIndian2.format(
                                                (double.tryParse("12872.00")))),
                                    MBPStatusListItem(
                                        title: "Equity F&O",
                                        index: 2,
                                        data: "₹ " +
                                            Formats.valueFormatIndian2.format(
                                                double.tryParse("123.12"))),
                                    MBPStatusListItem(
                                        title: "Currency",
                                        index: 1,
                                        data: "₹ " +
                                            Formats.valueFormatIndian2.format(
                                                double.tryParse("891.11"))),
                                    MBPStatusListItem(
                                        title: "Commodity",
                                        index: 2,
                                        data: "₹ " +
                                            Formats.valueFormatIndian2.format(
                                                double.tryParse("101219121"))),
                                  ],
                                ))
                          ],
                        ),
                      ))),
                      Padding(
                        padding:
                            const EdgeInsets.only(left: 16, right: 16, top: 34),
                        child: Container(
                          decoration: BoxDecoration(
                              color: customColors().backgroundTertiary,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(4))),
                          padding:
                              EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "Payout Status Tab",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_SemiBold,
                                    color: FontColor.FontPrimary),
                              ),
                              Image.asset("assets/external_link.png",
                                  color: customColors().fontPrimary),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 30,
                      )
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, bottom: 10),
                child: Container(
                  color: customColors().backgroundPrimary,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Expanded(
                          child: BasketButton(
                        bordercolor: customColors().green4,
                        text: "Withdraw",
                        textStyle: customTextStyle(
                            fontStyle: FontStyle.BodyL_Bold,
                            color: FontColor.Primary),
                        onpress: () {
                          BlocProvider.of<FundsCubit>(context)
                              .onWithdrawPressed(context);
                        },
                      )),
                      SizedBox(
                        width: 8,
                      ),
                      Expanded(
                          child: BasketButton(
                        bordercolor: transparent,
                        bgcolor: customColors().primary,
                        text: "Add Funds",
                        textStyle: customTextStyle(
                            fontStyle: FontStyle.BodyL_Bold,
                            color: FontColor.White),
                        onpress: () {
                          BlocProvider.of<FundsCubit>(context)
                              .onAddfundPressed(context);
                          // serviceLocator.navigationService
                          //     .openAddFundsPage(context);
                        },
                      )),
                    ],
                  ),
                ),
              ),
            ],
          );
        } else {
          return Container();
        }
      },
    );
  }
}

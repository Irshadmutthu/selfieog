import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_profile/profile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/mbp_status_list_item.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class PledgeTab extends StatelessWidget {
  PledgeTab({
    Key? key,
  }) : super(key: key);

  TextEditingController controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
            child: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Container(
                  color: customColors().backgroundSecondary,
                  child: Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.only(left: 16, right: 16, top: 16),
                        child: CustomRow(
                          "Collateral (Liquid Funds)",
                          "10000",
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            top: 12, left: 16, right: 16, bottom: 8),
                        child: CustomRow("Collateral (Equity)", "9000"),
                      ),
                      CustomDividerWithPadding(),
                      Padding(
                          padding: EdgeInsets.only(
                              top: 8, left: 16, right: 16, bottom: 16),
                          child: CustomRow("Total Collateral", "19000"))
                    ],
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(top: 10, left: 16, bottom: 10),
                child: Row(
                  children: [
                    Text(
                      "Total Pledge Benefit",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyL_SemiBold,
                          color: FontColor.FontPrimary),
                    ),
                  ],
                ),
              ),
              Column(
                children: [
                  MBPStatusListItem(
                      title: "Cash",
                      data: "₹ " +
                          Formats.valueFormatIndian2
                              .format(double.tryParse("10000")),
                      index: 1),
                  MBPStatusListItem(
                      title: "MTF",
                      data: "₹ " +
                          Formats.valueFormatIndian2
                              .format(double.tryParse("9000")),
                      index: 2),
                  MBPStatusListItem(
                      title: "FO",
                      data: "₹ " +
                          Formats.valueFormatIndian2
                              .format(double.tryParse("800000")),
                      index: 3),
                ],
              ),
              Container(
                child: Column(
                  children: [
                    ExpandableNotifier(
                        child: ScrollOnExpand(
                            child: Container(
                      child: Column(
                        children: [
                          Padding(
                            padding: EdgeInsets.symmetric(
                                horizontal: 16, vertical: 10),
                            child: Builder(
                              builder: (context) {
                                var controller = ExpandableController.of(
                                    context,
                                    required: true)!;
                                return InkWell(
                                  onTap: () {
                                    controller.toggle();
                                  },
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Pledge with Exchange Repledge Benefit",
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyL_SemiBold,
                                            color: FontColor.FontPrimary),
                                      ),
                                      InkWell(
                                          onTap: () {
                                            controller.toggle();
                                          },
                                          child: controller.expanded
                                              ? Icon(
                                                  Icons.keyboard_arrow_up,
                                                  color: customColors()
                                                      .fontPrimary,
                                                )
                                              : Icon(
                                                  Icons.keyboard_arrow_down,
                                                  color: customColors()
                                                      .fontPrimary,
                                                ))
                                    ],
                                  ),
                                );
                              },
                            ),
                          ),
                          Expandable(
                              collapsed: Container(),
                              expanded: Column(
                                children: [
                                  MBPStatusListItem(
                                      title: "Cash",
                                      data: "₹ " +
                                          Formats.valueFormatIndian2
                                              .format(double.tryParse("10000")),
                                      index: 1),
                                  MBPStatusListItem(
                                      title: "FO",
                                      data: "₹ " +
                                          Formats.valueFormatIndian2.format(
                                              double.tryParse("800000")),
                                      index: 2),
                                ],
                              )),
                        ],
                      ),
                    ))),
                    ExpandableNotifier(
                        child: ScrollOnExpand(
                            child: Container(
                      child: Column(
                        children: [
                          Padding(
                            padding: EdgeInsets.symmetric(
                                horizontal: 16, vertical: 10),
                            child: Builder(
                              builder: (context) {
                                var controller = ExpandableController.of(
                                    context,
                                    required: true)!;
                                return InkWell(
                                  onTap: () {
                                    controller.toggle();
                                  },
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Pledge without Exchange Repledge Benefit",
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyL_SemiBold,
                                            color: FontColor.FontPrimary),
                                      ),
                                      InkWell(
                                          onTap: () {
                                            controller.toggle();
                                          },
                                          child: controller.expanded
                                              ? Icon(
                                                  Icons.keyboard_arrow_up,
                                                  color: customColors()
                                                      .fontPrimary,
                                                )
                                              : Icon(
                                                  Icons.keyboard_arrow_down,
                                                  color: customColors()
                                                      .fontPrimary,
                                                ))
                                    ],
                                  ),
                                );
                              },
                            ),
                          ),
                          Expandable(
                              collapsed: Container(),
                              expanded: Column(
                                children: [
                                  MBPStatusListItem(
                                      title: "Cash",
                                      data: "₹" +
                                          Formats.valueFormatIndian2
                                              .format(double.tryParse("10000")),
                                      index: 1),
                                  MBPStatusListItem(
                                      title: "FO",
                                      data: "₹ " +
                                          Formats.valueFormatIndian2.format(
                                              double.tryParse("800000")),
                                      index: 2),
                                ],
                              )),
                        ],
                      ),
                    ))),
                  ],
                ),
              ),
            ],
          ),
        )),
        Padding(
          padding: EdgeInsets.fromLTRB(16, 24, 16, 16),
          child: Container(
            decoration: BoxDecoration(
              color: Color(0xffE7C160).withOpacity(0.1),
              border: Border.all(color: Color(0xffE7C160).withOpacity(0.2)),
            ),
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Text(
              "Interest will be applicable for Pledge Utilized without Repledge benefit from Exchange",
              style: customTextStyle(
                  fontStyle: FontStyle.BodyM_Regular,
                  color: FontColor.FontPrimary),
            ),
          ),
        ),
        Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
                border: Border(
              top: BorderSide(
                  color: customColors().backgroundTertiary, width: 1),
            )),
            child: InkWell(
              onTap: () {},
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(
                    color: customColors().primary,
                    borderRadius: BorderRadius.circular(3.54)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Pledge",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyL_Bold,
                          color: FontColor.White),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    Icon(
                      Icons.launch,
                      color: customColors().backgroundSecondary,
                      size: 20,
                    )
                  ],
                ),
              ),
            ))
      ],
    );
  }

  Widget CustomRow(String title, String amount) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: customTextStyle(
              fontStyle: FontStyle.BodyM_Regular,
              color: FontColor.FontSecondary),
        ),
        Text(
          "₹ " + Formats.valueFormatIndian2.format(double.tryParse(amount)),
          style: customTextStyle(
              fontStyle: FontStyle.BodyM_SemiBold,
              color: FontColor.FontPrimary),
        )
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_funds/withdraw_funds/ui/components/select_bank.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_profile/profile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/settings_list_panel.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

import '../../../../../../../theme/styles.dart';
import '../../../../../../widgets/custom_app_components/buttons/BasketButton.dart';

class WithdrawFundsPage extends StatefulWidget {
  ServiceLocator serviceLocator;
  WithdrawFundsPage({Key? key, required this.serviceLocator}) : super(key: key);

  @override
  State<WithdrawFundsPage> createState() => _WithdrawFundsPageState();
}

class _WithdrawFundsPageState extends State<WithdrawFundsPage> {
  int initial_index = 0;
  TextEditingController WithdrawAmountController = TextEditingController();
  GlobalKey<FormState> formkey = GlobalKey<FormState>();

  List<Map<String, dynamic>> BankNameList = [
    {"title": "HDFC Bank LTD - 9381", "leading_image": "assets/hdfc.png"},
    {"title": "ICICI Bank LTD - 1121", "leading_image": "assets/hdfc.png"},
    {"title": "SBI Bank LTD - 1121", "leading_image": "assets/hdfc.png"},
  ];

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: Form(
        key: formkey,
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    CustomAppBarInner(
                      title: "Withdraw Funds",
                      onBackPressed: () {
                        context.gNavigationService.back(context);
                      },
                    ),
                    Container(
                      color: customColors().backgroundSecondary,
                      child: Column(children: [
                        Padding(
                          padding: const EdgeInsets.only(
                              top: 16, left: 16, right: 16, bottom: 12),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(right: 8),
                                    child: Image.asset(
                                      "assets/wallet_active.png",
                                      color: customColors().primary,
                                    ),
                                  ),
                                  Text(
                                    'Withdrawable Balance:',
                                    style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_Regular,
                                      color: FontColor.FontPrimary,
                                    ),
                                  ),
                                ],
                              ),
                              Text(
                                "₹ 1,004,123",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_Bold,
                                    color: FontColor.FontPrimary),
                              )
                            ],
                          ),
                        ),
                        CustomDividerWithPadding(),
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 16, right: 16, bottom: 16, top: 12),
                          child: CustomTextFormField(
                            prefixWidget: Text(
                              "₹",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_Bold,
                                  color: FontColor.FontPrimary),
                            ),
                            controller: WithdrawAmountController,
                            validator: Validator.defaultValidator,
                            defaultErrorMessage: "Add Amount",
                            onFieldSubmit: (value) async {
                              if (formkey.currentState!.validate()) return;
                            },
                            onChange: (value) {
                              if (formkey.currentState!.validate()) return;
                            },
                            inputFormatter: [
                              FilteringTextInputFormatter.digitsOnly,
                            ],
                            fieldName: "Amount",
                          ),
                        ),
                      ]),
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(
                              top: 24, left: 16, right: 16),
                          child: InkWell(
                            onTap: () {
                              customShowModalBottomSheet(
                                  context: context,
                                  inputWidget: Selectbank(
                                    isSelected: initial_index,
                                    BankList: BankNameList,
                                    onChanged: (int index) {
                                      setState(() {
                                        initial_index = index;
                                      });
                                    },
                                  ));
                            },
                            child: SettongsListPanel(
                              title: "Transfer to",
                              optionName: BankNameList[initial_index]["title"],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 12, right: 12),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: customColors().backgroundTertiary,
              ),
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 12, right: 12, top: 8, bottom: 8),
                child: Row(children: [
                  Expanded(
                    child: Text(
                        "The amount will get credited into your account \n withinn 1-2 Hour.",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_Regular,
                            color: FontColor.FontPrimary)),
                  )
                ]),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Container(
              // height: 58.0,
              // width: MediaQuery.of(context).size.width,

              padding: const EdgeInsets.only(
                  left: 16, right: 16, bottom: 12, top: 12),
              color: customColors().backgroundPrimary,
              // color: Colors.black,
              child: BasketButton(
                bordercolor: transparent,
                bgcolor: customColors().primary,
                text: "Withdraw",
                textStyle: customTextStyle(
                    fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
                onpress: () {
                  if (formkey.currentState!.validate()) {}
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  update_bank(int p1) {}
}

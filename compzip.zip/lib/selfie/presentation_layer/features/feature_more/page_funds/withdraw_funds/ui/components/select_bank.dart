import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_profile/profile.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class Selectbank extends StatefulWidget {
  final List<Map<String, dynamic>> BankList;
  final Function(int index) onChanged;
  int isSelected;

  Selectbank(
      {Key? key,
      required this.BankList,
      required this.onChanged,
      required this.isSelected})
      : super(key: key);

  @override
  State<Selectbank> createState() => _SelectbankState();
}

class _SelectbankState extends State<Selectbank> {
  @override
  void initState() {
    // TODO: implement initState
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 4, left: 16, bottom: 12),
          child: Row(
            children: [
              Text(
                "Bank Account",
                style: customTextStyle(
                    fontStyle: FontStyle.HeaderXS_SemiBold,
                    color: FontColor.FontPrimary),
              ),
            ],
          ),
        ),
        Divider(
          thickness: 1.2,
          color: customColors().backgroundTertiary,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: ListView.builder(
            itemCount: widget.BankList.length,
            shrinkWrap: true,
            itemBuilder: (context, index) {
              return InkWell(
                onTap: () {
                  setState(() {
                    widget.isSelected = index;

                    widget.onChanged(index);
                  });

                  Navigator.of(context).pop();
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 16.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        height: 40.0,
                        width: 40.0,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage(
                                  widget.BankList[index]["leading_image"]),
                              fit: BoxFit.fill),
                        ),
                      ),
                      const SizedBox(
                        width: 4.0,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 6.0),
                        child: Text(
                          widget.BankList[index]["title"],
                          textAlign: TextAlign.center,
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Regular,
                              color: FontColor.FontPrimary),
                        ),
                      ),
                      Expanded(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            widget.isSelected == index
                                ? Image.asset("assets/tick_circle.png")
                                : Container(),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

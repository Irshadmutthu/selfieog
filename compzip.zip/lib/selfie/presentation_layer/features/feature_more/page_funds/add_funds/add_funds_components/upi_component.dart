import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/custom_check_box.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class UpiComponent extends StatefulWidget {
  const UpiComponent({
    Key? key,
  }) : super(key: key);

  @override
  State<UpiComponent> createState() => _UpiComponentState();
}

class _UpiComponentState extends State<UpiComponent> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 10.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Open with",
                style: customTextStyle(
                    fontStyle: FontStyle.HeaderXS_SemiBold,
                    color: FontColor.FontPrimary),
              )
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 20.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Column(
                children: [
                  SizedBox(
                    height: 40.0,
                    width: 40.0,
                    child: Image.asset("assets/bhim_upi.png"),
                  ),
                  Text(
                    "BHIM UPI",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyS_Regular,
                        color: FontColor.FontPrimary),
                  )
                ],
              ),
              Column(
                children: [
                  SizedBox(
                    height: 40.0,
                    width: 40.0,
                    child: Image.asset("assets/phonepe.png"),
                  ),
                  Text(
                    "PhonePe",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyS_Regular,
                        color: FontColor.FontPrimary),
                  )
                ],
              ),
              Column(
                children: [
                  SizedBox(
                    height: 40.0,
                    width: 40.0,
                    child: Image.asset("assets/gpay.png"),
                  ),
                  Text(
                    "GPay",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyS_Regular,
                        color: FontColor.FontPrimary),
                  )
                ],
              ),
              Column(
                children: [
                  SizedBox(
                    height: 40.0,
                    width: 40.0,
                    child: Image.asset("assets/gpay.png"),
                  ),
                  Text(
                    "PhonePe",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyS_Regular,
                        color: FontColor.FontPrimary),
                  )
                ],
              )
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 36.0, top: 26.0),
          child: Row(
            children: [
              EmptyCustomCheckBox(callback: (v) {}),
              const SizedBox(
                width: 2.0,
              ),
              Text(
                "Remember my choice",
                style: customTextStyle(
                    fontStyle: FontStyle.BodyM_Regular,
                    color: FontColor.FontPrimary),
              )
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(
            left: 36.0,
            top: 26.0,
            right: 36.0,
          ),
          child: BasketButton(
            bgcolor: customColors().primary,
            text: "Cancel",
            textStyle: customTextStyle(
                fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
            onpress: () {
              Navigator.pop(context);
            },
          ),
        ),
      ],
    );
  }
}

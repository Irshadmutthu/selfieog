import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class BankComponent extends StatefulWidget {
  int selected;

  Function(int)? onChanged;

  BankComponent({Key? key, this.onChanged, required this.selected})
      : super(key: key);

  @override
  State<BankComponent> createState() => _BankComponentState();
}

class _BankComponentState extends State<BankComponent> {
  int isSelected = 0;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
          child: Row(
            children: [
              Text(
                "Bank Account",
                style: customTextStyle(
                    fontStyle: FontStyle.HeaderXS_SemiBold,
                    color: FontColor.FontPrimary),
              ),
            ],
          ),
        ),
        Container(
          height: 1,
          color: customColors().backgroundTertiary,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: ListView.builder(
            itemCount: bankList.length,
            shrinkWrap: true,
            itemBuilder: (context, index) {
              return InkWell(
                onTap: () {
                  setState(() {
                    isSelected = index;
                    widget.selected = index;
                  });
                  widget.onChanged!(index);
                  Navigator.of(context).pop();
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 16.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        height: 40.0,
                        width: 40.0,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                              image:
                                  AssetImage(bankList[index]["leading_image"]),
                              fit: BoxFit.fill),
                        ),
                      ),
                      const SizedBox(
                        width: 8.0,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 6.0),
                        child: Text(
                          bankList[index]["title"],
                          textAlign: TextAlign.center,
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Regular,
                              color: FontColor.FontPrimary),
                        ),
                      ),
                      Expanded(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            isSelected == index
                                ? Image.asset("assets/tick_circle.png")
                                : Container(),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

List<Map<String, dynamic>> bankList = [
  {
    "leading_image": "assets/hdfc_bank.png",
    "title": "HDFC Bank LTD - 9381",
  },
  {
    "leading_image": "assets/icici_bank.png",
    "title": "ICICI Bank LTD - 1121",
  },
  {
    "leading_image": "assets/sbi_bank.png",
    "title": "ICICI Bank LTD - 1121",
  },
];

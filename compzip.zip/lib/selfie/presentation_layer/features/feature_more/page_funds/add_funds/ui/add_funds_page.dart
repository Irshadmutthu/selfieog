import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';

import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_funds/add_funds/add_funds_components/bank_component.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_funds/add_funds/add_funds_components/segment_component.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_funds/add_funds/add_funds_components/upi_component.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_help_appbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/segment_panel.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class AddFundsPage extends StatefulWidget {
  final ServiceLocator serviceLocator;
  const AddFundsPage({Key? key, required this.serviceLocator})
      : super(key: key);
  @override
  State<AddFundsPage> createState() => _AddFundsPageState();
}

class _AddFundsPageState extends State<AddFundsPage> {
  TextEditingController amountController = TextEditingController();
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  int segmenttype = 0;
  int banktype = 0;

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomHelpAppbar(
                iconPress: () {
                  Navigator.pop(context);
                },
                title: "Add Funds",
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 16.0),
                alignment: Alignment.center,
                width: screenSize.width,
                height: 165.0,
                decoration:
                    BoxDecoration(color: customColors().backgroundSecondary),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(
                        top: 18.0,
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Image.asset("assets/wallet_active.png"),
                          const SizedBox(width: 8.0),
                          Text(
                            "Cash Balance:",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_Regular,
                                color: FontColor.FontPrimary),
                          ),
                          Expanded(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Text(
                                  "₹ " +
                                      Formats.valueFormatIndian2.format(
                                        (double.tryParse(
                                          "1004123",
                                        )),
                                      ),
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_Bold,
                                      color: FontColor.FontPrimary),
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 8.0,
                    ),
                    Divider(
                        thickness: 2,
                        height: 1,
                        color: customColors().backgroundTertiary),
                    Padding(
                      padding: const EdgeInsets.only(top: 16.0),
                      child: CustomTextFormField(
                        autoFocus: false,
                        validator: Validator.defaultValidator,
                        defaultErrorMessage: "Add amount",
                        inputFormatter: [
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        controller: amountController,
                        fieldName: "Amount",
                        hintText: "₹",
                        keyboardType: TextInputType.number,
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(top: 24.0, left: 16.0, right: 16.0),
                child: InkWell(
                  onTap: () {
                    customShowModalBottomSheet(
                      context: context,
                      inputWidget: SegmentComponent(
                          onChanged: updateSegment, selected: segmenttype),
                    );
                  },
                  child: SegmentPanel(
                    title: "Segment",
                    endTitle: segmentoptions[segmenttype],
                  ),
                ),
              ),
              Padding(
                padding:
                    const EdgeInsets.only(top: 8.0, left: 16.0, right: 16.0),
                child: InkWell(
                  onTap: () {
                    customShowModalBottomSheet(
                      context: context,
                      inputWidget: BankComponent(
                        onChanged: updateBank,
                        selected: banktype,
                      ),
                    );
                  },
                  child: SegmentPanel(
                    title: "Bank",
                    endTitle: bankList[banktype]["title"].toString(),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16.0, top: 24.0),
                child: Text(
                  "Pay By",
                  style: customTextStyle(
                      fontStyle: FontStyle.HeaderXS_Bold,
                      color: FontColor.FontPrimary),
                ),
              ),
              Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(
                      top: 15,
                      left: 16.0,
                      right: 16.0,
                    ),
                    child: InkWell(
                      onTap: () {
                        if (_formKey.currentState!.validate()) return;
                        customShowModalBottomSheet(
                            context: context,
                            inputWidget: const UpiComponent());
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              SizedBox(
                                  height: 48.0,
                                  width: 48.0,
                                  child: Image.asset("assets/upi.png")),
                              const SizedBox(
                                width: 16.0,
                              ),
                              Text(
                                "UPI",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_SemiBold,
                                    color: FontColor.FontPrimary),
                              ),
                            ],
                          ),
                          const Icon(Icons.chevron_right_rounded)
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 16.0, right: 16.0),
                    child: Divider(
                      thickness: 1.2,
                      color: customColors().backgroundTertiary,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(
                      left: 16.0,
                      right: 16.0,
                    ),
                    child: InkWell(
                      onTap: () {
                        if (_formKey.currentState!.validate()) return;
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              SizedBox(
                                  height: 48.0,
                                  width: 48.0,
                                  child: Image.asset("assets/net_banking.png")),
                              const SizedBox(
                                width: 16.0,
                              ),
                              Text(
                                "Net Banking",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_SemiBold,
                                    color: FontColor.FontPrimary),
                              ),
                            ],
                          ),
                          const Icon(Icons.chevron_right_rounded)
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 16.0, right: 16.0),
                    child: Divider(
                      thickness: 1.2,
                      color: customColors().backgroundTertiary,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(
                      left: 16.0,
                      right: 16.0,
                    ),
                    child: InkWell(
                      onTap: () {
                        if (_formKey.currentState!.validate()) return;

                        widget.serviceLocator.navigationService
                            .openOnlineTransactionPage(context);
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              SizedBox(
                                  height: 48.0,
                                  width: 48.0,
                                  child: Image.asset("assets/neft.png")),
                              const SizedBox(
                                width: 16.0,
                              ),
                              Text(
                                "NEFT/RTGS/IMPS",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_SemiBold,
                                    color: FontColor.FontPrimary),
                              ),
                            ],
                          ),
                          const Icon(Icons.chevron_right_rounded)
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 16.0, right: 16.0),
                    child: Divider(
                      thickness: 1.2,
                      color: customColors().backgroundTertiary,
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 100.0,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Container(
                  padding: EdgeInsets.symmetric(vertical: 10.0),
                  alignment: Alignment.centerLeft,
                  decoration:
                      BoxDecoration(color: customColors().backgroundSecondary),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const SizedBox(
                            width: 12.0,
                          ),
                          Text(
                            "Your connected UPI Id:",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontSecondary),
                          ),
                        ],
                      ),
                      Text(
                        " jaydeep@ybl",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontPrimary),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void updateSegment(int st) {
    setState(() {
      segmenttype = st;
    });
  }

  void updateBank(int bt) {
    setState(() {
      banktype = bt;
    });
  }
}

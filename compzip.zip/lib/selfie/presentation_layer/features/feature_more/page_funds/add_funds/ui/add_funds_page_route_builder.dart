import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_funds/add_funds/ui/add_funds_page.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class AddFundsPageRouteBuilder {
  final ServiceLocator serviceLocator;

  AddFundsPageRouteBuilder(this.serviceLocator);
  Widget call(BuildContext context) {
    return MultiRepositoryProvider(
        providers: [
          RepositoryProvider.value(value: serviceLocator.tradingApi),
        ],
        child: AddFundsPage(
          serviceLocator: serviceLocator,
        ));
  }
}

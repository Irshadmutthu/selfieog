import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_help_appbar.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class NeftComponent extends StatefulWidget {
  NeftComponent({Key? key}) : super(key: key);

  @override
  State<NeftComponent> createState() => _NeftComponentState();
}

class _NeftComponentState extends State<NeftComponent> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomHelpAppbar(
            iconPress: () {
              Navigator.pop(context);
            },
            title: "NEFT/RTGS/IMPS",
          ),
          SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                    left: 16.0,
                    top: 8.0,
                    bottom: 8.0,
                  ),
                  child: Text(
                    "Selected Bank",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_SemiBold,
                        color: FontColor.FontPrimary),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Container(
                    decoration: BoxDecoration(
                        color: customColors().backgroundSecondary),
                    padding: EdgeInsets.symmetric(vertical: 12.0),
                    child: Padding(
                      padding: const EdgeInsets.only(left: 13.0),
                      child: Row(
                        children: [
                          Image.asset("assets/hdfc_bank.png"),
                          const SizedBox(
                            width: 5.0,
                          ),
                          Text(
                            "HDFC Bank Pvt. Ltd.",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontPrimary),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    left: 16.0,
                    top: 24.0,
                    bottom: 8.0,
                  ),
                  child: Text(
                    "Benificary Details",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_SemiBold,
                        color: FontColor.FontPrimary),
                  ),
                ),
                ListView.builder(
                  shrinkWrap: true,
                  itemCount: bankDetails.length,
                  itemBuilder: ((context, index) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: Container(
                        color: index % 2 == 0
                            ? customColors().backgroundPrimary
                            : customColors().backgroundSecondary,
                        alignment: Alignment.center,
                        padding:
                            EdgeInsets.symmetric(vertical: 15, horizontal: 8.0),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Text(
                                  bankDetails[index]["leading"],
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyM_Regular,
                                      color: FontColor.FontSecondary),
                                ),
                                Expanded(
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      Text(
                                        bankDetails[index]["title"],
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyM_SemiBold,
                                            color: FontColor.FontPrimary),
                                      ),
                                      const SizedBox(
                                        width: 8.0,
                                      ),
                                      GestureDetector(
                                        onTap: () {},
                                        child: Image.asset(
                                            bankDetails[index]["trailing"]),
                                      )
                                    ],
                                  ),
                                )
                              ],
                            )
                          ],
                        ),
                      ),
                    );
                  }),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 90),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 16.0, bottom: 8.0),
                        child: Text(
                          "Remarks",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                          left: 16.0,
                          right: 16.0,
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4.0),
                              color: customColors().warning.withOpacity(0.2)),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16.0, vertical: 12.0),
                          child: Text(
                            "In the case of NEFT/RTGS/IMPS fund transfer, First you have to add Geojit as benificary from your respective banking service.",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontPrimary),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                          left: 16.0,
                          right: 16.0,
                          top: 8.0,
                          bottom: 16.0,
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4.0),
                              color: customColors().warning.withOpacity(0.2)),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16.0, vertical: 12.0),
                          child: Text(
                            "This mode of transfer might take upto 1 hour to update for buying power ",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontPrimary),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 11),
                        child: Divider(
                          thickness: 1.5,
                          color: customColors().backgroundTertiary,
                          height: 2,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Container(
                          padding: EdgeInsets.symmetric(vertical: 14.0),
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: customColors().primary,
                            borderRadius: BorderRadius.circular(4.0),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                "Bank Portal",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_Bold,
                                    color: FontColor.White),
                              ),
                              const SizedBox(
                                width: 10.0,
                              ),
                              SizedBox(
                                width: 20.0,
                                height: 20.0,
                                child: Image.asset(
                                  "assets/external_link.png",
                                  color: customColors().backgroundPrimary,
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}

List<Map<String, dynamic>> bankDetails = [
  {
    "leading": "Name",
    "title": "Geojit Financial Services Ltd",
    "trailing": "assets/icon_copy.png",
  },
  {
    "leading": "Bank",
    "title": "HDFC Bank",
    "trailing": "assets/icon_copy.png",
  },
  {
    "leading": "IFSC",
    "title": "UTI000871",
    "trailing": "assets/icon_copy.png",
  },
  {
    "leading": "Benify ID",
    "title": "Vdf0913Geojit",
    "trailing": "assets/icon_copy.png",
  },
];

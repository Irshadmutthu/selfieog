import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/more_content.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

part 'contact_geojit_state.dart';

class ContactGeojitCubit extends Cubit<ContactGeojitState> {
  final ServiceLocator serviceLocator;
  ContactGeojitCubit({required this.serviceLocator}) : super(ContactGeojitInitial(callbackrequestList: callbackrequestList));

  onBackPressed(BuildContext context){
      serviceLocator.navigationService.back(context);
  }
}

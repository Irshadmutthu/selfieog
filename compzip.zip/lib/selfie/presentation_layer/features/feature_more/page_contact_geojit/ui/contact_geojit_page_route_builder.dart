import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_contact_geojit/bloc/contact_geojit_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_contact_geojit/ui/contact_geojit_page.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class ContactGeojitPageRouteBuilder{
  final ServiceLocator serviceLocator;

  ContactGeojitPageRouteBuilder(this.serviceLocator);
  Widget call(BuildContext context){
    return MultiProvider(providers: [
      BlocProvider(create: ((context) => ContactGeojitCubit(serviceLocator: serviceLocator))),
    ],
    child: MultiRepositoryProvider(providers: [
      RepositoryProvider.value(value: serviceLocator.navigationService),
      RepositoryProvider<CubitsLocator>.value(value: serviceLocator)
    ],child: const ContactGeojitPage(),
    ),);
  }
}
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_contact_geojit/bloc/contact_geojit_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/more_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/more/contact_geojit_list_item_selected.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';

class ContactGeojitPage extends StatefulWidget {
  const ContactGeojitPage({Key? key}) : super(key: key);

  @override
  State<ContactGeojitPage> createState() => _ContactGeojitPageState();
}

class _ContactGeojitPageState extends State<ContactGeojitPage> {
  bool callbackRequestStatus = false;
  int screenCount = 1;
  int checkcount = 0;
  List<String> checklist = [];
  bool isCallbackRequestLongpress = false;
  // Widget callback

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: Stack(
        children: [
          SingleChildScrollView(
            child: Column(
              verticalDirection: VerticalDirection.down,
              children: [
                CustomAppBarInner(
                    title: "Contact Geojit",
                    onBackPressed: () {
                      BlocProvider.of<ContactGeojitCubit>(context)
                          .onBackPressed(context);
                    }),
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8.0),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      "Branch Manager",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.FontSecondary),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                      left: 16.0, right: 16, top: 0, bottom: 8),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text("Manoj Kumar",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_SemiBold,
                            color: FontColor.FontPrimary)),
                  ),
                ),
                Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 8.0),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "Phone",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      ),
                    )),
                Padding(
                  padding: const EdgeInsets.only(
                      left: 16.0, right: 16, top: 0, bottom: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("+912241642213",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary)),
                      Image.asset("assets/call_normal.png"),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                      left: 16.0, right: 16, top: 8, bottom: 8),
                  child: SizedBox(
                    height: 0,
                    child: Divider(
                      height: 1,
                      color: customColors().backgroundTertiary,
                    ),
                  ),
                ),
                Padding(
                    padding: const EdgeInsets.only(
                        left: 16.0, right: 16, top: 8, bottom: 8),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "Dealer Number",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      ),
                    )),
                Padding(
                  padding: const EdgeInsets.only(
                      left: 16.0, right: 16, top: 0, bottom: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("+91 9876543210",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary)),
                      Image.asset("assets/call_normal.png"),
                    ],
                  ),
                ),
                Padding(
                    padding: const EdgeInsets.only(
                        left: 16.0, right: 16, top: 8, bottom: 8),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "Customer Care Number",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      ),
                    )),
                Padding(
                  padding: const EdgeInsets.only(
                      left: 16.0, right: 16, top: 0, bottom: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("844-417-3530",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary)),
                      Image.asset("assets/call_normal.png"),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                      left: 16.0, right: 16, top: 12, bottom: 8),
                  child: Divider(
                    height: 1,
                    color: customColors().backgroundTertiary,
                  ),
                ),
                Padding(
                    padding: const EdgeInsets.only(
                        left: 16.0, right: 16, top: 8, bottom: 8),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "WhatsApp Chat",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontSecondary),
                      ),
                    )),
                Padding(
                  padding: const EdgeInsets.only(
                      left: 16.0, right: 16, top: 0, bottom: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("9874563210",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary)),
                      Image.asset("assets/whatsapplogo.png",
                          color: customColors().primary),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                      left: 16.0, right: 16, top: 10, bottom: 30),
                  child: SizedBox(
                    height: 0,
                    child: Divider(
                      height: 1,
                      color: customColors().backgroundTertiary,
                    ),
                  ),
                ),
                if (screenCount == 1) EmptyCallbackWidget(),
                if (screenCount == 2 && !isCallbackRequestLongpress)
                  CallbackListWidget(
                    longpressAction: (val) {
                      setState(() {
                        isCallbackRequestLongpress = val;
                      });
                    },
                  ),
                if (screenCount == 2 && isCallbackRequestLongpress)
                  const CallbackEditListWidget(),
                // CallbackListWidget(),
              ],
            ),
          ),
          if (screenCount != 1 &&
              screenCount == 2 &&
              !isCallbackRequestLongpress)
            Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Container(
                  // color: Colors.white,
                  color: customColors().backgroundPrimary,
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: BasketButton(
                          textStyle: customTextStyle(
                              fontStyle: FontStyle.BodyL_Bold,
                              color: FontColor.White),
                          text: "Get a Call Back",
                          bgcolor: customColors().primary,
                          onpress: () {
                            context.gNavigationService
                                .openGetACallbackPage(context);
                          }),
                    ),
                  ),
                ),
              ],
            ),
          if (screenCount != 1 &&
              screenCount == 2 &&
              isCallbackRequestLongpress)
            Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Container(
                  // color: Colors.white,
                  color: customColors().backgroundPrimary,
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Row(
                        children: [
                          Expanded(
                            child: BasketButton(
                              bordercolor: customColors().primary,
                              text: "Cancel",
                              textStyle: customTextStyle(
                                  fontStyle: FontStyle.BodyL_Bold,
                                  color: FontColor.Primary),
                              onpress: () {
                                // Navigator.of(context).pop(true);
                                setState(() {
                                  isCallbackRequestLongpress = false;
                                });
                              },
                            ),
                          ),
                          const SizedBox(
                            width: 16,
                          ),
                          Expanded(
                            child: BasketButton(
                                textStyle: customTextStyle(
                                    fontStyle: FontStyle.BodyL_Bold,
                                    color: FontColor.White),
                                text: "Delete",
                                bgcolor: customColors().primary,
                                onpress: () {
                                  // context.gNavigationService
                                  //     .openGetACallbackPage(context);
                                  setState(() {
                                    isCallbackRequestLongpress = false;
                                  });
                                }),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          Align(
            alignment: Alignment.bottomCenter,
            child: skipButton(context, "$screenCount/2", () {
              if (screenCount > 1) {
                setState(() {
                  screenCount--;
                  callbackRequestStatus = false;
                });
              }
            }, () {
              if (screenCount < 3) {
                setState(() {
                  screenCount++;
                  callbackRequestStatus = true;
                });
              }
            }),
          ),
        ],
      ),
    );
  }
}

class EmptyCallbackWidget extends StatelessWidget {
  EmptyCallbackWidget({
    Key? key,
  }) : super(key: key);
  int checkcount = 0;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(height: 165, child: Image.asset("assets/circles_confirm.png")),
        Padding(
          padding:
              const EdgeInsets.only(left: 16.0, right: 16, top: 17, bottom: 85),
          child: Text("Need a personal assistance ?",
              style: customTextStyle(
                  fontStyle: FontStyle.BodyL_Regular,
                  color: FontColor.FontPrimary)),
        ),
      ],
    );
  }
}

class CallbackListWidget extends StatefulWidget {
  final Function(bool) longpressAction;
  CallbackListWidget({Key? key, required this.longpressAction})
      : super(key: key);

  @override
  State<CallbackListWidget> createState() => _CallbackListWidgetState();
}

class _CallbackListWidgetState extends State<CallbackListWidget> {
  int checkcount = 0;
  List<String> checklist = [];
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
          const EdgeInsets.only(left: 16.0, right: 16, top: 10, bottom: 10),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Call back requests",
                style: customTextStyle(
                    fontStyle: FontStyle.HeaderXS_Bold,
                    color: FontColor.FontPrimary),
              ),
            ],
          ),
          const SizedBox(
            height: 27,
          ),
          ListView.builder(
              itemCount: callbackrequestList.length,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemBuilder: (context, index) {
                return InkWell(
                  onLongPress: () => setState(() {
                    widget.longpressAction(true);
                  }),
                  onTap: () => setState(() {}),
                  child: ContactListItemSelected(
                    positionsamples: callbackrequestList[index],
                    checklist: checklist,
                    // isActive: isCallbackRequestLongpress,
                    upcount: updatecount,
                  ),
                );
              }),
          const SizedBox(
            height: 70,
          )
        ],
      ),
    );
  }

  void updatecount(int count) {
    setState(() {
      checkcount = count;
    });
  }
}

class CallbackEditListWidget extends StatefulWidget {
  const CallbackEditListWidget({Key? key}) : super(key: key);

  @override
  State<CallbackEditListWidget> createState() => _CallbackEditListWidgetState();
}

class _CallbackEditListWidgetState extends State<CallbackEditListWidget> {
  int checkcount = 0;
  List<String> checklist = [];
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
          const EdgeInsets.only(left: 16.0, right: 16, top: 10, bottom: 10),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Call back requests",
                style: customTextStyle(
                    fontStyle: FontStyle.HeaderXS_Bold,
                    color: FontColor.FontPrimary),
              ),
              Row(
                children: [
                  Text(
                    "All",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_SemiBold,
                        color: FontColor.FontPrimary),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  EmptyCustomCheckBox(
                    callback: (val) {
                      checkall();
                    },
                    isSelect: checklist.length == callbackrequestList.length
                        ? true
                        : false,
                  )
                ],
              ),
            ],
          ),
          const SizedBox(
            height: 27,
          ),
          ListView.builder(
              itemCount: callbackrequestList.length,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemBuilder: (context, index) {
                return ContactListItemSelected(
                  positionsamples: callbackrequestList[index],
                  checklist: checklist,
                  isActive: true,
                  upcount: updatecount,
                );
              }),
          const SizedBox(
            height: 45,
          )
        ],
      ),
    );
  }

  void updatecount(int count) {
    setState(() {
      checkcount = count;
    });
  }

  void checkall() {
    setState(() {
      if (checklist.isEmpty) {
        for (int i = 0; i < callbackrequestList.length; i++) {
          checklist.add(callbackrequestList[i]["name"]);
        }
      } else {
        checklist.clear();
      }
      checkcount = checklist.length;
    });
  }
}

import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'callback_request_state.dart';

class CallbackRequestCubit extends Cubit<CallbackRequestState> {
  CallbackRequestCubit() : super(CallbackRequestInitial());
}

part of 'callback_request_cubit.dart';

@immutable
abstract class CallbackRequestState {}

class CallbackRequestInitial extends CallbackRequestState {}

import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

part 'market_simulator_state.dart';

class MarketSimulatorCubit extends Cubit<MarketSimulatorState> {
  final ServiceLocator serviceLocator;
  MarketSimulatorCubit({required this.serviceLocator}) : super(MarketSimulatorInitial());
  onBackPressed(BuildContext context){
    serviceLocator.navigationService.back(context);
  }
}

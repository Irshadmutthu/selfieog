class AllNotificationDetailsModel {
  static final List<AllNotificationDetailsModel> searchResults = [
    AllNotificationDetailsModel(
      name: "Fund Transfer - Deposite ₹2000",
      date: "03/03/22",
      details: "You have added ₹2000 to your Geojit account.",
      symbol: "FT",
    ),
    AllNotificationDetailsModel(
      name: "Fund Transfer - Withdraw ₹2000",
      date: "03/03/22",
      details: "You have withdraw ₹2000 to your Geojit account.",
      symbol: "FT",
    ),
    AllNotificationDetailsModel(
      name: "Geojit",
      date: "04/03/22",
      details: "You have withdraw ₹2000 to your Geojit account.",
      symbol: "G",
    ),
    AllNotificationDetailsModel(
      name: "Fundamental Research - TATAPOWER",
      date: "12/03/22",
      details:
          "The detail Fundamental Research of TATAPOWER is\navailable for you.",
      symbol: "FR",
    ),
  ];

  AllNotificationDetailsModel({
    required this.details,
    required this.name,
    required this.symbol,
    required this.date,
  });
  String name;
  String details;
  String date;
  String symbol;
}


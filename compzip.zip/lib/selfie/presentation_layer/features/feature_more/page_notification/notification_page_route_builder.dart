import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_notification/notification_page.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class NotificationPageRouteBuilder {
  final ServiceLocator serviceLocator;

  NotificationPageRouteBuilder(this.serviceLocator);

  Widget call(BuildContext context) {
    return MultiRepositoryProvider(
      providers: [
        RepositoryProvider.value(value: serviceLocator.navigationService),
        RepositoryProvider<CubitsLocator>.value(value: serviceLocator),
      ],
      child: NotificationPage(),
    );
  }
}

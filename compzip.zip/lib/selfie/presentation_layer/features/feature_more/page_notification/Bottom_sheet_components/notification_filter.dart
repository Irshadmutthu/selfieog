import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class NotificationFilter extends StatefulWidget {
  const NotificationFilter({Key? key}) : super(key: key);

  @override
  State<NotificationFilter> createState() => _NotificationFilterState();
}

class _NotificationFilterState extends State<NotificationFilter> {
  int totalCount = 0;

  List<Map<String, dynamic>> items = [
    {"name": "All"},
    {"name": "Funds"},
    {"name": "IPO"},
    {"name": "Alerts"},
    {"name": "Smartfolio"},
    {"name": "Fundamental Research"},
    {"name": "Technical Research"},
  ];

  callback(bool stsa) {
    setState(() {
      stsa ? totalCount++ : totalCount--;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: Column(
        children: [
          Padding(
            padding:
                const EdgeInsets.only(left: 16, right: 16, top: 10, bottom: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Topics",
                  style: customTextStyle(
                    fontStyle: FontStyle.HeaderXS_SemiBold,
                    color: FontColor.FontPrimary,
                  ),
                ),
                InkWell(
                  onTap: () {},
                  child: Text(
                    "Clear",
                    style: customTextStyle(
                      fontStyle: FontStyle.BodyL_Bold,
                      color: FontColor.Primary,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Divider(
            height: 0,
            thickness: 1,
            color: customColors().backgroundTertiary,
          ),
          Column(
            children: [
              const SizedBox(
                height: 13,
              ),
              for (int i = 0; i < items.length; i++)
                Padding(
                  padding: const EdgeInsets.only(
                      left: 16, right: 16, top: 10, bottom: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 18,
                        width: 18,
                        child: EmptyCustomCheckBox(
                          callback: callback,
                          isSelect: i == 0 || i == 2 ? true : false,
                        ),
                      ),
                      const SizedBox(
                        width: 13,
                      ),
                      Text(
                        items[i]["name"],
                        style: customTextStyle(
                          fontStyle: FontStyle.BodyL_Regular,
                          color: FontColor.FontPrimary,
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
          const SizedBox(
            height: 20,
          ),
        ],
      ),
    );
  }
}

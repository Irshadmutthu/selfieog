import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_become_partner/become_partner_page.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class BecomePartnerRouteBuilder {
  final ServiceLocator serviceLocator;

  BecomePartnerRouteBuilder(this.serviceLocator);

  Widget call(BuildContext context) {
    return MultiBlocProvider(
      providers: [],
      child: BecomePartnerPage(),
    );
  }
}

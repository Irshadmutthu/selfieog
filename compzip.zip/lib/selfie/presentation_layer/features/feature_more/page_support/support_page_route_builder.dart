import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_more/page_support/support_page.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class SupportPageRouteBuilder {
  final ServiceLocator serviceLocator;

  SupportPageRouteBuilder(this.serviceLocator);

  Widget call(BuildContext context) {
    return MultiRepositoryProvider(
      providers: [
        RepositoryProvider.value(value: serviceLocator.navigationService),
        RepositoryProvider<CubitsLocator>.value(value: serviceLocator),
      ],
      child: Supportpage(),
    );
  }
}

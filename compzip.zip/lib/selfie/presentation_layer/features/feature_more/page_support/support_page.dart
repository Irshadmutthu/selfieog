import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_help_appbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/Button_with_Icon.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';

class Supportpage extends StatelessWidget {
  Supportpage({Key? key}) : super(key: key);

  List<Map<String, dynamic>> item = [
    {"name": "Contact Geojit", "icon": "assets/contactgeojit.png"},
    {"name": "Raise a Ticket", "icon": "assets/ticket.png"},
    {"name": "User Manual", "icon": "assets/manual.png"},
    {"name": "FAQ", "icon": "assets/document.png"},
    {"name": "Give Feedback", "icon": "assets/chat.png"},
    {"name": "Suggest Features", "icon": "assets/pen.png"},
    {"name": "Rate Us", "icon": "assets/partner.png"},
  ];

  pageNavigation({required int index, required BuildContext context}) {
    switch (index) {
      case 0:
        {
          context.gNavigationService.openContactGeojitPage(context);
        }
        break;
      case 1:
        {
          context.gNavigationService.openRaiseATicketPage(context);
        }
        break;
      case 2:
        {}
        break;
      case 3:
        {}
        break;
      case 4:
        {
          context.gNavigationService.openFeedbackPage(context);
        }
        break;
      case 5:
        {
          context.gNavigationService.openSuggestPage(context);
        }
        break;
      case 6:
        {}
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(0.0),
        child: AppBar(
          elevation: 0,
          backgroundColor: customColors().backgroundPrimary,
        ),
      ),
      body: SafeArea(
        child: Stack(
          children: [
            CustomHelpAppbar(
              iconPress: () {
                Navigator.pop(context);
              },
              title: "Support",
            ),
            Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 60),
                  child: SizedBox(
                    height: item.length.toDouble() * 70,
                    child: ListView.builder(
                      itemCount: item.length,
                      itemBuilder: (context, index) => InkWell(
                        onTap: () {
                          pageNavigation(index: index, context: context);
                        },
                        child: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 25, vertical: 20),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Image.asset(
                                        item[index]["icon"],
                                        height: 16,
                                        width: 16,
                                      ),
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(left: 16),
                                        child: Text(
                                          item[index]["name"],
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyL_SemiBold,
                                              color: FontColor.FontPrimary),
                                        ),
                                      )
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      InkWell(
                                        onTap: () {},
                                        child: SizedBox(
                                          child: Image.asset(
                                            "assets/arrowright.png",
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 16, right: 16),
                              child: Divider(
                                height: 1,
                                thickness: 1.2,
                                color: customColors().backgroundTertiary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 80),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Text(
                      "Toll free Number",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_Regular,
                          color: FontColor.FontPrimary),
                    ),
                  ),
                ),
                Padding(
                  padding:
                      const EdgeInsets.only(bottom: 20, left: 16, right: 16),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(
                          flex: 1,
                          child: ButtonWithIcon(
                            height: 48,
                            bgcolor: customColors().backgroundPrimary,
                            text: "1800 425 5501",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.FontPrimary),
                            icon1: "assets/Call.png",
                            bordercolor: customColors().green4,
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Expanded(
                          flex: 1,
                          child: ButtonWithIcon(
                            height: 48,
                            bgcolor: customColors().backgroundPrimary,
                            text: "1800 425 5501",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.FontPrimary),
                            icon1: "assets/Call.png",
                            bordercolor: customColors().green4,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}

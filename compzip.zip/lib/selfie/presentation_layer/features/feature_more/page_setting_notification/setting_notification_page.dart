import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/prefefence_utils.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/more_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_help_appbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/more/empty_volume_button/empty_volume_button.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';

class SettingNotificationPage extends StatefulWidget {
  SettingNotificationPage({Key? key}) : super(key: key);

  @override
  State<SettingNotificationPage> createState() =>
      _SettingNotificationPageState();
}

class _SettingNotificationPageState extends State<SettingNotificationPage> {
  bool rb1 = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(0.0),
        child: AppBar(
          elevation: 0,
          backgroundColor: customColors().backgroundPrimary,
        ),
      ),
      body: SafeArea(
        child: Stack(
          children: [
            CustomHelpAppbar(
              iconPress: () {
                Navigator.pop(context);
              },
              title: "Notifications",
            ),
            Padding(
              padding: const EdgeInsets.only(left: 16, right: 16, top: 60),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "GENERAL NOTIFICATIONS",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_Regular,
                              color: FontColor.FontSecondary),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text(
                              "PUSH",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_Regular,
                                  color: FontColor.FontSecondary),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 30),
                              child: Text(
                                "SOUND",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_Regular,
                                    color: FontColor.FontSecondary),
                              ),
                            )
                          ],
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 10, bottom: 10),
                      child: Divider(
                        height: 1,
                        color: customColors().backgroundTertiary,
                      ),
                    ),
                    Column(
                      children: [
                        customNotificationNameWidget(
                            title: "Equity Market Open/Close",
                            pushStatus: UserSettings.userSettings
                                .notificationSettings.equityMarketOpenClosePush,
                            soundStatus: UserSettings
                                .userSettings
                                .notificationSettings
                                .equityMarketOpenCloseSound,
                            pushOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .equityMarketOpenClosePush = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            },
                            soundOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .equityMarketOpenCloseSound = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            }),
                        customNotificationNameWidget(
                            title: "Alerts",
                            pushStatus: UserSettings
                                .userSettings.notificationSettings.alertsPush,
                            soundStatus: UserSettings
                                .userSettings.notificationSettings.alertsSound,
                            pushOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .alertsPush = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            },
                            soundOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .alertsSound = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            }),
                        customNotificationNameWidget(
                            title: "Nudge",
                            pushStatus: UserSettings
                                .userSettings.notificationSettings.nudgePush,
                            soundStatus: UserSettings
                                .userSettings.notificationSettings.nudgeSound,
                            pushOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .nudgePush = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            },
                            soundOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .nudgeSound = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            }),
                        customNotificationNameWidget(
                            title: "Security",
                            pushStatus: UserSettings
                                .userSettings.notificationSettings.securityPush,
                            soundStatus: UserSettings.userSettings
                                .notificationSettings.securitySound,
                            pushOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .securityPush = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            },
                            soundOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .securitySound = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            }),
                        customNotificationNameWidget(
                            title: "Risk Managment System",
                            pushStatus: UserSettings.userSettings
                                .notificationSettings.riskManagmentSystemPush,
                            soundStatus: UserSettings.userSettings
                                .notificationSettings.riskManagmentSystemSound,
                            pushOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .riskManagmentSystemPush = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            },
                            soundOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .riskManagmentSystemSound = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            }),
                      ],
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "ORDER NOTIFICATIONS",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_Regular,
                              color: FontColor.FontSecondary),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text(
                              "PUSH",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_Regular,
                                  color: FontColor.FontSecondary),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 30),
                              child: Text(
                                "SOUND",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_Regular,
                                    color: FontColor.FontSecondary),
                              ),
                            )
                          ],
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 10, bottom: 10),
                      child: Divider(
                        height: 1,
                        color: customColors().backgroundTertiary,
                      ),
                    ),
                    Column(
                      children: [
                        customNotificationNameWidget(
                            title: "Order Execution",
                            pushStatus: UserSettings.userSettings
                                .notificationSettings.orderExecutionPush,
                            soundStatus: UserSettings.userSettings
                                .notificationSettings.orderExecutionSound,
                            pushOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .orderExecutionPush = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            },
                            soundOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .orderExecutionSound = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            }),
                        customNotificationNameWidget(
                            title: "Review Order & Send",
                            pushStatus: UserSettings.userSettings
                                .notificationSettings.reviewOrderSendPush,
                            soundStatus: UserSettings.userSettings
                                .notificationSettings.reviewOrderSendSound,
                            pushOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .reviewOrderSendPush = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            },
                            soundOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .reviewOrderSendSound = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            }),
                      ],
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "RESEARCH NOTIFICATIONS",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_Regular,
                              color: FontColor.FontSecondary),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text(
                              "PUSH",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_Regular,
                                  color: FontColor.FontSecondary),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 30),
                              child: Text(
                                "SOUND",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_Regular,
                                    color: FontColor.FontSecondary),
                              ),
                            )
                          ],
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 10, bottom: 10),
                      child: Divider(
                        height: 1,
                        color: customColors().backgroundTertiary,
                      ),
                    ),
                    Column(
                      children: [
                        customNotificationNameWidget(
                            title: "Fundamental",
                            pushStatus: UserSettings.userSettings
                                .notificationSettings.fundamentalPush,
                            soundStatus: UserSettings.userSettings
                                .notificationSettings.fundamentalSound,
                            pushOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .fundamentalPush = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            },
                            soundOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .fundamentalSound = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            }),
                        customNotificationNameWidget(
                            title: "Technical",
                            pushStatus: UserSettings.userSettings
                                .notificationSettings.technicalPush,
                            soundStatus: UserSettings.userSettings
                                .notificationSettings.technicalSound,
                            pushOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .technicalPush = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            },
                            soundOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .technicalSound = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            }),
                        customNotificationNameWidget(
                            title: "Equity",
                            pushStatus: UserSettings
                                .userSettings.notificationSettings.equityPush,
                            soundStatus: UserSettings
                                .userSettings.notificationSettings.equitySound,
                            pushOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .equityPush = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            },
                            soundOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .equitySound = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            }),
                        customNotificationNameWidget(
                            title: "F&O",
                            pushStatus: UserSettings
                                .userSettings.notificationSettings.fandoPush,
                            soundStatus: UserSettings
                                .userSettings.notificationSettings.fandoSound,
                            pushOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .fandoPush = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            },
                            soundOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .fandoSound = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            }),
                        customNotificationNameWidget(
                            title: "Currency",
                            pushStatus: UserSettings
                                .userSettings.notificationSettings.currencyPush,
                            soundStatus: UserSettings.userSettings
                                .notificationSettings.currencySound,
                            pushOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .currencyPush = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            },
                            soundOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .currencySound = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            }),
                        customNotificationNameWidget(
                            title: "Commodity",
                            pushStatus: UserSettings.userSettings
                                .notificationSettings.commodityPush,
                            soundStatus: UserSettings.userSettings
                                .notificationSettings.commoditySound,
                            pushOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .commodityPush = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            },
                            soundOnchange: (value) async {
                              UserSettings.userSettings.notificationSettings
                                  .commoditySound = value;
                              await PreferenceUtils.storeDataToShared(
                                  UserController.userController.userId,
                                  UserSettings.userSettings.toJsonString());
                            }),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget customNotificationNameWidget(
      {required String title,
      dynamic pushStatus,
      dynamic soundStatus,
      required Function(bool) pushOnchange,
      required Function(bool) soundOnchange}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: customTextStyle(
                fontStyle: FontStyle.BodyL_Regular,
                color: FontColor.FontPrimary),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: EmptyCustomCheckBox(
                      isSelect: pushStatus,
                      callback: (bool checkValue) async {
                        pushOnchange(checkValue);
                        setState(() {
                          // UserSettings.userSettings.notificationSettings.notificationSettings[generalnotifications[index]["name"]+" push"]=checkValue;
                        });
                        await PreferenceUtils.storeDataToShared(
                            UserController.userController.userId,
                            UserSettings.userSettings.toJsonString());
                      }),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 30),
                  child: EmptyVolumeOffButton(
                      isSelect: soundStatus,
                      callback: (bool checkValue) async {
                        soundOnchange(checkValue);
                        setState(() {});
                        await PreferenceUtils.storeDataToShared(
                            UserController.userController.userId,
                            UserSettings.userSettings.toJsonString());
                      }),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/prefefence_utils.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/more_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/alert_dialogs.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/custom_radio_button.dart';
import 'package:selfie_mobile_flutter/theme/custom_theme.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';

class ThemeChangeBottomSheet extends StatefulWidget {
  const ThemeChangeBottomSheet({
    Key? key,
  }) : super(key: key);

  @override
  State<ThemeChangeBottomSheet> createState() => _ThemeChangeBottomSheetState();
}

class _ThemeChangeBottomSheetState extends State<ThemeChangeBottomSheet> {
  int gValue = 0;

  List<String> listItem = [
    'Light Mode',
    'Dark Mode',
    'Black Mode',
  ];

  @override
  void initState() {
    super.initState();
    CustomTheme.modelTheme.mode == CustomMode.Light
        ? gValue = 0
        : CustomTheme.modelTheme.mode == CustomMode.Mid
            ? gValue = 1
            : gValue = 2;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Text(
            "Select Theme",
            style: customTextStyle(
                fontStyle: FontStyle.HeaderXS_SemiBold,
                color: FontColor.FontPrimary),
          ),
        ),
        Container(
          height: 1,
          color: customColors().backgroundTertiary,
        ),
        const SizedBox(
          height: 10,
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 0, 10),
          child: ListView.builder(
              shrinkWrap: true,
              itemCount: listItem.length,
              itemBuilder: (context, index) {
                return MyRadioListTile<int>(
                  value: index,
                  groupValue: gValue,
                  title: Text(
                    listItem[index],
                    style: customTextStyle(
                      fontStyle: FontStyle.BodyL_Regular,
                      color: FontColor.FontPrimary,
                    ),
                  ),
                  onChanged: (value) {
                    setState(() {
                      gValue = value!;
                      switchThemeIndex(value);
                    });
                  },
                );
              }),
        ),
      ],
    );
  }

  switchThemeIndex(int index) async {
    switch (index) {
      case 0:
        {
          switchTheme(CustomMode.Light);
          break;
        }
      case 1:
        {
          switchTheme(CustomMode.Mid);
          break;
        }

      case 2:
        {
          switchTheme(CustomMode.Dark);
          break;
        }
    }
  }

  switchTheme(CustomMode mode) async {
    await showAlertDilogue(
        context: context,
        content: "Restart the application to save changes",
        positiveButtonName: "Restart",
        negativeButtonName: "Cancel",
        onPositiveButtonClick: () async {
          await updateTheme(mode);
        },
        onNegativeButtonClick: () {
          Navigator.pop(context);
          Navigator.pop(context);
        });
  }

  updateTheme(CustomMode mode) async {
    switch (mode) {
      case CustomMode.Dark:
        {
          setState(() {
            gValue = 2;
          });
          break;
        }
      case CustomMode.Mid:
        {
          setState(() {
            gValue = 1;
          });
          break;
        }
      case CustomMode.Light:
        {
          setState(() {
            gValue = 0;
          });
          break;
        }
    }
    UserSettings.userSettings.currentTheme = getThemeModeString(mode);
    await PreferenceUtils.storeDataToShared("theme", getThemeModeString(mode));
    await logout(context);
  }
}

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarMain.dart';
import 'package:selfie_mobile_flutter/text/idea.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class IdeaPage extends StatefulWidget {
  const IdeaPage({Key? key}) : super(key: key);

  @override
  State<IdeaPage> createState() => _IdeaPageState();
}

class _IdeaPageState extends State<IdeaPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          CustomAppBarMain(
            title: ideaPageTitle,
            onTapTitle: () {},
          ),
          const SizedBox(
            height: 150.0,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Image.asset(
              "assets/under_contruction.png",
              height: 250.0,
            ),
          ),
          Text(
            "Comin Soon !",
            style: TextStyle(color: customColors().fontPrimary, fontSize: 20),
          ),
        ],
      ),
    );
  }
}

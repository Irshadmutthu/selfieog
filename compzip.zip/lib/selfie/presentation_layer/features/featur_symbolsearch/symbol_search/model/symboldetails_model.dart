import 'dart:convert';

import 'package:trading_api/responses/symbol_search_response.dart';

class SymbolDetailsModel {
  SymbolDetailsModel(
      {required this.details,
      required this.exchange,
      required this.name,
      
      required this.response,
      required this.symbolKey});
  String name;
  String exchange;
  String details;
  String symbolKey;
  Reclistxmob response;

  static SymbolDetailsModel getEmptyData() {
    return SymbolDetailsModel(
        details: "",
        exchange: "",
        name: "",
        response: Reclistxmob(scripcode: "", venue: "", securitycode1: ""),
        symbolKey: "");
  }

  bool equals(SymbolDetailsModel other) =>
      this.response.venue == other.response.venue &&
      this.response.scripcode == other.response.scripcode;
}

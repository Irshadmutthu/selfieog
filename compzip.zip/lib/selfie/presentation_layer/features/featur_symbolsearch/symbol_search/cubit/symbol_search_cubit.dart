import 'dart:developer';
import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/constants/error_mapper.dart';
import 'package:selfie_mobile_flutter/constants/general_methods.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/featur_symbolsearch/symbol_search/model/symboldetails_model.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/user_controller/repo_files/watchlist/watchlist_repo.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller_impl.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';
import 'package:trading_api/responses/add_symboltowatch_response.dart';
import 'package:trading_api/responses/get_cloud_watch_response.dart';
import 'package:trading_api/responses/symbol_details_response.dart';
import 'package:trading_api/responses/symbol_search_response.dart';
import 'package:trading_api/utils/utils.dart';
part 'symbol_search_state.dart';

class SymbolSearchCubit extends Cubit<SymbolSearchState> {
  ServiceLocator serviceLocator;
  int _length = 0;
  int _categoryIndex = UserController.userController.searchIndex;
  int _fromIndex = 1;
  int watchlistId = 0;

  String _keyWord = "";
  final Map<String, dynamic> fromPage;
  final List<SymbolDetailsModel> _symbolSearchList = [];
  SymbolSearchResponse? _response;
  Map<String, Instrument> selectedSymbols = {};
  List<int> progress = [];
  List<String> categoryItems = [
    "All",
    "Cash",
    "F&O",
    "Index",
    "Currency",
    "Commodity",
    "Spread"
  ];

  SymbolSearchCubit({required this.serviceLocator, required this.fromPage})
      : super(SearchInitialState()) {
    watchlistId = fromPage["watchId"];
    selectedSymbols = fromPage["watchSymbols"];
    getCurrentWatchDetails();
  }

  getCurrentWatchDetails() async {
    int _index = GeneralMethods.getWatchIndex();
    _index == -1
        ? watchlistId = 0
        : watchlistId = int.parse(UserController
            .userController.watchlists[_index].watchlistData.watchlistid);
  }

//Search Executed When TextBox Text will be changed
  searchSymbol({required String keyword}) {
    _fromIndex = 1;
    _keyWord = keyword;
    filterSymbolSearch(_categoryIndex);
  }

//Search Executed When End Of The List
  viewMoreSymbols() {
    _fromIndex += 10;
    filterSymbolSearch(_categoryIndex);
  }

  ///Filters Handled Function
  filterSymbolSearch(int category) {
    UserController.userController.searchIndex = category;
    //Identifyed The Call From TextBox or Filter Tab
    if (_categoryIndex != category) {
      _symbolSearchList.clear();
      // _isViewMore = false;
      _fromIndex = 1;
    }
    _categoryIndex = category;
    switch (_categoryIndex) {
      //All Tab
      case 0:
        {
          _searchSymbol(
              keyword: _keyWord,
              venuCode:
                  "NSE|BSE|NSEFO|NSECD|MCX|NCDEX|INDEXNSE|INDEXBSE|INDEXNSEFO",
              fromIndex: _fromIndex,
              indexFilter: "",
              remarks: "N");
          break;
        }
      //Cash
      case 1:
        {
          _searchSymbol(
              keyword: _keyWord,
              venuCode: "NSE|BSE",
              fromIndex: _fromIndex,
              indexFilter: "N",
              remarks: "N");
          break;
        }
      //F&O
      case 2:
        {
          _searchSymbol(
              keyword: _keyWord,
              venuCode: "NSEFO",
              fromIndex: _fromIndex,
              indexFilter: "N",
              remarks: "N");
          break;
        }
      //Index
      case 3:
        {
          _searchSymbol(
              keyword: _keyWord,
              venuCode: "",
              fromIndex: _fromIndex,
              indexFilter: "Y",
              remarks: "N");
          break;
        }
      //Currency
      case 4:
        {
          _searchSymbol(
              keyword: _keyWord,
              venuCode: "NSECD",
              fromIndex: _fromIndex,
              indexFilter: "N",
              remarks: "N");
          break;
        }
      //Commodity
      case 5:
        {
          _searchSymbol(
              keyword: _keyWord,
              venuCode: "MCX|NCDEX",
              fromIndex: _fromIndex,
              indexFilter: "N",
              remarks: "N");
          break;
        }
      //Spread
      case 6:
        {
          _searchSymbol(
              keyword: _keyWord,
              venuCode: "",
              fromIndex: _fromIndex,
              indexFilter: "N",
              remarks: "Y");
          break;
        }
    }
  }

  /// Symbol Search Service Integrated Function
  /// Filter Tab Data Handled
  /// Keyword Venucode and start of seaching Index Parameters are Passed
  _searchSymbol(
      {required String keyword,
      required String venuCode,
      required String remarks,
      required String indexFilter,
      required int fromIndex}) async {
    if (keyword.length > 1) {
      //Service Called From Here
      //await Future.delayed(const Duration(seconds: 1));
      try {
        if (_symbolSearchList.isEmpty) {
          emit(SearchLoadingState());
        }
        _response = await serviceLocator.tradingApi.symbolSearchRequest(
            keyword: keyword,
            start: _fromIndex,
            venuCode: venuCode,
            indexFilter: indexFilter,
            remarks: remarks);
        if (_response!.searchresp![0].errorcode == 0) {
          _symbolSearchList.clear();
          _length = _response!.searchresp![0].reclistxmob!.length;

          if (_length == 0 || _keyWord.length <= 1) {
            //Emit When Service Returns Empty List
            _symbolSearchList.clear();
            emit(SearchLoadedState(
              symbolsList: _symbolSearchList,
              selectedSymbols: selectedSymbols,
            ));
            return;
          } else {
            //Get The Data From Service
            for (int _i = 0; _i < _length; _i++) {
              _symbolSearchList.add(
                SymbolDetailsModel(
                    response: _response!.searchresp![0].reclistxmob![_i],
                    details: _response!
                        .searchresp![0].reclistxmob![_i].description
                        .toString(),
                    exchange: _response!.searchresp![0].reclistxmob![_i].venue
                        .toString(),
                    name: _response!
                        .searchresp![0].reclistxmob![_i].securitycode1
                        .toString(),
                    symbolKey: _response!
                        .searchresp![0].reclistxmob![_i].symbolKey
                        .toString()),
              );
            }

            emit(SearchLoadedState(
                symbolsList: _symbolSearchList,
                selectedSymbols: selectedSymbols));
          }
        } else {
          emit(SearchErrorState(
              errorCode: 1,
              errorMessage:
                  errorMap[_response!.searchresp![0].errorcode].toString()));
        }
      } catch (e) {
        if (isClosed) return;
        emit(SearchErrorState(errorCode: 1, errorMessage: e.toString()));

        log(e.toString(), time: DateTime.now());
      }
    } else {
      _symbolSearchList.clear();
      emit(SearchLoadedState(
          symbolsList: _symbolSearchList, selectedSymbols: selectedSymbols));
    }
  }

//When Add Symbol To WatchList
  onSymbolTap(bool isChecked, int index, BuildContext context) async {
    //Add New Symbol to WatchList
    if (!isChecked) {
      if (selectedSymbols.length.toString() ==
              WatchlistRepository
                  .cloudWatchRetriveResponse.watchData[0].symbolno ||
          selectedSymbols.containsKey(_symbolSearchList[index].symbolKey)) {
        FocusScope.of(context).unfocus();
        ScaffoldMessenger.of(context).clearSnackBars();
        ScaffoldMessenger.of(context).showSnackBar(showWaringDialogue(
            errorMessage:
                "Cannot add more than ${WatchlistRepository.cloudWatchRetriveResponse.watchData.isNotEmpty ? WatchlistRepository.cloudWatchRetriveResponse.watchData[0].symbolno : "0"} securities to a watchlist."));
        return;
      }
      emit(SearchLoadedState(
          symbolsList: _symbolSearchList,
          selectedSymbols: selectedSymbols,
          progressIndex: addToProgress(index)));
      try {
        final _responseData =
            await serviceLocator.tradingApi.addNewSymbolToExistingWatchList(
          userID: UserController().userId,
          watchlistId: watchlistId,
          venuCode: _symbolSearchList[index].response.venue,
          venueScripcode: _symbolSearchList[index].response.scripcode,
          symbolName: _symbolSearchList[index].response.securitycode1,
        );
        if (_responseData.errorCode == "0") {
          if (_responseData.errorData.isNotEmpty) {
            if (_responseData.errorData[0].errorcode == "2") {
              emit(SearchErrorState(
                  errorCode: 2,
                  errorMessage:
                      "Duplicate Error ${_responseData.errorData[0].errormessage ?? ""}"));
              return;
            }
          }
          addSymbol(responseData: _responseData, index: index);
          return;
        } else {
          emit(SearchErrorState(
              errorCode: 1, errorMessage: "error adding symbol to watchlist"));
          return;
        }
      } catch (e) {
        if (isClosed) return;
        emit(SearchErrorState(errorCode: 1, errorMessage: e.toString()));
        return;
      }
    } else {
      emit(SearchLoadedState(
          symbolsList: _symbolSearchList,
          selectedSymbols: selectedSymbols,
          progressIndex: addToProgress(index)));
      await removeSymbol(index: index);
      return;
    }
  }

  List<int> addToProgress(int index) {
    progress.contains(index) ? null : progress.add(index);
    return progress;
  }

  List<int> removeFromProgress(int index) {
    progress.contains(index) ? progress.remove(index) : null;
    return progress;
  }

  addSymbol({required AddSymboltoWatchlist responseData, required int index}) {
    int _index = GeneralMethods.getWatchIndex();
    if (_index != -1) {
      UserController.userController.watchlists[_index].symbolDataList.add(
          SymbolData(
              instrumentType:
                  _symbolSearchList[index].response.insttype.toString(),
              sortorder: responseData.symbolDetails[0].sortorder.toString(),
              symbolname: _symbolSearchList[index].response.securitycode1,
              venuecode: _symbolSearchList[index].response.venue,
              venuescripcode: _symbolSearchList[index].response.scripcode,
              watchlistid: watchlistId.toString(),
              watchsymbolid:
                  responseData.symbolDetails[0].watchsymbolid.toString(),
              ca: responseData.symbolDetails[0].corpaction ?? ""));
      Instrument instrument = Instrument(
          scripcode: _symbolSearchList[index].response.scripcode,
          securityCode: _symbolSearchList[index].response.securitycode1,
          securityName: _symbolSearchList[index].response.description ?? "",
          series: "",
          venueIndex: getVenueIndex(_symbolSearchList[index].response.venue),
          type: _symbolSearchList[index].response.insttype!,
          ca: responseData.symbolDetails[0].corpaction ?? "");
      selectedSymbols[_symbolSearchList[index].symbolKey] = instrument;
      emit(SearchLoadedState(
          symbolsList: _symbolSearchList,
          selectedSymbols: selectedSymbols,
          progressIndex: removeFromProgress(index)));
    }
  }

  removeSymbol({required int index}) async {
    try {
      int _index = GeneralMethods.getWatchIndex();
      if (_index != -1) {
        SymbolData obj = UserController
            .userController.watchlists[_index].symbolDataList
            .firstWhere((element) =>
                element.venuescripcode + element.venuecode ==
                _symbolSearchList[index].response.scripcode +
                    _symbolSearchList[index].exchange);
        final _responseData = await serviceLocator.tradingApi
            .removeSymbolToExistingWatchList(
                userID: UserController().userId,
                watchlistId: watchlistId,
                watchsymbolId: obj.watchsymbolid);
        if (_responseData.errorCode == "0") {
          UserController.userController.watchlists[_index].symbolDataList
              .removeWhere((element) =>
                  element.venuescripcode + element.venuecode ==
                  _symbolSearchList[index].response.scripcode +
                      _symbolSearchList[index].exchange);
          selectedSymbols.remove(_symbolSearchList[index].symbolKey);
          if (isClosed) return;
          emit(SearchLoadedState(
              symbolsList: _symbolSearchList,
              selectedSymbols: selectedSymbols,
              progressIndex: removeFromProgress(index)));
        } else {
          if (isClosed) return;
          emit(SearchErrorState(
              errorCode: 1, errorMessage: "Internal Server Error"));
        }
      }
    } catch (e) {
      if (isClosed) return;
      emit(SearchErrorState(errorCode: 1, errorMessage: e.toString()));
    }
  }
}

Future<bool> fillSymbolData(BuildContext context, Instrument instrument) async {
  try {
    SymbolDetailResponse _response = await context.gTradingApiGateway
        .symbolDetailsSearchRequest(
            venuCode: instrument.venuecode,
            venuScripCode: instrument.scripcode);
    if (_response.searchresp!.elementAt(0).errorcode != 0) {
      return false;
    }
    Reclist reclist = _response.searchresp!.elementAt(0).reclist!.elementAt(0);
    instrument.isin = reclist.isin!;
    instrument.tradetotrade = reclist.tradetotrade!;
    instrument.isliquid = reclist.isliquid!;
    instrument.securityCode = reclist.securitycode!;
    instrument.securityName = reclist.symbolname!;
    instrument.series = reclist.series!;
    instrument.type = reclist.instrumenttype!;
    instrument.otherScripCode = reclist.otherScripCode!;
    instrument.otherSeries = reclist.otherseries!;
    instrument.ticksize = reclist.ticksize;
    instrument.lotsize = reclist.marketlot!;
    instrument.displayName = reclist.securitycode1 ?? "";
    instrument.contractDate = reclist.expirationdate!;
    UserControllerImpl().addSymbol(instrument);
  } catch (e) {
    log("Exception caught in fillSymbolData", error: e);
  }
  if (!UserControllerImpl().containsSymbol(
      instrument.venueIndex.toString() + "_" + instrument.scripcode)) {
  } else {
    Instrument dummy = UserControllerImpl().getSymbol(
        instrument.venueIndex.toString() + "_" + instrument.scripcode);
    instrument.isin = dummy.isin;
    instrument.tradetotrade = dummy.tradetotrade;
    instrument.isliquid = dummy.isliquid;
    instrument.securityCode = dummy.securityCode;
    instrument.securityName = dummy.securityName;
    instrument.series = dummy.series;
    instrument.type = dummy.type;
    instrument.otherScripCode = dummy.otherScripCode;
    instrument.otherSeries = dummy.otherSeries;
    instrument.ticksize = dummy.ticksize;
    instrument.lotsize = dummy.lotsize!;
    instrument.displayName = dummy.displayName;
    instrument.contractDate = dummy.contractDate;
  }
  return true;
}

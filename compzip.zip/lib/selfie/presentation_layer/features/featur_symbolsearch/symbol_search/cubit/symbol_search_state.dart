part of 'symbol_search_cubit.dart';

@immutable
abstract class SymbolSearchState {}

class SearchInitialState extends SymbolSearchState {}

class SearchLoadingState extends SymbolSearchState {}

class SearchLoadedState extends SymbolSearchState {
  final Map<String, Instrument> selectedSymbols;
  final List<SymbolDetailsModel> symbolsList;
  final List<int> progressIndex;
  SearchLoadedState(
      {required this.symbolsList,
      required this.selectedSymbols,
      this.progressIndex = const []});

  SearchLoadedState copyWith(
      {List<SymbolDetailsModel>? symbolsList,
      Map<String, Instrument>? selectedSymbols,
      List<int>? progressIndex}) {
    return SearchLoadedState(
        symbolsList: symbolsList ?? this.symbolsList,
        selectedSymbols: selectedSymbols ?? this.selectedSymbols,
        progressIndex: progressIndex ?? this.progressIndex);
  }
}

class SearchFilterState extends SymbolSearchState {}

class SearchErrorState extends SymbolSearchState {
  final int errorCode;
  final String errorMessage;
  SearchErrorState({required this.errorCode, required this.errorMessage});
}

class SearchNothingFoundState extends SymbolSearchState {}

class ViewMoreLoadingState extends SymbolSearchState {}

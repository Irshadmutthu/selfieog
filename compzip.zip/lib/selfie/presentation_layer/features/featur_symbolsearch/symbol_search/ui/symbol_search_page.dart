import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/featur_symbolsearch/symbol_search/components/symbol_search_shimmer.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/featur_symbolsearch/symbol_search/components/symbolsearch_filter.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/featur_symbolsearch/symbol_search/cubit/symbol_search_cubit.dart';

import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/position_search_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/symbol_search_item.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';

class SymbolSearchPage extends StatefulWidget {
  final Map<String, dynamic> fromPage;
  const SymbolSearchPage({Key? key, required this.fromPage}) : super(key: key);
  @override
  State<SymbolSearchPage> createState() => _SymbolSearchPageState();
}

class _SymbolSearchPageState extends State<SymbolSearchPage> {
  final _editcontroller = TextEditingController();
  final _scrollcontroller = ScrollController();

  // void loadMoreSymbols(context) {
  //   _scrollcontroller.addListener(() {
  //     if (_scrollcontroller.position.atEdge) {
  //       if (_scrollcontroller.position.pixels != 0) {
  //         BlocProvider.of<SymbolSearchCubit>(context).viewMoreSymbols();
  //       }
  //     }
  //   });
  // }

  @override
  void dispose() {
    _editcontroller.dispose();
    _scrollcontroller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // loadMoreSymbols(context);
    Size _displaySize = MediaQuery.of(context).size;
    return Scaffold(
        appBar: PreferredSize(
            preferredSize: const Size.fromHeight(0.0),
            child: AppBar(
              elevation: 0,
              backgroundColor: customColors().backgroundPrimary,
            )),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 8.0),
              child: Position_Search_Field(
                  onBackPressed: () {
                    context.gNavigationService.back(context);
                  },
                  hintText: "Search eg: infy",
                  controller: _editcontroller,
                  onSearch: (String keyword) {
                    BlocProvider.of<SymbolSearchCubit>(context)
                        .searchSymbol(keyword: keyword);
                  }),
            ),
            SymbolSearchFilter(
                category:
                    BlocProvider.of<SymbolSearchCubit>(context).categoryItems,
                buttonHandler: BlocProvider.of<SymbolSearchCubit>(context)
                    .filterSymbolSearch),
            Expanded(
              child: BlocConsumer<SymbolSearchCubit, SymbolSearchState>(
                  listener: (context, state) {
                if (state is SearchErrorState) {
                  ScaffoldMessenger.of(context).clearSnackBars();
                  ScaffoldMessenger.of(context).showSnackBar(
                      showErrorDialogue(errorMessage: state.errorMessage));
                }
              }, builder: (context, state) {
                if (state is SearchLoadingState) {
                  return const SymbolSearchShimmer();
                } else if (state is SearchLoadedState) {
                  return ListView.builder(
                    shrinkWrap: true,
                    controller: _scrollcontroller,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: state.symbolsList.length,
                    itemBuilder: (BuildContext context, int index) {
                      return SymbolSearchItem(
                        value: state.selectedSymbols
                            .containsKey(state.symbolsList[index].symbolKey),
                        loading: state.progressIndex.contains(index),
                        addSymbol: (isChecked) {
                          BlocProvider.of<SymbolSearchCubit>(context)
                              .onSymbolTap(isChecked, index, context);
                        },
                        details: state.symbolsList[index].details,
                        symbol: state.symbolsList[index].name,
                        exchangeName: state.symbolsList[index].exchange,
                      );
                    },
                  );
                } else if (state is SearchErrorState) {
                  return const SizedBox();
                } else if (state is SearchNothingFoundState) {
                  return const SizedBox();
                } else {
                  return const SizedBox();
                }
              }),
            ),
            BlocBuilder<SymbolSearchCubit, SymbolSearchState>(
                builder: (context, state) {
              if (state is ViewMoreLoadingState) {
                return Container(
                  height: 50,
                  color: transparent,
                  child: Center(
                    child: CircularProgressIndicator(
                        backgroundColor: customColors().green1),
                  ),
                );
              } else {
                return const SizedBox();
              }
            }),
            // PaytmAdWidget(
            //   icon: "assets/logo.png",
            //   height: _displaySize.height * 0.13,
            //   discription: "Get access to the PAYTM IPO now!",
            //   heading: "PAYTM IPO!",
            //   clickabeText: "Book Now",
            // ),
          ],
        ));
  }
}

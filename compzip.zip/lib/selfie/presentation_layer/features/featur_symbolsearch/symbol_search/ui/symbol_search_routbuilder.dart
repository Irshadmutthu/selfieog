import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/featur_symbolsearch/symbol_search/cubit/symbol_search_cubit.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'symbol_search_page.dart';

class SymbolSearchPageRouteBuilder {
  final ServiceLocator _serviceLocator;
  final Map<String, dynamic> fromPage;

  SymbolSearchPageRouteBuilder(this._serviceLocator, this.fromPage);

  Widget call(BuildContext context) {
    return MultiBlocProvider(
        providers: [
          BlocProvider(
              create: (context) => SymbolSearchCubit(
                  serviceLocator: _serviceLocator, fromPage: fromPage)),
        ],
        child: MultiRepositoryProvider(
            providers: [
              RepositoryProvider.value(value: _serviceLocator.tradingApi),
            ],
            child: SymbolSearchPage(
              fromPage: fromPage,
            )));
  }
}

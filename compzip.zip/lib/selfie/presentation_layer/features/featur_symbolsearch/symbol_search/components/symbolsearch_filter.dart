import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';

class SymbolSearchFilter extends StatefulWidget {
  List<String> category;
  Color? bagroundColor;
  final Function buttonHandler;

  SymbolSearchFilter(
      {required this.category,
      required this.buttonHandler,
      this.bagroundColor});
  

  State<StatefulWidget> createState() => SearchFilterState();
}

class SearchFilterState extends State<SymbolSearchFilter> {
  int selectedIndex = UserController.userController.searchIndex;
  @override
  Widget build(BuildContext context) {
    return Container(
      color: customColors().backgroundSecondary,
      height: 56,
      child: ListView.builder(
        itemCount: widget.category.length,
        scrollDirection: Axis.horizontal,
        itemBuilder: (context, position) {
          return InkWell(
            child: Column(
              children: [
                const Expanded(child: SizedBox()),
                Center(
                  child: Container(
                      padding: const EdgeInsets.only(
                          bottom: 18.0, right: 18, left: 18),
                      decoration: BoxDecoration(
                          border: Border(
                              bottom: BorderSide(
                                  color: selectedIndex == position
                                      ? customColors().primary
                                      : transparent,
                                  width: 2))),
                      child: Text(
                        widget.category.elementAt(position),
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_SemiBold,
                            color: selectedIndex == position
                                ? FontColor.Primary
                                : FontColor.FontSecondary),
                      )),
                ),
              ],
            ),
            onTap: () {
              setState(() {
                selectedIndex = position;
                widget.buttonHandler(selectedIndex); //
              });
            },
          );
        },
      ),
    );
  }
}

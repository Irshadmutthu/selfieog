import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/utils/shimmer_loader.dart';

class SymbolSearchShimmer extends StatelessWidget {
  const SymbolSearchShimmer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: ListView.builder(
          itemCount: 15,
          shrinkWrap: true,
          itemBuilder: (context, index) {
            return Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                  border: Border(
                      bottom: BorderSide(
                          color: customColors().backgroundTertiary))),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ShimmerLoader(height: 20.0, width: 70.0),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          ShimmerLoader(height: 20.0, width: 200.0),
                        ],
                      )
                    ],
                  ),
                  // CustomCheckBox(),
                  ShimmerLoader(height: 30.0, width: 30.0)
                ],
              ),
            );
          }),
    );
  }
}

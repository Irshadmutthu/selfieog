part of 'custom_symbol_search_cubit.dart';

@immutable
abstract class CustomSymbolSearchState {}

class SearchInitialState extends CustomSymbolSearchState {}

class SearchLoadingState extends CustomSymbolSearchState {}

class SearchLoadedState extends CustomSymbolSearchState {
  final Map<String, Instrument> selectedSymbols;
  final List<SymbolDetailsModel> symbolsList;
  final List<int> progressIndex;
  SearchLoadedState(
      {required this.symbolsList,
      required this.selectedSymbols,
      this.progressIndex = const []});

  SearchLoadedState copyWith(
      {List<SymbolDetailsModel>? symbolsList,
      Map<String, Instrument>? selectedSymbols,
      List<int>? progressIndex}) {
    return SearchLoadedState(
        symbolsList: symbolsList ?? this.symbolsList,
        selectedSymbols: selectedSymbols ?? this.selectedSymbols,
        progressIndex: progressIndex ?? this.progressIndex);
  }
}

class SearchFilterState extends CustomSymbolSearchState {}

class SearchErrorState extends CustomSymbolSearchState {
  final int errorCode;
  final String errorMessage;
  SearchErrorState({required this.errorCode, required this.errorMessage});
}

class SearchNothingFoundState extends CustomSymbolSearchState {}

class ViewMoreLoadingState extends CustomSymbolSearchState {}

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/featur_symbolsearch/custom_symbolsearch/cubit/custom_symbol_search_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/featur_symbolsearch/symbol_search/components/symbol_search_shimmer.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/featur_symbolsearch/symbol_search/components/symbolsearch_filter.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/position_search_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/symbol_search_item.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';

class CustomSymbolSearchPage extends StatelessWidget {
  final _editcontroller = TextEditingController();
  final _scrollcontroller = ScrollController();
   CustomSymbolSearchPage({Key? key}) : super(key: key);
  //  @override
  // void dispose() {
  //   _editcontroller.dispose();
  //   _scrollcontroller.dispose();
  //   super.dispose();
  // }

  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: PreferredSize(
            preferredSize: const Size.fromHeight(0.0),
            child: AppBar(
              elevation: 0,
              backgroundColor: customColors().backgroundPrimary,
            )),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 8.0),
              child: Position_Search_Field(
                  onBackPressed: () {
                    context.gNavigationService.back(context);
                  },
                  hintText: "Search eg: infy",
                  controller: _editcontroller,
                  onSearch: (String keyword) {
                    BlocProvider.of<CustomSymbolSearchCubit>(context)
                        .searchSymbol(keyword: keyword);
                  }),
            ),
            SymbolSearchFilter(
                category: BlocProvider.of<CustomSymbolSearchCubit>(context)
                    .categoryItems,
                buttonHandler: BlocProvider.of<CustomSymbolSearchCubit>(context)
                    .filterSymbolSearch),
            Expanded(
              child: BlocConsumer<CustomSymbolSearchCubit, CustomSymbolSearchState>(
                  listener: (context, state) {
                if (state is SearchErrorState) {
                  ScaffoldMessenger.of(context).showSnackBar(
                      showErrorDialogue(errorMessage: state.errorMessage));
                }
              }, builder: (context, state) {
                if (state is SearchLoadingState) {
                  return const SymbolSearchShimmer();
                } else if (state is SearchLoadedState) {
                  return ListView.builder(
                    shrinkWrap: true,
                    controller: _scrollcontroller,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: state.symbolsList.length,
                    itemBuilder: (BuildContext context, int index) {
                      return SymbolSearchItem(
                        value: state.selectedSymbols
                            .containsKey(state.symbolsList[index].symbolKey),
                        loading: state.progressIndex.contains(index),
                        addSymbol: (isChecked) {
                          BlocProvider.of<CustomSymbolSearchCubit>(context)
                              .onSymbolTap(isChecked, index);
                        },
                        details: state.symbolsList[index].details,
                        symbol: state.symbolsList[index].name,
                        exchangeName: state.symbolsList[index].exchange,
                      );
                    },
                  );
                } else if (state is SearchErrorState) {
                  return const SizedBox();
                } else if (state is SearchNothingFoundState) {
                  return const SizedBox();
                } else {
                  return const SizedBox();
                }
              }),
            ),
            BlocBuilder<CustomSymbolSearchCubit, CustomSymbolSearchState>(
                builder: (context, state) {
              if (state is ViewMoreLoadingState) {
                return Container(
                  height: 50,
                  color: transparent,
                  child: Center(
                    child: CircularProgressIndicator(
                        backgroundColor: customColors().green1),
                  ),
                );
              } else {
                return const SizedBox();
              }
            }),
          ],
        ));
  }
}

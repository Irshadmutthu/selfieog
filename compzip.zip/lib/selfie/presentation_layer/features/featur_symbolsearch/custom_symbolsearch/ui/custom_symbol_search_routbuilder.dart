import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/featur_symbolsearch/custom_symbolsearch/cubit/custom_symbol_search_cubit.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'custom_symbol_search_ui.dart';

class CustomSymolSearchRoutbuilder {
  final ServiceLocator _serviceLocator;
  final Map<String, dynamic> initialData;

  CustomSymolSearchRoutbuilder(this._serviceLocator, this.initialData);

  Widget call(BuildContext context) {
    return MultiBlocProvider(
        providers: [
          BlocProvider(
              create: (context) => CustomSymbolSearchCubit(
                  serviceLocator: _serviceLocator, initialData: initialData)),
        ],
        child: MultiRepositoryProvider(providers: [
          RepositoryProvider.value(value: _serviceLocator.tradingApi),
        ], child: CustomSymbolSearchPage()));
  }
}

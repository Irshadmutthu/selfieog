import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class SuggestSuccessBottomSheet extends StatelessWidget {
  const SuggestSuccessBottomSheet({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        SizedBox(
          height: 40,
        ),
        Image.asset("assets/Tick.png"),
        SizedBox(
          height: 16,
        ),
        Text(
          "Suggestion Received",
          style: customTextStyle(
              fontStyle: FontStyle.HeaderS_SemiBold,
              color: FontColor.FontPrimary),
        ),
        SizedBox(
          height: 10,
        ),
        Text(
          "Thank you for your suggestion!\nOur best minds will take over from here.",
          textAlign: TextAlign.center,
          style: customTextStyle(
              fontStyle: FontStyle.BodyL_Regular,
              color: FontColor.FontSecondary),
        ),
        SizedBox(
          height: 18,
        ),
        Padding(
          padding:
              const EdgeInsets.only(top: 12, bottom: 25, left: 16, right: 16),
          child: Row(
            children: [
              Expanded(
                child: BasketButton(
                  bordercolor: transparent,
                  bgcolor: customColors().primary,
                  text: "Close",
                  textStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
                  onpress: () {
                    Navigator.of(context).pop(true);
                  },
                ),
              )
            ],
          ),
        ),
      ],
    );
  }
}

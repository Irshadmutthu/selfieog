import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CustomTextFormFieldWithMaxLengthLimit extends StatefulWidget {
  final bool enabled;
  final Function(String)? onChange;
  final dynamic textCapitalization;
  final TextEditingController controller;
  final List<TextInputFormatter>? inputFormatter;
  final Color? bordercolor;
  final Color? bgColor;
  final String fieldName;
  final String? hintText;
  final String defaultErrorMessage;
  final Widget? maxLengthEnforcement;
  final TextInputType? keyboardType;
  // final ValueChanged<String>? onchangedAction;
  final int? maxLength;
  final String? error;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final Validator? validator;
  final int? width;
  final double? height;
  final double? labelBottomPadding;
  final bool obscureTextStatus;
  final bool readonlyState;
  final Function? keyboardAction;
  final bool isInputaction;
  final bool autoFocus;
  TextInputAction? textInputAction;
  final Color? fillColor;
  final Widget? topEndWidget;
  final Widget? bottomStartWidget;
  final Widget? bottomEndWidget;
  final Function(String)? onFieldSubmit;
  final int? maxLines;
  FocusNode? focusNode;
  final String? suffixtext;
  CustomTextFormFieldWithMaxLengthLimit(
      {Key? key,
      this.autoFocus = false,
      this.onChange,
      this.enabled = true,
      this.textCapitalization = TextCapitalization.none,
      required this.controller,
      this.inputFormatter,
      this.bordercolor,
      this.bgColor,
      required this.fieldName,
      this.hintText = " ",
      this.defaultErrorMessage = "Please fill valid data",
      this.maxLength,
      this.error,
      this.validator,
      this.prefixIcon,
      this.suffixIcon,
      this.obscureTextStatus = false,
      this.width,
      this.height = 69,
      this.maxLengthEnforcement,
      this.keyboardType,
      // this.onchangedAction,
      this.readonlyState = false,
      this.labelBottomPadding,
      this.keyboardAction,
      this.isInputaction = false,
      this.textInputAction,
      this.fillColor,
      this.topEndWidget,
      this.bottomStartWidget,
      this.bottomEndWidget,
      this.onFieldSubmit,
      this.focusNode,
      this.maxLines,
      this.suffixtext})
      : super(key: key);
  @override
  State<CustomTextFormFieldWithMaxLengthLimit> createState() =>
      _CustomTextFormFieldWithMaxLengthLimitState();
}

class _CustomTextFormFieldWithMaxLengthLimitState
    extends State<CustomTextFormFieldWithMaxLengthLimit> {
  bool contentVisibility = false;
  // final phoneValidator = MultiValidator();
  @override
  void initState() {
    // TODO: implement initState
    contentVisibility = widget.obscureTextStatus;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    double mheight = MediaQuery.of(context).size.height * 1.22;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              widget.fieldName,
              style: customTextStyle(
                  fontStyle: FontStyle.BodyL_Regular,
                  color: FontColor.FontPrimary),
            ),
            widget.topEndWidget ?? Container(),
          ],
        ),
        Padding(
          padding:
              EdgeInsets.only(top: widget.labelBottomPadding ?? mheight * .006),
          child: TextFormField(
            //    enableInteractiveSelection: false,
            //    textInputAction: widget.textInputAction ?? TextInputAction.none,
            // onFieldSubmitted: (value) {
            //   //     if (widget.keyboardAction != null) widget.keyboardAction!();
            // },
            minLines: widget.maxLines ?? 1,
            maxLines: widget.maxLines ?? 1,
            cursorRadius: Radius.circular(4.0),
            showCursor: true,
            onFieldSubmitted: widget.onFieldSubmit,
            obscureText: contentVisibility,
            obscuringCharacter: "●",
            maxLength: widget.maxLength,
            autofocus: widget.autoFocus,
            textCapitalization: widget.textCapitalization,
            textAlignVertical: TextAlignVertical.center,
            controller: widget.controller,
            focusNode: widget.focusNode,
            inputFormatters: widget.inputFormatter,
            cursorColor: customColors().fontPrimary,
            onChanged: widget.onChange,

            validator: (value) {
              switch (widget.validator) {
                case Validator.none:
                  return noValidation(value.toString());
                case Validator.defaultValidator:
                  return emptyValidation(widget.controller.value.toString(),
                      widget.defaultErrorMessage);
                case Validator.account:
                  return accountValidation(value.toString());
                case Validator.password:
                  return passwordValidation(value.toString());
                default:
                  return emptyValidation(widget.controller.value.toString(),
                      widget.defaultErrorMessage);
              }
            },

            enabled: widget.enabled,
            style: customTextStyle(
                fontStyle: FontStyle.BodyL_Regular,
                color: FontColor.FontPrimary),
            decoration: InputDecoration(
              counterText: "",
              filled: true,
              suffixText: widget.suffixtext,
              fillColor: widget.enabled
                  ? widget.fillColor ?? customColors().backgroundPrimary
                  : customColors().backgroundSecondary,
              border: OutlineInputBorder(
                  borderSide: BorderSide(
                      color: widget.bordercolor ??
                          customColors().backgroundTertiary,
                      width: 1),
                  borderRadius: BorderRadius.circular(4.0)),
              hintText: widget.hintText,
              hintStyle: customTextStyle(
                  fontStyle: FontStyle.BodyL_Regular,
                  color: FontColor.FontTertiary),
              focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      color: widget.bordercolor ??
                          customColors().backgroundTertiary,
                      width: 1),
                  borderRadius: BorderRadius.circular(4.0)),
              enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                      color: widget.bordercolor ??
                          customColors().backgroundTertiary,
                      width: 1),
                  borderRadius: BorderRadius.circular(4.0)),
              suffixIcon: widget.suffixIcon,
              contentPadding:
                  EdgeInsets.symmetric(vertical: 15, horizontal: 10),
            ),
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            widget.bottomStartWidget ?? Container(),
            widget.bottomEndWidget ?? Container(),
          ],
        ),
      ],
    );
  }
}

dynamic emptyValidation(String value, String errorString) {
  if (value.isEmpty) {
    return errorString;
  }
  return null;
}

dynamic noValidation(String value) {
  // return null;
}
dynamic accountValidation(String value) {
  if (value == "") {
    return "Account ID required";
  }
  //  else if (value != "ADMIN") {
  //   return "Account doesnot exist";
  // }
}

dynamic passwordValidation(String value) {
  if (value == "") {
    return "Password required";
  }
  //  else if (value != "admin") {
  //   return "Incorrect Password";
  // }
}

enum Validator { none, defaultValidator, password, account }

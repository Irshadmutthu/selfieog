import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_suggest/suggest_page.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class SuggestPageRouteBuilder {
  final ServiceLocator serviceLocator;

  SuggestPageRouteBuilder(this.serviceLocator);

  Widget call(BuildContext context) {
    return SuggestPage();
  }
}

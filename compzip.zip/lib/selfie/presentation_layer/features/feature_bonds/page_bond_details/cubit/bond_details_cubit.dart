import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/model/bond_application_model.dart';
import 'package:selfie_mobile_flutter/model/bond_details_header_model.dart';
import 'package:selfie_mobile_flutter/model/bond_details_issuer_model.dart';
import 'package:selfie_mobile_flutter/model/bond_details_overview_model.dart';
import 'package:selfie_mobile_flutter/model/bond_details_returns_model.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

part 'bond_details_state.dart';

class BondDetailsCubit extends Cubit<BondDetailsState> {
  final ServiceLocator serviceLocator;
  final TradingApiGateway? tradingApiGateway;
  final int bondId;

  BondDetailsCubit(
      {required this.serviceLocator,
      this.tradingApiGateway,
      required this.bondId})
      : super(BondDetailsInitial(
            bondDetailsHeaderData: BondDetailsHeaderData.fromJson({}),
            bondDetailsOverviewData: BondDetailsOverviewData.fromJson({}),
            bondDetailsReturnsData: bondDetailsReturnsModelFromJson("{}"),
            bondDetailsIssuerData: BondDetailsIssuerData.fromJson({}),
            checkMyBond: false,
            checkIpo: false,
            checkRegular: false)) {
    sendBondDetailsRequest(bondId: bondId);
  }

  sendBondDetailsRequest({required int bondId}) async {
    bool checkMyBond = false;
    bool checkIpo = false;
    bool checkRegular = false;
    try {
      emit(BondDetailsLoading());
      if (kDebugMode) {}
      String response =
          await serviceLocator.tradingApi.getBondDetails(bondId: this.bondId);
      BondDetailsHeaderModel bondDetailsHeaderModel =
          bondDetailsHeaderModelFromJson(response);
      BondDetailsOverviewModel sample =
          bondDetailsOverviewModelFromJson(response);
      if (bondDetailsHeaderModel.bondDetailsHeaderData![0].selected == 'Y') {
        checkMyBond = true;
      } else if (bondDetailsHeaderModel.bondDetailsHeaderData![0].type == 'I') {
        checkIpo = true;
      } else if (bondDetailsHeaderModel.bondDetailsHeaderData![0].type == 'R') {
        checkRegular = true;
      }
      emit(BondDetailsInitial(
          bondDetailsHeaderData: bondDetailsHeaderModelFromJson(response)
              .bondDetailsHeaderData![0],
          checkRegular: checkRegular,
          checkIpo: checkIpo,
          checkMyBond: checkMyBond,
          bondDetailsOverviewData: bondDetailsOverviewModelFromJson(response)
              .bondDetailsOverviewData![0],
          bondDetailsReturnsData: bondDetailsReturnsModelFromJson(response),
          bondDetailsIssuerData: bondDetailsIssuerModelFromJson(response)
              .bondDetailsIssuerData![0]));
    } catch (errorMessage) {
      emit(BondsDetailsError(
          errorCode: 000, errorMessage: errorMessage.toString()));
    }
  }

  bondDetailsNavigation(BuildContext context,
      BondApplicationArgumentModel bondApplicationArgumentModel) {
    context.gNavigationService.openBondDetailsInvestPage(
      context,
      bondApplicationArgumentModel,
    );
  }
}

part of 'bond_details_cubit.dart';

@immutable
abstract class BondDetailsState {}

class BondDetailsLoading extends BondDetailsState {}

class BondDetailsInitial extends BondDetailsState {
  BondDetailsHeaderData bondDetailsHeaderData;
  BondDetailsOverviewData bondDetailsOverviewData;
  BondDetailsReturnsModel bondDetailsReturnsData;
  BondDetailsIssuerData bondDetailsIssuerData;
  bool checkMyBond;
  bool checkIpo;
  bool checkRegular;

  BondDetailsInitial(
      {required this.bondDetailsHeaderData,
      required this.bondDetailsOverviewData,
      required this.bondDetailsReturnsData,
      required this.bondDetailsIssuerData,
      required this.checkMyBond,
      required this.checkIpo,
      required this.checkRegular});
}

class BondsDetailsError extends BondDetailsState {
  final int errorCode;
  final String errorMessage;
  BondsDetailsError({required this.errorCode, required this.errorMessage});
}

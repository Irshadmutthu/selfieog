import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/model/bond_details_returns_model.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_profile/profile.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class ReturnsTileItem extends StatelessWidget {
  BondDetailsReturnsTImelineTileModel item;
  Size screenSize;
  bool checkLast;
  ReturnsTileItem({
    Key? key,
    required this.item,
    required this.screenSize,
    this.checkLast = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                item.year!,
                style: customTextStyle(
                  fontStyle: FontStyle.BodyL_Bold,
                  color: FontColor.FontPrimary,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                  item.date!,
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontSecondary),
                ),
              )
            ],
          ),
        ],
      ),
      const Expanded(
        child: SizedBox(),
      ),
      SizedBox(
        width: screenSize.width * 0.55,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Intrest",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontSecondary),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                    "₹" +
                        Formats.valueFormatIndian2
                            .format(double.tryParse(item.interest!)),
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_Bold,
                        color: FontColor.FontPrimary),
                  ),
                )
              ],
            ),
            checkLast == false
                ? Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: CustomDividerWithPadding(
                      horizondalPadding: 0,
                    ),
                  )
                : const Padding(
                    padding: EdgeInsets.only(bottom: 12),
                  )
          ],
        ),
      ),
    ]);
  }
}

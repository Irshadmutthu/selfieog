import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/model/bond_details_issuer_model.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/mbp_status_list_item.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class BondDetailsIssuerTab extends StatelessWidget {
  BondDetailsIssuerTab({Key? key, required this.bondDetailsIssuerData})
      : super(key: key);
  final BondDetailsIssuerData bondDetailsIssuerData;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
            child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(
                    top: 16, left: 16, bottom: 12, right: 16),
                child: Text(
                  bondDetailsIssuerData.title.toString(),
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyL_SemiBold,
                      color: FontColor.FontPrimary),
                ),
              ),
              MBPStatusListItem(
                  title: "Industrys",
                  data: bondDetailsIssuerData.industry.toString(),
                  index: 1),
              MBPStatusListItem(
                  title: "Annual Revenue",
                  data: bondDetailsIssuerData.annualrevenue.toString(),
                  index: 2),
              MBPStatusListItem(
                  title: "Type of Issuer",
                  data: bondDetailsIssuerData.typeofissuer.toString(),
                  index: 3),
              Padding(
                padding: const EdgeInsets.only(
                    bottom: 11, left: 16, top: 20, right: 16),
                child: Text(
                  'Key Highlight',
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyL_SemiBold,
                      color: FontColor.FontPrimary),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  bondDetailsIssuerData.keyhighlights.toString(),
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_Regular,
                      color: FontColor.FontPrimary),
                ),
              ),
            ],
          ),
        ))
      ],
    );
  }
}

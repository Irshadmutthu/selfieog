import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/model/bond_details_returns_model.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_profile/profile.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class ReturnFirstTileItem extends StatelessWidget {
  BondDetailsReturnsFirstTImelineTileModel item;
  Size screenSize;
  bool flag;
  ReturnFirstTileItem({
    required this.item,
    required this.screenSize,
    this.flag = true,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                item.year!,
                style: customTextStyle(
                  fontStyle: FontStyle.BodyL_Bold,
                  color: FontColor.FontPrimary,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                  item.date!,
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontSecondary),
                ),
              )
            ],
          ),
        ],
      ),
      const Expanded(
        child: SizedBox(),
      ),
      SizedBox(
        width: screenSize.width * 0.55,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Your Investment of",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontSecondary),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                    "₹" +
                        Formats.valueFormatIndian2
                            .format(double.tryParse(item.investment!)),
                    style: customTextStyle(
                      fontStyle: FontStyle.BodyL_Bold,
                      color: FontColor.FontPrimary,
                    ),
                  ),
                )
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Row(
                children: [
                  Text(
                    "Accrude Intrest",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontSecondary),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 2),
                    child: Text(
                      item.accrudeinterest!,
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.FontPrimary),
                    ),
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Row(
                children: [
                  Text(
                    "Premium",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontSecondary),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 2),
                    child: Text(
                      item.premium!,
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.FontPrimary),
                    ),
                  )
                ],
              ),
            ),
            Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: flag
                    ? CustomDividerWithPadding(
                        horizondalPadding: 0,
                      )
                    : Container())
          ],
        ),
      ),
    ]);
  }
}

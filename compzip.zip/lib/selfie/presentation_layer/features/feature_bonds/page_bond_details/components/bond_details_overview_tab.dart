import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/model/bond_details_overview_model.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_profile/profile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_tags/custom_tag.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/mbp_status_list_item.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class BondDetailsOverviewTab extends StatelessWidget {
  final BondDetailsOverviewData bondDetailsOverviewItem;

  const BondDetailsOverviewTab({
    Key? key,
    required this.bondDetailsOverviewItem,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16, top: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(bottom: 2),
                            child: Text(
                              "Credit Rating",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary),
                            ),
                          ),
                          Text(
                            bondDetailsOverviewItem.creditrating.toString(),
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontPrimary),
                          ),
                        ],
                      ),
                      if (bondDetailsOverviewItem.misc1 != "-")
                        customTag(
                            value: bondDetailsOverviewItem.misc1.toString(),
                            size: TagSize.small),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 16, bottom: 4),
                  child: CustomDividerWithPadding(),
                ),
                Column(
                  children: [
                    MBPStatusListItem(
                        title: "Min Investment ",
                        data: (bondDetailsOverviewItem.mininvestment == "-")
                            ? bondDetailsOverviewItem.mininvestment.toString()
                            : "₹" +
                                Formats.valueFormatIndian2.format(
                                    double.tryParse(bondDetailsOverviewItem
                                        .mininvestment
                                        .toString())),
                        index: 1),
                    MBPStatusListItem(
                        title: "Face Value",
                        data: (bondDetailsOverviewItem.facevalue == "-")
                            ? bondDetailsOverviewItem.facevalue.toString()
                            : "₹" +
                                Formats.valueFormatIndian2.format(
                                    double.tryParse(bondDetailsOverviewItem
                                        .facevalue
                                        .toString())),
                        index: 2),
                    MBPStatusListItem(
                        title: "Lot Size",
                        data: bondDetailsOverviewItem.lotsize.toString(),
                        index: 3),
                    MBPStatusListItem(
                        title: "Instrument Type",
                        data: bondDetailsOverviewItem.instrumenttype.toString(),
                        index: 4),
                    MBPStatusListItem(
                        title: "Interest Payment",
                        data:
                            bondDetailsOverviewItem.interestpayment.toString(),
                        index: 5),
                    MBPStatusListItem(
                        title: "Issue Date",
                        data: bondDetailsOverviewItem.issuedate.toString(),
                        index: 6),
                    MBPStatusListItem(
                        title: "Maturity Date",
                        data: bondDetailsOverviewItem.maturitydate.toString(),
                        index: 7),
                    MBPStatusListItem(
                        title: "Yield",
                        data: bondDetailsOverviewItem.bondDetailsOverviewYield
                            .toString(),
                        index: 8),
                    MBPStatusListItem(
                        title: "Coupon",
                        data: bondDetailsOverviewItem.coupon.toString(),
                        index: 9),
                    MBPStatusListItem(
                        title: "Listed",
                        data: bondDetailsOverviewItem.listed.toString(),
                        index: 10),
                    MBPStatusListItem(
                        title: "NRI",
                        data: bondDetailsOverviewItem.nri.toString(),
                        index: 11),
                    MBPStatusListItem(
                        title: "Tenure Remaning",
                        data:
                            bondDetailsOverviewItem.tenureremaining.toString(),
                        index: 12),
                    MBPStatusListItem(
                        title: "Issuer Mode",
                        data: bondDetailsOverviewItem.issuermode.toString(),
                        index: 13),
                    MBPStatusListItem(
                        title: "Bond Price Level",
                        data: bondDetailsOverviewItem.issuermode.toString(),
                        index: 14),
                    MBPStatusListItem(
                        title: "Bank Bond Type",
                        data: bondDetailsOverviewItem.bankbondtype.toString(),
                        index: 15),
                    MBPStatusListItem(
                        title: "Perpetual",
                        data: bondDetailsOverviewItem.perpetual.toString(),
                        index: 16),
                    MBPStatusListItem(
                        title: "Call Option",
                        data: bondDetailsOverviewItem.calloption.toString(),
                        index: 17),
                    const SizedBox(
                      height: 29,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

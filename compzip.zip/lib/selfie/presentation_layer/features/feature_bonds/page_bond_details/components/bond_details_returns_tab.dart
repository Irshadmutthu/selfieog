import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/model/bond_details_returns_model.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/page_bond_details/components/widgets/returns_first_tile_widget.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/page_bond_details/components/widgets/returns_tile_widget.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_profile/profile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_counter_widget.dart/custom_counter.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:timelines/timelines.dart';

class BondDetailsReturnsTab extends StatelessWidget {
  BondDetailsReturnsModel bondDetailsReturnsData;
  Function(int)? callBack;
  BondDetailsReturnsTab({
    required this.bondDetailsReturnsData,
    this.callBack,
    Key? key,
  }) : super(key: key);

  TextEditingController unitController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    double variable = (0.3 /
        (bondDetailsReturnsData.bondDetailsReturnsTImelineTileModel!.length +
            1));
    Size screenSize = MediaQuery.of(context).size;
    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.only(top: 20, left: 16, bottom: 27),
              child: FixedTimeline(
                  theme: TimelineThemeData(
                      connectorTheme: ConnectorThemeData(
                          color: customColors().backgroundTertiary,
                          thickness: 6),
                      indicatorTheme: IndicatorThemeData(
                          color: customColors().primary, size: 10),
                      indicatorPosition: 0),
                  children: [
                    if (bondDetailsReturnsData
                        .bondDetailsReturnsFirstTImelineTileModel!.isNotEmpty)
                      TimelineTile(
                        node: TimelineNode(
                          startConnector: const SolidLineConnector(),
                          endConnector: (bondDetailsReturnsData
                                  .bondDetailsReturnsTImelineTileModel!.isEmpty)
                              ? const SolidLineConnector(
                                  thickness: 0,
                                )
                              : SizedBox(
                                  child: DecoratedLineConnector(
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        begin: Alignment.topCenter,
                                        end: Alignment.bottomCenter,
                                        colors: [
                                          customColors()
                                              .primary
                                              .withOpacity(0.31),
                                          customColors()
                                              .primary
                                              .withOpacity(0.31 - variable),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                          indicator: const DotIndicator(),
                        ),
                        nodeAlign: TimelineNodeAlign.start,
                        contents: Container(
                          padding: const EdgeInsets.only(left: 16),
                          child: ReturnFirstTileItem(
                            item: bondDetailsReturnsData
                                .bondDetailsReturnsFirstTImelineTileModel![0],
                            screenSize: screenSize,
                            flag: bondDetailsReturnsData
                                .bondDetailsReturnsTImelineTileModel!
                                .isNotEmpty,
                          ),
                        ),
                      ),
                    for (int i = 0;
                        i <
                            bondDetailsReturnsData
                                .bondDetailsReturnsTImelineTileModel!.length;
                        i++)
                      TimelineTile(
                        node: TimelineNode(
                          startConnector: const SolidLineConnector(),
                          endConnector: (i ==
                                  bondDetailsReturnsData
                                          .bondDetailsReturnsTImelineTileModel!
                                          .length -
                                      1)
                              ? const SolidLineConnector(
                                  thickness: 0,
                                )
                              : SizedBox(
                                  child: DecoratedLineConnector(
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        begin: Alignment.topCenter,
                                        end: Alignment.bottomCenter,
                                        colors: [
                                          customColors().primary.withOpacity(
                                              0.31 - (variable * (i + 1))),
                                          customColors().primary.withOpacity(
                                              0.31 - (variable * (i + 2))),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                          indicator: const DotIndicator(),
                          overlap: true,
                        ),
                        nodeAlign: TimelineNodeAlign.start,
                        contents: Container(
                            padding: const EdgeInsets.only(left: 16),
                            child: ReturnsTileItem(
                              item: bondDetailsReturnsData
                                  .bondDetailsReturnsTImelineTileModel![i],
                              screenSize: screenSize,
                              checkLast: (i ==
                                      bondDetailsReturnsData
                                              .bondDetailsReturnsTImelineTileModel!
                                              .length -
                                          1)
                                  ? true
                                  : false,
                            )),
                      ),
                    if (bondDetailsReturnsData
                            .bondDetailsReturnsContainerModel![0].facevalue !=
                        "-")
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          SizedBox(
                            width: screenSize.width * 0.55,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Image.asset("assets/plus_green.png"),
                                Padding(
                                  padding: const EdgeInsets.only(top: 12),
                                  child: Text(
                                    "Face Value",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_SemiBold,
                                        color: FontColor.FontSecondary),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 2),
                                  child: Text(
                                    "₹" +
                                        Formats.valueFormatIndian2.format(double
                                            .tryParse(bondDetailsReturnsData
                                                .bondDetailsReturnsContainerModel![
                                                    0]
                                                .facevalue
                                                .toString())),
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyL_Bold,
                                        color: FontColor.FontPrimary),
                                  ),
                                ),
                              ],
                            ),
                          )
                        ],
                      )
                  ]),
            ),
          ),
        ),
        Stack(
          alignment: Alignment.center,
          children: [
            Container(
              padding: EdgeInsets.only(
                  top: screenSize.height * 0.025,
                  bottom: screenSize.height * 0.02,
                  left: 16,
                  right: 16),
              color: customColors().backgroundSecondary,
              child: Column(
                children: [
                  Row(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Total Investment",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontSecondary),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Text(
                              bondDetailsReturnsData
                                          .bondDetailsReturnsContainerModel![0]
                                          .totalinvestment !=
                                      "-"
                                  ? "₹" +
                                      Formats.valueFormatIndian2.format(
                                          double.tryParse(bondDetailsReturnsData
                                              .bondDetailsReturnsContainerModel![
                                                  0]
                                              .totalinvestment
                                              .toString()))
                                  : bondDetailsReturnsData
                                      .bondDetailsReturnsContainerModel![0]
                                      .totalinvestment
                                      .toString(),
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary),
                            ),
                          )
                        ],
                      ),
                      const Expanded(
                        child: SizedBox(),
                      ),
                      SizedBox(
                        width: screenSize.width * 0.41,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Units",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyS_SemiBold,
                                  color: FontColor.FontSecondary),
                            ),
                            Padding(
                                padding: const EdgeInsets.only(top: 4),
                                child: customCounterWidget(
                                  initial: int.parse(bondDetailsReturnsData
                                      .bondDetailsReturnsContainerModel![0]
                                      .units!),
                                  buttonHeight: 24,
                                  buttonWidth: 24,
                                  textPadding: 0,
                                  callBack: (value) {
                                    callBack!(value);
                                  },
                                  step: bondDetailsReturnsData
                                      .bondDetailsReturnsContainerModel![0]
                                      .unitInterval!,
                                  textStyle: customTextStyle(
                                      fontStyle: FontStyle.BodyL_SemiBold,
                                      color: FontColor.FontPrimary),
                                  decrWidget: const Image(
                                      image: AssetImage(
                                          "assets/minus_filled.png")),
                                  incrWidget: const Image(
                                      image:
                                          AssetImage("assets/plus_filled.png")),
                                ))
                          ],
                        ),
                      )
                    ],
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(
                        vertical: screenSize.height * 0.015),
                    child: CustomDividerWithPadding(
                      horizondalPadding: 0,
                    ),
                  ),
                  Row(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Interest Earned",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontSecondary),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Text(
                              bondDetailsReturnsData
                                          .bondDetailsReturnsContainerModel![0]
                                          .interestearned !=
                                      "-"
                                  ? "₹" +
                                      Formats.valueFormatIndian2.format(
                                          double.tryParse(bondDetailsReturnsData
                                              .bondDetailsReturnsContainerModel![
                                                  0]
                                              .interestearned
                                              .toString()))
                                  : bondDetailsReturnsData
                                      .bondDetailsReturnsContainerModel![0]
                                      .interestearned
                                      .toString(),
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary),
                            ),
                          )
                        ],
                      ),
                      const Expanded(
                        child: SizedBox(),
                      ),
                      SizedBox(
                        width: screenSize.width * 0.41,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Total Returns",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_Regular,
                                  color: FontColor.FontSecondary),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 4),
                              child: Text(
                                bondDetailsReturnsData
                                            .bondDetailsReturnsContainerModel![
                                                0]
                                            .totalreturns !=
                                        "-"
                                    ? "₹" +
                                        Formats.valueFormatIndian2.format(double
                                            .tryParse(bondDetailsReturnsData
                                                .bondDetailsReturnsContainerModel![
                                                    0]
                                                .totalreturns
                                                .toString()))
                                    : bondDetailsReturnsData
                                        .bondDetailsReturnsContainerModel![0]
                                        .totalreturns
                                        .toString(),
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_SemiBold,
                                    color: FontColor.FontPrimary),
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ],
              ),
            ),
            Container(
              alignment: Alignment.center,
              height: screenSize.height * 0.15,
              child: VerticalDivider(
                color: customColors().backgroundTertiary,
                thickness: 1,
              ),
            )
          ],
        )
      ],
    );
  }
}

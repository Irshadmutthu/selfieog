import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/model/bond_application_model.dart';
import 'package:selfie_mobile_flutter/model/bond_details_header_model.dart';
import 'package:selfie_mobile_flutter/model/bond_details_issuer_model.dart';
import 'package:selfie_mobile_flutter/model/bond_details_overview_model.dart';
import 'package:selfie_mobile_flutter/model/bond_details_returns_model.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/page_bond_details/components/bond_details_issuer_tab.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/page_bond_details/components/bond_details_overview_tab.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/page_bond_details/components/bond_details_returns_tab.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/page_bond_details/cubit/bond_details_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_shimmer/bond_details_shimmer.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_top_tab.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';

class BondDetailsPage extends StatelessWidget {
  final int bondId;

  BondDetailsPage({
    Key? key,
    required this.bondId,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return BlocConsumer<BondDetailsCubit, BondDetailsState>(
      listener: (context, state) {
        if (state is BondsDetailsError) {
          if (state.errorMessage != "") {
            ScaffoldMessenger.of(context).showSnackBar(
                showErrorDialogue(errorMessage: state.errorMessage));
          }
        }
      },
      builder: (context, state) {
        if (state is BondDetailsLoading) {
          return BondDetailsShimmer();
          // } else if (state is BondDetailsInitial) {
        } else if (state is BondDetailsInitial) {
          return Scaffold(
            appBar: PreferredSize(
                preferredSize: const Size.fromHeight(0.0),
                child: AppBar(
                  elevation: 0,
                  backgroundColor: customColors().backgroundPrimary,
                )),
            body: Column(
              children: [
                CustomAppBarInner(
                    title: "Bond Details",
                    onBackPressed: () {
                      context.gNavigationService.back(context);
                    }),
                BondDetailsHeaderContainer(
                    screenSize: screenSize,
                    bondDetailsHeaderData: state.bondDetailsHeaderData),
                Expanded(
                    child: CustomTabBar(
                  isScrollable: true,
                  indicatorSize: TabBarIndicatorSize.label,
                  tabContent: const ["Overview", "Returns", "Issuer"],
                  tabBarViewChildern: [
                    BondDetailsOverviewTab(
                        bondDetailsOverviewItem: state.bondDetailsOverviewData),
                    BondDetailsReturnsTab(
                      bondDetailsReturnsData: state.bondDetailsReturnsData,
                      callBack: (val) {
                        state
                            .bondDetailsReturnsData
                            .bondDetailsReturnsContainerModel![0]
                            .units = val.toString();
                      },
                    ),
                    BondDetailsIssuerTab(
                      bondDetailsIssuerData: state.bondDetailsIssuerData,
                    )
                  ],
                )),
              ],
            ),
            bottomNavigationBar: BottomAppBar(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Visibility(
                    visible: state.checkRegular,
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 16, right: 16, top: 13, bottom: 12),
                          child: BasketButton(
                            bgcolor: customColors().primary,
                            text: "Invest Now!",
                            textStyle: customTextStyle(
                                fontStyle: FontStyle.BodyL_Bold,
                                color: FontColor.White),
                            onpress: () {
                              if (int.parse(state
                                      .bondDetailsReturnsData
                                      .bondDetailsReturnsContainerModel![0]
                                      .units!) !=
                                  0) {
                                BlocProvider.of<BondDetailsCubit>(context)
                                    .bondDetailsNavigation(
                                        context,
                                        BondApplicationArgumentModel(
                                          bondId: bondId.toString(),
                                          bondtype:
                                              state.bondDetailsHeaderData.type,
                                          buySellInvestStatus: "I",
                                          coupon: state
                                              .bondDetailsOverviewData.coupon,
                                          issueDate: state
                                              .bondDetailsOverviewData
                                              .issuedate,
                                          maturityDate: state
                                              .bondDetailsOverviewData
                                              .maturitydate,
                                          minInvestment: state
                                              .bondDetailsOverviewData
                                              .mininvestment,
                                          misc1: state
                                              .bondDetailsOverviewData.misc1,
                                          name:
                                              state.bondDetailsHeaderData.name,
                                          yield: state.bondDetailsOverviewData
                                              .bondDetailsOverviewYield,
                                          totalInvestment: state
                                              .bondDetailsReturnsData
                                              .bondDetailsReturnsContainerModel![
                                                  0]
                                              .totalinvestment,
                                          unit: state
                                              .bondDetailsReturnsData
                                              .bondDetailsReturnsContainerModel![
                                                  0]
                                              .units,
                                          installments: state
                                              .bondDetailsOverviewData
                                              .interestpayment,
                                        ));
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                    showErrorDialogue(
                                        errorMessage:
                                            "Please enter the valid units"));
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                  Visibility(
                    visible: state.checkIpo,
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 16, right: 16, top: 13, bottom: 12),
                          child: BasketButton(
                            bgcolor: customColors().primary,
                            text: "Apply Now!",
                            textStyle: customTextStyle(
                                fontStyle: FontStyle.BodyL_Bold,
                                color: FontColor.White),
                            onpress: () {
                              ScaffoldMessenger.of(context).showSnackBar(
                                  showSuccessDialogue(
                                      errorMessage: "Applied Successfully"));
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                  Visibility(
                    visible: state.checkMyBond,
                    child: Padding(
                      padding: const EdgeInsets.only(
                          left: 16, right: 16, bottom: 13, top: 8),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                              child: BasketButton(
                            bordercolor: customColors().green4,
                            text: "Invest More",
                            textStyle: customTextStyle(
                                fontStyle: FontStyle.BodyL_Bold,
                                color: FontColor.Primary),
                            onpress: () {
                              if (int.parse(state
                                      .bondDetailsReturnsData
                                      .bondDetailsReturnsContainerModel![0]
                                      .units!) !=
                                  0) {
                                BlocProvider.of<BondDetailsCubit>(context)
                                    .bondDetailsNavigation(
                                        context,
                                        BondApplicationArgumentModel(
                                          bondId: bondId.toString(),
                                          bondtype:
                                              state.bondDetailsHeaderData.type,
                                          buySellInvestStatus: "IM",
                                          coupon: state
                                              .bondDetailsOverviewData.coupon,
                                          issueDate: state
                                              .bondDetailsOverviewData
                                              .issuedate,
                                          maturityDate: state
                                              .bondDetailsOverviewData
                                              .maturitydate,
                                          minInvestment: state
                                              .bondDetailsOverviewData
                                              .mininvestment,
                                          misc1: state
                                              .bondDetailsOverviewData.misc1,
                                          name:
                                              state.bondDetailsHeaderData.name,
                                          yield: state.bondDetailsOverviewData
                                              .bondDetailsOverviewYield,
                                          totalInvestment: state
                                              .bondDetailsReturnsData
                                              .bondDetailsReturnsContainerModel![
                                                  0]
                                              .totalinvestment,
                                          unit: state
                                              .bondDetailsReturnsData
                                              .bondDetailsReturnsContainerModel![
                                                  0]
                                              .units,
                                          installments: state
                                              .bondDetailsOverviewData
                                              .interestpayment,
                                        ));
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                    showErrorDialogue(
                                        errorMessage:
                                            "Please enter the valid units"));
                              }
                            },
                          )),
                          const SizedBox(
                            width: 8,
                          ),
                          Expanded(
                              child: BasketButton(
                            bordercolor: transparent,
                            bgcolor: customColors().primary,
                            text: " Sell ",
                            textStyle: customTextStyle(
                                fontStyle: FontStyle.BodyL_Bold,
                                color: FontColor.White),
                            onpress: () {
                              if (int.parse(state
                                      .bondDetailsReturnsData
                                      .bondDetailsReturnsContainerModel![0]
                                      .units!) !=
                                  0) {
                                BlocProvider.of<BondDetailsCubit>(context)
                                    .bondDetailsNavigation(
                                        context,
                                        BondApplicationArgumentModel(
                                          bondId: bondId.toString(),
                                          bondtype:
                                              state.bondDetailsHeaderData.type,
                                          buySellInvestStatus: "S",
                                          coupon: state
                                              .bondDetailsOverviewData.coupon,
                                          issueDate: state
                                              .bondDetailsOverviewData
                                              .issuedate,
                                          maturityDate: state
                                              .bondDetailsOverviewData
                                              .maturitydate,
                                          minInvestment: state
                                              .bondDetailsOverviewData
                                              .mininvestment,
                                          misc1: state
                                              .bondDetailsOverviewData.misc1,
                                          name:
                                              state.bondDetailsHeaderData.name,
                                          yield: state.bondDetailsOverviewData
                                              .bondDetailsOverviewYield,
                                          totalInvestment: state
                                              .bondDetailsReturnsData
                                              .bondDetailsReturnsContainerModel![
                                                  0]
                                              .totalinvestment,
                                          unit: state
                                              .bondDetailsReturnsData
                                              .bondDetailsReturnsContainerModel![
                                                  0]
                                              .units,
                                          installments: state
                                              .bondDetailsOverviewData
                                              .interestpayment,
                                        ));
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                    showErrorDialogue(
                                        errorMessage:
                                            "Please enter the valid units"));
                              }
                            },
                          )),
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
          );
        }

        return Scaffold(
          appBar: PreferredSize(
              preferredSize: const Size.fromHeight(0.0),
              child: AppBar(
                elevation: 0,
                backgroundColor: customColors().backgroundPrimary,
              )),
          body: Column(
            children: [
              CustomAppBarInner(
                  title: "Bond Details",
                  onBackPressed: () {
                    context.gNavigationService.back(context);
                  }),
              BondDetailsHeaderContainer(
                screenSize: screenSize,
                bondDetailsHeaderData: BondDetailsHeaderData.fromJson({}),
              ),
              Expanded(
                  child: CustomTabBar(
                isScrollable: true,
                indicatorSize: TabBarIndicatorSize.label,
                tabContent: const ["Overview", "Returns", "Issuer"],
                tabBarViewChildern: [
                  BondDetailsOverviewTab(
                      bondDetailsOverviewItem:
                          BondDetailsOverviewData.fromJson({})),
                  BondDetailsReturnsTab(
                    bondDetailsReturnsData:
                        bondDetailsReturnsModelFromJson("{}"),
                  ),
                  BondDetailsIssuerTab(
                    bondDetailsIssuerData: BondDetailsIssuerData.fromJson({}),
                  )
                ],
              )),
            ],
          ),
        );
      },
    );
  }
  // resizeToAvoidBottomInset: false,

}

class BondDetailsHeaderContainer extends StatelessWidget {
  final Size screenSize;
  final BondDetailsHeaderData bondDetailsHeaderData;
  const BondDetailsHeaderContainer({
    required this.bondDetailsHeaderData,
    required this.screenSize,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          color: customColors().backgroundSecondary,
          child: Padding(
            padding: const EdgeInsets.only(
              left: 16,
            ),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 20, bottom: 20),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 16),
                        child: Image.asset('assets/bonds_icon.png'),
                      ),
                      SizedBox(
                        width: screenSize.width * .38,
                        child: Text(
                          ((bondDetailsHeaderData.type != "-")
                                  ? ((bondDetailsHeaderData.type == "R")
                                      ? "Regular Income "
                                      : "IPO - ")
                                  : "") +
                              bondDetailsHeaderData.name.toString(),
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary),
                        ),
                      )
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Bond Type",
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyM_Regular,
                                      color: FontColor.FontSecondary),
                                ),
                                Text(
                                  bondDetailsHeaderData.bondtype.toString(),
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_SemiBold,
                                      color: FontColor.FontPrimary),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: screenSize.width * .45,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "ISIN",
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyM_Regular,
                                      color: FontColor.FontSecondary),
                                ),
                                Text(
                                  bondDetailsHeaderData.isin.toString(),
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_SemiBold,
                                      color: FontColor.FontPrimary),
                                ),
                              ],
                            ),
                          )
                        ],
                      ),
                      if (bondDetailsHeaderData.selected == "Y")
                        Padding(
                          padding: const EdgeInsets.only(top: 16),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Intrest",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_Regular,
                                          color: FontColor.FontSecondary),
                                    ),
                                    Text(
                                      (bondDetailsHeaderData.interest == "-")
                                          ? bondDetailsHeaderData.interest
                                              .toString()
                                          : "₹" +
                                              Formats.valueFormatIndian2.format(
                                                  double.tryParse(
                                                      bondDetailsHeaderData
                                                          .interest
                                                          .toString())),
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyL_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: screenSize.width * .45,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Next Payment",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_Regular,
                                          color: FontColor.FontSecondary),
                                    ),
                                    Text(
                                      bondDetailsHeaderData.nextPayment
                                          .toString(),
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyL_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                  ],
                                ),
                              )
                            ],
                          ),
                        )
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/page_bond_details/bond_details_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/page_bond_details/cubit/bond_details_cubit.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class BondDetailsPageRouteBuilder {
  final ServiceLocator _serviceLocator;
  int bondId;

  BondDetailsPageRouteBuilder(this._serviceLocator, this.bondId);
  Widget call(BuildContext context) {
    // return MultiRepositoryProvider(
    //   providers: [RepositoryProvider.value(value: _serviceLocator.tradingApi)],
    //   child: BondDetailsPage(),
    // );
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) =>
              BondDetailsCubit(serviceLocator: _serviceLocator, bondId: bondId),
        )
      ],
      child: MultiRepositoryProvider(
        providers: [
          RepositoryProvider.value(value: _serviceLocator.tradingApi)
        ],
        child: BondDetailsPage(
          bondId: bondId,
        ),
      ),
    );
  }
}

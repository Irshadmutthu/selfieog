// part of 'bonds_feature_cubit.dart';

// @immutable
// abstract class BondsFeatureState {}

// class BondsFeatureLoading extends BondsFeatureState {}

// class BondsFeatureInitial extends BondsFeatureState {}

// class BondsFeatureError extends BondsFeatureState {
//   final int errorCode;
//   final String errorMessage;
//   BondsFeatureError({required this.errorCode, required this.errorMessage});
// }

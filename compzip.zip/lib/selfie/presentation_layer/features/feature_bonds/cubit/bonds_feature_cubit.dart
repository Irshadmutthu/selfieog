// import 'package:bloc/bloc.dart';
// import 'package:flutter/foundation.dart';
// // import 'package:selfie_mobile_flutter/model/my_bonds_model.dart';
// import 'package:selfie_mobile_flutter/services/api_gateway.dart';
// import 'package:selfie_mobile_flutter/services/service_locator.dart';
// import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';

// part 'bonds_feature_state.dart';

// class BondsFeatureCubit extends Cubit<BondsFeatureState> {
//   final ServiceLocator serviceLocator;
//   // final TradingApiGateway? tradingApiGateway;
//   BondsFeatureCubit({required this.serviceLocator})
//       : super(BondsFeatureInitial()) {
//     sendAllBondsRequest();
//     // sendMyBondsRequest();
//   }
//   sendAllBondsRequest() async {
//     try {
//       emit(BondsFeatureLoading());
//       if (kDebugMode) {}
//       if (UserController.userController.allBondsList.apiRequestStatus ==
//           false) {
//         await serviceLocator.tradingApi.getAllBonds();
//       }
//       emit(BondsFeatureInitial());
//     } catch (errorMessage) {
//       emit(BondsFeatureError(
//           errorCode: 000, errorMessage: errorMessage.toString()));
//     }
//   }

//   sendMyBondsRequest() async {
//     try {
//       emit(BondsFeatureLoading());
//       if (kDebugMode) {}
//       String response = await serviceLocator.tradingApi.getMyBonds();
//       print("send request my bond function success . $response");
//       emit(BondsFeatureInitial());
//     } catch (errorMessage) {
//       emit(BondsFeatureError(
//           errorCode: 000, errorMessage: errorMessage.toString()));
//     }
//   }
// }

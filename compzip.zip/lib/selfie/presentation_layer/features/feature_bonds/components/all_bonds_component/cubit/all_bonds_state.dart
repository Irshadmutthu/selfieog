part of 'all_bonds_cubit.dart';

@immutable
abstract class AllBondsState {}

class AllBondsLoading extends AllBondsState {}

class AllBondsInitial extends AllBondsState {
  int selectedSortIndex;
  List<Map<String, dynamic>> filterList;
  List<BondsListData> allBondsModelFiltered;
  List<BondsListData> allBondsModel;

  AllBondsInitial({
    this.selectedSortIndex = 0,
    this.filterList = const [],
    required this.allBondsModelFiltered,
    required this.allBondsModel,
  });
}

class AllBondsError extends AllBondsState {
  final int errorCode;
  final String errorMessage;
  AllBondsError({required this.errorCode, required this.errorMessage});
}

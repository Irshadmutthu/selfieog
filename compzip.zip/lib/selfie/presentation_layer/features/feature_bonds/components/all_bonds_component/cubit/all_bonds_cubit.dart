import 'dart:convert';

import 'package:bloc/bloc.dart';
import 'package:flutter/foundation.dart';
import 'package:selfie_mobile_flutter/model/bonds_list_data_model.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/components/my_bond_component/cubit/my_bond_cubit.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/bonds_utils.dart';
part 'all_bonds_state.dart';

class AllBondsCubit extends Cubit<AllBondsState> {
  final ServiceLocator serviceLocator;
  AllBondsCubit({required this.serviceLocator})
      : super(AllBondsInitial(
            selectedSortIndex: 0,
            allBondsModelFiltered: [],
            allBondsModel: const [])) {
    sendAllBondsRequest(filterList: resetBondsFilterList);
  }

  sendAllBondsRequest({required List<Map<String, dynamic>> filterList}) async {
    try {
      emit(AllBondsLoading());
      if (kDebugMode) {}
      // List<AllBondsDataModel> allBondslistFiltered = [];
      if (UserController.userController.allBondsList.apiRequestStatus ==
          false) {
        await serviceLocator.tradingApi.getAllBonds();
      }
      List<BondsListData> allBondslistFiltered =
          resetAllbondList(UserController().allBondsList.allBondsData);
      updateSort(
        filterList: filterList,
        selectedSortIndex: 0,
        allBondsModel: UserController().allBondsList.allBondsData,
        allBondsModelFiltered: allBondslistFiltered,
      );
      emit(AllBondsInitial(
          filterList: filterList,
          allBondsModelFiltered: allBondslistFiltered,
          allBondsModel: UserController().allBondsList.allBondsData));
    } catch (errorMessage) {
      emit(
          AllBondsError(errorCode: 000, errorMessage: errorMessage.toString()));
    }
  }

  updateSort(
      {required List<Map<String, dynamic>> filterList,
      required int selectedSortIndex,
      required List<BondsListData> allBondsModel,
      required List<BondsListData> allBondsModelFiltered}) {
    // List<BondsListData> convertedBondList = allBondsModelFromJson(sortOperation(
    //         bondList: List<Map<String, dynamic>>.from(
    //             json.decode(jsonEncode(allBondsModelFiltered))),
    //         selectedSortIndex: selectedSortIndex))
    //     .allBondsData;
    allBondsModelFiltered = sortOperation(
        bondList: allBondsModelFiltered, selectedSortIndex: selectedSortIndex);

    emit(AllBondsInitial(
        filterList: filterList,
        selectedSortIndex: selectedSortIndex,
        allBondsModelFiltered: allBondsModelFiltered,
        allBondsModel: allBondsModel));
  }

  updateFilter(
      {required int categoryId,
      required int itemId,
      required bool value,
      required List<Map<String, dynamic>> filterList}) {
    filterList[categoryId]["items"][itemId]["selected"] = value;

    emit(AllBondsInitial(
      filterList: filterList,
      allBondsModelFiltered: filterOpertion(
          bondsList:
              resetMybondList(UserController().allBondsList.allBondsData),
          filterList: filterList),
      allBondsModel: UserController().allBondsList.allBondsData,
    ));
  }

  filterItem() {}
}

List<BondsListData> resetAllbondList(List<BondsListData> myBondsModel) {
  List<BondsListData> resetMyBondList = List.generate(myBondsModel.length,
      (index) => BondsListData.fromJson(myBondsModel[index].toJson()));
  return resetMyBondList.toList();
}

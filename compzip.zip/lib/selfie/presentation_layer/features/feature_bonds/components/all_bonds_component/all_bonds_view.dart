import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/model/all_bonds_model.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/components/all_bonds_component/cubit/all_bonds_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/sort_list_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_bottom_sheet/sort_filter_bottom_sheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_empty_container/custom_empty_container_with_refresh_indicator.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_list_item/all_bonds_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_search_filter_bar/custom_search_filter_bar_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_shimmer/all_bonds_shimmer.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/bonds_utils.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';

class AllBondsView extends StatelessWidget {
  final AllBondsModel allBondsModel;
  AllBondsView({
    required this.allBondsModel,
    Key? key,
  }) : super(key: key);
  int selectedABS = 0;
  bool sortActive = false;

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return BlocConsumer<AllBondsCubit, AllBondsState>(
        listener: (context, state) {
      if (state is AllBondsError) {
        if (state.errorMessage != "") {
          ScaffoldMessenger.of(context).showSnackBar(
              showErrorDialogue(errorMessage: state.errorMessage));
        }
      }
    }, builder: (context, state) {
      if (state is AllBondsLoading) {
        return const AllBondsShimmerLoader();
      } else if (state is AllBondsInitial) {
        return (UserController().allBondsList.allBondsData.isEmpty)
            ? CustomEmptyContainerWithRefreshIndicator(
                screenSize: screenSize,
                onRefress: () async {
                  UserController().allBondsList.apiRequestStatus = false;
                  BlocProvider.of<AllBondsCubit>(context)
                      .sendAllBondsRequest(filterList: state.filterList);
                },
                title: "No Bonds",
                subTitle: "Bonds Data Are Empty",
              )
            : RefreshIndicator(
                backgroundColor: customColors().primary,
                onRefresh: () async {
                  UserController().allBondsList.apiRequestStatus = false;
                  BlocProvider.of<AllBondsCubit>(context)
                      // .sendAllBondsRequest(filterList: state.filterList);
                      .sendAllBondsRequest(filterList: resetBondsFilterList);
                },
                child: Column(children: [
                  CustomSearchFilterBar(
                    showBubble: false,
                    onSearchPress: () {},
                    onFilterPress: () {
                      customShowModalBottomSheet(
                          context: context,
                          inputWidget: SortFilterResetBottomSheet(
                            selectedSortIndex: state.selectedSortIndex,
                            sortList: allBondsSortList,
                            filterList: state.filterList,
                            onPressFilter: (categoryId, itemId, value) {
                              context.read<AllBondsCubit>().updateFilter(
                                  categoryId: categoryId,
                                  itemId: itemId,
                                  value: value,
                                  filterList: state.filterList);
                            },
                            onPressSort: (changedIndex) {
                              context.read<AllBondsCubit>().updateSort(
                                    filterList: state.filterList,
                                    allBondsModel: UserController()
                                        .allBondsList
                                        .allBondsData,
                                    allBondsModelFiltered:
                                        state.allBondsModelFiltered,
                                    selectedSortIndex: changedIndex,
                                  );
                              Navigator.of(context).pop();
                              selectedABS = state.selectedSortIndex;
                            },
                            onPressReset: () {
                              Navigator.of(context).pop();
                            },
                          ));
                    },
                  ),
                  Expanded(
                    child: ListView.builder(
                        itemBuilder: (context, index) => InkWell(
                            child: AllBondListItem(
                                allBondsListItem:
                                    state.allBondsModelFiltered[index]),
                            onTap: () => context.gNavigationService
                                .openBondDetailsPage(
                                    context,
                                    int.tryParse(state
                                        .allBondsModelFiltered[index].id
                                        .toString())!)),
                        itemCount: state.allBondsModelFiltered.length),
                  ),
                  // Expanded(
                  //   child: ListView.builder(
                  //       itemBuilder: (context, index) => InkWell(
                  //           child: AllBondListItem(
                  //               allBondsListItem: UserController()
                  //                   .allBondsList
                  //                   .allBondsData[index]),
                  //           onTap: () => context.gNavigationService
                  //               .openBondDetailsPage(
                  //                   context,
                  //                   int.tryParse(UserController()
                  //                       .allBondsList
                  //                       .allBondsData[index]
                  //                       .id
                  //                       .toString())!)),
                  //       itemCount:
                  //           UserController().allBondsList.allBondsData.length),
                  // ),
                ]),
              );
      } else if (state is AllBondsError) {
        return CustomEmptyContainerWithRefreshIndicator(
          screenSize: screenSize,
          onRefress: () async {
            UserController().allBondsList.apiRequestStatus = false;
            BlocProvider.of<AllBondsCubit>(context)
                .sendAllBondsRequest(filterList: []);
          },
          title: "No Bonds",
          subTitle: "Bonds Data Are Empty",
        );
      } else {
        return Container();
      }
    });
  }
}

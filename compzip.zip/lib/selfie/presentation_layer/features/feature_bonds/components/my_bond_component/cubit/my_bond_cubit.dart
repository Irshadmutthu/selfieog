import 'dart:convert';

import 'package:bloc/bloc.dart';
import 'package:flutter/foundation.dart';
import 'package:selfie_mobile_flutter/model/bonds_list_data_model.dart';
import 'package:selfie_mobile_flutter/model/my_bonds_model.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/utils/bonds_utils.dart';

part 'my_bond_state.dart';

class MyBondCubit extends Cubit<MyBondState> {
  final ServiceLocator serviceLocator;
  MyBondCubit({required this.serviceLocator})
      : super(MyBondInitial(
            myBondsModel: const [], myBondsModelFiltered: const [])) {
    sendMyBondsRequest(filterList: resetBondsFilterList);
  }
  sendMyBondsRequest({required List<Map<String, dynamic>> filterList}) async {
    try {
      emit(MyBondLoading());
      if (kDebugMode) {}
      String response = await serviceLocator.tradingApi.getMyBonds();
      List<BondsListData> myBondsModel =
          myBondsModelFromJson(response).myBondsData!;
      List<BondsListData> myBondsModelFiltered =
          resetMybondList(myBondsModelFromJson(response).myBondsData!);
      updateSort(
          filterList: filterList,
          selectedSortIndex: 0,
          myBondsModel: myBondsModel,
          myBondsModelFiltered: myBondsModelFiltered);
      emit(MyBondInitial(
          myBondsModel: myBondsModel,
          myBondsModelFiltered: myBondsModelFiltered,
          filterList: filterList));
    } catch (errorMessage) {
      emit(MyBondError(errorCode: 000, errorMessage: errorMessage.toString()));
    }
  }

  updateSort(
      {required List<Map<String, dynamic>> filterList,
      required int selectedSortIndex,
      required List<BondsListData> myBondsModel,
      required List<BondsListData> myBondsModelFiltered}) {
    // List<BondsListData> convertedBondList = myBondsModelFromJson(sortOperation(
    //         bondList: List<Map<String, dynamic>>.from(
    //             json.decode(jsonEncode(myBondsModelFiltered))),
    //         selectedSortIndex: selectedSortIndex))
    //     .myBondsData!;
    myBondsModelFiltered = sortOperation(
        bondList: myBondsModelFiltered, selectedSortIndex: selectedSortIndex);
    emit(MyBondInitial(
        selectedSortIndex: selectedSortIndex,
        myBondsModel: myBondsModel,
        myBondsModelFiltered: myBondsModelFiltered,
        filterList: filterList));
  }

  updateFilter({
    required int categoryId,
    required int itemId,
    required bool value,
    required List<Map<String, dynamic>> filterList,
    required List<BondsListData> myBondsModel,
  }) {
    filterList[categoryId]["items"][itemId]["selected"] = value;
    emit(MyBondInitial(
        filterList: filterList,
        myBondsModel: myBondsModel,
        myBondsModelFiltered: filterOpertion(
            bondsList: resetMybondList(myBondsModel), filterList: filterList)));
  }
}

List<BondsListData> resetMybondList(List<BondsListData> myBondsModel) {
  List<BondsListData> resetMyBondList = List.generate(myBondsModel.length,
      (index) => BondsListData.fromJson(myBondsModel[index].toJson()));
  return resetMyBondList.toList();
}

part of 'my_bond_cubit.dart';

@immutable
abstract class MyBondState {}

class MyBondLoading extends MyBondState {}

class MyBondInitial extends MyBondState {
  final List<BondsListData> myBondsModel;
  List<BondsListData> myBondsModelFiltered;
  List<Map<String, dynamic>> filterList;
  int selectedSortIndex;
  MyBondInitial(
      {required this.myBondsModel,
      required this.myBondsModelFiltered,
      this.selectedSortIndex = 0,
      this.filterList = const []});
}

class MyBondError extends MyBondState {
  final int errorCode;
  final String errorMessage;
  MyBondError({required this.errorCode, required this.errorMessage});
}

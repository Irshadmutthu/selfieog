import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/components/my_bond_component/cubit/my_bond_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/sort_list_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_bottom_sheet/sort_filter_bottom_sheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_empty_container/custom_empty_container_with_refresh_indicator.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_list_item/my_bonds_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_search_filter_bar/custom_search_filter_bar_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_shimmer/my_bonds_shimmer.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/utils/bonds_utils.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';

class MyBondsView extends StatelessWidget {
  MyBondsView({
    Key? key,
  }) : super(key: key);
  int selectedMBS = 0;

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return BlocConsumer<MyBondCubit, MyBondState>(
      listener: (context, state) {
        if (state is MyBondError) {
          if (state.errorMessage != "") {
            ScaffoldMessenger.of(context).showSnackBar(
                showErrorDialogue(errorMessage: state.errorMessage));
          }
        }
      },
      builder: (context, state) {
        if (state is MyBondLoading) {
          return const MyBondsShimmerLoader();
        } else if (state is MyBondInitial) {
          return (state.myBondsModel.isEmpty)
              ? CustomEmptyContainerWithRefreshIndicator(
                  screenSize: screenSize,
                  onRefress: () async {
                    BlocProvider.of<MyBondCubit>(context)
                        .sendMyBondsRequest(filterList: state.filterList);
                  },
                  title: "No Bonds",
                  subTitle: "Bonds Data Are Empty",
                )
              : RefreshIndicator(
                  backgroundColor: customColors().primary,
                  onRefresh: () async {
                    BlocProvider.of<MyBondCubit>(context)
                        // .sendMyBondsRequest(filterList: state.filterList);
                        .sendMyBondsRequest(filterList: resetBondsFilterList);
                  },
                  child: Column(
                    children: [
                      CustomSearchFilterBar(
                        showBubble: false,
                        onSearchPress: () {},
                        onFilterPress: () {
                          customShowModalBottomSheet(
                              context: context,
                              inputWidget: SortFilterResetBottomSheet(
                                selectedSortIndex: state.selectedSortIndex,
                                sortList: myBondsSortList,
                                filterList: state.filterList,
                                onPressFilter: (categoryId, itemId, value) {
                                  context.read<MyBondCubit>().updateFilter(
                                      myBondsModel: state.myBondsModel,
                                      // myBondsModelFiltered:
                                      //     state.myBondsModelFiltered,
                                      categoryId: categoryId,
                                      itemId: itemId,
                                      value: value,
                                      filterList: state.filterList);
                                },
                                onPressSort: (changedIndex) {
                                  context.read<MyBondCubit>().updateSort(
                                      filterList: state.filterList,
                                      selectedSortIndex: changedIndex,
                                      myBondsModel: state.myBondsModel,
                                      myBondsModelFiltered:
                                          state.myBondsModelFiltered);
                                  selectedMBS = state.selectedSortIndex;
                                  Navigator.of(context).pop();
                                },
                                onPressReset: () {
                                  Navigator.of(context).pop();
                                },
                              ));
                        },
                      ),
                      Expanded(
                        child: ListView.builder(
                          itemBuilder: (context, index) => InkWell(
                            child: MyBondsListItem(
                                myBondsListItem:
                                    state.myBondsModelFiltered[index]),
                            onTap: () => context.gNavigationService
                                .openBondDetailsPage(
                                    context,
                                    int.tryParse(state
                                        .myBondsModelFiltered[index].id
                                        .toString())!),
                          ),
                          itemCount: state.myBondsModelFiltered.length,
                        ),
                      ),
                    ],
                  ),
                );
        } else if (state is MyBondError) {
          return CustomEmptyContainerWithRefreshIndicator(
            screenSize: screenSize,
            onRefress: () async {
              BlocProvider.of<MyBondCubit>(context)
                  .sendMyBondsRequest(filterList: []);
            },
            title: "No Bonds",
            subTitle: "Bonds Data Are Empty",
          );
        } else {
          return Container();
        }
      },
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/model/bond_application_model.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/page_bond_details_invest/cubit/bond_details_invest_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_profile/profile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_tags/custom_tag.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class BondDetailsInvestPage extends StatelessWidget {
  BondApplicationArgumentModel bondApplicationArgumentModel;
  bool isClicked = false;

  BondDetailsInvestPage({Key? key, required this.bondApplicationArgumentModel})
      : super(key: key);

  final formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: BlocConsumer<BondDetailsInvestCubit, BondDetailsInvestState>(
        listener: (context, state) {},
        builder: (context, state) {
          if (state is BondDetailsInvestLoading) {
          } else if (state is BondDetailsInvestInitial) {
            return Column(
              children: [
                CustomAppBarInner(
                    title: "Bond Details",
                    onBackPressed: () {
                      context.gNavigationService.back(context);
                    }),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Container(
                          color: customColors().backgroundSecondary,
                          child: Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                    left: 16, top: 20, bottom: 16, right: 13),
                                child: Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceAround,
                                          children: [
                                            Image.asset(
                                                'assets/bonds_icon.png'),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 16),
                                              child: Column(
                                                children: [
                                                  Text(
                                                      ((bondApplicationArgumentModel
                                                                      .bondtype !=
                                                                  "-")
                                                              ? ((bondApplicationArgumentModel
                                                                          .bondtype ==
                                                                      "R")
                                                                  ? "Regular Income\n"
                                                                  : "IPO - ")
                                                              : "") +
                                                          bondApplicationArgumentModel
                                                              .name
                                                              .toString(),
                                                      style: customTextStyle(
                                                          fontStyle: FontStyle
                                                              .BodyL_SemiBold,
                                                          color: FontColor
                                                              .FontPrimary)),
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                        customTag(
                                            value: bondApplicationArgumentModel
                                                        .misc1 !=
                                                    "-"
                                                ? bondApplicationArgumentModel
                                                    .misc1!
                                                : "",
                                            size: TagSize.small),
                                      ],
                                    ),
                                    state.isClick
                                        ? Column(
                                            children: [
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                    top: 20),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    SizedBox(
                                                      width: screenSize.width *
                                                          0.15,
                                                      child: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Text("Yield",
                                                              style: customTextStyle(
                                                                  fontStyle:
                                                                      FontStyle
                                                                          .BodyM_Regular,
                                                                  color: FontColor
                                                                      .FontTertiary)),
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    top: 4),
                                                            child: Text(
                                                                bondApplicationArgumentModel
                                                                    .yield!,
                                                                style: customTextStyle(
                                                                    fontStyle:
                                                                        FontStyle
                                                                            .BodyM_SemiBold,
                                                                    color: FontColor
                                                                        .FontPrimary)),
                                                          ),
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    top: 20),
                                                            child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                Text("Coupon",
                                                                    style: customTextStyle(
                                                                        fontStyle:
                                                                            FontStyle
                                                                                .BodyM_Regular,
                                                                        color: FontColor
                                                                            .FontTertiary)),
                                                                Padding(
                                                                  padding: const EdgeInsets
                                                                          .only(
                                                                      top: 4),
                                                                  child: Text(
                                                                      bondApplicationArgumentModel
                                                                          .coupon!,
                                                                      style: customTextStyle(
                                                                          fontStyle: FontStyle
                                                                              .BodyM_SemiBold,
                                                                          color:
                                                                              FontColor.FontPrimary)),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    const Expanded(
                                                        child: SizedBox()),
                                                    SizedBox(
                                                      width: screenSize.width *
                                                          0.3,
                                                      child: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Text("Min Investment",
                                                              style: customTextStyle(
                                                                  fontStyle:
                                                                      FontStyle
                                                                          .BodyM_Regular,
                                                                  color: FontColor
                                                                      .FontTertiary)),
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    top: 4),
                                                            child: Text(
                                                                bondApplicationArgumentModel
                                                                            .minInvestment !=
                                                                        "-"
                                                                    ? "₹" +
                                                                        Formats
                                                                            .valueFormatIndian2
                                                                            .format(double.tryParse(bondApplicationArgumentModel
                                                                                .minInvestment!))
                                                                    : bondApplicationArgumentModel
                                                                        .minInvestment!,
                                                                style: customTextStyle(
                                                                    fontStyle:
                                                                        FontStyle
                                                                            .BodyM_SemiBold,
                                                                    color: FontColor
                                                                        .FontPrimary)),
                                                          ),
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    top: 20),
                                                            child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                Text(
                                                                    "Installments",
                                                                    style: customTextStyle(
                                                                        fontStyle:
                                                                            FontStyle
                                                                                .BodyM_Regular,
                                                                        color: FontColor
                                                                            .FontTertiary)),
                                                                Padding(
                                                                  padding: const EdgeInsets
                                                                          .only(
                                                                      top: 4),
                                                                  child: Text(
                                                                      bondApplicationArgumentModel
                                                                          .installments!,
                                                                      style: customTextStyle(
                                                                          fontStyle: FontStyle
                                                                              .BodyM_SemiBold,
                                                                          color:
                                                                              FontColor.FontPrimary)),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    const Expanded(
                                                        child: SizedBox()),
                                                    Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text("Maturity Date",
                                                            style: customTextStyle(
                                                                fontStyle: FontStyle
                                                                    .BodyM_Regular,
                                                                color: FontColor
                                                                    .FontTertiary)),
                                                        Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .only(top: 4),
                                                          child: Text(
                                                              bondApplicationArgumentModel
                                                                  .maturityDate!,
                                                              style: customTextStyle(
                                                                  fontStyle:
                                                                      FontStyle
                                                                          .BodyM_SemiBold,
                                                                  color: FontColor
                                                                      .FontPrimary)),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .only(
                                                                  top: 20),
                                                          child: Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Text("Issue Date",
                                                                  style: customTextStyle(
                                                                      fontStyle:
                                                                          FontStyle
                                                                              .BodyM_Regular,
                                                                      color: FontColor
                                                                          .FontTertiary)),
                                                              Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .only(
                                                                        top: 4),
                                                                child: Text(
                                                                    bondApplicationArgumentModel
                                                                        .issueDate!,
                                                                    style: customTextStyle(
                                                                        fontStyle:
                                                                            FontStyle
                                                                                .BodyM_SemiBold,
                                                                        color: FontColor
                                                                            .FontPrimary)),
                                                              ),
                                                            ],
                                                          ),
                                                        )
                                                      ],
                                                    )
                                                  ],
                                                ),
                                              ),
                                            ],
                                          )
                                        : Container()
                                  ],
                                ),
                              ),
                              CustomDividerWithPadding(
                                horizondalPadding: 0,
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(top: 8, bottom: 12),
                                child: InkWell(
                                  onTap: () {
                                    BlocProvider.of<BondDetailsInvestCubit>(
                                            context)
                                        .showContainer(isClicked: isClicked);
                                    isClicked = !isClicked;
                                  },
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Text("Details",
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyL_SemiBold,
                                              color: FontColor.Primary)),
                                      Padding(
                                          padding:
                                              const EdgeInsets.only(left: 4),
                                          child: state.isClick
                                              ? Image.asset(
                                                  "assets/up_arrow.png")
                                              : Image.asset(
                                                  "assets/down_arrow.png"))
                                    ],
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: Container(
                            decoration: BoxDecoration(
                                border: Border.all(
                                    color: customColors().backgroundTertiary)),
                            child: Column(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(
                                      top: 20, left: 16, right: 16),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: Form(
                                          key: formKey,
                                          child: CustomTextFormField(
                                            controller: TextEditingController(
                                                text: bondApplicationArgumentModel
                                                            .unit !=
                                                        "-"
                                                    ? bondApplicationArgumentModel
                                                        .unit!
                                                    : ""),
                                            fieldName: "Units",
                                            validator:
                                                Validator.minimumValueLimit,
                                            minimumValueLimit: 10,
                                            onChange: (value) {
                                              formKey.currentState!.validate();
                                            },
                                            inputFormatter: [
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[0-9]')),
                                              LengthLimitingTextInputFormatter(
                                                  8),
                                            ],
                                            topEndWidget: Text(
                                              "Min: 10",
                                              style: customTextStyle(
                                                  fontStyle:
                                                      FontStyle.BodyL_Regular,
                                                  color:
                                                      FontColor.FontTertiary),
                                            ),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(
                                        width: 16,
                                      ),
                                      Expanded(
                                        child: CustomTextFormField(
                                          controller: TextEditingController(),
                                          fieldName: "Price",
                                          enabled: false,
                                          hintText: "10,000",
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                CustomDividerWithPadding(
                                  horizondalPadding: 0,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                      top: 8, left: 16, bottom: 12, right: 16),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text("Total Investment",
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyM_Regular,
                                              color: FontColor.FontSecondary)),
                                      Text(
                                          bondApplicationArgumentModel
                                                      .totalInvestment !=
                                                  "-"
                                              ? "₹" +
                                                  Formats.valueFormatIndian2
                                                      .format(double.tryParse(
                                                          bondApplicationArgumentModel
                                                              .totalInvestment!))
                                              : bondApplicationArgumentModel
                                                  .totalInvestment!,
                                          style: customTextStyle(
                                              fontStyle: FontStyle.BodyL_Bold,
                                              color: FontColor.FontPrimary))
                                    ],
                                  ),
                                )
                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            );
          }
          return Container();
        },
      ),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
            child: Container(
              color: customColors().accent.withOpacity(0.1),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Get a Quote",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary)),
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Text(
                                "Our Bond Dealers might have a\nbetter Quote for you.",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_Regular,
                                    color: FontColor.FontSecondary)),
                          ),
                        ],
                      ),
                    ),
                    InkWell(
                      onTap: () {},
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            vertical: 10, horizontal: 18),
                        decoration: BoxDecoration(
                            border: Border.all(color: customColors().green4),
                            borderRadius: BorderRadius.circular(4)),
                        child: Text("Call Us",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.Primary)),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
          Container(
            color: customColors().backgroundSecondary,
            padding: const EdgeInsets.symmetric(vertical: 7, horizontal: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text("Available Margin: ",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontSecondary)),
                Text("₹78.80",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontPrimary)),
              ],
            ),
          ),
          if (bondApplicationArgumentModel.buySellInvestStatus == "S")
            Container(
              decoration: BoxDecoration(
                  border: Border(
                      top: BorderSide(
                          color: customColors().backgroundTertiary))),
              padding: const EdgeInsets.only(
                  left: 16, right: 16, top: 12, bottom: 12),
              child: BasketButton(
                bgcolor: customColors().danger,
                text: "Sell",
                textStyle: customTextStyle(
                    fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
                onpress: () {
                  if (formKey.currentState!.validate()) {}
                },
              ),
            )
          else
            Container(
              decoration: BoxDecoration(
                  border: Border(
                      top: BorderSide(
                          color: customColors().backgroundTertiary))),
              padding: const EdgeInsets.only(
                  left: 16, right: 16, top: 12, bottom: 12),
              child: BasketButton(
                bgcolor: customColors().primary,
                text: "Invest Now!",
                textStyle: customTextStyle(
                    fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
                onpress: () {
                  if (formKey.currentState!.validate()) {}
                },
              ),
            ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/model/bond_application_model.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/page_bond_details_invest/bond_details_invest_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/page_bond_details_invest/cubit/bond_details_invest_cubit.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class BondDetailsInvestPageRouteBuilder {
  final ServiceLocator _serviceLocator;

  BondApplicationArgumentModel bondApplicationArgumentModel;

  BondDetailsInvestPageRouteBuilder(
      this._serviceLocator, this.bondApplicationArgumentModel);

  Widget call(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        // BlocProvider(
        //   create: (context) =>
        //       BondDetailsInvestCubit(serviceLocator: _serviceLocator),
        // ),
        BlocProvider(
          create: (context) =>
              BondDetailsInvestCubit(serviceLocator: _serviceLocator),
        ),
      ],
      child: MultiRepositoryProvider(
          providers: [
            RepositoryProvider.value(value: _serviceLocator.tradingApi)
          ],
          child: BondDetailsInvestPage(
            bondApplicationArgumentModel: bondApplicationArgumentModel,
          )),
    );
  }
}

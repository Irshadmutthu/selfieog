part of 'bond_details_invest_cubit.dart';

@immutable
abstract class BondDetailsInvestState {}

class BondDetailsInvestLoading extends BondDetailsInvestState {}

class BondDetailsInvestInitial extends BondDetailsInvestState {
  bool isClick;
  BondDetailsInvestInitial({required this.isClick});
}

class BondDetailsTabUpdate extends BondDetailsInvestState {
  bool isClick;
  BondDetailsTabUpdate({
    required this.isClick,
  });
}

class BondsDetailsInvestError extends BondDetailsInvestState {
  final int errorCode;
  final String errorMessage;
  BondsDetailsInvestError(
      {required this.errorCode, required this.errorMessage});
}

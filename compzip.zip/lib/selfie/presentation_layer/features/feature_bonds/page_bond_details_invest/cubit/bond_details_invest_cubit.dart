import 'package:bloc/bloc.dart';
import 'package:flutter/foundation.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
part 'bond_details_invest_state.dart';

class BondDetailsInvestCubit extends Cubit<BondDetailsInvestState> {
  final ServiceLocator serviceLocator;

  BondDetailsInvestCubit({required this.serviceLocator})
      : super(BondDetailsInvestInitial(isClick: false));

  showContainer({required bool isClicked}) {
    emit(BondDetailsInvestInitial(isClick: !isClicked));
  }
}

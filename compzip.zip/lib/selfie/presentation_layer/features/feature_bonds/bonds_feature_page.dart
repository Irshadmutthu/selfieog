import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/components/all_bonds_component/all_bonds_view.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/components/all_bonds_component/cubit/all_bonds_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/components/my_bond_component/cubit/my_bond_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/components/my_bond_component/my_bonds_view.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_top_tab.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';

class BondsFeaturePage extends StatelessWidget {
  BondsFeaturePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: PreferredSize(
            preferredSize: const Size.fromHeight(0.0),
            child: AppBar(
              elevation: 0,
              backgroundColor: customColors().backgroundPrimary,
            )),
        body: Column(
          children: [
            CustomAppBarInner(
                title: "Bonds",
                onBackPressed: () {
                  context.gNavigationService.back(context);
                }),
            Expanded(
                child: CustomTabBar(
              isScrollable: true,
              indicatorSize: TabBarIndicatorSize.label,
              tabContent: ["All Bonds", "My Bonds"],
              tabBarViewChildern: [
                BlocBuilder<AllBondsCubit, AllBondsState>(
                  builder: (context, state) {
                    return AllBondsView(
                        allBondsModel: UserController().allBondsList);
                  },
                ),
                BlocBuilder<MyBondCubit, MyBondState>(
                  builder: (context, state) {
                    return MyBondsView();
                  },
                )
              ],
            )),
          ],
        ));
  }
}

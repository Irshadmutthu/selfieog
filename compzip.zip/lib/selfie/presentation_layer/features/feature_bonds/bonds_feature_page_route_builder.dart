import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/bonds_feature_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/components/all_bonds_component/cubit/all_bonds_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_bonds/components/my_bond_component/cubit/my_bond_cubit.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class BondsFeaturePageRouteBuilder {
  final ServiceLocator _serviceLocator;

  BondsFeaturePageRouteBuilder(this._serviceLocator);
  Widget call(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => AllBondsCubit(serviceLocator: _serviceLocator),
        ),
        BlocProvider(
          create: (context) => MyBondCubit(serviceLocator: _serviceLocator),
        )
      ],
      child: MultiRepositoryProvider(
        providers: [
          RepositoryProvider.value(value: _serviceLocator.tradingApi)
        ],
        child: BondsFeaturePage(),
      ),
    );
  }
}

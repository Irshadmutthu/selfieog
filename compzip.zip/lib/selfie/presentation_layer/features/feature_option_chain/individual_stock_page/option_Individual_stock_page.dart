import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/cutom_app_bar_option_chain.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/individual_stock_list_item.dart';

import '../../../../../theme/styles.dart';
import '../../../../repository_layer/option_chain_content.dart';
import '../../../../widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import '../../../../widgets/others/sort.dart';

class OptionStockPage extends StatefulWidget {
  const OptionStockPage({Key? key}) : super(key: key);

  @override
  State<OptionStockPage> createState() => _OptionStockPageState();
}

class _OptionStockPageState extends State<OptionStockPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: PreferredSize(
            preferredSize: const Size.fromHeight(0.0),
            child: AppBar(
              elevation: 0,
              backgroundColor: customColors().backgroundPrimary,
            )),
        backgroundColor: customColors().backgroundPrimary,
        body: Column(
          children: [
            CustomAppBarOptionChain(
              title: "BANKNIFTY",
              subtitle: "5,744.53 (+0.12%)",
              onBackPressed: () {},
              onEndIconPressed: () {
                customShowModalBottomSheet(
                    context: context,
                    inputWidget: NormalListwidget(
                      // MoreDataListwidget
                      // OptionMoreActionBottomSheet(
                      // enabled: false,
                      header:
                          "Default Visible Expires ", //Select Number of Strikes,Select Expiry
                      holdingList: [
                        {"name": "60 Days"},
                        {"name": "90 Days"},
                        {"name": "120 Days"},
                        {"name": "180 Days"},
                        {"name": "365 Days"},
                        {"name": "All"}
                      ],
                      // [
                      //   {"name": "Expected Move", "value": "500"},
                      //   {"name": "IV", "value": "25%"},
                      //   {"name": "IV Rank", "value": "25%"},
                      //   {"name": "IV Percentile", "value": "25%"},
                      //   {"name": "Max Paid", "value": "16,5000"},
                      // ],
                      //     [
                      //   {"name": "12"},
                      //   {"name": "24"},
                      //   {"name": "48"},
                      //   {"name": "96"},
                      // ],
                      // [
                      //             {"name": "3 March"},
                      //             {"name": "11 March"},
                      //             {"name": "18 March"},
                      //             {"name": "25 March"},
                      //
                      //           ]
                    ));
              },
              onEndIconPressedsecond: () {},
              fontColor: FontColor.Success,
            ),
            Expanded(
                child: ListView.builder(
                    itemCount: OptionChainCOntent.length,
                    itemBuilder: (BuildContext context, int index) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: IndiavidualStockListItem(
                            date: OptionChainCOntent.elementAt(index)["date"],
                            days: OptionChainCOntent.elementAt(index)["days"],
                            tagname:
                                OptionChainCOntent.elementAt(index)["tagname"],
                            ivdata:
                                OptionChainCOntent.elementAt(index)["ivdata"],
                            indicators: OptionChainCOntent.elementAt(
                                index)["indicators"],
                            tagdate:
                                OptionChainCOntent.elementAt(index)["tagdate"],
                            pldata:
                                OptionChainCOntent.elementAt(index)["pldata"]),
                      );
                    }))
          ],
        ));
  }
}

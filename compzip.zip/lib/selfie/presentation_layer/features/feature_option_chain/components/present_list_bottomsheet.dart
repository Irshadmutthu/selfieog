import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/option_chain/present_item.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

import '../../feature_order_window/order_window_components/order_window_title_component.dart';

class PresentCategoryList extends StatefulWidget {
  const PresentCategoryList({Key? key}) : super(key: key);

  @override
  State<PresentCategoryList> createState() => _PresentCategoryListState();
}

class _PresentCategoryListState extends State<PresentCategoryList> {
  int gValue = 1;
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          child: Text(
            "Select Preset",
            style: customTextStyle(
                fontStyle: FontStyle.HeaderXS_SemiBold,
                color: FontColor.FontPrimary),
          ),
        ),
        Container(
          height: 1,
          color: customColors().backgroundTertiary,
        ),
        PresentItem(
          radioBtn: (value) {
            setState(() {
              gValue = value;
            });
          },
          value: 1,
          category: "Price",
          groupValue: gValue,
        ),
        PresentItem(
          radioBtn: (value) {
            setState(() {
              gValue = value;
            });
          },
          value: 2,
          category: "Open Interest",
          groupValue: gValue,
        ),
        PresentItem(
          radioBtn: (value) {
            setState(() {
              gValue = value;
            });
          },
          value: 3,
          category: "Greeks",
          groupValue: gValue,
        ),
        PresentItem(
          radioBtn: (value) {
            setState(() {
              gValue = value;
            });
          },
          value: 4,
          category: "Custom 1",
          groupValue: gValue,
        ),
      ],
    );
  }
}

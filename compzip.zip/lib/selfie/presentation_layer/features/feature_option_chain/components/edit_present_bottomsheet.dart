import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/option_chain/selected_present_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/option_chain/unselected_present_items.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class EditPresentBottomSheet extends StatefulWidget {
  String title;
  EditPresentBottomSheet({Key? key, required this.title}) : super(key: key);
  @override
  State<EditPresentBottomSheet> createState() => _EditPresentBottomSheetState();
}

class _EditPresentBottomSheetState extends State<EditPresentBottomSheet> {
  List<String> selectedList = ["Ask Size", "Bid Size"];
  List<String> unSelectedList = [
    "Spread",
    "LTP",
    "Open Interest",
    "IV%",
    "Prob ITM %",
    "Change in Open Interest",
    "Delta",
    "Gamma",
    "Theta",
    "Vego"
  ];
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 16, bottom: 16, top: 30),
          child: Text("Edit Preset",
              style: customTextStyle(
                  fontStyle: FontStyle.HeaderXS_Bold,
                  color: FontColor.FontPrimary)),
        ),
        Container(
          color: customColors().backgroundTertiary,
          height: 1,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 16, top: 16),
          child: Text("Preset Name",
              style: customTextStyle(
                  fontStyle: FontStyle.BodyL_Regular,
                  color: FontColor.FontPrimary)),
        ),
        Container(
          width: double.maxFinite,
          margin: const EdgeInsets.all(16),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              border: Border.all(
                  color: customColors().backgroundTertiary, width: 1)),
          child: Text(widget.title,
              style: customTextStyle(
                  fontStyle: FontStyle.BodyL_Regular,
                  color: FontColor.FontPrimary)),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "SELECTED COLUMNS (${selectedList.length} of 6)",
                style: customTextStyle(
                    fontStyle: FontStyle.TagNameL_SemiBold,
                    color: FontColor.FontSecondary),
              ),
              GestureDetector(
                onTap: () {
                  setState(() {
                    unSelectedList.addAll(selectedList);
                    selectedList.clear();
                  });
                },
                child: Text(
                  "Clear",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.Primary),
                ),
              ),
            ],
          ),
        ),
        Container(
          height: 1,
          margin: const EdgeInsets.symmetric(horizontal: 16),
          color: customColors().backgroundTertiary,
        ),
        ListView.builder(
            primary: false,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: selectedList.length,
            itemBuilder: ((context, index) => SelectedPresentItem(
                  selectedMethod: () {
                    setState(() {
                      unSelectedList.add(selectedList.elementAt(index));
                      selectedList.removeAt(index);
                    });
                  },
                  itemName: selectedList[index],
                ))),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          child: Text(
            "AVAILABLE COLUMNS",
            style: customTextStyle(
                fontStyle: FontStyle.TagNameL_SemiBold,
                color: FontColor.FontSecondary),
          ),
        ),
        Container(
          height: 1,
          margin: const EdgeInsets.symmetric(horizontal: 16),
          color: customColors().backgroundTertiary,
        ),
        ListView.builder(
            primary: false,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: unSelectedList.length,
            itemBuilder: ((context, index) => UnSelectedPresentItem(
                  unSelectedMethod: (() {
                    if (selectedList.length < 6) {
                      setState(() {
                        selectedList.add(unSelectedList.elementAt(index));
                        unSelectedList.removeAt(index);
                      });
                    }
                  }),
                  itemName: unSelectedList[index],
                ))),
      ],
    );
  }
}

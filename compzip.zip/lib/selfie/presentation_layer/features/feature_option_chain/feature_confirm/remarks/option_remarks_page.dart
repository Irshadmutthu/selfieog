import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';

import '../../../../../../../theme/styles.dart';

import '../../../../../widgets/custom_app_components/appbar/customAppbarInner.dart';
import '../../../../../widgets/others/message_tile.dart';
import '../../../../../widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';

class OptionRemarkPage extends StatefulWidget {
  OptionRemarkPage({Key? key}) : super(key: key);

  @override
  State<OptionRemarkPage> createState() => _OptionRemarkPageState();
  // bool isgsm;
}

class _OptionRemarkPageState extends State<OptionRemarkPage> {
  bool isgs = false;
  bool rb1 = false, rb2 = false;
  int screenCount = 1;

  bool isOrderPlacingAllowed =
      false; //isOrderPlacingAllowed,isCreditChargingAllowed
  bool isCreditChargingAllowed = false;
  bool isGSM_Allowed = false;

  onOrderPlaceClick(bool val) {
    setState(() {
      isOrderPlacingAllowed = val;
    });
  }

  onCreditChargeClick(bool val) {
    setState(() {
      isCreditChargingAllowed = val;
    });
  }

  onGSMClick(bool val) {
    setState(() {
      isGSM_Allowed = val;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: PreferredSize(
            preferredSize: const Size.fromHeight(0.0),
            child: AppBar(
              elevation: 0,
              backgroundColor: customColors().backgroundPrimary,
            )),
        body: SafeArea(
          child: Stack(
            children: [
              Column(children: [
                CustomAppBarInner(
                    title: "Flip Plug",
                    endIcon: EndIcon.Empty,
                    onBackPressed: () {
                      context.gNavigationService.back(context);
                    }),
                Expanded(
                  // padding: const EdgeInsets.symmetric(horizontal: 0.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Visibility(
                        visible: true,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 16.0),
                              child: Text("Confirm",
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_SemiBold,
                                      color: FontColor.FontPrimary)),
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 11.0, horizontal: 16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Visibility(
                                    visible: !isgs, //!widget.isgsm
                                    child: Row(
                                      children: [
                                        EmptyCustomCheckBox(
                                            callback: onOrderPlaceClick),
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Text(
                                            "Allow exchange to place order on your behalf",
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyM_Regular,
                                                color: FontColor
                                                    .FontPrimary)), //GSM- 1 Category
                                      ],
                                    ),
                                  ),
                                  Visibility(
                                    visible: isgs,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          children: [
                                            EmptyCustomCheckBox(
                                                callback: onGSMClick),
                                            SizedBox(
                                              width: 10,
                                            ),
                                            Text("GSM- 1 Category",
                                                style: customTextStyle(
                                                    fontStyle:
                                                        FontStyle.BodyM_Regular,
                                                    color: FontColor
                                                        .FontPrimary)), //y
                                          ],
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.only(
                                            left: 36,
                                            top: 4,
                                            right: 10,
                                          ),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text("Margin Required - 100%",
                                                  style: customTextStyle(
                                                      fontStyle: FontStyle
                                                          .BodyM_Regular,
                                                      color: FontColor
                                                          .FontSecondary)),
                                              Text(
                                                  "Additional Security Deposite - 100%",
                                                  style: customTextStyle(
                                                      fontStyle: FontStyle
                                                          .BodyM_Regular,
                                                      color: FontColor
                                                          .FontSecondary)),
                                              Text(
                                                  "Additional Security Deposite block for - 3 months",
                                                  style: customTextStyle(
                                                      fontStyle: FontStyle
                                                          .BodyM_Regular,
                                                      color: FontColor
                                                          .FontSecondary)),
                                              Text("T2T Category",
                                                  style: customTextStyle(
                                                      fontStyle: FontStyle
                                                          .BodyM_Regular,
                                                      color: FontColor
                                                          .FontSecondary)),
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                  SizedBox(
                                    height: 12,
                                  ),
                                  Row(
                                    children: [
                                      EmptyCustomCheckBox(
                                          callback: onCreditChargeClick),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                          "Allow exchange to credit your account with charges",
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyM_Regular,
                                              color: FontColor.FontPrimary)),
                                    ],
                                  )
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 8,
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 8.0, horizontal: 16.0),
                              child: Text("Others",
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_SemiBold,
                                      color: FontColor.FontPrimary)),
                            ),
                          ],
                        ),
                      ),
                      Visibility(
                        visible: true,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16.0, vertical: 16),
                          child: Container(
                            padding: EdgeInsets.symmetric(horizontal: 16.0),
                            decoration: BoxDecoration(
                              border: Border(
                                left: BorderSide(
                                    color: customColors().peachBackgrond,
                                    width: 2),
                              ),
                            ),
                            child: Text(
                                "TATAPOWER (BSE) is a trade to trade category stock. You will be able to sell the stocks bought today only after the stocks are settled in your demat account (T+2 days).",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_Regular,
                                    color: FontColor.FontPrimary)),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 8,
                      ),
                      Visibility(
                        visible: true,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16.0, vertical: 16),
                          child: Row(
                            children: [
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 16.0),
                                decoration: BoxDecoration(
                                    border: Border(
                                  left: BorderSide(
                                      color: customColors().peachBackgrond,
                                      width: 2),
                                )),
                                child: Text(
                                    "TATAPOWER (BSE) is a trade to trade category stock.",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_Regular,
                                        color: FontColor.FontPrimary)),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 8,
                      ),
                      Visibility(
                        visible: true,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16.0, vertical: 16),
                          child: Container(
                            padding: EdgeInsets.symmetric(horizontal: 16.0),
                            decoration: BoxDecoration(
                              border: Border(
                                left: BorderSide(
                                    color: customColors().peachBackgrond,
                                    width: 2),
                              ),
                            ),
                            child: Text(
                                "TATAPOWER (BSE) is a trade to trade category stock. You will be able to sell the stocks bought today only after the stocks are settled in your demat account (T+2 days).",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_Regular,
                                    color: FontColor.FontPrimary)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                      border: Border(
                          top: BorderSide(
                              color: isCreditChargingAllowed &&
                                      isOrderPlacingAllowed
                                  ? customColors().backgroundTertiary
                                  : customColors()
                                      .backgroundTertiary
                                      .withOpacity(.4)))),
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Container(
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Expanded(
                            child: BasketButton(
                              textStyle: isCreditChargingAllowed &&
                                      isOrderPlacingAllowed
                                  ? customTextStyle(
                                      fontStyle: FontStyle.BodyL_Bold,
                                      color: FontColor.Primary)
                                  : customTextStyle(
                                          fontStyle: FontStyle.BodyL_Bold)
                                      .copyWith(
                                          color: customColors()
                                              .primary
                                              .withOpacity(0.4)),
                              bgcolor: isCreditChargingAllowed &&
                                      isOrderPlacingAllowed
                                  ? customColors().backgroundPrimary
                                  : customColors()
                                      .backgroundPrimary
                                      .withOpacity(.4),
                              bordercolor: isCreditChargingAllowed &&
                                      isOrderPlacingAllowed
                                  ? customColors().primary
                                  : customColors().primary.withOpacity(.4),
                              text: "Edit",
                            ),
                          ),
                          SizedBox(
                            width: 8,
                          ),
                          Expanded(
                            child: BasketButton(
                              textStyle: customTextStyle(
                                  fontStyle: FontStyle.BodyL_Bold,
                                  color: FontColor.White),
                              bgcolor: isCreditChargingAllowed &&
                                      isOrderPlacingAllowed
                                  ? customColors().primary
                                  : customColors().primary.withOpacity(.4),
                              bordercolor: isCreditChargingAllowed &&
                                      isOrderPlacingAllowed
                                  ? customColors().primary
                                  : customColors().primary.withOpacity(.4),
                              text: "Send",
                            ),
                          ),
                        ]),
                  ),
                )
              ]),
              // Align(
              //   alignment: Alignment.bottomCenter,
              //   child: skipButton(context, "$screenCount/2", () {
              //     if (screenCount > 1) {
              //       setState(() {
              //         screenCount--;
              //         isgs = false;
              //       });
              //     }
              //   }, () {
              //     if (screenCount < 2) {
              //       setState(() {
              //         screenCount++;
              //         isgs = true;
              //       });
              //     }
              //   }),
              // ),
            ],
          ),
        ));
  }
}

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/custom_bottom_strip.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

import '../../../../../../../theme/styles.dart';
import '../../../../widgets/custom_app_components/appbar/customAppbarInner.dart';
import '../../../../widgets/custom_app_components/buttons/BasketButton.dart';
import '../../../../widgets/custom_app_components/buttons/custom_swipe_button.dart';
import '../../../../widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';

class OCConfirmOrderPage extends StatefulWidget {
  const OCConfirmOrderPage({Key? key}) : super(key: key);

  @override
  State<OCConfirmOrderPage> createState() => _OCConfirmPageState();
}

class _OCConfirmPageState extends State<OCConfirmOrderPage> {
  bool rdb1 = false;
  bool rdb2 = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: PreferredSize(
            preferredSize: const Size.fromHeight(0.0),
            child: AppBar(
              elevation: 0,
              backgroundColor: customColors().backgroundPrimary,
            )),
        body: SafeArea(
          child: Column(children: [
            CustomAppBarInner(
                title: "Order Confirmation",
                endIcon: EndIcon.Empty,
                onBackPressed: () {
                  context.gNavigationService.back(context);
                }),
            Expanded(
                child: Container(
                    child: SingleChildScrollView(
                        child: Column(children: [
              Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: EdgeInsets.symmetric(vertical: 8),
                          child: Container(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.only(
                                              left: 7.0,
                                              right: 7.0,
                                              top: 2.0,
                                              bottom: 3.0),
                                          decoration: BoxDecoration(
                                            color: getbackcolor("SELL"),
                                            borderRadius:
                                                const BorderRadius.all(
                                                    Radius.circular(2)),
                                          ),
                                          child: Center(
                                              child: Text(
                                            "SELL",
                                            textAlign: TextAlign.start,
                                            style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.TagNameS_SemiBold,
                                              color: getfontcolor("SELL"),
                                            ),
                                          )),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Container(
                                          padding: const EdgeInsets.only(
                                              left: 7.0,
                                              right: 7.0,
                                              top: 2.0,
                                              bottom: 3.0),
                                          decoration: BoxDecoration(
                                            color: getbackcolor("CASH"),
                                            borderRadius:
                                                const BorderRadius.all(
                                                    Radius.circular(2)),
                                          ),
                                          child: Center(
                                              child: Text(
                                            "CASH",
                                            textAlign: TextAlign.start,
                                            style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.TagNameS_SemiBold,
                                              color: getfontcolor("CASH"),
                                            ),
                                          )),
                                        )
                                      ],
                                    ),
                                    SizedBox(
                                      height: 8,
                                    ),
                                    Text(
                                      '12 JAN 89.65 PE ',
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyL_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          "LIMIT",
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyM_Regular,
                                              color: FontColor.FontSecondary),
                                        ),
                                        SizedBox(
                                          width: 4,
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 4,
                                    ),
                                    Text(
                                      "0.1575",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          "LOTS",
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.TagNameS_SemiBold,
                                              color: FontColor.FontSecondary),
                                        ),
                                        SizedBox(
                                          width: 4,
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 8,
                                    ),
                                    Text(
                                      "1",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                  ],
                                )
                              ],
                            ),
                          ),
                        ),
                        SizedBox(height: 8),
                        Container(
                          padding: EdgeInsets.symmetric(vertical: 8),
                          child: Container(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.only(
                                              left: 7.0,
                                              right: 7.0,
                                              top: 2.0,
                                              bottom: 3.0),
                                          decoration: BoxDecoration(
                                            color: getbackcolor("BUY"),
                                            borderRadius:
                                                const BorderRadius.all(
                                                    Radius.circular(2)),
                                          ),
                                          child: Center(
                                              child: Text(
                                            "BUY",
                                            textAlign: TextAlign.start,
                                            style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.TagNameS_SemiBold,
                                              color: getfontcolor("BUY"),
                                            ),
                                          )),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Container(
                                          padding: const EdgeInsets.only(
                                              left: 7.0,
                                              right: 7.0,
                                              top: 2.0,
                                              bottom: 3.0),
                                          decoration: BoxDecoration(
                                            color: getbackcolor("INTRADAY"),
                                            borderRadius:
                                                const BorderRadius.all(
                                                    Radius.circular(2)),
                                          ),
                                          child: Center(
                                              child: Text(
                                            "INTRADAY",
                                            textAlign: TextAlign.start,
                                            style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.TagNameS_SemiBold,
                                              color: getfontcolor("INTRADAY"),
                                            ),
                                          )),
                                        )
                                      ],
                                    ),
                                    SizedBox(
                                      height: 8,
                                    ),
                                    Text(
                                      '12 JAN 123.65 PE ',
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyL_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          "LIMIT",
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyM_Regular,
                                              color: FontColor.FontSecondary),
                                        ),
                                        SizedBox(
                                          width: 4,
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 4,
                                    ),
                                    Text(
                                      "-",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          "LOTS",
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.TagNameS_SemiBold,
                                              color: FontColor.FontSecondary),
                                        ),
                                        SizedBox(
                                          width: 4,
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 8,
                                    ),
                                    Text(
                                      "2",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                  ],
                                )
                              ],
                            ),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(vertical: 8),
                          child: Container(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.only(
                                              left: 7.0,
                                              right: 7.0,
                                              top: 2.0,
                                              bottom: 3.0),
                                          decoration: BoxDecoration(
                                            color: getbackcolor("SELL"),
                                            borderRadius:
                                                const BorderRadius.all(
                                                    Radius.circular(2)),
                                          ),
                                          child: Center(
                                              child: Text(
                                            "SELL",
                                            textAlign: TextAlign.start,
                                            style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.TagNameS_SemiBold,
                                              color: getfontcolor("SELL"),
                                            ),
                                          )),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Container(
                                          padding: const EdgeInsets.only(
                                              left: 7.0,
                                              right: 7.0,
                                              top: 2.0,
                                              bottom: 3.0),
                                          decoration: BoxDecoration(
                                            color: getbackcolor("INTRADAY"),
                                            borderRadius:
                                                const BorderRadius.all(
                                                    Radius.circular(2)),
                                          ),
                                          child: Center(
                                              child: Text(
                                            "INTRADAY",
                                            textAlign: TextAlign.start,
                                            style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.TagNameS_SemiBold,
                                              color: getfontcolor("INTRADAY"),
                                            ),
                                          )),
                                        )
                                      ],
                                    ),
                                    SizedBox(
                                      height: 8,
                                    ),
                                    Text(
                                      '12 JAN 89.00 PE ',
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyL_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          "LIMIT",
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyM_Regular,
                                              color: FontColor.FontSecondary),
                                        ),
                                        SizedBox(
                                          width: 4,
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 4,
                                    ),
                                    Text(
                                      "0.86",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          "LOTS",
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.TagNameS_SemiBold,
                                              color: FontColor.FontSecondary),
                                        ),
                                        SizedBox(
                                          width: 4,
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 8,
                                    ),
                                    Text(
                                      "3",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                  ],
                                )
                              ],
                            ),
                          ),
                        ),
                        SizedBox(height: 8),
                        Container(
                          padding: EdgeInsets.symmetric(vertical: 8),
                          child: Container(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Container(
                                          padding: const EdgeInsets.only(
                                              left: 7.0,
                                              right: 7.0,
                                              top: 2.0,
                                              bottom: 3.0),
                                          decoration: BoxDecoration(
                                            color: getbackcolor("BUY"),
                                            borderRadius:
                                                const BorderRadius.all(
                                                    Radius.circular(2)),
                                          ),
                                          child: Center(
                                              child: Text(
                                            "BUY",
                                            textAlign: TextAlign.start,
                                            style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.TagNameS_SemiBold,
                                              color: getfontcolor("BUY"),
                                            ),
                                          )),
                                        ),
                                        SizedBox(
                                          width: 6,
                                        ),
                                        Container(
                                          padding: const EdgeInsets.only(
                                              left: 7.0,
                                              right: 7.0,
                                              top: 2.0,
                                              bottom: 3.0),
                                          decoration: BoxDecoration(
                                            color: getbackcolor("CASH"),
                                            borderRadius:
                                                const BorderRadius.all(
                                                    Radius.circular(2)),
                                          ),
                                          child: Center(
                                              child: Text(
                                            "CASH",
                                            textAlign: TextAlign.start,
                                            style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.TagNameS_SemiBold,
                                              color: getfontcolor("CASH"),
                                            ),
                                          )),
                                        )
                                      ],
                                    ),
                                    SizedBox(
                                      height: 8,
                                    ),
                                    Text(
                                      '12 JAN 123.00 PE ',
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyL_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          "LIMIT",
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyM_Regular,
                                              color: FontColor.FontSecondary),
                                        ),
                                        SizedBox(
                                          width: 4,
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 4,
                                    ),
                                    Text(
                                      "0.645",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          "LOTS",
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.TagNameS_SemiBold,
                                              color: FontColor.FontSecondary),
                                        ),
                                        SizedBox(
                                          width: 4,
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 8,
                                    ),
                                    Text(
                                      "1",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                  ],
                                )
                              ],
                            ),
                          ),
                        ),
                      ])),
              SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 16, horizontal: 16.0),
                      child: InkWell(
                        onTap: () {
                          context.gNavigationService
                              .openOptionRemarkPage(context); //OpenConfirmPage
                        },
                        child: Text(
                          "Remarks",
                          style: customTextStyle(
                              fontStyle: FontStyle.HeaderXS_Bold,
                              color: FontColor.FontPrimary),
                        ),
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16.0),
                          child: Text("Needs Attention",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary)),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 11.0, horizontal: 16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  EmptyCustomCheckBox(
                                      callback: ((bool checked) {
                                    setState(() {
                                      rdb1 = checked;
                                    });
                                  })),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                      "Allow exchange to place order on your behalf",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_Regular,
                                          color: FontColor.FontPrimary)),
                                ],
                              ),
                              SizedBox(
                                height: 16,
                              ),
                              Row(
                                children: [
                                  EmptyCustomCheckBox(callback: (bool checked) {
                                    setState(() {
                                      rdb2 = checked;
                                    });
                                  }),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                      "Allow exchange to credit your account with charges",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_Regular,
                                          color: FontColor.FontPrimary)),
                                ],
                              )
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 8,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 8.0, horizontal: 16.0),
                          child: Text("Others",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary)),
                        ),
                      ],
                    ),
                    Visibility(
                      visible: true,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Container(
                          padding: EdgeInsets.only(right: 20),
                          child: Text(
                              "TATAPOWER (BSE) is a trade to trade category stock. You will be able to sell the stocks bought today only after the stocks are settled in your demat account (T+2 days).",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_Regular,
                                  color: FontColor.FontPrimary)),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ])))),
            Container(
              decoration: BoxDecoration(
                  border: Border(
                      top: BorderSide(
                          color: rdb1 && rdb2
                              ? customColors().backgroundTertiary
                              : customColors()
                                  .backgroundTertiary
                                  .withOpacity(.4)))),
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Container(
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Expanded(
                        child: BasketButton(
                          textStyle: rdb1 && rdb2
                              ? customTextStyle(
                                  fontStyle: FontStyle.BodyL_Bold,
                                  color: FontColor.Primary)
                              : customTextStyle(fontStyle: FontStyle.BodyL_Bold)
                                  .copyWith(
                                      color: customColors()
                                          .primary
                                          .withOpacity(0.4)),
                          bgcolor: rdb1 && rdb2
                              ? customColors().backgroundPrimary
                              : customColors()
                                  .backgroundPrimary
                                  .withOpacity(.4),
                          bordercolor: rdb1 && rdb2
                              ? customColors().primary
                              : customColors().primary.withOpacity(.4),
                          text: "Edit",
                        ),
                      ),
                      SizedBox(
                        width: 8,
                      ),
                      Expanded(
                        child: BasketButton(
                          textStyle: customTextStyle(
                              fontStyle: FontStyle.BodyL_Bold,
                              color: FontColor.White),
                          bgcolor: rdb1 && rdb2
                              ? customColors().primary
                              : customColors().primary.withOpacity(.4),
                          bordercolor: rdb1 && rdb2
                              ? customColors().primary
                              : customColors().primary.withOpacity(.4),
                          text: "Send",
                        ),
                      ),
                    ]),
              ),
            )
          ]),
        ));
  }

  getfontcolor(String status) {
    switch (status) {
      case "NSE":
        return FontColor.Crisps;
      case "SELL":
        return FontColor.Danger;
      case "BUY":
        return FontColor.Success;
      case "NSEFO":
        return FontColor.Purple;
      case "CASH":
        return FontColor.DodgerBlue;
      case "INTRADAY":
        return FontColor.PacificBlue;
      default:
    }
  }

  getbackcolor(String status) {
    switch (status) {
      case "NSE":
        return customColors().crisps.withOpacity(0.15);
      case "SELL":
        return customColors().danger.withOpacity(0.15);
      case "BUY":
        return customColors().success.withOpacity(0.15);
      case "NSEFO":
        return customColors().mattPurple.withOpacity(0.15);
      case "CASH":
        return customColors().dodgerBlue.withOpacity(0.15);
      case "INTRADAY":
        return customColors().pacificBlue.withOpacity(0.15);
      default:
    }
  }
}

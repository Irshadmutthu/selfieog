import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'order_winodw_state.dart';

class OrderWinodwCubit extends Cubit<OrderWinodwState> {
  OrderWinodwCubit() : super(OrderWinodwInitial());
}

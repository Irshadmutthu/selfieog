part of 'order_winodw_cubit.dart';

@immutable
abstract class OrderWinodwState {}

class OrderWinodwInitial extends OrderWinodwState {}

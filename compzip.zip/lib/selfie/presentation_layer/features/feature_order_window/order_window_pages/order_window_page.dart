import 'dart:async';

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/order_model/Order.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_bo_component.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_buysell_component.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_product_type.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_tab_component.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_time_condition.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_title_component.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/default_order_settings_values.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/custom_bottom_strip.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:trading_api/utils/utils.dart';
import 'package:intl/intl.dart';
import '../../../../../mds_controller.dart/mds_controller.dart';
import '../../../../widgets/custom_app_components/textfields/custom_text_form_field.dart';

enum Segment {
  CASH,
  FO,
  SPREAD,
}

class OrderWindowPage extends StatefulWidget {
  // final Map<String, dynamic> data;
  final OrderModel order;
  const OrderWindowPage({Key? key, required this.order}) : super(key: key);

  @override
  State<OrderWindowPage> createState() => _OrderWindowPageState();
}

class _OrderWindowPageState extends State<OrderWindowPage> {
  bool isBuy = true;
  bool noVenueSelected = false;
  bool hasVenueSelection = false;
  bool BO_order = false;
  bool stopLoss = false;
  StreamSubscription? subscription;
  Segment orderType = Segment.SPREAD;
  double BSP = 278.95;
  double BBP = 278.95;
  late Instrument selectedInstrument, nseInstrument, bseInstrument;
  double NSE_price = 278.95;
  double BSE_price = 278.92;

  int _productType = product;
  int _timeCondition = timeCondition;
  int _condition = condition;
  int _pageCount = 1;
  int _quantity = 0;
  int _exchange = -1;
  late List<Instrument> feedList; //list that binds to ui listview
  Map<String, Instrument> feedMap = {}; //map to update feed
  String title = "TATAPOWER";
  TextEditingController priceController = TextEditingController();
  TextEditingController triggerPriceController = TextEditingController();
  TextEditingController quantityController = TextEditingController();
  TextEditingController dateField = TextEditingController();
  TextEditingController txtDisclosedQty = TextEditingController();

  @override
  void initState() {
    super.initState();
    setState(() {
      selectedInstrument = widget.order.instrument;
      orderType = selectedInstrument.isFao()
          ? Segment.FO
          : selectedInstrument.isEquity()
              ? Segment.CASH
              : orderType;
      isBuy = widget.order.buyOrSell == BUY;
      switch (orderType) {
        case Segment.CASH:
          _exchange = widget.order.orderSettings.stockExchange;
          _condition = widget.order.orderSettings.stocksType;
          _productType = widget.order.orderSettings.stocksProductType;
          break;
        case Segment.FO:
          _condition = widget.order.orderSettings.futureType;
          _productType = widget.order.orderSettings.futureProductType;
          break;
        case Segment.SPREAD:
          break;
        default:
      }
      if (widget.order.productType > 0) {
        _productType = getProductListIndex(
            getProductDisplayType(widget.order.productType),
            selectedInstrument.venueIndex);
      }
      if (widget.order.tifDate.isNotEmpty) {
        dateField.text =
            dateConversion(widget.order.tifDate, "dd/MMM/yyyy", "dd/MM/yyyy");
      }
      if (selectedInstrument.otherScripCode.isNotEmpty &&
          !widget.order.isModify) {
        hasVenueSelection = true;
        noVenueSelected = true;
        int venueindx = selectedInstrument.venueIndex == 1 ? 2 : 1;
        if (venueindx == 2) {
          bseInstrument = Instrument(
              scripcode: selectedInstrument.otherScripCode,
              securityCode: selectedInstrument.securityCode,
              securityName: selectedInstrument.securityName,
              series: selectedInstrument.otherSeries,
              type: selectedInstrument.type,
              venueIndex: venueindx);
          bseInstrument.ticksize = selectedInstrument.ticksize!;
          nseInstrument = widget.order.instrument;
        } else {
          nseInstrument = Instrument(
              scripcode: selectedInstrument.otherScripCode,
              securityCode: selectedInstrument.securityCode,
              securityName: selectedInstrument.securityName,
              series: selectedInstrument.otherSeries,
              type: selectedInstrument.type,
              venueIndex: venueindx);
          nseInstrument.ticksize = selectedInstrument.ticksize!;
          bseInstrument = widget.order.instrument;
        }
        if (_exchange == 1) {
          selectedInstrument = nseInstrument;
        } else if (_exchange == 2) {
          selectedInstrument = bseInstrument;
        }
        if (PRODUCT_TYPES_DISPLAY[selectedInstrument.venueIndex]!.length <=
            _productType) {
          _productType = 0;
        }
      }
      if (widget.order.squareOff) {
        quantityController.text = widget.order.qty.abs().toString();
      }
      if (widget.order.isModify || widget.order.isReorder) {
        _productType = getProductListIndex(
            getProductDisplayType(widget.order.productType),
            selectedInstrument.venueIndex);
        _timeCondition =
            timeconditionDispkaylistindex(widget.order.timeCondition);
        _condition = getPriceCondition(widget.order.priceCondition) - 1;
        if ((_condition == 2 || _condition == 3)) {
          triggerPriceController.text = double.parse(widget.order.triggerPrice)
              .toStringAsFixed(selectedInstrument.precision);
        }
        if (!(_condition == 0 || _condition == 3) && !widget.order.isReorder) {
          priceController.text = double.parse(widget.order.price)
              .toStringAsFixed(selectedInstrument.precision);
        }
        if (orderType == Segment.FO) {
          quantityController.text =
              (widget.order.qty.abs() ~/ selectedInstrument.lotsize!)
                  .toString();
          _quantity = widget.order.qty.abs();
        } else {
          quantityController.text = widget.order.qty.abs().toString();
        }

        // _timeCondition = widget.order.timeCondition;
      }
    });
    quantityController.addListener(() {
      setState(() {
        if (quantityController.text.isNotEmpty) {
          _quantity =
              int.parse(quantityController.text) * selectedInstrument.lotsize!;
        } else {
          _quantity = 0;
        }
      });
    });
    // priceController.addListener(() {
    //   setState(() {
    //     if (priceController.text.isNotEmpty) {

    //     }
    //   });
    // });
    // triggerPriceController.addListener(() {
    //   setState(() {

    //   });
    // });
    if (noVenueSelected) {
      MDS_Controller().subscribeSymbols([nseInstrument, bseInstrument]);
      feedMap[nseInstrument.getRicAddress()] = nseInstrument;
      feedMap[bseInstrument.getRicAddress()] = bseInstrument;
    } else {
      MDS_Controller().subscribeSymbols([selectedInstrument]);
      feedMap[selectedInstrument.getRicAddress()] = selectedInstrument;
    }
    initializeSubscriptionListner();
  }

  @override
  void dispose() {
    if (subscription != null) subscription!.cancel();
    if (noVenueSelected) {
      MDS_Controller().unsubscribeSymbols([nseInstrument, bseInstrument]);
    } else {
      MDS_Controller().unsubscribeSymbols([selectedInstrument]);
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: SafeArea(
        bottom: true,
        child: GestureDetector(
          onTap: (() {
            FocusManager.instance.primaryFocus?.unfocus();
          }),
          child: Column(
            children: [
              CustomAppBarInner(
                  title: widget.order.instrument.displayName ??
                      widget.order.instrument.securityCode,
                  extraWidget:
                      widget.order.instrument.otherScripCode.isNotEmpty &&
                              !widget.order.isModify
                          ? OrderWindowTitleComponent(
                              groupValue: _exchange,
                              NSE_price: nseInstrument.lastTrdPrice
                                  .toStringAsFixed(nseInstrument.precision),
                              BSE_price: bseInstrument.lastTrdPrice
                                  .toStringAsFixed(bseInstrument.precision),
                              onChanged: (String value) {
                                setState(() {
                                  if (value == "NSE") {
                                    // BSP = nseInstrument.bestSellPrice;
                                    // BBP = nseInstrument.bestBuyPrice;
                                    selectedInstrument = nseInstrument;
                                    _exchange = 1;
                                  } else {
                                    // BSP = bseInstrument.bestSellPrice;
                                    // BBP = bseInstrument.bestBuyPrice;
                                    selectedInstrument = bseInstrument;
                                    _exchange = 2;
                                  }
                                  if (PRODUCT_TYPES_DISPLAY[
                                              selectedInstrument.venueIndex]!
                                          .length <=
                                      _productType) {
                                    _productType = 0;
                                  }
                                  if (priceController.text.isEmpty &&
                                      !(_condition == 0 || _condition == 3)) {
                                    if (isBuy) {
                                      priceController.text = selectedInstrument
                                          .bestSellPrice
                                          .toStringAsFixed(
                                              selectedInstrument.precision);
                                    } else {
                                      priceController.text = selectedInstrument
                                          .bestBuyPrice
                                          .toStringAsFixed(
                                              selectedInstrument.precision);
                                    }
                                  }
                                });
                                noVenueSelected = false;
                              },
                            )
                          : RichText(
                              text: TextSpan(
                                  text: "₹ ",
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_SemiBold,
                                      color: FontColor.FontSecondary),
                                  children: <TextSpan>[
                                    TextSpan(
                                        text: selectedInstrument.lastTrdPrice
                                            .toString(),
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyM_SemiBold,
                                            color: FontColor.FontSecondary))
                                  ]),
                            ),
                  endIcon: EndIcon.Settings,
                  onEndIconPressed: () {
                    context.gNavigationService
                        .openDefaultOrderSettingsPage(context);
                  },
                  onBackPressed: () {
                    context.gNavigationService.back(context);
                  }),
              Expanded(
                child: Stack(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: Column(
                        children: [
                          const SizedBox(
                            height: 17,
                          ),
                          OrderWindowBuySellSwitch(
                              fixed: selectedInstrument.precision,
                              isBuy: isBuy,
                              BSP: selectedInstrument.bestSellPrice
                                  .toStringAsFixed(
                                      selectedInstrument.precision),
                              BBP: selectedInstrument.bestBuyPrice
                                  .toStringAsFixed(
                                      selectedInstrument.precision),
                              onChanged: (bool value) {
                                setState(() {
                                  isBuy = value;
                                });
                                widget.order.buyOrSell = value ? 1 : 2;
                              }),
                          Expanded(
                            child: SingleChildScrollView(
                              child: Column(
                                children: [
                                  if (orderType == Segment.SPREAD)
                                    const Padding(
                                        padding: EdgeInsets.only(top: 6.0),
                                        child: SpreadData(spreadData: {
                                          "title": "INFY 22JAN FUT",
                                          "buy": 222.12,
                                          "sell": 123.12,
                                        })),
                                  const SizedBox(
                                    height: 24,
                                  ),
                                  if (orderType == Segment.FO)
                                    OrderWindowTabContainer(
                                        orderType: OrderTypes.FO,
                                        lotsQuantity: _quantity.toString(),
                                        orderTabIndex: _condition,
                                        triggerPriceController:
                                            triggerPriceController,
                                        priceController: priceController,
                                        quantityController: quantityController,
                                        onPriceConditionUpdate: (int val) {
                                          _condition = val;
                                          setState(() {
                                            if (val == 0 || val == 3) {
                                              priceController =
                                                  TextEditingController();
                                            }
                                          });
                                        }),
                                  if (orderType != Segment.FO)
                                    OrderWindowTabContainer(
                                      triggerPriceController:
                                          triggerPriceController,
                                      priceController: priceController,
                                      orderTabIndex: _condition,
                                      quantityController: quantityController,
                                      onPriceConditionUpdate: (int val) {
                                        _condition = val;
                                        if (val == 0 || val == 3) {
                                          setState(() {
                                            priceController =
                                                TextEditingController();
                                          });
                                        }
                                      },
                                    ),
                                  const SizedBox(
                                    height: 16,
                                  ),
                                  if (orderType != Segment.SPREAD)
                                    Column(
                                      children: [
                                        OrderWindowBOComponent(
                                          isBuy: isBuy,
                                          BO_Order: BO_order,
                                          stopLoss: stopLoss,
                                          onTapBO: () {
                                            setState(() {
                                              BO_order = !BO_order;
                                            });
                                          },
                                          onTapStoploss: () {
                                            setState(() {
                                              stopLoss = !stopLoss;
                                            });
                                          },
                                        ),
                                        const SizedBox(
                                          height: 16,
                                        ),
                                      ],
                                    ),
                                  OrderWindowProduct(
                                    selected: _productType,
                                    venueIndex: selectedInstrument.venueIndex,
                                    onProductUpdate: (int product) {
                                      setState(() {
                                        if (product > _productType &&
                                            product > 1) {
                                          _timeCondition = 0;
                                        }
                                        _productType = product;
                                      });
                                    },
                                  ),
                                  const SizedBox(
                                    height: 16,
                                  ),
                                  OrderWindowTimeCondition(
                                    isfo: widget.order.instrument.isFao(),
                                    timeCondition: _timeCondition,
                                    isoco: false,
                                    withGtd: _productType < 2 &&
                                        selectedInstrument.venueIndex != 7,
                                    condition: _condition,
                                    onTimeConditionChange: (int val) {
                                      timeCondition = val;
                                      setState(() {
                                        _timeCondition = val;
                                      });
                                    },
                                    onConditionChange: (int val) {
                                      condition = val;
                                      setState(() {
                                        _condition = val;
                                      });
                                    },
                                    dateField: dateField,
                                  ),
                                  const SizedBox(
                                    height: 16,
                                  ),
                                  CustomTextFormField(
                                    controller: txtDisclosedQty,
                                    fieldName: "Disclosed Quantity",
                                    hintText: " 0",
                                  ),
                                  const SizedBox(
                                    height: 16,
                                  ),
                                  if (orderType == Segment.FO)
                                    Column(
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Row(
                                              children: [
                                                Text(
                                                  "Allow split orders",
                                                  style: customTextStyle(
                                                      fontStyle: FontStyle
                                                          .BodyL_Regular,
                                                      color: FontColor
                                                          .FontPrimary),
                                                ),
                                                const SizedBox(
                                                  width: 7.33,
                                                ),
                                                Image.asset(
                                                  "assets/info.png",
                                                  color: customColors()
                                                      .fontPrimary,
                                                  height: 13.33,
                                                  width: 13.33,
                                                )
                                              ],
                                            ),
                                            EmptyCustomCheckBox(
                                              callback: (bool) {},
                                            )
                                          ],
                                        ),
                                        const SizedBox(
                                          height: 16,
                                        ),
                                      ],
                                    ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    // Align(
                    //     alignment: Alignment.bottomCenter,
                    //     child: skipButton(context, "${_pageCount}/3", () {
                    //       int count = _pageCount - 1;
                    //       if (count >= 1) {
                    //         setState(() {
                    //           orderType = count == 1
                    //               ? Segment.CASH
                    //               : count == 2
                    //                   ? Segment.FO
                    //                   : Segment.SPREAD;
                    //           _pageCount = count;
                    //           _pageCount == 1
                    //               ? title = "TATAPOWER"
                    //               : _pageCount == 2
                    //                   ? title = "AMBUJACEMENT FUT"
                    //                   : title = "INFY 22DEC - INFY 22JAN FUT";
                    //         });
                    //       }
                    //     }, () {
                    //       int count = _pageCount + 1;
                    //       if (count <= 3) {
                    //         setState(() {
                    //           orderType = count == 1
                    //               ? Segment.CASH
                    //               : count == 2
                    //                   ? Segment.FO
                    //                   : Segment.SPREAD;
                    //           _pageCount = count;
                    //           _pageCount == 1
                    //               ? title = "TATAPOWER"
                    //               : _pageCount == 2
                    //                   ? title = "AMBUJACEMENT FUT"
                    //                   : title = "INFY 22DEC - INFY 22JAN FUT";
                    //         });
                    //       }
                    //     })),
                  ],
                ),
              ),
              // const CustomBottomStrip(
              //   fundOrMargin: FundOrMargin.MARGIN,
              //   required: "15,000",
              //   available: "21,000",
              //   refreshIcon: true,
              // ),
              Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  child: BasketButton(
                    textStyle: customTextStyle(
                        fontStyle: FontStyle.BodyL_SemiBold,
                        color: FontColor.White),
                    text: "Send order",
                    bgcolor:
                        isBuy ? customColors().success : customColors().danger,
                    onpress: () {
                      if (!validateOrder()) {
                        return;
                      }
                      widget.order.instrument = selectedInstrument;
                      widget.order.priceCondition = selectedInstrument
                          .getPriceConditionAsString(_condition + 1);
                      widget.order.price =
                          priceController.text.toString().isEmpty
                              ? "0"
                              : priceController.text.toString();
                      widget.order.triggerPrice =
                          triggerPriceController.text.toString();
                      widget.order.timeCondition =
                          timeconditionsettingslist[_timeCondition]["name"];
                      widget.order.tifDate = widget.order.timeCondition == "GTD"
                          ? dateField.text.toString()
                          : "";
                      if (widget.order.isModify) {
                        if (orderType == Segment.FO) {
                          widget.order.qtyChange = _quantity - widget.order.qty;
                        } else {
                          widget.order.qtyChange =
                              int.parse(quantityController.text.toString()) -
                                  widget.order.qty;
                        }
                      }
                      if (orderType == Segment.FO) {
                        widget.order.qty = _quantity;
                        widget.order.lots =
                            int.parse(quantityController.text.toString());
                      } else {
                        widget.order.qty =
                            int.parse(quantityController.text.toString());
                      }

                      widget.order.productType = _productType;
                      widget.order.segment = getSegmentInt(orderType);
                      context.gNavigationService
                          .openReviewOrder(context, {"order": widget.order});
                    },
                  )),
            ],
          ),
        ),
      ),
    );
  }

  bool validateOrder() {
    if (noVenueSelected) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("Please select an exchange."),
      ));
      return false;
    }
    if (!(_condition == 0 || _condition == 3)) {
      if (priceController.text.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text("Enter Price."),
        ));
        return false;
      }
    }
    if (quantityController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("Enter Quantity."),
      ));
      return false;
    }
    if (double.parse(quantityController.text.toString()) < 1) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("Enter a valid Quantity."),
      ));
      return false;
    }
    if (timeconditionsettingslist[_timeCondition]["name"] == "GTD") {
      if (dateField.text.toString().isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text("Please enter Good Till Date"),
        ));
        return false;
      }
    }
    if (!(_condition == 0 || _condition == 3)) {
      if (!validateticksize(double.parse(priceController.text.toString()),
          selectedInstrument.ticksize!)) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text("Price should be multiple of " +
              selectedInstrument.ticksize.toString() +
              " ."),
        ));
        return false;
      }
    }
    if (_condition == 2 || _condition == 3) {
      if (!validateticksize(
          double.parse(triggerPriceController.text.toString()),
          selectedInstrument.ticksize!)) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text("Trigger Price should be multiple of " +
              selectedInstrument.ticksize.toString() +
              " ."),
        ));
        return false;
      }
    }
    return true;
  }

  int getSegmentInt(Segment segment) {
    switch (segment) {
      case Segment.CASH:
        return 1;

      case Segment.FO:
        return 2;
      case Segment.SPREAD:
        return 3;
      default:
    }
    return 0;
  }

  void initializeSubscriptionListner() {
    subscription = MDS_Controller()
        .marketUpdateStream
        .listen((List<FlairResponseModel> flairResponseModel) {
      for (var element in flairResponseModel) {
        if (feedMap.containsKey(element.ric)) {
          feedMap[element.ric] = element.instrument;
          setState(() {
            if (hasVenueSelection) {
              if (element.instrument.venuecode == "NSE") {
                nseInstrument.lastTrdPrice = element.instrument.lastTrdPrice;
                nseInstrument.bestBuyPrice = element.instrument.bestBuyPrice;
                nseInstrument.bestSellPrice = element.instrument.bestSellPrice;
              } else {
                bseInstrument.lastTrdPrice = element.instrument.lastTrdPrice;
                bseInstrument.bestBuyPrice = element.instrument.bestBuyPrice;
                bseInstrument.bestSellPrice = element.instrument.bestSellPrice;
              }
            } else {
              selectedInstrument.lastTrdPrice = element.instrument.lastTrdPrice;
              selectedInstrument.bestBuyPrice = element.instrument.bestBuyPrice;
              selectedInstrument.bestSellPrice =
                  element.instrument.bestSellPrice;
            }
          });
          if (!noVenueSelected) {
            if (priceController.text.isEmpty &&
                !(_condition == 0 || _condition == 3)) {
              if (isBuy) {
                priceController.text = selectedInstrument.bestSellPrice
                    .toStringAsFixed(selectedInstrument.precision);
              } else {
                priceController.text = selectedInstrument.bestBuyPrice
                    .toStringAsFixed(selectedInstrument.precision);
              }
            }
          }
        }
      }
    });
  }
}

String dateConversion(String input, String inputFormate, String outputFormate) {
  input = input.split("/")[0] +
      "/" +
      input.split("/")[1].substring(0, 1) +
      input.split("/")[1].substring(1).toLowerCase() +
      "/" +
      input.split("/")[2];
  DateTime parseDate = DateFormat(inputFormate).parse(input);
  var inputDate = DateTime.parse(parseDate.toString());
  var outputFormat = DateFormat(outputFormate);
  var outputDate = outputFormat.format(inputDate);
  return outputDate;
}
/*

  SwipeOnOffButton(
                  width: MediaQuery.of(context).size.width - 32,
                  startText: "Swipe to send order",
                  endText: "order placed",
                  backgroundColor:
                      
                  foregroundColor: isBuy ? green600 : red600,
                  onConfirmation: () {
                    context.gNavigationService.OpenReviewOrder(context);
                  },
                ),

*/

class SpreadData extends StatelessWidget {
  final Map<String, dynamic> spreadData;
  const SpreadData({
    Key? key,
    required this.spreadData,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              spreadData["title"],
              style: customTextStyle(
                  fontStyle: FontStyle.BodyM_Bold, color: FontColor.Success),
            ),
            const SizedBox(
              height: 4,
            ),
            RichText(
              text: TextSpan(
                  text: "₹ ",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.Success),
                  children: <TextSpan>[
                    TextSpan(
                        text: spreadData["buy"].toString(),
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyS_SemiBold,
                            color: FontColor.Success))
                  ]),
            ),
          ],
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              spreadData["title"],
              style: customTextStyle(
                  fontStyle: FontStyle.BodyM_Bold, color: FontColor.Danger),
            ),
            const SizedBox(
              height: 4,
            ),
            RichText(
              text: TextSpan(
                  text: "₹ ",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.Danger),
                  children: <TextSpan>[
                    TextSpan(
                        text: spreadData["sell"].toString(),
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyS_SemiBold,
                            color: FontColor.Danger))
                  ]),
            ),
          ],
        ),
      ],
    );
  }
}

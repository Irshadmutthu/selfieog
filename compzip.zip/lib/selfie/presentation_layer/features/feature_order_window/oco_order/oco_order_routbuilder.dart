import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import '../../../../../order_model/Order.dart';
import 'oco_order_page.dart';

class OCOOrderPageRouteBuilder {
  final ServiceLocator _serviceLocator;
  // final Map<String, dynamic> data;
  OrderModel order;

  OCOOrderPageRouteBuilder(this._serviceLocator, this.order);

  Widget call(BuildContext context) {
    return MultiRepositoryProvider(
        providers: [
          RepositoryProvider.value(value: _serviceLocator.tradingApi),
        ],
        child: OCOOrderPage(
          order: order,
        ));
  }
}

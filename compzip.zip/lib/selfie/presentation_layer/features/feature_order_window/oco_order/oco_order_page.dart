import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/constants/enums.dart';
import 'package:selfie_mobile_flutter/order_model/Order.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_time_condition.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/custom_swipe_button.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/default_order_settings_values.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/custom_bottom_strip.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:trading_api/utils/utils.dart';

import '../../../../../mds_controller.dart/mds_controller.dart';

class OCOOrderPage extends StatefulWidget {
  final OrderModel order;
  const OCOOrderPage({Key? key, required this.order}) : super(key: key);

  @override
  State<OCOOrderPage> createState() => _OCOOrderPageState();
}

class _OCOOrderPageState extends State<OCOOrderPage> {
  bool isBuy = false;
  String _productType = "Cash";
  int timeCondition = 0;
  int condition = 0;
  double __profitDiff = 0;
  double _approxProfit = 0;
  double _lossDiff = 0;
  double _approxLoss = 0;
  StreamSubscription? subscription;
  TextEditingController dateField = TextEditingController();
  TextEditingController targetPriceConroller = TextEditingController(text: "0");
  TextEditingController _qtyController = TextEditingController(text: "0");
  TextEditingController _losePriceController =
      TextEditingController(text: "00.00");

  @override
  void initState() {
    isBuy = widget.order.buyOrSell == BUY;
    _qtyController.text = widget.order.qty.toString();
    if (widget.order.productType > 0) {
      _productType = getProductDisplayType(widget.order.productType + 1);
    }
    if (widget.order.isModify) {
      targetPriceConroller.text = widget.order.targetPrice.toString();
      _losePriceController.text = widget.order.stoplossPrice.toString();
      // updateField();
    }
    super.initState();
    targetPriceConroller.addListener(() {
      setState(() {
        updateField();
      });
    });
    _losePriceController.addListener(() {
      setState(() {
        updateField();
      });
    });
    _qtyController.addListener(() {
      setState(() {
        updateField();
      });
    });
    MDS_Controller().subscribeSymbols([widget.order.instrument]);
    initializeSubscriptionListner();
  }

  @override
  void dispose() {
    if (subscription != null) subscription!.cancel();

    MDS_Controller().unsubscribeSymbols([widget.order.instrument]);

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: GestureDetector(
        onTap: (() {
          FocusManager.instance.primaryFocus?.unfocus();
        }),
        child: Column(
          children: [
            CustomAppBarInner(
                title:
                    !widget.order.isModify ? "OCO Order" : "Modify OCO Order",
                onBackPressed: () {
                  context.gNavigationService.back(context);
                }),
            Expanded(
              child: SingleChildScrollView(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                          "${widget.order.instrument.displayName}" +
                              (widget.order.isModify
                                  ? ""
                                  : (widget.order.buyOrSell == SELL
                                          ? " Long"
                                          : " Short") +
                                      " ${widget.order.qty} @ ₹${widget.order.price}"),
                          style: customTextStyle(
                              fontStyle: FontStyle.HeaderXS_Bold,
                              color: FontColor.Success)),
                      const SizedBox(
                        height: 6,
                      ),
                      RichText(
                        text: TextSpan(
                            text: 'LTP: ',
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontPrimary),
                            children: <TextSpan>[
                              TextSpan(
                                  text: "₹ ",
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_SemiBold,
                                      color: FontColor.FontSecondary)),
                              TextSpan(
                                  text: widget.order.instrument.lastTrdPrice
                                      .toStringAsFixed(
                                          widget.order.instrument.precision),
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyM_SemiBold,
                                      color: FontColor.FontSecondary))
                            ]),
                      ),
                      const SizedBox(
                        height: 24,
                      ),
                      Row(
                        children: [
                          Expanded(
                              child: CustomTextFormField(
                            inputFormatter: [
                              FilteringTextInputFormatter.allow(
                                  RegExp('[0-9]')),
                            ],
                            maxLength: 9,
                            keyboardType: const TextInputType.numberWithOptions(
                                decimal: false),
                            controller: _qtyController,
                            fieldName: "Quantity",
                            hintText: " Quantity",
                          )),
                          const SizedBox(
                            width: 16,
                          ),
                          Expanded(
                              child: CustomTextFormField(
                            controller: TextEditingController(),
                            fieldName: "Price",
                            hintText: "00.00",
                            enabled: false,
                          )),
                        ],
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      RichText(
                        text: TextSpan(
                            text: 'OCO Order ',
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_Bold,
                                color: FontColor.FontPrimary),
                            children: <TextSpan>[
                              TextSpan(
                                  text: isBuy ? "(Buy)" : "(Sell)",
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_Bold,
                                      color: isBuy
                                          ? FontColor.Success
                                          : FontColor.Danger)),
                            ]),
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      Container(
                        decoration: BoxDecoration(
                          border: Border.all(
                              width: 1,
                              color: customColors().backgroundTertiary),
                          borderRadius: BorderRadius.circular(4.0),
                        ),
                        padding: const EdgeInsets.symmetric(
                            vertical: 14, horizontal: 16),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Product Type",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary),
                            ),
                            Text(
                              _productType,
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_Bold,
                                  color: FontColor.FontPrimary),
                            )
                          ],
                        ),
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      Row(
                        children: [
                          Expanded(
                              child: CustomTextFormField(
                            inputFormatter: [
                              FilteringTextInputFormatter.allow(
                                  RegExp('[0-9.]')),
                            ],
                            keyboardType: const TextInputType.numberWithOptions(
                                decimal: true),
                            controller: targetPriceConroller,
                            fieldName: "Target Price",
                            hintText: "0",
                            topEndWidget: widget.order.isModify
                                ? Container()
                                : Text(
                                    __profitDiff > 0
                                        ? "+" +
                                            __profitDiff.toStringAsFixed(widget
                                                .order.instrument.precision)
                                        : __profitDiff.toStringAsFixed(
                                            widget.order.instrument.precision),
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_Regular,
                                        color: FontColor.FontSecondary)),
                            bottomStartWidget: widget.order.isModify
                                ? Container()
                                : RichText(
                                    text: TextSpan(
                                        text: 'Apox Profit: ',
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyM_Regular,
                                            color: FontColor.FontSecondary),
                                        children: <TextSpan>[
                                          TextSpan(
                                              text: __profitDiff > 0
                                                  ? "+" +
                                                      _approxProfit
                                                          .toStringAsFixed(
                                                              widget
                                                                  .order
                                                                  .instrument
                                                                  .precision)
                                                  : _approxProfit
                                                      .toStringAsFixed(widget
                                                          .order
                                                          .instrument
                                                          .precision),
                                              style: customTextStyle(
                                                  fontStyle:
                                                      FontStyle.BodyM_Regular,
                                                  color: FontColor.Success))
                                        ]),
                                  ),
                          )),
                          const SizedBox(width: 16),
                          Expanded(
                              child: CustomTextFormField(
                            inputFormatter: [
                              FilteringTextInputFormatter.allow(
                                  RegExp('[0-9.]')),
                            ],
                            keyboardType: const TextInputType.numberWithOptions(
                                decimal: true),
                            controller: _losePriceController,
                            fieldName: "Stoploss Price",
                            hintText: "00.00",
                            topEndWidget: widget.order.isModify
                                ? Container()
                                : Text(
                                    // _lossDiff > 0
                                    //     ? "-" +
                                    _lossDiff.toStringAsFixed(
                                        widget.order.instrument.precision),
                                    // : _lossDiff.toStringAsFixed(
                                    //     widget.order.instrument.precision),
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_Regular,
                                        color: FontColor.FontSecondary)),
                            bottomStartWidget: widget.order.isModify
                                ? Container()
                                : RichText(
                                    text: TextSpan(
                                        text: 'Apox Loss: ',
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyM_Regular,
                                            color: FontColor.FontSecondary),
                                        children: <TextSpan>[
                                          TextSpan(
                                              text: _approxLoss.toStringAsFixed(
                                                  widget.order.instrument
                                                      .precision),
                                              style: customTextStyle(
                                                  fontStyle:
                                                      FontStyle.BodyM_Regular,
                                                  color: FontColor.Danger))
                                        ]),
                                  ),
                          )),
                        ],
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      OrderWindowTimeCondition(
                        isfo: widget.order.instrument.isFao(),
                        timeCondition: timeCondition,
                        condition: condition,
                        withGtd: true,
                        isoco: true,
                        onTimeConditionChange: (int val) {
                          setState(() {
                            timeCondition = val;
                          });
                        },
                        onConditionChange: (int val) {
                          setState(() {
                            condition = val;
                          });
                        },
                        dateField: dateField,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const CustomBottomStrip(
              fundOrMargin: FundOrMargin.MARGIN,
              required: "15,000",
              available: "21,000",
              refreshIcon: true,
            ),
            InkWell(
              onTap: () {
                if (!validateOrder()) {
                  return;
                }
                // widget.order.instrument = selectedInstrument;
                // widget.order.priceCondition = selectedInstrument
                //     .getPriceConditionAsString(_condition + 1);
                // widget.order.price = priceController.text.toString().isEmpty
                //     ? "0"
                //     : priceController.text.toString();
                // widget.order.triggerPrice =
                //     triggerPriceController.text.toString();
                // widget.order.timeCondition =
                //     timeconditionsettingslist[_timeCondition]["name"];
                widget.order.tifDate = widget.order.timeCondition == "GTD"
                    ? dateField.text.toString()
                    : "";
                if (widget.order.isModify) {
                  // if (orderType == Segment.FO) {
                  //   widget.order.qtyChange = _quantity - widget.order.qty;
                  // } else {
                  //   widget.order.qtyChange =
                  //       int.parse(quantityController.text.toString()) -
                  //           widget.order.qty;
                  // }
                }
                // if (orderType == Segment.FO) {
                //   widget.order.qty = _quantity;
                //   widget.order.lots =
                //       int.parse(quantityController.text.toString());
                // } else {
                //   widget.order.qty =
                //       int.parse(quantityController.text.toString());
                // }

                // widget.order.productType = _productType;
                // widget.order.segment = getSegmentInt(orderType);
                widget.order.qty = int.parse(_qtyController.text);
                widget.order.targetPrice =
                    double.parse(targetPriceConroller.text);
                widget.order.stoplossPrice =
                    double.parse(_losePriceController.text);
                context.gNavigationService
                    .openReviewOrder(context, {"order": widget.order});
              },
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                child: BasketButton(
                  textStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_SemiBold,
                      color: FontColor.White),
                  text: "Send order",
                  bgcolor:
                      isBuy ? customColors().success : customColors().danger,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void initializeSubscriptionListner() {
    subscription = MDS_Controller()
        .marketUpdateStream
        .listen((List<FlairResponseModel> flairResponseModel) {
      for (var element in flairResponseModel) {
        if (widget.order.instrument.getRicAddress() == element.ric) {
          setState(() {
            widget.order.instrument.lastTrdPrice =
                element.instrument.lastTrdPrice;
          });
        }
      }
    });
  }

  updateField() {
    if (_qtyController.text.isEmpty) return;
    if (targetPriceConroller.text.isNotEmpty) {
      __profitDiff = double.parse(targetPriceConroller.text) -
          double.parse(widget.order.price);
      _approxProfit = __profitDiff * double.parse(_qtyController.text);
      __profitDiff =
          (__profitDiff.abs() / double.parse(widget.order.price)) * 100;
    }
    if (_losePriceController.text.isNotEmpty) {
      _lossDiff = double.parse(_losePriceController.text) -
          double.parse(widget.order.price);
      _approxLoss = _lossDiff * double.parse(_qtyController.text);
      _lossDiff = (_lossDiff.abs() / double.parse(widget.order.price)) * 100;
    }
  }

  bool validateOrder() {
    if (_losePriceController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("Enter Stopploss Price."),
      ));
      return false;
    }
    if (targetPriceConroller.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("Enter Target Price."),
      ));
      return false;
    }
    if (_qtyController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("Enter Quantity."),
      ));
      return false;
    }
    if (double.parse(_qtyController.text.toString()) < 1) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("Enter a valid Quantity."),
      ));
      return false;
    }
    if (timeconditionsettingslist[timeCondition]["name"] == "GTD") {
      if (dateField.text.toString().isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text("Please enter Good Till Date"),
        ));
        return false;
      }
    }

    if (!validateticksize(double.parse(targetPriceConroller.text.toString()),
        widget.order.instrument.ticksize!)) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Target Price should be multiple of " +
            widget.order.instrument.ticksize.toString() +
            " ."),
      ));
      return false;
    }

    if (!validateticksize(double.parse(_losePriceController.text.toString()),
        widget.order.instrument.ticksize!)) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Loss Price should be multiple of " +
            widget.order.instrument.ticksize.toString() +
            " ."),
      ));
      return false;
    }
    return true;
  }
}

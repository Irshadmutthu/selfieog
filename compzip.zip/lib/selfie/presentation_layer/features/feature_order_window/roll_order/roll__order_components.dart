import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_buysell_component.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_components/order_window_title_component.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class OrderContainerTitle extends StatefulWidget {
  final bool isBuy;
  final int prodType;
  final String tagName;
  final Function(int)? onProdTypeChange;
  const OrderContainerTitle({
    Key? key,
    required this.isBuy,
    this.prodType = 1,
    this.onProdTypeChange,
    required this.tagName,
  }) : super(key: key);

  @override
  State<OrderContainerTitle> createState() => _OrderContainerTitleState();
}

class _OrderContainerTitleState extends State<OrderContainerTitle> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          border:
              Border.all(width: 1, color: customColors().backgroundTertiary),
          borderRadius: BorderRadius.circular(4.0)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(16.0),
            color: customColors().backgroundSecondary,
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(2.0),
                          color: lightBlue.withOpacity(0.15)),
                      padding: const EdgeInsets.symmetric(
                          vertical: 4.0, horizontal: 6.0),
                      child: Text(widget.tagName,
                          style: customTextStyle(
                              fontStyle: FontStyle.TagNameS_SemiBold,
                              color: FontColor.PacificBlue)),
                    ),
                    const SizedBox(width: 8.0),
                    Text(
                      "BANKNIFTY MAR FUT",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyL_SemiBold,
                          color: FontColor.FontPrimary),
                    )
                  ],
                ),
                const SizedBox(
                  height: 4.0,
                ),
                Row(
                  children: [
                    Text(
                      "LTP",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_Regular,
                          color: FontColor.FontPrimary),
                    ),
                    const SizedBox(
                      width: 5.0,
                    ),
                    Text(
                      "250.02",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.Success),
                    )
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(
            height: 8.0,
          ),
          DefaultTabController(
            length: 2,
            child: Column(
              children: [
                TabBar(
                  labelStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_SemiBold,
                      color: FontColor.Primary),
                  unselectedLabelStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_Regular,
                      color: FontColor.FontSecondary),
                  unselectedLabelColor: customColors().fontSecondary,
                  labelColor: customColors().primary,
                  indicatorColor: customColors().primary,
                  indicatorSize: TabBarIndicatorSize.tab,
                  tabs: const [
                    Tab(text: "Limit"),
                    Tab(text: "Market"),
                  ],
                ),
                tabWidget()
              ],
            ),
          ),
        ],
      ),
    );
  }

  tabWidget() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Column(
        children: [
          const SizedBox(
            height: 20.0,
          ),
          Row(
            children: [
              Text("Product Type",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyL_Regular,
                      color: FontColor.FontPrimary)),
              const SizedBox(
                width: 24,
              ),
              CustomRadioButton(
                  value: 1,
                  groupValue: widget.prodType,
                  label: "Intraday",
                  onChanged: widget.onProdTypeChange ?? (int val) {}),
              const SizedBox(
                width: 24,
              ),
              CustomRadioButton(
                  value: 2,
                  groupValue: widget.prodType,
                  label: "Cash",
                  onChanged: widget.onProdTypeChange ?? (int val) {}),
            ],
          ),
          const SizedBox(
            height: 20.0,
          ),
          OrderWindowBuySellSwitch(
              fixed: 2,
              isBuy: widget.isBuy,
              BSP: 278.95.toString(),
              BBP: 278.95.toString(),
              onChanged: (bool val) {}),
          const SizedBox(
            height: 20.0,
          ),
          Row(
            children: [
              Expanded(
                  child: CustomTextFormField(
                controller: TextEditingController(),
                fieldName: "Price",
                hintText: "Eg: 2,500",
              )),
              const SizedBox(
                width: 16.0,
              ),
              const Expanded(child: LotsCounter())
            ],
          ),
          const SizedBox(
            height: 16.0,
          ),
        ],
      ),
    );
  }
}

class LotsCounter extends StatelessWidget {
  final String? fieldName;
  final String? fieldEndName;
  const LotsCounter({Key? key, this.fieldName, this.fieldEndName})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              fieldName ?? "Lots",
              style: customTextStyle(
                  fontStyle: FontStyle.BodyL_Regular,
                  color: FontColor.FontPrimary),
            ),
            Text(
              fieldEndName ?? "112 Qty",
              style: customTextStyle(
                  fontStyle: FontStyle.BodyM_Regular,
                  color: FontColor.FontSecondary),
            ),
          ],
        ),
        const SizedBox(
          height: 4.0,
        ),
        Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(
              border: Border.all(
                  width: 1, color: customColors().backgroundTertiary),
              borderRadius: BorderRadius.circular(4.0)),
          padding: const EdgeInsets.all(
            4.0,
          ),
          child: CounterWidget(),
        )
      ],
    );
  }
}

class CounterWidget extends StatefulWidget {
  final TextEditingController? controller;
  // final FocusNode? focusNode;
  final int initial;
  final int max;
  final int min;
  final int step;
  final bool enablePressAndHold;

  CounterWidget({
    Key? key,
    this.initial = 1,
    this.controller,
    // this.focusNode,
    this.max = 99999999,
    this.min = 1,
    this.step = 1,
    this.enablePressAndHold = true,
  }) : super(key: key);

  @override
  State<StatefulWidget> createState() => _CounterWidgetState();
}

class _CounterWidgetState extends State<CounterWidget> {
  late TextEditingController _controller;
  // late FocusNode _focusNode;
  bool _canGoUp = true;
  bool _canGoDown = false;
  bool val = true;
  Timer _timer = Timer.periodic(const Duration(milliseconds: 300), (timer) {});

  @override
  void initState() {
    super.initState();
    _controller = widget.controller ?? TextEditingController();
    // _focusNode = widget.focusNode ?? FocusNode();
    _updateArrows(int.tryParse(_controller.text) ?? 0);
    _controller.text = widget.initial.toString();
  }

  @override
  void didUpdateWidget(covariant CounterWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    _controller = widget.controller ?? _controller;
    // _focusNode = widget.focusNode ?? _focusNode;
    _updateArrows(int.tryParse(_controller.text) ?? 0);
  }

  void _updateArrows(int value) {
    final canGoUp = value < widget.max;
    final canGoDown = value > widget.min;
    if (_canGoUp != canGoUp || _canGoDown != canGoDown) {
      setState(() {
        _canGoUp = canGoUp;
        _canGoDown = canGoDown;
      });
    }
  }

  void _update(bool up) {
    if (_canGoDown && !up || _canGoUp && up) {
      var intValue = int.tryParse(_controller.text) ?? 0;
      intValue += up ? widget.step : -widget.step;
      _controller.text = intValue.toString();
      _updateArrows(intValue);
      // _focusNode.requestFocus();
      setState(() {
        val = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          GestureDetector(
            onTap: _canGoDown ? () => _update(false) : null,
            onLongPress: () {
              widget.enablePressAndHold && _canGoDown
                  ? _timer =
                      Timer.periodic(const Duration(milliseconds: 100), (t) {
                      _update(false);
                    })
                  : null;
            },
            onLongPressUp: () {
              _timer.cancel();
            },
            child: Container(
              height: 40,
              width: 40,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4.0),
                color: customColors().backgroundSecondary,
              ),
              child: Center(
                  child: Icon(
                Icons.remove,
                color: !_canGoDown
                    ? customColors().fontTertiary
                    : customColors().fontPrimary,
              )),
            ),
          ),
          const SizedBox(
            width: 4.0,
          ),
          Expanded(
            child: Container(
              width: double.maxFinite,
              height: 40,
              alignment: Alignment.center,
              padding: const EdgeInsets.only(bottom: 6.0),
              child: TextField(
                controller: _controller,
                showCursor: val,
                textInputAction: TextInputAction.done,
                textAlignVertical: TextAlignVertical.center,
                onTap: () {
                  setState(() {
                    val = true;
                  });
                },
                maxLines: 1,
                onChanged: (value) {
                  final intValue = int.tryParse(value);
                  _updateArrows(intValue ?? 0);
                },
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                  LengthLimitingTextInputFormatter(8),
                ],
                decoration: const InputDecoration(
                  enabledBorder: InputBorder.none,
                  disabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  border: InputBorder.none,
                  errorBorder: InputBorder.none,
                ),
                style: customTextStyle(
                    fontStyle: FontStyle.BodyL_Regular,
                    color: FontColor.FontPrimary),
                textAlign: TextAlign.center,
                keyboardType: TextInputType.number,
              ),
            ),
          ),
          const SizedBox(
            width: 4.0,
          ),
          GestureDetector(
            onTap: _canGoUp ? () => _update(true) : null,
            onLongPress: () {
              widget.enablePressAndHold && _canGoUp
                  ? _timer =
                      Timer.periodic(const Duration(milliseconds: 100), (t) {
                      _update(true);
                    })
                  : null;
            },
            onLongPressUp: () {
              _timer.cancel();
            },
            child: Container(
              height: 40,
              width: 40,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4.0),
                color: customColors().backgroundSecondary,
              ),
              child: Center(
                  child: Icon(
                Icons.add,
                color: !_canGoUp
                    ? customColors().fontTertiary
                    : customColors().fontPrimary,
              )),
            ),
          ),
        ],
      ),
    );
  }
}

class _NumberTextInputFormatter extends TextInputFormatter {
  final int min;
  final int max;
  _NumberTextInputFormatter(this.min, this.max);
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    if (const ['-', ''].contains(newValue.text)) return newValue;
    final intValue = int.tryParse(newValue.text);
    if (intValue == null) return oldValue;
    if (intValue < min) return newValue.copyWith(text: min.toString());
    if (intValue > max) return newValue.copyWith(text: max.toString());
    return newValue.copyWith(text: intValue.toString());
  }
}


// class LotsWidget extends StatefulWidget {
//   final int count;
//   final String? fieldName;
//   final String? fieldEndName;
//   final Function()? onAdd;
//   final Function()? onRemove;
//   final Function(int)? onValueChanged;
//   const LotsWidget({Key? key, this.count = 0, this.onAdd, this.onRemove, this.fieldName, this.fieldEndName, this.onValueChanged})
//       : super(key: key);

//   @override
//   State<LotsWidget> createState() => _LotsWidgetState();
// }

// class _LotsWidgetState extends State<LotsWidget> {
//   TextEditingController countController = TextEditingController();
//   bool disableRemove = true;
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//   }
//   @override
//   Widget build(BuildContext context) {
//     countController.text = widget.count.toString();
//     countController.selection = TextSelection.fromPosition(TextPosition(offset: countController.text.length));

//     return 
// Column(
//       children: [
//         Row(
//           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//           children: [
//             Text(
//               widget.fieldName ?? "Lots",
//               style: customTextStyle(
//                   fontStyle: FontStyle.BodyL_Regular,
//                   color: FontColor.FontPrimary),
//             ),
//             Text(
//               widget.fieldEndName ?? "112 Qty",
//               style: customTextStyle(
//                   fontStyle: FontStyle.BodyM_Regular,
//                   color: FontColor.FontSecondary),
//             ),
//           ],
//         ),
//         const SizedBox(
//           height: 4.0,
//         ),
//         Container(
//           decoration: BoxDecoration(
//               border: Border.all(
//                   width: 1, color: customColors().backgroundTertiary),
//               borderRadius: BorderRadius.circular(4.0)),
//           padding: const EdgeInsets.all(4.0),
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               InkWell(
//                 onTap: widget.onRemove,
//                 child: Container(
//                   height: 40,
//                   width: 40,
//                   decoration: BoxDecoration(
//                     borderRadius: BorderRadius.circular(4.0),
//                     color: customColors().backgroundSecondary,
//                   ),
//                   child: Center(
//                       child: Icon(
//                     Icons.remove,
//                     color: widget.count <= 1? customColors().fontTertiary : customColors().fontPrimary,

//                   )),
//                 ),
//               ),
//               Expanded(
//                   child: Focus(
//                     child: TextFormField(
//                       onChanged: (value) {
//                         if(value != "" && widget.onValueChanged != null){
//                           widget.onValueChanged!(int.parse(value));
//                         }else{
//                           widget.onValueChanged!(0);
//                         }
//                       },
//                       onEditingComplete: (){
//                         if(countController.text == ""){
//                           widget.onValueChanged!(1);
//                         }
//                       },
//                       onFieldSubmitted: (String val){
//                         if(val == ""){
//                           widget.onValueChanged!(1);
//                         }
//                       },
//                       controller: countController,
//                       inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9]')), 
//                       TextInputFormatter.withFunction((oldValue, newValue){
//                         if(newValue.text != "" && int.parse(newValue.text) < 0){
//                           return const TextEditingValue(
//                             text: "1", 
//                             selection: TextSelection.collapsed(offset: 1)
//                           );
//                         }
//                         return newValue;
//                       })
//                       ],
//                       decoration: const InputDecoration(
//                         enabledBorder: InputBorder.none,
//                         disabledBorder: InputBorder.none,
//                         focusedBorder: InputBorder.none,
//                         border: InputBorder.none,
//                         errorBorder: InputBorder.none,
//                       ),
//                       style: customTextStyle(fontStyle: FontStyle.BodyL_Regular, color: FontColor.FontPrimary),
//                       textAlign: TextAlign.center,
//                       keyboardType: TextInputType.number,
//                     ),
//                     onFocusChange: (bool hasFocus){
//                       if(!hasFocus){
//                         if(countController.text == "" || int.parse(countController.text) <= 0){
//                           widget.onValueChanged!(1);
//                         }
//                       }
//                     },
//                   )
//               ),
//               InkWell(
//                 onTap: widget.onAdd,
//                 child: Container(
//                   height: 40,
//                   width: 40,
//                   decoration: BoxDecoration(
//                     borderRadius: BorderRadius.circular(4.0),
//                     color: customColors().backgroundSecondary,
//                   ),
//                   child: Center(
//                       child: Icon(
//                     Icons.add,
//                     color: customColors().fontPrimary,
//                   )),
//                 ),
//               )
//             ],
//           ),
//         )
//       ],
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class OrderWindowBuySellSwitch extends StatelessWidget {
  final bool isBuy;
  final String BSP;
  final String BBP;
  final int fixed;
  final Function(bool) onChanged;
  const OrderWindowBuySellSwitch({
    Key? key,
    required this.isBuy,
    required this.BSP,
    required this.BBP,
    required this.onChanged,
    required this.fixed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Row(
          children: [
            Expanded(
              child: InkWell(
                onTap: () {
                  onChanged(true);
                },
                child: Container(
                  decoration: BoxDecoration(
                      color: isBuy
                          ? customColors().success
                          : customColors().success.withOpacity(0.05),
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(4.0),
                        bottomLeft: Radius.circular(4.0),
                      ),
                      border: Border.all(
                          width: 1,
                          color: customColors().success.withOpacity(0.1))),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 8.0, horizontal: 16.0),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Buy",
                            style: customTextStyle(
                                    fontStyle: FontStyle.HeaderXS_Bold)
                                .copyWith(
                                    color: isBuy
                                        ? white
                                        : customColors()
                                            .success
                                            .withOpacity(0.5)),
                          ),
                          const SizedBox(
                            height: 2,
                          ),
                          RichText(
                            text: TextSpan(
                                text: 'BSP: ',
                                style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_Regular,
                                ).copyWith(
                                    color: isBuy
                                        ? white
                                        : customColors().fontSecondary),
                                children: <TextSpan>[
                                  // TextSpan(
                                  //   text: "₹ ",
                                  //   style: customTextStyle(
                                  //           fontStyle: FontStyle.BodyL_SemiBold)
                                  //       .copyWith(
                                  //           color: isBuy
                                  //               ? white
                                  //               : customColors().fontSecondary),
                                  // ),
                                  TextSpan(
                                    text: BSP,
                                    style: customTextStyle(
                                      fontStyle: FontStyle.BodyM_SemiBold,
                                    ).copyWith(
                                        color: isBuy
                                            ? white
                                            : customColors().fontSecondary),
                                  )
                                ]),
                          ),
                        ]),
                  ),
                ),
              ),
            ),
            Expanded(
              child: InkWell(
                onTap: () {
                  onChanged(false);
                },
                child: Container(
                  decoration: BoxDecoration(
                      color: !isBuy
                          ? customColors().danger
                          : customColors().danger.withOpacity(0.05),
                      borderRadius: const BorderRadius.only(
                        topRight: Radius.circular(4.0),
                        bottomRight: Radius.circular(4.0),
                      ),
                      border: Border.all(
                          width: 1,
                          color: customColors().danger.withOpacity(0.1))),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 8.0, horizontal: 16.0),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            "Sell",
                            style: customTextStyle(
                                    fontStyle: FontStyle.HeaderXS_Bold)
                                .copyWith(
                                    color: !isBuy
                                        ? white
                                        : customColors()
                                            .danger
                                            .withOpacity(0.5)),
                          ),
                          const SizedBox(
                            height: 2,
                          ),
                          RichText(
                            text: TextSpan(
                                text: BBP.toString(),
                                style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_SemiBold)
                                    .copyWith(
                                        color: !isBuy
                                            ? white
                                            : customColors().fontSecondary),
                                children: <TextSpan>[
                                  // TextSpan(
                                  //     text: "₹ ",
                                  //     style: customTextStyle(
                                  //         fontStyle: FontStyle.BodyL_SemiBold).copyWith(
                                  //           color: !isBuy? white : customColors().fontSecondary
                                  //         )),
                                  TextSpan(
                                      text: ' :BBP',
                                      style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyM_Regular)
                                          .copyWith(
                                              color: !isBuy
                                                  ? white
                                                  : customColors()
                                                      .fontSecondary))
                                ]),
                          ),
                        ]),
                  ),
                ),
              ),
            )
          ],
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 2.0),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(2.0), color: peachBackground),
          child: Text(
            (double.parse(BBP) - double.parse(BSP))
                .abs()
                .toStringAsFixed(fixed),
            style: customTextStyle(fontStyle: FontStyle.BodyS_SemiBold)
                .copyWith(color: peachText),
          ),
        ),
      ],
    );
  }
}

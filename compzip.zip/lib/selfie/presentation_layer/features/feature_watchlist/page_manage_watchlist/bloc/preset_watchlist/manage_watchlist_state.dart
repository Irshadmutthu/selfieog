part of 'manage_watchlist_cubit.dart';

@immutable
abstract class ManagePresetWatchlistState {}

class ManagePrestWatchlistInitial extends ManagePresetWatchlistState {
  final List<String> presetWatchlistItem;
  final List<String> selectedWatchlist;
  final String errorMsg;
  ManagePrestWatchlistInitial(
      {required this.presetWatchlistItem,
      required this.selectedWatchlist,
      required this.errorMsg});
}

import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/constants/enums.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/delete_watchlist.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';
import 'package:trading_api/responses/get_cloud_watch_response.dart';
part 'manage_my_watchlist_state.dart';

class ManageMyWatchlistCubit extends Cubit<ManageMyWatchlistState> {
  final ServiceLocator serviceLocator;
  Map<String, dynamic> data = {"": ""};
  Map<String, dynamic> returnArgs = {};
  bool isReorder = false;
  bool isLoading = false;
  List<WatchlistModel> watchlists = [];

  ManageMyWatchlistCubit({required this.serviceLocator, required this.data})
      : super(ManageMyWatchListInitial(
            listWatchList: UserController.userController.watchlists,
            errorMsg: "")) {
    watchlists = List.generate(UserController().watchlists.length,
        (index) => UserController().watchlists[index].copyWith());
    emit(ManageMyWatchListInitial(listWatchList: watchlists, errorMsg: ""));
  }

  onDeleteWatch(BuildContext context, int index) {
    if (watchlists.length <= 1) return;
    if (isLoading) {
      ScaffoldMessenger.of(context).clearSnackBars();
      ScaffoldMessenger.of(context).showSnackBar(showWaringDialogue(
          errorMessage: "Please wait, cloud watch saving in progress..."));
      return;
    }
    return customShowModalBottomSheet(
      context: context,
      inputWidget: WatchListAction(
        watchlistName: watchlists[index].watchlistData.watchname,
        actionType: ActionType.delete,
        negativeOnPres: () async {
          Navigator.pop(context);
          try {
            isLoading = true;
            final _response = await context.gTradingApiGateway
                .deleteCloudWatchListData(
                    watchlistId:
                        int.parse(watchlists[index].watchlistData.watchlistid),
                    userID: UserController.userController.userId);
            if (_response.errorCode == "0") {
              isLoading = false;
              watchlists.removeAt(index);
              UserController.userController.watchlists = watchlists;
              emit(ManageMyWatchListInitial(
                  listWatchList: watchlists, errorMsg: ""));
            } else {
              isLoading = false;
              emit(ManageMyWatchListInitial(
                  listWatchList: watchlists,
                  errorMsg: "Internal Server Error"));
            }
          } catch (e) {
            isLoading = false;
            emit(ManageMyWatchListInitial(
                listWatchList: watchlists, errorMsg: "Internal Server Error"));
          }
        },
        positiveOnPress: () {
          Navigator.pop(context);
        },
      ),
    );
  }

  onBackPressed(BuildContext context) {
    if (isLoading) {
      ScaffoldMessenger.of(context).clearSnackBars();
      ScaffoldMessenger.of(context).showSnackBar(showWaringDialogue(
          errorMessage: "Please wait, cloud watch saving in progress..."));
      return;
    }
    if (isReorder) {
      return customShowModalBottomSheet(
        context: context,
        inputWidget: WatchListAction(
          actionType: ActionType.save,
          negativeOnPres: () {
            Navigator.pop(context);
            serviceLocator.navigationService.back(context, arg: data);
          },
          positiveOnPress: () async {
            try {
              int _errorCode = await watchReorderRequest();
              if (_errorCode == 0) {
                UserController.userController.watchlists = watchlists;
                Navigator.pop(context);
                serviceLocator.navigationService.back(context, arg: data);
              } else {
                emit(ManageMyWatchListInitial(
                    listWatchList: watchlists,
                    errorMsg: "Internal Server Error"));
                Navigator.pop(context);
              }
            } catch (e) {
              Navigator.pop(context);
            }
          },
        ),
      );
    } else {
      serviceLocator.navigationService.back(context, arg: data);
    }
  }

  Future<int> watchReorderRequest() async {
    try {
      int _len = watchlists.length;
      String _sortList = "";
      String _watchId = "";
      for (int i = 0; i < _len; i++) {
        _watchId = _watchId + watchlists[i].watchlistData.watchlistid + "|";
        _sortList = _sortList + i.toString() + "|";
      }
      final _response = await serviceLocator.tradingApi
          .updateMultipleSortOrdersforWatchlist(
              sortedOrdersList: _sortList,
              userID: UserController.userController.userId,
              watchlistIdList: _watchId);
      if (_response.errorCode == "0") {
        return 0;
      } else {
        return 1;
      }
    } catch (e) {
      return 1;
    }
  }

  onReoder(int oldIndex, int newIndex) async {
    isReorder = true;
    isLoading = true;
    if (newIndex > oldIndex) {
      newIndex -= 1;
    }
    final item = watchlists.removeAt(oldIndex);
    watchlists.insert(newIndex, item);
    emit(ManageMyWatchListInitial(listWatchList: watchlists, errorMsg: ""));
    int _errorCode = await watchReorderRequest();
    if (_errorCode == 0) {
      isReorder = false;
      isLoading = false;
      UserController.userController.watchlists = watchlists;
    } else {
      emit(ManageMyWatchListInitial(
          listWatchList: watchlists, errorMsg: "Internal Server Error"));
      isLoading = false;
      isReorder = true;
    }
  }
}

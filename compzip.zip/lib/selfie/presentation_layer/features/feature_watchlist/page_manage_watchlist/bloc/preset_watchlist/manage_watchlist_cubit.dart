import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/enums.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/delete_watchlist.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/get_cloud_watch_response.dart';

part 'manage_watchlist_state.dart';

class ManagePresetWatchlistCubit extends Cubit<ManagePresetWatchlistState> {
  final ServiceLocator serviceLocator;
  final Map<String, dynamic> data;
  List<String> allPresetWatchs = UserController.userController.allPreset;
  List<String> selectedWatchs = List.generate(
      UserController.userController.selectedPresetWatch.length,
      (index) => UserController.userController.selectedPresetWatch[index]);
  final String _oldSelectedWatch =
      UserController.userController.selectedPresetWatch.join("|");
  bool _isUpdate = false;

  ManagePresetWatchlistCubit({required this.serviceLocator, required this.data})
      : super(ManagePrestWatchlistInitial(
            presetWatchlistItem: UserController.userController.allPreset,
            selectedWatchlist:
                UserController.userController.selectedPresetWatch,
            errorMsg: ""));

  updatelistCheck(int index, bool status) {
    _isUpdate = true;
    if (status) {
      if (selectedWatchs.length <= 1) return;
      selectedWatchs.remove(allPresetWatchs[index]);
    } else {
      if (selectedWatchs.length >= 6) {
        emit(ManagePrestWatchlistInitial(
            presetWatchlistItem: allPresetWatchs,
            selectedWatchlist: selectedWatchs,
            errorMsg: "Maximum Limit Exceeded"));
        return;
      } else {
        selectedWatchs.add(allPresetWatchs[index]);
      }
    }

    emit(ManagePrestWatchlistInitial(
        presetWatchlistItem: allPresetWatchs,
        selectedWatchlist: selectedWatchs,
        errorMsg: ""));
  }

  onBackPressed(BuildContext context) {
    if (_isUpdate) {
      return customShowModalBottomSheet(
        context: context,
        inputWidget: WatchListAction(
          actionType: ActionType.save,
          negativeOnPres: () {
            Navigator.pop(context);
            serviceLocator.navigationService.back(context, arg: data);
          },
          positiveOnPress: () async {
            try {
              Navigator.pop(context);

              final _response = await serviceLocator.tradingApi
                  .updateAllPresetWatchlist(
                      userID: UserController.userController.userId,
                      watchName: selectedWatchs.join("|"));
              if (_response.errorCode == "0") {
                UserController.userController.presetWatchList.removeWhere(
                    (element) => !selectedWatchs
                        .contains(element.watchlistData.watchname));
                for (String watchName in selectedWatchs) {
                  if (!_oldSelectedWatch.contains(watchName)) {
                    UserController.userController.presetWatchList.add(
                      WatchlistModel(
                          watchlistData: WatchlistData(
                              sortorder: "",
                              usercode: "",
                              version: "",
                              watchlistid: "0",
                              watchname: watchName),
                          symbolDataList: []),
                    );
                  }
                }
                UserController.userController.selectedPresetWatch =
                    selectedWatchs;
                serviceLocator.navigationService.back(context);
              } else {
                emit(ManagePrestWatchlistInitial(
                    presetWatchlistItem: allPresetWatchs,
                    selectedWatchlist: selectedWatchs,
                    errorMsg: "Internal Server Error"));
              }
            } catch (e) {
              emit(ManagePrestWatchlistInitial(
                  presetWatchlistItem: allPresetWatchs,
                  selectedWatchlist: selectedWatchs,
                  errorMsg: e.toString()));
            }
          },
        ),
      );
    } else {
      serviceLocator.navigationService.back(context);
    }
  }

  Future<bool> willPopNavigation(BuildContext context) async {
    if (_isUpdate) {
      return customShowModalBottomSheet(
        context: context,
        inputWidget: WatchListAction(
          actionType: ActionType.save,
          negativeOnPres: () {
            Navigator.pop(context);
            serviceLocator.navigationService.back(context, arg: data);
          },
          positiveOnPress: () async {
            try {
              Navigator.pop(context);

              final _response = await serviceLocator.tradingApi
                  .updateAllPresetWatchlist(
                      userID: UserController.userController.userId,
                      watchName: selectedWatchs.join("|"));
              if (_response.errorCode == "0") {
                UserController.userController.selectedPresetWatch =
                    selectedWatchs;
                UserController.userController.presetWatchList.removeWhere(
                    (element) => !selectedWatchs
                        .contains(element.watchlistData.watchname));
                for (String watchName in selectedWatchs) {
                  if (!_oldSelectedWatch.contains(watchName)) {
                    UserController.userController.presetWatchList.add(
                      WatchlistModel(
                          watchlistData: WatchlistData(
                              sortorder: "",
                              usercode: "",
                              version: "",
                              watchlistid: "0",
                              watchname: watchName),
                          symbolDataList: []),
                    );
                  }
                }
                serviceLocator.navigationService.back(context);
              } else {
                emit(ManagePrestWatchlistInitial(
                    presetWatchlistItem: allPresetWatchs,
                    selectedWatchlist: selectedWatchs,
                    errorMsg: "Internal Server Error"));
              }
            } catch (e) {
              emit(ManagePrestWatchlistInitial(
                  presetWatchlistItem: allPresetWatchs,
                  selectedWatchlist: selectedWatchs,
                  errorMsg: e.toString()));
            }
          },
        ),
      );
    } else {
      serviceLocator.navigationService.back(context);
    }
    return false;
  }
}

  // positiveOnPress: () async {
  //           try {
  //             _selectedWatchString = selectedWatchs.join("|");
  //             final _response = await serviceLocator.tradingApi
  //                 .updateAllPresetWatchlist(
  //                     userID: UserController.userController.userId,
  //                     watchName: _selectedWatchString);
  //             if (_response.errorCode == "0") {
  //               Navigator.pop(context);
  //               UserController.userController.selectedPresetWatch =
  //                   _selectedWatchString;
  //               _oldSelectedWatch.split("|").forEach((elements) {
  //                  UserController.userController.presetWatchList.removeWhere(
  //                   (element) => element.watchlistData.watchname == elements);
  //               for (String watchName in selectedWatchs) {
  //                 if (!_oldSelectedWatch.contains(watchName)) {
  //                   UserController.userController.presetWatchList.add(
  //                     WatchlistModel(
  //                         watchlistData: WatchlistData(
  //                             sortorder: "",
  //                             usercode: "",
  //                             version: "",
  //                             watchlistid: "0",
  //                             watchname: watchName),
  //                         symbolDataList: []),
  //                   );
  //                 }
  //               }           
  //               });

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_manage_watchlist/bloc/preset_watchlist/manage_watchlist_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_top_tab.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';

class ManagePresetWatchlist extends StatefulWidget {
  final ServiceLocator serviceLocator;
  ManagePresetWatchlist({Key? key, required this.serviceLocator})
      : super(key: key);

  @override
  _ManagePresetWatchlistPageState createState() =>
      _ManagePresetWatchlistPageState();
}

class _ManagePresetWatchlistPageState extends State<ManagePresetWatchlist>
    with TickerProviderStateMixin {
  AnimationController? _controller;

  @override
  void initState() {
    super.initState();
    _controller = BottomSheet.createAnimationController(this);
    _controller!.duration = const Duration(milliseconds: 400);
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  bool manage = false;
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () async {
          bool status =
              await BlocProvider.of<ManagePresetWatchlistCubit>(context)
                  .willPopNavigation(context);
          return status;
        },
        child: Scaffold(
          appBar: PreferredSize(
              preferredSize: const Size.fromHeight(0.0),
              child: AppBar(
                elevation: 0,
                backgroundColor: customColors().backgroundPrimary,
              )),
          backgroundColor: customColors().backgroundPrimary,
          body: SafeArea(
            bottom: true,
            child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CustomAppBarInner(
                      title: "Manage",
                      onBackPressed: () {
                        BlocProvider.of<ManagePresetWatchlistCubit>(context)
                            .onBackPressed(context);
                      }),
                  Expanded(
                      child: CustomTabBar(
                    isScrollable: true,
                    tabContent: const ["Preset Watchlist"],
                    tabBarViewChildern: [
                      BlocConsumer<ManagePresetWatchlistCubit,
                          ManagePresetWatchlistState>(
                        listener: (context, state) {
                          if (state is ManagePrestWatchlistInitial) {
                            if (state.errorMsg != "") {
                              ScaffoldMessenger.of(context).clearSnackBars();
                              ScaffoldMessenger.of(context).showSnackBar(
                                  showErrorDialogue(
                                      errorMessage: state.errorMsg));
                            }
                          }
                        },
                        builder: (context, state) {
                          if (state is ManagePrestWatchlistInitial) {
                            return Column(
                              children: [
                                MessageTile(
                                    context,
                                    "Choose indices you would like to see in your watchlist:",
                                    "${BlocProvider.of<ManagePresetWatchlistCubit>(context).selectedWatchs.length}/6 Selected"),
                                Expanded(
                                  child: presetWatchlistManageContent(
                                      context: context,
                                      selectedItems: state.selectedWatchlist,
                                      items: state.presetWatchlistItem,
                                      onTap: (index, status) {
                                        BlocProvider.of<
                                                    ManagePresetWatchlistCubit>(
                                                context)
                                            .updatelistCheck(index, status);
                                      }),
                                ),
                              ],
                            );
                          }
                          return Container();
                        },
                      ),
                    ],
                  )),
                ]),
          ),
        ));
  }
}

Widget presetWatchlistManageContent(
    {required BuildContext context,
    required List<String> selectedItems,
    required List<String> items,
    required void Function(int, bool) onTap}) {
  return ListView.builder(
      shrinkWrap: true,
      itemCount: items.length,
      itemBuilder: (context, index) {
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
              border: Border(
                  bottom:
                      BorderSide(color: customColors().backgroundTertiary))),
          child: SizedBox(
            height: 65,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  items[index],
                  style: TextStyle(
                      fontFamily: "OpenSansSemiBold",
                      fontSize: 14,
                      color: customColors().fontPrimary),
                ),
                selectedItems.contains(items[index])
                    ? IconButton(
                        onPressed: () {
                          onTap(index, true);
                        },
                        icon: Image.asset(
                          "assets/ic_checkbox_checked.png",
                          height: 24,
                          width: 24,
                          fit: BoxFit.fill,
                        ))
                    : IconButton(
                        onPressed: () {
                          onTap(index, false);
                        },
                        icon: Image.asset("assets/ic_checkbox_plus.png",
                            height: 24, width: 24, fit: BoxFit.fill)),
              ],
            ),
          ),
        );
      });
}

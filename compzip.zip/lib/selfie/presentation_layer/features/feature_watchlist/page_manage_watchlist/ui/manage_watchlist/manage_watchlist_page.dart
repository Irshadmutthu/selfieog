import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_manage_watchlist/bloc/my_watchlist/manage_my_watchlist_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/watchlist/manage_watchlist/custom_reoderable_list.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_top_tab.dart';
import 'package:selfie_mobile_flutter/user_controller/repo_files/watchlist/watchlist_repo.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';

class ManageWatchlistPage extends StatefulWidget {
  final ServiceLocator serviceLocator;
  ManageWatchlistPage({Key? key, required this.serviceLocator})
      : super(key: key);

  @override
  _ManageWatchlistPageState createState() => _ManageWatchlistPageState();
}

class _ManageWatchlistPageState extends State<ManageWatchlistPage>
    with TickerProviderStateMixin {
  AnimationController? _controller;

  @override
  void initState() {
    super.initState();
    _controller = BottomSheet.createAnimationController(this);
    _controller!.duration = const Duration(milliseconds: 400);
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  bool manage = false;
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () async {
          await BlocProvider.of<ManageMyWatchlistCubit>(context)
              .onBackPressed(context);
          return false;
        },
        child: Scaffold(
          appBar: PreferredSize(
              preferredSize: const Size.fromHeight(0.0),
              child: AppBar(
                elevation: 0,
                backgroundColor: customColors().backgroundPrimary,
              )),
          backgroundColor: customColors().backgroundPrimary,
          body: SafeArea(
            bottom: true,
            child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CustomAppBarInner(
                      title: "Manage",
                      onBackPressed: () {
                        BlocProvider.of<ManageMyWatchlistCubit>(context)
                            .onBackPressed(context);
                      }),
                  Expanded(
                      child: CustomTabBar(
                    isScrollable: true,
                    tabContent: const ["My Watchlist"],
                    tabBarViewChildern: [
                      BlocConsumer<ManageMyWatchlistCubit,
                          ManageMyWatchlistState>(
                        listener: (context, state) {
                          if (state is ManageMyWatchListInitial) {
                            if (state.errorMsg != "") {
                              ScaffoldMessenger.of(context).clearSnackBars();
                              ScaffoldMessenger.of(context).showSnackBar(
                                  showErrorDialogue(
                                      errorMessage: state.errorMsg));
                            }
                          }
                        },
                        builder: (context, state) {
                          if (state is ManageMyWatchListInitial) {
                            return Column(
                              children: [
                                MessageTile(
                                    context,
                                    "Choose or create custom watchlists:",
                                    "${state.listWatchList.length}/${WatchlistRepository.cloudWatchRetriveResponse.watchData[0].watchlistno} Created"),
                                Expanded(
                                  child: CustomReoderableList(
                                      delete: (index) {
                                        BlocProvider.of<ManageMyWatchlistCubit>(
                                                context)
                                            .onDeleteWatch(context, index);
                                      },
                                      watchlists: state.listWatchList),
                                ),
                              ],
                            );
                          }
                          return Container();
                        },
                      ),
                    ],
                  )),
                ]),
          ),
        ));
  }
}

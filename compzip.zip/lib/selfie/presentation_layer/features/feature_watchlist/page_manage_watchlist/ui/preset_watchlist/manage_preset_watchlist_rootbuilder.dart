import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_manage_watchlist/bloc/my_watchlist/manage_my_watchlist_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_manage_watchlist/bloc/preset_watchlist/manage_watchlist_cubit.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

import 'manage_preset_watchlist_page.dart';

class ManagePresetWatchlistPageRouteBuilder {
  final ServiceLocator _serviceLocator;
  final Map<String, dynamic> data;

  ManagePresetWatchlistPageRouteBuilder(this._serviceLocator, this.data);

  Widget call(BuildContext context) {
    return MultiBlocProvider(
        providers: [
          BlocProvider(
              create: (context) => ManageMyWatchlistCubit(
                  serviceLocator: _serviceLocator, data: data)),
          BlocProvider(
              create: (context) => ManagePresetWatchlistCubit(
                  serviceLocator: _serviceLocator, data: data)),
        ],
        child: MultiRepositoryProvider(
            providers: [
              RepositoryProvider<CubitsLocator>.value(value: _serviceLocator),
            ],
            child: ManagePresetWatchlist(
              serviceLocator: _serviceLocator,
            )));
  }
}

class PresetWatchListModel {
  String watchName;
  String watchId;
  List<WatchListSymbols> watchSymbols;
  PresetWatchListModel(
      {required this.watchName,
      required this.watchId,
      required this.watchSymbols});
}

class WatchListSymbols {
  WatchListSymbols({
    required this.scripcode,
    required this.venue,
    required this.description,
    required this.w,
    required this.ca,
    required this.securitycode,
    required this.securitycode1,
  });

  String scripcode;
  String venue;
  String description;
  String w;
  String ca;
  String securitycode;
  String securitycode1;
}

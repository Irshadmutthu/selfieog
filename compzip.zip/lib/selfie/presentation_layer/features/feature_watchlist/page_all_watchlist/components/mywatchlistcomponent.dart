import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:trading_api/responses/get_cloud_watch_response.dart';

Widget myWatchListContent(
    {required BuildContext context,
    required String selectedWatch,
    required List<WatchlistModel> items,
    required Function(int) onTap}) {
  return ListView.builder(
      shrinkWrap: true,
      itemCount: items.length,
      itemBuilder: (context, index) {
        return GestureDetector(
          onTap: () => onTap(index),
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
                border: Border(
                    bottom:
                        BorderSide(color: customColors().backgroundTertiary))),
            child: SizedBox(
              height: 65,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    items[index].watchlistData.watchname,
                    style: TextStyle(
                        fontFamily: "OpenSansSemiBold",
                        fontSize: 14,
                        color: customColors().fontPrimary),
                  ),
                  items[index].watchlistData.watchlistid == selectedWatch
                      ? Image.asset("assets/tick_circle.png")
                      : Container(),
                ],
              ),
            ),
          ),
        );
      });
}

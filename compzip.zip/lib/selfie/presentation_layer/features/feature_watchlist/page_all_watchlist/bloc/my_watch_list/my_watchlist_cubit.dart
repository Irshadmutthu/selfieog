import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/general_methods.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/watchlist_content.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/get_cloud_watch_response.dart';

part 'my_watchlist_state.dart';

class MyWatchlistCubit extends Cubit<MyWatchlistState> {
  final ServiceLocator serviceLocator;
  List<Map<String, dynamic>> myWatchList = myWatchListItems;
  MyWatchlistCubit({required this.serviceLocator})
      : super(MyWatchListInitialState(UserController.userController.watchlists,
            UserController.userController.selectedWatchIndex, ""));

  // List<Map<String, dynamic>> getListItems(List<Map<String, dynamic>> item) {
  //   List<Map<String, dynamic>> generatedItems = [];
  //   for (var i = 0; i < item.length; i++) {
  //     item[i]["properties"]["enabled"] ? generatedItems.add(item[i]) : null;
  //   }
  //   return generatedItems;
  // }

  updatelist(int index) async {
    emit(MyWatchlistLoading());
    try {
      List<WatchlistModel> list = UserController.userController.watchlists;
      UserController.userController.selectedWatchIndex =
          list[index].watchlistData.watchlistid;
      emit(MyWatchListInitialState(
          list, UserController.userController.selectedWatchIndex, ""));
      final response = await serviceLocator.tradingApi.selectedFlagUpdated(
          userID: UserController.userController.userId,
          watchname: list[index].watchlistData.watchlistid);
      if (response.errorCode != "0") {
        emit(MyWatchListInitialState(
            list,
            UserController.userController.selectedWatchIndex,
            "Internal Server Error"));
      }
    } on SocketException {
      // emit(NetworkError());
    } catch (e) {
      if (!isClosed) {
        emit(MyWatchListInitialState(UserController.userController.watchlists,
            UserController.userController.selectedWatchIndex, e.toString()));
      }
    }
  }

  onBackPressed({required BuildContext context, int index = -1}) {
    serviceLocator.navigationService.back(context);
  }

  refreshList() {
    emit(MyWatchListInitialState(UserController.userController.watchlists,
        UserController.userController.selectedWatchIndex, ""));
  }

  onManagePressed(BuildContext context) async {
    await serviceLocator.navigationService
        .openWatchlistManagePage(context, {"name": "myWachList"});
    refreshList();
    int _currentIndex = GeneralMethods.getWatchIndex();
    if (_currentIndex == -1) {
      updatelist(0);
    }
  }

  onCreatePressed({required context, required String watchlistName}) {}
}

part of 'preset_watchlist_cubit.dart';

@immutable
abstract class PresetWatchlistState {}

class PrestWatchlistInitial extends PresetWatchlistState {
  final List presetWatchlistItem;
  String errorMsg;
  final int initialIndex;
  final String selectedIndex;
  PrestWatchlistInitial(
      this.presetWatchlistItem, this.selectedIndex, this.errorMsg,
      {this.initialIndex = 0});
}

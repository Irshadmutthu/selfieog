import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/general_methods.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/watchlist_content.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/models/watchlist_model.dart';
import 'package:trading_api/responses/get_cloud_watch_response.dart';

part 'preset_watchlist_state.dart';

class PresetWatchlistCubit extends Cubit<PresetWatchlistState> {
  final ServiceLocator serviceLocator;
  PresetWatchlistCubit({required this.serviceLocator})
      : super(PrestWatchlistInitial(presetWatchListItems,
            UserController.userController.selectedWatchIndex, ""));

  // List<Map<String, dynamic>> getListItems(List<Map<String, dynamic>> item) {
  //   List<Map<String, dynamic>> generatedItems = [];
  //   for (var i = 0; i < item.length; i++) {
  //     item[i]["properties"]["enabled"] ? generatedItems.add(item[i]) : null;
  //   }
  //   return generatedItems;
  // }

  updatePresetWatch(int index) async {
    try {
      List<WatchlistModel> list = UserController.userController.presetWatchList;
      UserController.userController.selectedWatchIndex =
          list[index].watchlistData.watchname;
      if (!isClosed) {
        emit(PrestWatchlistInitial(
            list, UserController.userController.selectedWatchIndex, ""));
      }
      final updateResponse = await serviceLocator.tradingApi
          .selectedFlagUpdated(
              userID: UserController.userController.userId,
              watchname: list[index].watchlistData.watchname);
      if (updateResponse.errorCode != "0") {
        if (!isClosed) {
          emit(PrestWatchlistInitial(
              list,
              UserController.userController.selectedWatchIndex,
              "Internal Server Error"));
        }
        return;
      }
    } catch (e) {
      if (!isClosed) {
        emit(PrestWatchlistInitial(
            UserController.userController.presetWatchList,
            UserController.userController.selectedWatchIndex,
            e.toString()));
      }
    }
  }

  getPresetWatchlist(int index) async {
    if (UserController.userController.presetWatchList[index].symbolDataList
        .isNotEmpty) return;
    try {
      List<WatchlistModel> list = UserController.userController.presetWatchList;
      UserController.userController.selectedWatchIndex =
          list[index].watchlistData.watchname;

      final response = await serviceLocator.tradingApi.symbolSearchRequest(
          indexFilter: "N",
          keyword: "",
          remarks: "",
          start: 1,
          limt: 0,
          venuCode: "",
          index: UserController.userController.presetWatchList[index]
                      .watchlistData.watchname ==
                  "SENSEX"
              ? "S&P SENSEX"
              : UserController.userController.presetWatchList[index]
                  .watchlistData.watchname);
      if (response.searchresp![0].errorcode == 0) {
        for (int i = 0; i < response.searchresp![0].reclistxmob!.length; i++) {
          UserController.userController.presetWatchList[index].symbolDataList
              .add(SymbolData(
                instrumentType: response.searchresp![0].reclistxmob![i].insttype.toString(),
                  sortorder: i.toString(),
                  symbolname: response
                      .searchresp![0].reclistxmob![i].securitycode1
                      .toString(),
                  venuecode:
                      response.searchresp![0].reclistxmob![i].venue.toString(),
                  venuescripcode: response
                      .searchresp![0].reclistxmob![i].scripcode
                      .toString(),
                  watchlistid: index.toString(),
                  watchsymbolid: "",
                  ca: response.searchresp![0].reclistxmob![i].ca ?? ""));
        }
      } else {
        emit(PrestWatchlistInitial(
            list,
            UserController.userController.selectedWatchIndex,
            "Internal Server Error"));
      }
    } catch (e) {
      emit(PrestWatchlistInitial(UserController.userController.presetWatchList,
          UserController.userController.selectedWatchIndex, e.toString()));
    }
  }

  onBackPressed(BuildContext context) {
    serviceLocator.navigationService.back(context);
  }

  refreshList() {
    emit(PrestWatchlistInitial(UserController.userController.presetWatchList,
        UserController.userController.selectedWatchIndex, ""));
  }

  onManagePressed(BuildContext context) async {
    await serviceLocator.navigationService
        .openPresetWatchlistManagePage(context, {"name": "presetWatchList"});
    refreshList();
    int _index = GeneralMethods.getWatchIndex();
    if (_index == -1) {
      updatePresetWatch(0);
      getPresetWatchlist(0);
    }
  }

  onCreatePressed(BuildContext context) {}
}

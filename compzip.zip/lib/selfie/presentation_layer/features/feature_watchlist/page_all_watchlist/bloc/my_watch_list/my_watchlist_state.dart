part of 'my_watchlist_cubit.dart';

@immutable
abstract class MyWatchlistState {}

class MyWatchlistLoading extends MyWatchlistState {}

class MyWatchListInitialState extends MyWatchlistState {
  final String selectedWatch;
  final String errorMessage;
  final List<WatchlistModel> myWatchListItems;
  MyWatchListInitialState(
      this.myWatchListItems, this.selectedWatch, this.errorMessage);
}

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_all_watchlist/bloc/my_watch_list/my_watchlist_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_all_watchlist/bloc/preset_watch_list/preset_watchlist_cubit.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'all_watchlist_page.dart';

class AllWatchlistPageRouteBuilder {
  final ServiceLocator _serviceLocator;

  AllWatchlistPageRouteBuilder(this._serviceLocator);

  Widget call(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (context) => MyWatchlistCubit(serviceLocator: _serviceLocator)),
        BlocProvider(create: (context) => PresetWatchlistCubit(serviceLocator: _serviceLocator)),
      ],
      child: MultiRepositoryProvider(providers: [
        RepositoryProvider<CubitsLocator>.value(value: _serviceLocator),
    ], child: AllWatchlistPage(serviceLocator: _serviceLocator,)));
  }
}

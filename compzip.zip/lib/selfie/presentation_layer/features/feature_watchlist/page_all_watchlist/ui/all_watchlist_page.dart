import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/constants/general_methods.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_all_watchlist/bloc/my_watch_list/my_watchlist_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_all_watchlist/bloc/preset_watch_list/preset_watchlist_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_all_watchlist/components/mywatchlistcomponent.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_all_watchlist/components/presetWatchListContent.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/custom_bottom_sheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_top_tab.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/watchlist/bottom_sheet/watchlist_bottomsheet.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/repo_files/watchlist/watchlist_repo.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';

class AllWatchlistPage extends StatefulWidget {
  final ServiceLocator serviceLocator;
  const AllWatchlistPage({Key? key, required this.serviceLocator})
      : super(key: key);
  @override
  _AllWatchlistPageState createState() => _AllWatchlistPageState();
}

class _AllWatchlistPageState extends State<AllWatchlistPage>
    with TickerProviderStateMixin {
  AnimationController? _controller;
  int selectedIndex = -1;
  int watchlistLimit = 10;
  bool loadingBar = false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _controller = BottomSheet.createAnimationController(this);
    _controller!.duration = const Duration(milliseconds: 400);
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    return WillPopScope(
      onWillPop: () async {
        BlocProvider.of<MyWatchlistCubit>(context)
            .onBackPressed(context: context, index: selectedIndex);
        return false;
      },
      child: Scaffold(
        appBar: PreferredSize(
            preferredSize: const Size.fromHeight(0.0),
            child: AppBar(
              elevation: 0,
              backgroundColor: customColors().backgroundPrimary,
            )),
        backgroundColor: customColors().backgroundPrimary,
        body: SafeArea(
          child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                BlocBuilder<MyWatchlistCubit, MyWatchlistState>(
                  builder: (context, state) {
                    return (state is MyWatchlistLoading)
                        ? LinearProgressIndicator(
                            minHeight: 6.0,
                            color: customColors().primary.withOpacity(0.8),
                            backgroundColor:
                                customColors().primary.withOpacity(0.2),
                            // value: controller.value,
                          )
                        : Container();
                  },
                ),
                CustomAppBarInner(
                    title: "All Watchlists",
                    onBackPressed: () {
                      BlocProvider.of<MyWatchlistCubit>(context).onBackPressed(
                          context: context, index: selectedIndex);
                    }),
                BlocBuilder<PresetWatchlistCubit, PresetWatchlistState>(
                  builder: (context, state) =>
                      BlocBuilder<MyWatchlistCubit, MyWatchlistState>(
                    builder: (context, state) => Expanded(
                        child: CustomTabBar(
                      isScrollable: true,
                      onTap: (tab) {
                        if (tab == 0) {
                          BlocProvider.of<MyWatchlistCubit>(context)
                              .refreshList();
                        } else if (tab == 1) {
                          BlocProvider.of<PresetWatchlistCubit>(context)
                              .refreshList();
                        }
                      },
                      initialSelected: GeneralMethods.isMyWatch() ? 0 : 1,
                      indicatorSize: TabBarIndicatorSize.label,
                      tabContent: [
                        "My Watchlist (${UserController.userController.watchlists.length.toString()}/${WatchlistRepository.cloudWatchRetriveResponse.watchData[0].watchlistno})",
                        "Preset Watchlist (${UserController.userController.presetWatchList.length.toString()}/6)"
                      ],
                      tabBarViewChildern: [
                        BlocConsumer<MyWatchlistCubit, MyWatchlistState>(
                          listener: (context, state) {
                            if (state is MyWatchListInitialState) {
                              if (state.errorMessage != "") {
                                ScaffoldMessenger.of(context).showSnackBar(
                                    showErrorDialogue(
                                        errorMessage: state.errorMessage));
                              }
                            }
                          },
                          builder: (context, state) {
                            if (state is MyWatchListInitialState) {
                              return Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: myWatchListContent(
                                        context: context,
                                        selectedWatch: state.selectedWatch,
                                        items: state.myWatchListItems,
                                        onTap: (int index) {
                                          selectedIndex = index;
                                          BlocProvider.of<MyWatchlistCubit>(
                                                  context)
                                              .updatelist(index);
                                        }),
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                    children: [
                                      Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 12),
                                          child: BasketButton(
                                            bordercolor: customColors().primary,
                                            bgcolor: customColors()
                                                .backgroundPrimary,
                                            text: "Manage",
                                            textStyle: customTextStyle(
                                                fontStyle: FontStyle.BodyL_Bold,
                                                color: FontColor.Primary),
                                            onpress: () {
                                              BlocProvider.of<MyWatchlistCubit>(
                                                      context)
                                                  .onManagePressed(context);
                                            },
                                            buttonwidth: width * 0.45,
                                          )),
                                      Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 12),
                                          child: BasketButton(
                                            bordercolor: transparent,
                                            enabled: (UserController
                                                    .userController
                                                    .watchlists
                                                    .length <
                                                (int.tryParse(WatchlistRepository
                                                        .cloudWatchRetriveResponse
                                                        .watchData[0]
                                                        .watchlistno) ??
                                                    watchlistLimit)),
                                            bgcolor: customColors().primary,
                                            text: "Create",
                                            textStyle: customTextStyle(
                                                fontStyle: FontStyle.BodyL_Bold,
                                                color: FontColor.White),
                                            onpress: () {
                                              customCreateModalBottomSheet(
                                                context: context,
                                                inputWidget: CreateWatchlist(
                                                  serviceLocator:
                                                      widget.serviceLocator,
                                                  onViewWatchlistPressed:
                                                      (updateIndex) {
                                                    BlocProvider.of<
                                                                MyWatchlistCubit>(
                                                            context)
                                                        .updatelist(
                                                            updateIndex!);
                                                    selectedIndex = updateIndex;
                                                    Navigator.of(context)
                                                        .pop(true);
                                                    if (updateIndex is int) {
                                                      BlocProvider.of<
                                                                  MyWatchlistCubit>(
                                                              context)
                                                          .onBackPressed(
                                                              context: context,
                                                              index:
                                                                  selectedIndex);
                                                    }
                                                  },
                                                ),
                                              );
                                            },
                                            buttonwidth: width * 0.45,
                                          )),
                                    ],
                                  )
                                ],
                              );
                            } else {
                              return Container();
                            }
                          },
                        ),
                        BlocConsumer<PresetWatchlistCubit,
                            PresetWatchlistState>(
                          listener: (context, state) {
                            if (state is PrestWatchlistInitial) {
                              if (state.errorMsg != "") {
                                ScaffoldMessenger.of(context).showSnackBar(
                                    showErrorDialogue(
                                        errorMessage: state.errorMsg));
                              }
                            }
                          },
                          builder: (context, state) {
                            if (state is PrestWatchlistInitial) {
                              return Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: presetWatchListContent(
                                        context: context,
                                        selectedWatch: state.selectedIndex,
                                        items: UserController
                                            .userController.presetWatchList,
                                        onTap: (int index) {
                                          BlocProvider.of<PresetWatchlistCubit>(
                                                  context)
                                              .updatePresetWatch(index);
                                          BlocProvider.of<PresetWatchlistCubit>(
                                                  context)
                                              .getPresetWatchlist(index);
                                        }),
                                  ),
                                  Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 12),
                                      child: BasketButton(
                                        bordercolor: transparent,
                                        bgcolor: customColors().primary,
                                        text: "Manage",
                                        textStyle: customTextStyle(
                                            fontStyle: FontStyle.BodyL_Bold,
                                            color: FontColor.White),
                                        onpress: () {
                                          BlocProvider.of<PresetWatchlistCubit>(
                                                  context)
                                              .onManagePressed(context);
                                        },
                                        buttonwidth: width * 0.94,
                                      ))
                                ],
                              );
                            }
                            if (state is PrestWatchlistInitial) {
                              return const CircularProgressIndicator(
                                backgroundColor:
                                    Color.fromARGB(255, 5, 147, 43),
                              );
                            } else {
                              return Container();
                            }
                          },
                        ),
                      ],
                    )),
                  ),
                )
              ]),
        ),
      ),
    );
  }
}

part of 'watchlist_cubit.dart';

@immutable
abstract class WatchlistState {}

class WatchlistInitial extends WatchlistState {
  final List<Instrument> feedData;
  bool isLoading;
  final String watchlistName;
  final String watchId;
  final int count;
  WatchlistInitial(
      {required this.watchlistName,
      required this.feedData,
      this.isLoading = false,
      this.watchId = "",
      this.count = 0});

  WatchlistInitial copyWith(
      {String? watchlistName,
      List<Instrument>? feedData,
      bool? isLoading,
      String? watchId,
      int? count}) {
    return WatchlistInitial(
        watchlistName: watchlistName ?? this.watchlistName,
        feedData: feedData ?? this.feedData,
        isLoading: isLoading ?? this.isLoading,
        watchId: watchId ?? this.watchId,
        count: count ?? this.count);
  }
}

class Watchlistloading extends WatchlistState {}

import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/constants/error_mapper.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/constants/general_methods.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/portfolio_model/Portfolio.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/more_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/alert_dialogs.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/user_controller/repo_files/watchlist/watchlist_repo_impl.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';
import 'package:trading_api/responses/cloud_watch_response.dart';
import 'package:trading_api/utils/utils.dart';
import 'package:trading_api/responses/get_cloud_watch_response.dart';
part 'watchlist_state.dart';

class WatchlistCubit extends Cubit<WatchlistState> {
  final TradingApiGateway tradingApiGateway;
  BuildContext context;
  List<Instrument> watchFeed = [];
  String watchId = "0";
  String watchName = "";
  int watchIndex = -1;
  int itemCount = 0;

  WatchlistCubit({required this.tradingApiGateway, required this.context})
      : super(WatchlistInitial(
          watchlistName: "",
          feedData: const [],
          isLoading: true,
        )) {
    getWatchlistData();
    MDS_Controller().mdsInit(
        tradecode: UserController().userId,
        omsSessionId: UserController().sessionKey);
  }

  openAllWatchList(String title) async {
    await context.gNavigationService.openAllWatchlistPage(context);
    getWatchlist(index: GeneralMethods.getWatchIndex());
  }

  getWatchlistData() async {
    try {
      emit((state as WatchlistInitial).copyWith(isLoading: true));
      List<WatchlistModel> listWatchlist =
          await WatchlistRepositoryImpl(gateway: tradingApiGateway)
              .retriveWatchlist(userId: UserController().userId);
      itemCount = listWatchlist.length;
      if (listWatchlist.isEmpty) {
        emit((state as WatchlistInitial).copyWith(isLoading: false, count: 0));
        return;
      }
      listWatchlist.sort((a, b) =>
          a.watchlistData.sortorder.compareTo(b.watchlistData.sortorder));
      UserController.userController.watchlists = listWatchlist;
      int selectedIndex = 0;
      selectedIndex = GeneralMethods.getWatchIndex();

      if (selectedIndex == -1) {
        UserController.userController.selectedWatchIndex = UserController
            .userController.watchlists[0].watchlistData.watchlistid;
        selectedIndex = GeneralMethods.getWatchIndex();
      }
      watchIndex = selectedIndex;

      if (GeneralMethods.isMyWatch()) {
        //When Select My Watch
        for (var i = 0; i < listWatchlist.length; i++) {
          listWatchlist[i].symbolDataList.sort((a, b) =>
              (int.tryParse(a.sortorder) ?? 0)
                  .compareTo(int.tryParse(b.sortorder) ?? 0));
        }

        getWatchlist(index: selectedIndex);
      } else {
        //When Select Preset Watch
        await getPresetWatch(
            UserController.userController.selectedWatchIndex, selectedIndex);
        getWatchlist(index: selectedIndex);
      }
    } catch (e) {
      showAlertDilogue(
          context: context,
          content: "Failed to fetch data from cloud",
          positiveButtonName: "Relogin",
          onPositiveButtonClick: () async {
            await logout(context);
          });
      // ScaffoldMessenger.of(context)
      //     .showSnackBar(showErrorDialogue(errorMessage: e.toString()));
      // CustomSnackbar()
      //     .validationSnackbar(context: context, message: e.toString());
    }
  }

  getPresetWatch(String indexKey, int index) async {
    try {
      final _response = await tradingApiGateway.symbolSearchRequest(
          indexFilter: "N",
          keyword: "",
          remarks: "",
          start: 1,
          limt: 0,
          venuCode: "",
          index: indexKey == "SENSEX" ? "S&P SENSEX" : indexKey);
      if (_response.searchresp![0].errorcode == 0) {
        for (int i = 0; i < _response.searchresp![0].reclistxmob!.length; i++) {
          UserController.userController.presetWatchList[index].symbolDataList
              .add(SymbolData(
                  instrumentType: _response
                      .searchresp![0].reclistxmob![i].insttype
                      .toString(),
                  sortorder: i.toString(),
                  symbolname: _response
                      .searchresp![0].reclistxmob![i].securitycode1
                      .toString(),
                  venuecode:
                      _response.searchresp![0].reclistxmob![i].venue.toString(),
                  venuescripcode: _response
                      .searchresp![0].reclistxmob![i].scripcode
                      .toString(),
                  watchlistid: i.toString(),
                  watchsymbolid: "",
                  ca: _response.searchresp![0].reclistxmob![i].ca ?? ""));
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
            showErrorDialogue(errorMessage: "Internal Server Error"));
        // CustomSnackbar().validationSnackbar(
        //     context: context, message: "Internal Server Error");
      }
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(showErrorDialogue(errorMessage: e.toString()));
      // CustomSnackbar()
      //     .validationSnackbar(context: context, message: e.toString());
    }
    emit((state as WatchlistInitial).copyWith(isLoading: false));
  }

  updateFromEditWatch(Map<String, dynamic> editWatch) async {
    if (!editWatch.containsKey("change")) return;
    if (editWatch["change"] != "") {
      try {
        CloudSymbolRetriveResponse _response =
            await tradingApiGateway.retrieveSymbol(
                userID: UserController().userId,
                watchlistId: int.tryParse(editWatch["change"]) ?? 0);
        if (_response.errorCode == "0") {
          _response.symbolData.sort(((a, b) =>
              int.parse(a.sortorder).compareTo(int.parse(a.sortorder))));
          UserController.userController.watchlists[watchIndex].symbolDataList =
              _response.symbolData;
          updateEditedData(
              model: UserController.userController.watchlists[watchIndex]);
        } else {
          ScaffoldMessenger.of(context).clearSnackBars();
          ScaffoldMessenger.of(context).showSnackBar(
              showErrorDialogue(errorMessage: errorMap[_response.errorCode].toString()));
        }
      } catch (exeption) {
        ScaffoldMessenger.of(context).clearSnackBars();
        ScaffoldMessenger.of(context)
            .showSnackBar(showErrorDialogue(errorMessage: exeption.toString()));
      }
    }
  }

  updateEditedData({required WatchlistModel model}) async {
    MDS_Controller().unsubscribeSymbols(watchFeed);
    watchFeed.clear();
    for (var i = 0; i < model.symbolDataList.length; i++) {
      watchFeed.add(model.symbolDataList[i].getInstrument);
    }
    // MDS_Controller().subscribeSymbols(feed);
    emit(WatchlistInitial(
      watchlistName: model.watchlistData.watchname,
      watchId: model.watchlistData.watchlistid,
      feedData: watchFeed,
    ));
  }

  getWatchlist({required int index}) {
    if (GeneralMethods.getWatchIndex() == -1) {
      UserController.userController.selectedWatchIndex =
          UserController.userController.watchlists[0].watchlistData.watchlistid;
      index = GeneralMethods.getWatchIndex();
    }
    watchIndex = index;
    List<WatchlistModel> watchlists = [];
    if (GeneralMethods.isMyWatch()) {
      watchlists = UserController.userController.watchlists;
      watchName = UserController
          .userController.watchlists[index].watchlistData.watchname;
      watchId = UserController
          .userController.watchlists[index].watchlistData.watchlistid;
    } else if (GeneralMethods.isMyWatch() == false) {
      watchlists = UserController.userController.presetWatchList;
      watchName = UserController
          .userController.presetWatchList[index].watchlistData.watchname;
      watchId = UserController
          .userController.presetWatchList[index].watchlistData.watchlistid;
    }
    watchFeed = List.generate(watchlists[index].symbolDataList.length,
        (i) => watchlists[index].symbolDataList[i].getInstrument);
    // feed = watchlists[index].generateSymbolData().values.toList();
    itemCount = watchFeed.length;
    return emit(WatchlistInitial(
      watchlistName: watchName,
      watchId: watchId,
      feedData: watchFeed,
      count: itemCount,
    ));
  }
}

extension on SymbolData {
  Instrument get getInstrument => Instrument(
      scripcode: venuescripcode,
      securityCode: symbolname,
      securityName: symbolname,
      series: "",
      venueIndex: getVenueIndex(venuecode),
      type: instrumentType,
      ca: ca,
      subscriptionType: SubscriptionType.watch);
}

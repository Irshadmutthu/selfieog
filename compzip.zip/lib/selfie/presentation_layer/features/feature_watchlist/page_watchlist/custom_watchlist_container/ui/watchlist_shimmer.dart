import 'package:flutter/material.dart';

import '../../../../../../../theme/styles.dart';
import '../../../../../../../utils/shimmer_loader.dart';

class WatchlistShimmer extends StatelessWidget {
  const WatchlistShimmer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        shrinkWrap: true,
        itemCount: 5,
        itemBuilder: (context, index) {
          return Container(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
            child: Column(
              children: [
                Row(
                  children: [
                    Wrap(
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [ShimmerLoader(height: 20.0, width: 100.0)],
                    ),
                  ],
                ),
                SizedBox(
                  height: 8,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        ShimmerLoader(height: 20.0, width: 50.0),
                      ],
                    ),
                    ShimmerLoader(height: 20.0, width: 30.0)
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 16),
                  child: Container(
                    color: customColors().backgroundTertiary,
                    height: 1,
                  ),
                )
              ],
            ),
          );
        });
  }
}

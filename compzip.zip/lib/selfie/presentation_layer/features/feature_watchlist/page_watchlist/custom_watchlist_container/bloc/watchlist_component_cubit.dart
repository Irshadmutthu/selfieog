import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/constants/general_methods.dart';
import 'package:selfie_mobile_flutter/global_methods/global_methods.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/model/watch_sort_model.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/bloc_navigation/navigation_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_watchlist/bloc/watchlist_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/watchlist_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/delete_watchlist.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
part 'watchlist_component_state.dart';

Map<String, Instrument> watchSymbols = {};
Map<String, dynamic> fromPage = {
  "Page": "watchlist",
  "watchId": 0,
  "watchSymbols": watchSymbols,
};

class WatchlistComponetCubit extends Cubit<WatchlistComponetState> {
  Map<String, dynamic> heatmaplist1 = {
    "item0": {
      "name": "Above 2%",
      "ratio": "",
      "color": customColors().green1,
      "inneritems": []
    },
    "item1": {
      "name": "Gain from .5% to 2% ",
      "ratio": "",
      "color": customColors().green2,
      "inneritems": []
    },
    "item2": {
      "name": "Gain from 0 to .5%",
      "ratio": "",
      "color": customColors().green3,
      "inneritems": []
    },
    "item3": {
      "name": "Decline from 0 to .5%",
      "ratio": "",
      "color": customColors().red3,
      "inneritems": []
    },
    "item4": {
      "name": "Decline from .5% to 2% ",
      "ratio": "",
      "color": customColors().red2,
      "inneritems": []
    },
    "item5": {
      "name": "Decline above 2",
      "ratio": "",
      "color": customColors().red1,
      "inneritems": []
    },
  };
  List<String> defaultSortOrder = [];
  List<String> sortOrder = [];
  List<Instrument> feedList;
  BuildContext context;
  StreamSubscription? streamSubscription;
  bool sorted = false;
  String watchKey = "0";
  WatchlistComponetCubit(this.feedList, this.context)
      : super(Watchlistloadingstate()) {
    // feedMap.clear();
    // feedList.clear();
    getDefaultSortOrder;
    updateWatchKey(context);
    updateGridState();
    context.read<NavigationCubit>().adcontroller.stream.listen((event) {
      if (!isClosed) {
        if (event != 0) {
          unsubscribeSymbols();
        } else {
          subscribeSymbols();
          updateSort();
        }
      }
    });
  }

  updateWatchKey(BuildContext context) {
    watchKey = BlocProvider.of<WatchlistCubit>(context).watchId;
    if (watchKey == "0") {
      watchKey = BlocProvider.of<WatchlistCubit>(context).watchName;
    }
  }

  subscribeSymbols() {
    if (feedList.isEmpty || isClosed) return;
    MDS_Controller().subscribeSymbols(feedList);
    streamSubscription = MDS_Controller()
        .marketUpdateStream
        .listen((List<FlairResponseModel> flairResponseModel) {
      updateItemOfList(flairResponseModel);
    });
  }

  unsubscribeSymbols() {
    if (feedList.isEmpty) return;
    MDS_Controller().unsubscribeSymbols(feedList);
  }

  openEditWatchList(BuildContext context) async {
    await context.gNavigationService.openEditWatchlistPage(context, {"": 0});
    updateSort();
  }

  openSearch(BuildContext context) async {
    watchSymbols.clear();
    for (Instrument element in feedList) {
      watchSymbols[element.venueIndex.toString() +
          "_" +
          element.scripcode.toString()] = element;
    }

    fromPage["watchSymbols"] = watchSymbols;

    await context.gNavigationService.openSymbolSearch(context, fromPage);

    BlocProvider.of<WatchlistCubit>(context)
        .getWatchlist(index: GeneralMethods.getWatchIndex());
  }

  openHeatMap() {
    updateHeatMap(feedList);
  }

  updateItemOfList(List<FlairResponseModel> data) {
    if (isClosed) {
      if (streamSubscription != null) streamSubscription!.cancel();
      return;
    }
    if (state is GridState) {
      updateSort();
    } else if (state is HeatMapState) {
      updateHeatMap(feedList);
    }
  }

  List<String> get getDefaultSortOrder => defaultSortOrder = List.generate(
      feedList.length, (index) => feedList[index].getRicAddress());

  List<String> get getSortOrder => sortOrder = List.generate(
      feedList.length, (index) => feedList[index].getRicAddress());

  updateSortOrder(int index) {
    watchSortMap[watchKey] = watchSortMap[watchKey] ?? WatchSortModel();
    watchSortMap[watchKey]!.setSortId = index;
    sorted = index != -1;
    feedList = getsortlist(feedList, index, sortOrder: defaultSortOrder);
    watchSortMap[watchKey]!.setSortOrder = getSortOrder;
    updateGridState();
  }

  int getSortId() {
    int id = -1;
    sortOrder = [];
    if (watchSortMap[watchKey] != null) {
      id = watchSortMap[watchKey]!.getSortId;
      sortOrder = watchSortMap[watchKey]!.getSortOrder;
    }
    sorted = id != -1;
    return id;
  }

  refreshData(BuildContext context, List<Instrument> feed) {
    updateData(feed);
    unsubscribeSymbols();
    subscribeSymbols();
    updateWatchKey(context);
    if (state is GridState) {
      updateSort();
    }
  }

  updateSort() {
    getSortId();
    feedList = getsortlist(feedList, -1, sortOrder: sortOrder);
    updateGridState();
  }

  openGrid() {
    updateSort();
  }

  updateData(List<Instrument> list) {
    if (isClosed) return;
    feedList = list;
    getDefaultSortOrder;
    updateGridState();
  }

  updateHeatMap(List<Instrument> list) {
    List<Instrument> data1 = [];
    List<Instrument> data2 = [];
    List<Instrument> data3 = [];
    List<Instrument> data4 = [];
    List<Instrument> data5 = [];
    List<Instrument> data6 = [];
    list.sort((a, b) => b.percChange.compareTo(a.percChange));
    for (int i = 0; i < list.length; i++) {
      if (list[i].percChange > 2) {
        data1.add(list[i]);
      } else if (list[i].percChange >= 0.5 && list[i].percChange <= 2) {
        data2.add(list[i]);
      } else if (list[i].percChange >= 0.0 && list[i].percChange < 0.5) {
        data3.add(list[i]);
      } else if (list[i].percChange < 0.0 && list[i].percChange > -0.5) {
        data4.add(list[i]);
      } else if (list[i].percChange <= -0.5 && list[i].percChange >= -2) {
        data5.add(list[i]);
      } else {
        //if (list[i].percChange < -2)
        data6.add(list[i]);
      }
    }
    heatmaplist1.addAll({
      "item0": {
        "name": "Above 2%",
        "ratio": "  (${data1.length}/50)",
        "color": customColors().green1,
        "inneritems": data1
      }
    });
    heatmaplist1.addAll({
      "item1": {
        "name": "Gain from .5% to 2% ",
        "ratio": "  (${data2.length}/50)",
        "color": customColors().green2,
        "inneritems": data2
      },
    });
    heatmaplist1.addAll({
      "item2": {
        "name": "Gain from 0 to .5%",
        "ratio": "  (${data3.length}/50)",
        "color": customColors().green3,
        "inneritems": data3
      },
    });
    heatmaplist1.addAll({
      "item3": {
        "name": "Decline from 0 to .5%",
        "ratio": "  (${data4.length}/50)",
        "color": customColors().red3,
        "inneritems": data4
      },
    });
    heatmaplist1.addAll({
      "item4": {
        "name": "Decline from .5% to 2% ",
        "ratio": "  (${data5.length}/50)",
        "color": customColors().red2,
        "inneritems": data5
      },
    });
    heatmaplist1.addAll({
      "item5": {
        "name": "Decline above 2",
        "ratio": "  (${data6.length}/50)",
        "color": customColors().red1,
        "inneritems": data6
      }
    });

    emit(HeatMapState(heatmaplist1: heatmaplist1));
  }

  updateGridState() {
    emit(GridState(items: feedList, sorted: sorted));
  }
}

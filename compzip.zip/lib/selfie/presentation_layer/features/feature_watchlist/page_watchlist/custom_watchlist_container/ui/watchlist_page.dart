import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/constants/general_methods.dart';
import 'package:selfie_mobile_flutter/global_methods/global_methods.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_watchlist/bloc/watchlist_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_watchlist/custom_watchlist_container/bloc/watchlist_component_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_watchlist/watchlist_components/indices/custom_indices_list.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_watchlist/watchlist_components/indices/indices_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_watchlist/watchlist_screen.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/watchlist_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/custom_image_button.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/sort.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/watchlist/custom_watchlist_content/custom_watchlist_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/watchlist/heatmaplist/heatmap_list_item.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/user_controller/repo_files/watchlist/watchlist_repo.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';

class WatchlistContainer extends StatefulWidget {
  const WatchlistContainer({
    Key? key,
  }) : super(key: key);

  @override
  State<WatchlistContainer> createState() => _WatchlistContainerState();
}

class _WatchlistContainerState extends State<WatchlistContainer>
    with TickerProviderStateMixin {
  late AnimationController _controller;
  _WatchlistContainerState();

  Map<String, dynamic> returnArgs = {"EditedWatchlist": ""};

  ScrollController scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _controller = BottomSheet.createAnimationController(this);
    _controller.duration = const Duration(milliseconds: 400);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      controller: scrollController,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          BlocListener<WatchlistCubit, WatchlistState>(
            listener: (context, state) {
              if (state is WatchlistInitial) {
                BlocProvider.of<WatchlistComponetCubit>(context)
                    .refreshData(context, state.feedData);
              }
            },
            child: Container(),
          ),
          UserSettings.userSettings.otherSettings.indexVisibility
              ? BlocProvider(
                  create: (context) => IndicesCubit(),
                  child: CustomIndicesList(
                      onTap: () async {
                        await context.gNavigationService
                            .openSettingOthersPage(context);
                        setState(() {});
                      },
                      actionWidget: const ImageIcon(
                        AssetImage("assets/settings.png"),
                        size: 24,
                      )),
                )
              : Container(),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                searchField(context, () {
                  if (GeneralMethods.isMyWatch()) {
                    context.read<WatchlistComponetCubit>().openSearch(context);
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                      content: Text(
                          "You are not allowed to add security to preset watchlist"),
                    ));
                  }
                }),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: BlocBuilder<WatchlistComponetCubit,
                      WatchlistComponetState>(
                    builder: (context, state) {
                      if (state is GridState) {
                        return CustomImageButton(
                            imagePath: "assets/sort.png",
                            color: customColors().fontPrimary,
                            showBubble: state.sorted,
                            onTap: () {
                              customShowModalBottomSheet(
                                context: context,
                                inputWidget: SortList(
                                  currentIndex:
                                      BlocProvider.of<WatchlistComponetCubit>(
                                              context)
                                          .getSortId(),
                                  onresetPress: () {
                                    BlocProvider.of<WatchlistComponetCubit>(
                                            context)
                                        .updateSortOrder(-1); //-1 for reset
                                    Navigator.pop(context);
                                    setState(() {});
                                  },
                                  onChangeEffect: (int index) {
                                    BlocProvider.of<WatchlistComponetCubit>(
                                            context)
                                        .updateSortOrder(index);
                                    Navigator.pop(context);
                                    setState(() {});
                                  },
                                ),
                                controller: _controller,
                              );
                            });
                      } else {
                        return CustomImageButton(
                            imagePath: "assets/sort.png",
                            color: customColors().fontPrimary.withOpacity(.4),
                            showBubble: false,
                            onTap: () {});
                      }
                    },
                  ),
                ),
                BlocBuilder<WatchlistComponetCubit, WatchlistComponetState>(
                    builder: (context, state) {
                  if (state is GridState) {
                    return CustomImageButton(
                        imagePath: "assets/grid.png",
                        onTap: () {
                          BlocProvider.of<WatchlistComponetCubit>(context)
                              .openHeatMap();
                        });
                  } else if (state is HeatMapState) {
                    return CustomImageButton(
                        imagePath: "assets/list.png",
                        onTap: () {
                          BlocProvider.of<WatchlistComponetCubit>(context)
                              .openGrid();
                        });
                  } else {
                    return Container();
                  }
                }),
              ],
            ),
          ),
          GestureDetector(
            onLongPress: () async {
              if (GeneralMethods.isMyWatch()) {
                returnArgs = await context.gNavigationService
                        .openEditWatchlistPage(context, {
                      "watchlist":
                          BlocProvider.of<WatchlistCubit>(context).watchIndex,
                      "sortOrder":
                          BlocProvider.of<WatchlistComponetCubit>(context)
                              .sortOrder,
                    }) ??
                    {};
                BlocProvider.of<WatchlistCubit>(context)
                    .updateFromEditWatch(returnArgs);
              }
            },
            child: BlocBuilder<WatchlistCubit, WatchlistState>(
              builder: (context, state) {
                if (state is WatchlistInitial && state.isLoading) {
                  return ListShimmer;
                }
                return BlocBuilder<WatchlistComponetCubit,
                    WatchlistComponetState>(builder: (context, state) {
                  if (state is GridState) {
                    return state.items.isEmpty
                        ? emptyContainerWatchlist(context)
                        : CustomWatchlistContent(
                            dataList: state.items,
                            onTapItem: (Instrument data) {
                              if (data.type != "") {
                                context.gNavigationService
                                    .openIndividualStockPage(
                                        context, {"StockDetails": data});
                              } else {
                                context.gNavigationService.openIndexDetailPage(
                                    context, {"StockDetails": data});
                              }
                            });
                  } else if (state is HeatMapState) {
                    return InkWell(
                        highlightColor: transparent,
                        focusColor: transparent,
                        splashColor: transparent,
                        onLongPress: () {},
                        child: const HeatMapListItem());
                  } else {
                    return Container();
                  }
                });
              },
            ),
          ),
          Container(),
        ],
      ),
    );
  }
}

searchField(BuildContext context, void Function() onTap) {
  return GestureDetector(
    onTap: onTap,
    child: Container(
      height: 48,
      width: MediaQuery.of(context).size.width * 0.6,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4),
        color: customColors().backgroundSecondary,
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Align(
        alignment: Alignment.center,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            ImageIcon(
              const AssetImage("assets/searchicon.png"),
              color: customColors().fontPrimary,
            ),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 8),
                    child: Text("Search & Add",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_Regular,
                            color: FontColor.FontSecondary)),
                  ),
                  BlocBuilder<WatchlistCubit, WatchlistState>(
                      builder: (context, state) {
                    if (state is WatchlistInitial) {
                      return GeneralMethods.isMyWatch()
                          ? Text(
                              state.count.toString() +
                                  "/" +
                                  (WatchlistRepository.cloudWatchRetriveResponse
                                          .watchData.isNotEmpty
                                      ? WatchlistRepository
                                          .cloudWatchRetriveResponse
                                          .watchData[0]
                                          .symbolno
                                      : "0"),
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: customColors().fontSecondary,
                                  fontSize: 12))
                          : const SizedBox();
                    }
                    return Container();
                  })
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

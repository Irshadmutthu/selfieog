part of 'watchlist_component_cubit.dart';

@immutable
abstract class WatchlistComponetState {}

class GridState extends WatchlistComponetState {
  final List<Instrument> items;
  final bool sorted;
  GridState({required this.items, required this.sorted});

  GridState copyWith({List<Instrument>? items, bool? sorted}) {
    return GridState(items: items ?? this.items, sorted: sorted ?? this.sorted);
  }
}

class HeatMapState extends WatchlistComponetState {
  // final List<Instrument> items;
  Map<String, dynamic> heatmaplist1;
  HeatMapState({required this.heatmaplist1});
}

class Watchlistloadingstate extends WatchlistComponetState {}

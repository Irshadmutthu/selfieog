import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_watchlist/bloc/watchlist_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_watchlist/custom_watchlist_container/bloc/watchlist_component_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_watchlist/custom_watchlist_container/ui/watchlist_page.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarMain.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/watchlist/market_overview.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/utils/shimmer_loader.dart';

class WatchlistScreen extends StatefulWidget {
  const WatchlistScreen({Key? key}) : super(key: key);

  @override
  State<WatchlistScreen> createState() => _WatchlistScreenState();
}

class _WatchlistScreenState extends State<WatchlistScreen>
    with TickerProviderStateMixin {
  late AnimationController _controller;
  bool notify = false;

  @override
  void initState() {
    _controller = BottomSheet.createAnimationController(this);
    _controller.duration = const Duration(milliseconds: 400);
    // BlocProvider.of<WatchlistCubit>(context).getWatchlistData();
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  togleSort() {
    setState(() {
      notify = !notify;
    });
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<WatchlistCubit, WatchlistState>(
        builder: (context, state) {
      if (state is WatchlistInitial) {
        return Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: SizedBox(
                  height: 58,
                  child: CustomAppBarMain(
                      title: state.watchlistName,
                      endIcon: InkWell(
                        highlightColor: transparent,
                        splashColor: transparent,
                        onTap: () {
                          customBottomSheet(
                              controller: _controller,
                              height: .9,
                              minimumHeight: .7,
                              context: context,
                              inputWidget: MarKetOverview());
                        },
                        child: const Padding(
                          padding: EdgeInsets.all(16),
                          child: ImageIcon(
                            AssetImage("assets/frame.png"),
                            size: 24,
                          ),
                        ),
                      ),
                      showTitleButton: true,
                      onTapTitle: () {
                        BlocProvider.of<WatchlistCubit>(context)
                            .openAllWatchList("");
                      }),
                ),
              ),
              Expanded(
                flex: 1,
                child: BlocProvider<WatchlistComponetCubit>(
                  create: (context) =>
                      WatchlistComponetCubit(state.feedData, context),
                  child: WatchlistContainer(),
                ),
              ),
            ]);
      }
      return Container();
    });
  }
}

Widget get ListShimmer => ListView.builder(
    shrinkWrap: true,
    physics: const NeverScrollableScrollPhysics(),
    itemCount: 10,
    itemBuilder: (context, index) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          // decoration: BoxDecoration(
          //     border: Border(
          //   bottom: BorderSide(
          //       color: customColors().backgroundTertiary, width: 1),
          // )),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Visibility(
                // visible: widget.closedList.containsKey("topview"),
                visible: true,
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Row(
                        children: [
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 0.0),
                            child: ShimmerLoader(height: 10, width: 20),
                          ),
                          SizedBox(
                            width: 6,
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 0.0),
                            child: ShimmerLoader(height: 10, width: 20),
                          ),
                        ],
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          ShimmerLoader(height: 10, width: 20),
                          const Padding(
                            padding: EdgeInsets.only(left: 6.0, right: 6.0),
                            child: SizedBox(),
                          ),
                          // CustomDotSeparator(),
                          ShimmerLoader(height: 10, width: 20)
                        ],
                      )
                    ]),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      ShimmerLoader(height: 15, width: 130),
                      ShimmerLoader(height: 15, width: 50),
                    ]),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 4.0),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      ShimmerLoader(height: 10, width: 20),
                      ShimmerLoader(height: 10, width: 20)
                    ]),
              ),
            ],
          ),
        ),
      );
    });

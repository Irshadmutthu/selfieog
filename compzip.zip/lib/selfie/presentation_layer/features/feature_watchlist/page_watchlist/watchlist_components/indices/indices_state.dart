part of 'indices_cubit.dart';

@immutable
abstract class IndicesState {}

class IndicesInitial extends IndicesState {
  List<Instrument> feed;
  IndicesInitial({required this.feed});
}

import 'dart:async';
import 'dart:developer';

import 'package:bloc/bloc.dart';
import 'package:intl/intl.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/get_cloud_watch_response.dart';
import 'package:trading_api/utils/utils.dart';

part 'indices_state.dart';

class IndicesCubit extends Cubit<IndicesState> {
  List<SymbolData> symbolData = [];
  List<Instrument> feed = [];
  late StreamSubscription streamSubscription;
  late StreamSubscription subscription;
  IndicesCubit() : super(IndicesInitial(feed: [])) {
    subscription = UserController().stream.listen((event) {
      if (event == "indexList update") getIndices();
    });
    getIndices();
  }

  getIndices() {
    try {
      if (UserController().indexInstruments.isEmpty) return;
      feed.clear();
      for (var i = 0; i < 2; i++) {
        feed.add(UserController().indexInstruments[i]);
      }
      streamSubscription = MDS_Controller()
          .marketUpdateStream
          .listen((List<FlairResponseModel> flairResponseModel) {
        updateItemOfList();
      });
      MDS_Controller().getLatestFeedUpdates(feed);
      if (!isClosed) emit(IndicesInitial(feed: feed));
    } catch (e) {
      log("exception caught in getIndices", error: e);
    }
  }

  unsubscribe() {
    if (feed.isEmpty) return;
    MDS_Controller().unsubscribeSymbols(feed);
  }

  updateItemOfList() {
    if (isClosed) {
      streamSubscription.cancel();
      subscription.cancel();
      return;
    }
    emit(IndicesInitial(feed: feed));
  }
}

extension on SymbolData {
  Instrument get getInstrument => Instrument(
      scripcode: venuescripcode,
      securityCode: symbolname,
      securityName: symbolname,
      series: "",
      venueIndex: getVenueIndex(venuecode),
      type: instrumentType,
      ca: ca,
      subscriptionType: SubscriptionType.watch);
}

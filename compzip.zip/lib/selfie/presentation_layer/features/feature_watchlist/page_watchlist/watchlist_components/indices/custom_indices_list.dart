import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_watchlist/watchlist_components/indices/indices_cubit.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class CustomIndicesList extends StatelessWidget {
  final Widget actionWidget;
  final Function()? onTap;
  const CustomIndicesList(
      {Key? key, this.actionWidget = const SizedBox(), this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: customColors().backgroundSecondary,
      height: 70,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: BlocBuilder<IndicesCubit, IndicesState>(
        builder: (context, state) {
          if (state is IndicesInitial) {
            return Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: List.generate(state.feed.length, (index) {
                          int precision = state.feed[index].precision;
                          int todayChange = state.feed[index].changePrice > 0
                              ? 1
                              : state.feed[index].changePrice < 0
                                  ? -1
                                  : 0;
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(state.feed[index].securityCode,
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyM_SemiBold,
                                      color: FontColor.FontPrimary)),
                              const SizedBox(height: 4),
                              RichText(
                                text: TextSpan(
                                  text: state.feed[index].lastTrdPrice
                                      .toStringAsFixed(
                                          state.feed[index].precision),
                                  // style: DefaultTextStyle.of(context).style,
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_SemiBold,
                                      color: todayChange > 0
                                          ? FontColor.Success
                                          : todayChange < 0
                                              ? FontColor.Danger
                                              : FontColor.FontSecondary),
                                  children: <TextSpan>[
                                    TextSpan(
                                        text:
                                            "  (${todayChange > 0 ? "+" : ""}${state.feed[index].percChange.toStringAsFixed(precision)}%)",
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyM_Regular,
                                            color: FontColor.FontSecondary)),
                                  ],
                                ),
                              ),
                            ],
                          );
                        })),
                  ),
                  InkWell(
                    splashColor: transparent,
                    focusColor: transparent,
                    onTap: onTap,
                    child: SizedBox(
                      width: 70.0,
                      child: Align(
                          alignment: Alignment.centerRight,
                          child: actionWidget),
                    ),
                  )
                ]);
            // return ListView.separated(
            //   separatorBuilder: (context, index) {
            //     return const SizedBox(width: 30.0);
            //   },
            //     physics: const NeverScrollableScrollPhysics(),
            //     scrollDirection: Axis.horizontal,
            //     itemCount: state.feed.length,
            //     itemBuilder: (context, index) {

            //       return
            //     });
            // return Row(
            //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //   crossAxisAlignment: CrossAxisAlignment.center,
            //   children: [

            //     Column(
            //       crossAxisAlignment: CrossAxisAlignment.start,
            //       mainAxisAlignment: MainAxisAlignment.center,
            //       children: [
            //         Text(
            //           "${(inputData[1]["dataHeadding"] ?? "")}",
            //           style: customTextStyle(
            //               fontStyle: FontStyle.BodyM_SemiBold,
            //               color: FontColor.FontPrimary),
            //         ),
            //         const SizedBox(height: 4),
            //         RichText(
            //           text: TextSpan(
            //             text: (inputData[1]["value"] != null)
            //                 ? Formats.valueFormat.format(inputData[1]["value"])
            //                 : '0',
            //             style: valueStyle(context, inputData[1]["value"] ?? 0),
            //             children: <TextSpan>[
            //               TextSpan(
            //                   text:
            //                       '  (${(inputData[1]["margin"] != null && inputData[1]["margin"] > 0 ? "+" : "")}${(inputData[1]["margin"] ?? "")}%)',
            //                   style: customTextStyle(
            //                       fontStyle: FontStyle.BodyM_Regular,
            //                       color: FontColor.FontSecondary)),
            //             ],
            //           ),
            //         ),
            //       ],
            //     ),

            //   ],
            // );

          }
          return Container();
        },
      ),
    );
  }
}

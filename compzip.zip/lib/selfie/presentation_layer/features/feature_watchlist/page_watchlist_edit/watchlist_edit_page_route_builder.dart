import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_watchlist_edit/bloc/watchlistedit_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_watchlist_edit/watchlist_edit_page.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';

class WatchlistEditPageRouteBuilder {
  final ServiceLocator _serviceLocator;
  final Map<String, dynamic> data;

  WatchlistEditPageRouteBuilder(this._serviceLocator, this.data);

  Widget call(BuildContext context) {
    return MultiBlocProvider(
        providers: [
          BlocProvider(
              create: (context) => WatchlisteditCubit(
                  serviceLocator: _serviceLocator,
                  watchlistDetails:
                      UserController().watchlists[data["watchlist"] as int],
                  sortOrder: data["sortOrder"] ?? [])),
        ],
        child: MultiRepositoryProvider(providers: [
          RepositoryProvider.value(value: _serviceLocator.navigationService),
          RepositoryProvider<CubitsLocator>.value(value: _serviceLocator),
        ], child: WatchlistEditPage()));
  }
}

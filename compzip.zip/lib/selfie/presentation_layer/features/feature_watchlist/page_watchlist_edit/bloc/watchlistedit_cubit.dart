import 'dart:developer';
import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/enums.dart';
import 'package:selfie_mobile_flutter/constants/error_mapper.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/model/watch_sort_model.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/watchlist_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/delete_watchlist.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/error_response.dart';
import 'package:trading_api/responses/get_cloud_watch_response.dart';
import 'package:trading_api/utils/utils.dart';

part 'watchlistedit_state.dart';

class WatchlisteditCubit extends Cubit<WatchlisteditState> {
  GlobalKey<FormState> formKey = GlobalKey<FormState>();
  final ServiceLocator serviceLocator;
  final WatchlistModel watchlistDetails;
  late WatchlistModel watchlistDetailscopy;
  TextEditingController textfieldcontroller = TextEditingController(text: "");
  bool rename = false;
  bool deleteOrsort = false;
  bool _isLoading = false;
  bool _isSelected = false;
  int selectedCount = 0;
  String watchName = "";
  String watchId = "";
  String watchNameCopy = "";
  String errorMsg = "";
  List<bool> statusList = [];
  List<String> sortOrder = [];
  WatchlisteditCubit(
      {required this.serviceLocator,
      required this.watchlistDetails,
      required this.sortOrder})
      : super(WatchlisteditLoading()) {
    watchlistDetailscopy = watchlistDetails.copyWith();
    watchName = watchlistDetails.watchlistData.watchname;
    watchId = watchlistDetails.watchlistData.watchlistid;
    watchNameCopy = watchName;
    textfieldcontroller.text = watchName;
    List<SymbolData> items = watchlistDetailscopy.symbolDataList;
    List<SymbolData> temp = [];
    try {
      for (var ric in sortOrder) {
        for (var symbol in items) {
          String _ric = generateRIC_Address(
              scripCode: symbol.venuescripcode,
              venueIndex: getVenueIndex(symbol.venuecode),
              type: 1);
          if (ric == _ric) {
            temp.add(symbol);
            items.remove(symbol);
            break;
          }
        }
      }
      temp.addAll(items);
      items = temp;
    } catch (e) {
      print("exception caught $e");
    }
    statusList = List.generate(items.length, (index) => false);
    watchlistDetailscopy.symbolDataList = items;

    emit(WatchlisteditInitial(
        watchlistModel: watchlistDetailscopy,
        isLoading: _isLoading,
        isSelected: _isSelected,
        watchName: watchName,
        statusList: statusList,
        errorMsg: ""));
  }

  editWatchName(String name) {
    watchName = name;
    rename = (watchName != watchNameCopy);
  }

  selectItem({required bool selected, required int index}) {
    if (selected) {
      statusList[index] = true;
      selectedCount += 1;
      _isSelected = selectedCount == statusList.length;
      emit(WatchlisteditInitial(
          watchlistModel: watchlistDetailscopy,
          isLoading: _isLoading,
          isSelected: _isSelected,
          watchName: watchName,
          statusList: statusList,
          errorMsg: ""));
    } else {
      statusList[index] = false;
      selectedCount -= 1;
      _isSelected = selectedCount == statusList.length;
      emit(WatchlisteditInitial(
          watchlistModel: watchlistDetailscopy,
          isLoading: _isLoading,
          isSelected: _isSelected,
          watchName: watchName,
          statusList: statusList,
          errorMsg: ""));
    }
  }

  selectAllSymbols(bool selected) {
    _isSelected = selected;
    selected
        ? selectedCount = watchlistDetailscopy.symbolDataList.length
        : selectedCount = 0;
    for (int i = 0; i < watchlistDetailscopy.symbolDataList.length; i++) {
      selected ? statusList[i] = true : statusList[i] = false;
    }
    emit(WatchlisteditInitial(
        watchlistModel: watchlistDetailscopy,
        isLoading: _isLoading,
        isSelected: _isSelected,
        watchName: watchName,
        statusList: statusList,
        errorMsg: ""));
  }

  onReoder(int oldIndex, int newIndex) {
    deleteOrsort = true;
    if (newIndex > oldIndex) {
      newIndex -= 1;
    }
    final item = watchlistDetailscopy.symbolDataList.removeAt(oldIndex);
    watchlistDetailscopy.symbolDataList.insert(newIndex, item);

    final status = statusList.removeAt(oldIndex);
    statusList.insert(newIndex, status);
    emit(WatchlisteditInitial(
        watchlistModel: watchlistDetailscopy,
        isLoading: _isLoading,
        isSelected: _isSelected,
        watchName: watchName,
        statusList: statusList,
        errorMsg: ""));
  }

  discardChanges() {
    rename = false;
    deleteOrsort = false;
    watchlistDetailscopy = watchlistDetails.copyWith();
  }

  Future<bool> updateCloudWatchNameWithSymbols() async {
    if (watchSortMap.containsKey(watchlistDetails.watchlistData.watchlistid)) {
      watchSortMap[watchId] = WatchSortModel();
    }
    try {
      _isLoading = true;
      String _symList = " ";
      String _sortList = " ";
      int _watchId = 0;
      emit(WatchlisteditInitial(
          watchlistModel: watchlistDetailscopy,
          isLoading: _isLoading,
          isSelected: _isSelected,
          watchName: watchName,
          statusList: statusList,
          errorMsg: ""));
      _watchId =
          int.tryParse(watchlistDetailscopy.watchlistData.watchlistid) ?? 0;
      int _len = watchlistDetailscopy.symbolDataList.length;
      for (int i = 0; i < _len; i++) {
        _symList = _symList +
            watchlistDetailscopy.symbolDataList[i].watchsymbolid +
            "|";
        _sortList = _sortList + (i + 1).toString() + "|";
      }

      final _result = await serviceLocator.tradingApi
          .renameWatchListWithSymbolList(
              userID: UserController().userId,
              watchName: watchName,
              sortOrderList: _sortList,
              watchlistId: _watchId,
              symbolList: _symList);
      ErrorResponse obj = errorResponseFromJson(_result.toString());
      _isLoading = false;
      if (obj.errorCode == "0") {
        watchlistDetails.watchlistData.watchname = watchName;
        rename = false;
        deleteOrsort = false;
        return true;
      } else {
        emit(WatchlisteditInitial(
            watchlistModel: watchlistDetailscopy,
            isLoading: _isLoading,
            isSelected: _isSelected,
            statusList: statusList,
            watchName: watchName,
            errorMsg: errorMap[obj.errorCode].toString()));
        return false;
      }
    } catch (e) {
      _isLoading = false;
      emit(WatchlisteditInitial(
          watchlistModel: watchlistDetailscopy,
          isLoading: _isLoading,
          isSelected: _isSelected,
          statusList: statusList,
          watchName: watchName,
          errorMsg: e.toString()));
      log(e.toString(), time: DateTime.now());
      return false;
    }
  }

  Future<bool> updateWatchName() async {
    try {
      _isLoading = true;
      int _watchId = 0;
      _watchId =
          int.tryParse(watchlistDetailscopy.watchlistData.watchlistid) ?? 0;
      final _result = await serviceLocator.tradingApi.renameCloudWatchListData(
          userID: UserController().userId,
          watchName: watchName,
          watchlistId: _watchId);
      ErrorResponse obj = errorResponseFromJson(_result.toString());
      _isLoading = false;
      if (obj.errorCode == "0") {
        watchlistDetails.watchlistData.watchname = watchName;
        rename = false;
        return true;
      } else {
        emit(WatchlisteditInitial(
            watchlistModel: watchlistDetailscopy,
            isLoading: _isLoading,
            isSelected: _isSelected,
            statusList: statusList,
            watchName: watchName,
            errorMsg: errorMap[obj.errorCode].toString()));
        return false;
      }
    } catch (e) {
      _isLoading = false;
      emit(WatchlisteditInitial(
          watchlistModel: watchlistDetailscopy,
          isLoading: _isLoading,
          isSelected: _isSelected,
          statusList: statusList,
          watchName: watchName,
          errorMsg: e.toString()));
      log(e.toString(), time: DateTime.now());
      return false;
    }
  }

  deleteItems() {
    if (watchlistDetailscopy.symbolDataList.isNotEmpty) {
      deleteOrsort = true;
      selectedCount = 0;
      int _len = watchlistDetailscopy.symbolDataList.length;

      for (int i = 0; i < _len; i++) {
        if (statusList[i]) {
          watchlistDetailscopy.symbolDataList.removeAt(i);
          statusList.removeAt(i);
          _len -= 1;
          i -= 1;
        }
      }
      emit(WatchlisteditInitial(
          watchlistModel: watchlistDetailscopy,
          isLoading: _isLoading,
          isSelected: _isSelected,
          watchName: watchName,
          statusList: statusList,
          errorMsg: ""));
    }
  }

// // Device Back Button Execution
//   Future<bool> WillPopScopeWork(BuildContext context) async {
//     bool _status;
//     textfieldcontroller.text = watchName = textfieldcontroller.text.trim();
//     if (formKey.currentState!.validate()) {
//       textfieldcontroller.text = watchName = textfieldcontroller.text
//           .replaceFirst(textfieldcontroller.text[0],
//               textfieldcontroller.text[0].toUpperCase());
//       if (rename == true || deleteOrsort == true) {
//         return customShowModalBottomSheet(
//           context: context,
//           inputWidget: WatchListAction(
//             actionType: ActionType.save,
//             // Discard Changes
//             negativeOnPres: () {
//               discardChanges();
//               Navigator.pop(context);
//               serviceLocator.navigationService
//                   .back(context, arg: {"EditedWatchlist": watchlistDetails});
//             },
//             // Save Changes
//             positiveOnPress: () async {
//               // When Only Change WatchName
//               if (rename == true && deleteOrsort == false) {
//                 _status = await updateWatchName();
//                 if (_status == true) {
//                   Navigator.pop(context);
//                   serviceLocator.navigationService.back(context,
//                       arg: {"EditedWatchlist": watchlistDetailscopy});
//                 } else {
//                   Navigator.pop(context);
//                 }
//                 // When Change WatchName or Sortorder
//               } else if (rename == true || deleteOrsort == true) {
//                 _status = await updateCloudWatchNameWithSymbols();
//                 if (_status == true) {
//                   Navigator.pop(context);
//                   serviceLocator.navigationService.back(context,
//                       arg: {"EditedWatchlist": watchlistDetailscopy});
//                 } else {
//                   Navigator.pop(context);
//                 }
//               } else {
//                 serviceLocator.navigationService.back(context,
//                     arg: {"EditedWatchlist": watchlistDetailscopy});
//               }
//             },
//           ),
//         );
//       } else {
//         serviceLocator.navigationService
//             .back(context, arg: {"EditedWatchlist": watchlistDetailscopy});
//       }
//       return false;
//     }
//     return false;
//   }

  // Page Back Button
  backNavigation(BuildContext context) async {
    bool _status;
    textfieldcontroller.text = watchName = textfieldcontroller.text.trim();
    if (!formKey.currentState!.validate()) return;
    textfieldcontroller.text = watchName = textfieldcontroller.text
        .replaceFirst(textfieldcontroller.text[0],
            textfieldcontroller.text[0].toUpperCase());

    if (rename == true || deleteOrsort == true) {
      FocusScope.of(context).unfocus();
      return customShowModalBottomSheet(
        context: context,
        inputWidget: WatchListAction(
          actionType: ActionType.save,
          negativeOnPres: () {
            discardChanges();
            Navigator.pop(context);
            serviceLocator.navigationService.back(context);
          },
          positiveOnPress: () async {
            if (rename == true && deleteOrsort == false) {
              _status = await updateWatchName();
              if (_status == true) {
                Navigator.pop(context);
                serviceLocator.navigationService.back(context, arg: {
                  "change": watchlistDetailscopy.watchlistData.watchlistid
                });
              } else {
                Navigator.pop(context);
              }
            } else if (rename == true || deleteOrsort == true) {
              _status = await updateCloudWatchNameWithSymbols();
              if (_status == true) {
                Navigator.pop(context);
                serviceLocator.navigationService.back(context, arg: {
                  "change": watchlistDetailscopy.watchlistData.watchlistid
                });
              } else {
                Navigator.pop(context);
              }
            } else {
              Navigator.pop(context);
            }
          },
        ),
      );
    } else {
      Navigator.pop(context);
    }
  }

  saveButton(BuildContext context) async {
    bool _status;
    textfieldcontroller.text = watchName = textfieldcontroller.text.trim();

    if (formKey.currentState!.validate()) {
      textfieldcontroller.text = watchName = textfieldcontroller.text
          .replaceFirst(textfieldcontroller.text[0],
              textfieldcontroller.text[0].toUpperCase());
      if (rename == true && deleteOrsort == false) {
        _status = await updateWatchName();
        if (_status == true) {
          serviceLocator.navigationService.back(context,
              arg: {"change": watchlistDetailscopy.watchlistData.watchlistid});
        }
      } else if (rename == true || deleteOrsort == true) {
        _status = await updateCloudWatchNameWithSymbols();

        if (_status == true) {
          serviceLocator.navigationService.back(context,
              arg: {"change": watchlistDetailscopy.watchlistData.watchlistid});
        }
      } else {
        serviceLocator.navigationService.back(context,
            arg: {"change": watchlistDetailscopy.watchlistData.watchlistid});
      }
    }
  }

  // bool compareWatch() {
  //   if (watchlistDetailscopy.symbolDataList.length !=
  //       watchlistDetails.symbolDataList.length) {
  //     return true;
  //   } else if (watchName != watchlistDetails.watchlistData.watchname) {
  //     return true;
  //   } else {
  //     int _len = watchlistDetailscopy.symbolDataList.length;

  //     for (int i = 0; i < _len; i++) {
  //       if (watchlistDetails.symbolDataList[i].sortorder !=
  //           watchlistDetailscopy.symbolDataList[i].sortorder) {
  //         return true;
  //       }
  //     }
  //   }
  //   return false;
  // }
}

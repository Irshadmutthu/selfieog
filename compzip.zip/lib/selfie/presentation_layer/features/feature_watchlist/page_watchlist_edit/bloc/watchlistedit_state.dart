part of 'watchlistedit_cubit.dart';

@immutable
abstract class WatchlisteditState {}

class WatchlisteditLoading extends WatchlisteditState {}

class WatchlisteditInitial extends WatchlisteditState {
  final String errorMsg;
  final bool isLoading;
  final bool isSelected;
  final WatchlistModel watchlistModel;
  final String watchName;
  final List<bool> statusList;

  WatchlisteditInitial(
      {required this.watchlistModel,
      required this.watchName,
      required this.statusList,
      required this.errorMsg,
      required this.isLoading,
      required this.isSelected});
}

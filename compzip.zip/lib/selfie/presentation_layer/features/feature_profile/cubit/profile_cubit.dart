import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:flutter/foundation.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';
import 'package:trading_api/responses/profile_response.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

part 'profile_state.dart';

class ProfileCubit extends Cubit<ProfileState> {
  final ServiceLocator serviceLocator;
  final TradingApiGateway? tradingApiGateway;
  ProfileCubit({required this.serviceLocator, this.tradingApiGateway})
      : super(ProfileInitial()) {}
  sendProfieRequest({
    required context,
    required String userId,
  }) async {
    try {
      if (UserController.userController.profileData.result2![0].errorcode ==
          null) {
        emit(ProfileLoading());
        if (kDebugMode) {}
        await serviceLocator.tradingApi.profileRequest();
        emit(ProfileInitial());
      }
    } catch (errorMessage) {
      emit(ProfileError(errorCode: 000, errorMessage: errorMessage.toString()));
    }
  }
}

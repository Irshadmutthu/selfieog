// import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/more/bottomsheet_feedback_submitted_fivestar_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/more/bottomsheet_feedback_submitted_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/sort.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

import '../../../widgets/custom_app_components/appbar/customAppbarInner.dart';
import '../../../widgets/custom_app_components/buttons/BasketButton.dart';
import '../../../widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';

class FeedBackPage extends StatefulWidget {
  const FeedBackPage({Key? key}) : super(key: key);
  @override
  _FeedbackPageState createState() => _FeedbackPageState();
}

class _FeedbackPageState extends State<FeedBackPage> {
  var i = 0;
  int ratingIndex = 0;

  TextEditingController commentFieldController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: Column(
        children: [
          CustomAppBarInner(
            title: "Give Feedback",
            onBackPressed: () {
              context.gNavigationService.back(context);
            },
          ),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  CustomRateYourExperience(ratingValue: (rateVal) {
                    setState(() {
                      ratingIndex = rateVal;
                    });
                  }),
                  Padding(
                    padding:
                        const EdgeInsets.only(left: 16.0, right: 16, top: 8),
                    child: CustomTextFormField(
                      controller: commentFieldController,
                      fieldName: "Write a feedback",
                      hintText: "Text",
                      maxLines: 5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: (ratingIndex == 0)
                ? BasketButton(
                    textStyle: customTextStyle(
                        fontStyle: FontStyle.BodyL_Bold,
                        color: FontColor.White),
                    text: "Submit",
                    bgcolor: customColors().primary.withOpacity(0.4),
                    bordercolor: customColors().primary.withOpacity(0.1),
                    onpress: () {})
                : BasketButton(
                    textStyle: customTextStyle(
                        fontStyle: FontStyle.BodyL_Bold,
                        color: FontColor.White),
                    text: "Submit",
                    bgcolor: customColors().primary,
                    bordercolor: customColors().primary,
                    onpress: () {
                      customShowModalBottomSheet(
                        context: context,
                        inputWidget: ratingIndex == 5
                            ? const FeedbackSubmittedFiveStarBottomsheetWidget()
                            : const FeedbackSubmittedBottomsheetWidget(),
                      );
                    }),
          ),
        ],
      ),
    );
  }
}

class CustomRateYourExperience extends StatefulWidget {
  final Function(int) ratingValue;
  const CustomRateYourExperience({
    Key? key,
    required this.ratingValue,
  }) : super(key: key);

  @override
  State<CustomRateYourExperience> createState() =>
      _CustomRateYourExperienceState();
}

class _CustomRateYourExperienceState extends State<CustomRateYourExperience> {
  String imageUrl = 'assets/ratingicon.png';
  String comment = "";
  bool buttonVisibility = false;

  List<Map<String, dynamic>> ratingList = [
    {"image": "assets/rating2.png", "comment": "What went wrong?"},
    {"image": "assets/rating2.png", "comment": "In which area we can improve?"},
    {"image": "assets/rating3.png", "comment": "In which area we can improve?"},
    {"image": "assets/rating4.png", "comment": "In which area we can improve?"},
    {"image": "assets/rating5.png", "comment": "What you enjoyed the most?"},
  ];

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
            child: Container(
                decoration: BoxDecoration(
                    color: customColors().backgroundSecondary,
                    borderRadius: const BorderRadius.all(Radius.circular(4))),
                width: screenSize.width,
                child: Column(children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 20),
                    child: (!buttonVisibility)
                        ? Image.asset(imageUrl,
                            color: customColors().backgroundSecondary,
                            colorBlendMode: BlendMode.color)
                        : Image.asset(
                            imageUrl,
                          ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12.0),
                    child: Text(
                      "Rate your experience*",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyL_Regular,
                          color: FontColor.FontPrimary),
                    ),
                  ),
                  Padding(
                      padding: EdgeInsets.only(
                          left: screenSize.width * .1313,
                          right: screenSize.width * .1313,
                          bottom: 20),
                      child: CustomStarWidget(
                        ratingAction: (val) {
                          setState(() {
                            imageUrl = ratingList[val]["image"];
                            comment = ratingList[val]["comment"];
                            buttonVisibility = true;
                            widget.ratingValue(val + 1);
                          });
                        },
                      ))
                ]))),
        Visibility(
          visible: buttonVisibility,
          child: Container(
            padding: const EdgeInsets.only(
                top: 20.0, left: 16.0, right: 16.0, bottom: 8),
            alignment: Alignment.topLeft,
            child: Text(
              comment,
              style: customTextStyle(
                  fontStyle: FontStyle.BodyL_Regular,
                  color: FontColor.FontPrimary),
            ),
          ),
        ),
        Visibility(
          visible: buttonVisibility,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 16.0, right: 16),
                child: FilterItemListWidget(
                  onfilterpress: (value) {},
                  filterarrayposition: [],
                  itemsList: const [
                    {"text": "App Experience"},
                    {"text": "Customer Service"},
                    {"text": "Both"},
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(
                    left: 16.0, right: 16, top: 20, bottom: 8),
                child: SizedBox(
                  height: 0,
                  child: Divider(
                      thickness: 1.2, color: customColors().backgroundTertiary),
                ),
              ),
            ],
          ),
        )
      ],
    );
  }
}

class CustomStarWidget extends StatefulWidget {
  final Function(int) ratingAction;
  const CustomStarWidget({
    Key? key,
    required this.ratingAction,
  }) : super(key: key);

  @override
  State<CustomStarWidget> createState() => _CustomStarWidgetState();
}

class _CustomStarWidgetState extends State<CustomStarWidget> {
  int selectedRange = 0;

  @override
  Widget build(BuildContext context) {
    return Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: List.generate(
            5,
            (index) => InkWell(
                  onTap: (() {
                    setState(() {
                      selectedRange = index + 1;
                    });
                    widget.ratingAction(index);
                  }),
                  child: Column(
                    children: [
                      (index < selectedRange)
                          ? Image.asset("assets/rating_star_active.png")
                          : Image.asset("assets/rating_star.png"),
                      const SizedBox(
                        height: 4,
                      ),
                      Text("${index + 1}")
                    ],
                  ),
                )).toList());
  }
}

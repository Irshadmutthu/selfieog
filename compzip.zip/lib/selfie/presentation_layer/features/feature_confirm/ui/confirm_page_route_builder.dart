import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:trading_api/responses/order_response.dart';

import 'confirm_page.dart';

class ConfirmPagePageRouteBuilder {
  final ServiceLocator _serviceLocator;
  final OrderResponse _orderResponse;

  ConfirmPagePageRouteBuilder(this._serviceLocator, this._orderResponse);

  Widget call(BuildContext context) {
    return MultiRepositoryProvider(
        providers: [
          RepositoryProvider.value(
              value: _serviceLocator.navigationService),
          RepositoryProvider<CubitsLocator>.value(value: _serviceLocator),
        ],
        child: ConirmPage(
          orderResponse: _orderResponse,
        ));
  }
}

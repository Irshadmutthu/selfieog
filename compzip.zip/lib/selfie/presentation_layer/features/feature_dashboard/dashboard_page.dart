import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/settingsAppbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/market_dashboard_page.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/dashboard/my_dashboard_container.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({Key? key}) : super(key: key);

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  int initialIndex = 0;
  String tabName = "My Dashboard";
  int index = 0;
  late TabController _controller;

  List<Widget> dashboardwidgets = [];

  List<Tab> tablist = [
    Tab(
      text: "My Dashboard",
    ),
    Tab(
      text: "Market Dashboard",
    ),
  ];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initialIndex = 0;
    tabName = "My Dashboard";
    _controller = TabController(length: tablist.length, vsync: this);

    _controller.addListener(() {
      setState(() {
        initialIndex = _controller.index;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    dashboardwidgets = [
      MyDashBoardContainer(),
      MarketDashBoardPage(),
    ];

    return Scaffold(
      backgroundColor: customColors().backgroundPrimary,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(0.0),
        child: AppBar(
          elevation: 0,
          backgroundColor: customColors().backgroundPrimary,
        ),
      ),
      body: SafeArea(
          child: Column(
        children: [
          SettingsAppbar(
            title: "Dashboard",
            onBackPressed: () {
              Navigator.pop(context);
            },
            buttonname: "",
            onResetPressed: () {
              setState(() {
                // ordersdropdownlist = optionorderlist;
              });
            },
          ),
          Container(
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
                border: Border(
                    bottom: BorderSide(
                        width: 1.0, color: customColors().backgroundTertiary))),
            child: TabBar(
              controller: _controller,
              tabs: tablist,
              isScrollable: true,
              labelStyle: customTextStyle(
                  fontStyle: FontStyle.BodyL_SemiBold,
                  color: FontColor.Primary),
              labelColor: customColors().primary,
              indicatorSize: TabBarIndicatorSize.label,
              indicatorColor: customColors().primary,
              unselectedLabelStyle: customTextStyle(
                  fontStyle: FontStyle.BodyL_Regular,
                  color: FontColor.FontSecondary),
              unselectedLabelColor: customColors().fontSecondary,
            ),
          ),
          Expanded(
            child: TabBarView(
              children: dashboardwidgets,
              controller: _controller,
            ),
          )
        ],
      )),
    );
  }
}

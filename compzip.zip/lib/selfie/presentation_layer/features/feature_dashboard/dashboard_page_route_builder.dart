import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_dashboard/dashboard_page.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class DashboardPageRouteBuilder {
  final ServiceLocator serviceLocator;

  DashboardPageRouteBuilder(this.serviceLocator);

  Widget call(BuildContext context) {
    return MultiRepositoryProvider(
        providers: [RepositoryProvider.value(value: serviceLocator.tradingApi)],
        child: DashboardPage());
  }
}

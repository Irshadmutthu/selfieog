import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/ipo_applied_model.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/ipo/ipo_applied_list_tile.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';

class AppliedTab extends StatelessWidget {
  const AppliedTab({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          ListView.builder(
            shrinkWrap: true,
            itemCount: appliedList.length,
            itemBuilder: (context, index) {
              return InkWell(
                onTap: () {
                  context.gNavigationService.openIpoAppliedDetailPage(context);
                },
                child: IpoAppliedListTile(
                  listItem: appliedList[index],
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

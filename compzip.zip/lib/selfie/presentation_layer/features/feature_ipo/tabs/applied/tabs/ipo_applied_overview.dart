import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class IpoAppliedOverView extends StatelessWidget {
  const IpoAppliedOverView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    TextStyle companyStyle = customTextStyle(
      fontStyle: FontStyle.BodyL_SemiBold,
      color: FontColor.FontPrimary,
    );
    TextStyle detailStyle = customTextStyle(
      fontStyle: FontStyle.BodyM_Regular,
      color: FontColor.FontPrimary,
    );
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Company Profile",
              style: companyStyle,
            ),
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Text(
                "Life insurance in India made its debut well over 100 years ago.",
                style: detailStyle,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Text(
                "In our country, which is one of the most populated in the world, the prominence of insurance is not as widely understood, as it ought to be. What follows is an attempt to acquaint readers with some of the concepts of life insurance, with special reference to LIC.  ",
                style: detailStyle,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Text(
                "It should, however, be clearly understood that the following content is by no means an exhaustive description of the terms and conditions of an LIC policy or its benefits or privileges.",
                style: detailStyle,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 20),
              child: Text(
                "Strengths",
                style: companyStyle,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Text(
                "The new owners have quickly scripted a turnaround after taking over the diversified fast-moving consumer goods (FMCG) company. The company has turned profitable and its debt has been sizably reduced.",
                style: detailStyle,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 20),
              child: Text(
                "Weaknesses",
                style: companyStyle,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Text(
                "The new owners have quickly scripted a turnaround after taking over the diversified fast-moving consumer goods (FMCG) company. The company has turned profitable and its debt has been sizably reduced.",
                style: detailStyle,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

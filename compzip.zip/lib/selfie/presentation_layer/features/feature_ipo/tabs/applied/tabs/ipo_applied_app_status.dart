import 'package:flutter/material.dart';
import 'package:just_the_tooltip/just_the_tooltip.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

List<Model> count1 = [
  Model(
    title: "UPI Mandate Pending",
    color: FontColor.FontPrimary,
    date: "24 Feb, 22",
  ),
  Model(
    title: "Sent to Exchange",
    color: FontColor.Success,
    date: "24 Feb, 22",
  ),
];

List<Model> count2 = [
  Model(
    title: "Allotment",
    color: FontColor.FontPrimary,
    date: "24 Feb, 22",
  ),
  Model(
    title: "UPI Mandate Pending",
    color: FontColor.Success,
    date: "24 Feb, 22",
  ),
  Model(
    title: "Sent to Exchange",
    color: FontColor.Success,
    date: "24 Feb, 22",
  ),
];

List<Model> count3 = [
  Model(
    title: "Allotment Finalized",
    color: FontColor.Success,
    date: "24 Feb, 22",
  ),
  Model(
    title: "UPI Mandate Pending",
    color: FontColor.Success,
    date: "24 Feb, 22",
  ),
  Model(
    title: "Sent to Exchange",
    color: FontColor.Success,
    date: "24 Feb, 22",
  ),
];

List<Model> count4 = [
  Model(
    title: "Allotment Finalized",
    color: FontColor.Danger,
    date: "24 Feb, 22",
  ),
  Model(
    title: "UPI Mandate Pending",
    color: FontColor.Success,
    date: "24 Feb, 22",
  ),
  Model(
    title: "Sent to Exchange",
    color: FontColor.Success,
    date: "24 Feb, 22",
  ),
];

class IpoAppliedAppStatus extends StatefulWidget {
  const IpoAppliedAppStatus({Key? key}) : super(key: key);

  @override
  State<IpoAppliedAppStatus> createState() => _IpoAppliedAppStatusState();
}

class _IpoAppliedAppStatusState extends State<IpoAppliedAppStatus> {
  List<Map<String, dynamic>> onView = count1.cast<Map<String, dynamic>>();
  int screenCount = 1;
  // JustTheController controller3 = JustTheController();

  final List<JustTheController> _controllers = [];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 11, right: 16, top: 20, bottom: 6),
      child: Stack(
        children: [
          screenCount == 1
              ? ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: count1.length,
                  itemBuilder: (context, index) {
                    _controllers.add(JustTheController());
                    return Stack(
                      children: [
                        index != count1.length - 1
                            ? Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Row(
                                    children: [
                                      Column(
                                        children: List.generate(
                                          8,
                                          (ii) => Padding(
                                            padding: const EdgeInsets.only(
                                                left: 10,
                                                right: 10,
                                                bottom: 2,
                                                top: 2),
                                            child: Container(
                                              height: 4,
                                              width: 1,
                                              color: customColors().silverDust,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              )
                            : const SizedBox(),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          left: 6, right: 12, bottom: 4),
                                      child: Container(
                                        height: 10,
                                        width: 10,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: index == 4 || index == 5
                                              ? customColors().success
                                              : customColors().silverDust,
                                        ),
                                      ),
                                    ),
                                    Text(
                                      count1[index].title,
                                      style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_SemiBold,
                                        color: count1[index].color,
                                      ),
                                    ),
                                    index == 0
                                        ? tooTip(context, index,
                                            count1[index].color!)
                                        : const SizedBox(),
                                  ],
                                ),
                                Text(
                                  count1[index].date,
                                  style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_SemiBold,
                                    color: FontColor.FontSecondary,
                                  ),
                                )
                              ],
                            ),
                          ],
                        ),
                      ],
                    );
                  },
                )
              : screenCount == 2
                  ? ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: count2.length,
                      itemBuilder: (context, index) {
                        _controllers.add(JustTheController());
                        return Stack(
                          children: [
                            index != count2.length - 1
                                ? Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Row(
                                        children: [
                                          Column(
                                            children: List.generate(
                                              8,
                                              (ii) => Padding(
                                                padding: const EdgeInsets.only(
                                                    left: 10,
                                                    right: 10,
                                                    bottom: 2,
                                                    top: 2),
                                                child: Container(
                                                  height: 4,
                                                  width: 1,
                                                  color:
                                                      customColors().silverDust,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  )
                                : const SizedBox(),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              left: 6, right: 12, bottom: 4),
                                          child: Container(
                                            height: 10,
                                            width: 10,
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              color: index == 4 || index == 5
                                                  ? customColors().success
                                                  : customColors().silverDust,
                                            ),
                                          ),
                                        ),
                                        Text(
                                          count2[index].title,
                                          style: customTextStyle(
                                            fontStyle: FontStyle.BodyM_SemiBold,
                                            color: count2[index].color,
                                          ),
                                        ),
                                        index == 1
                                            ? tooTip(context, index,
                                                count2[index].color!)
                                            : const SizedBox(),
                                      ],
                                    ),
                                    index == 0
                                        ? const SizedBox()
                                        : Text(
                                            count2[index].date,
                                            style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyM_SemiBold,
                                              color: FontColor.FontSecondary,
                                            ),
                                          )
                                  ],
                                ),
                              ],
                            ),
                          ],
                        );
                      })
                  : screenCount == 3
                      ? ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: count3.length,
                          itemBuilder: (context, index) {
                            _controllers.add(JustTheController());
                            return Stack(
                              children: [
                                index != count3.length - 1
                                    ? Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Row(
                                            children: [
                                              Column(
                                                children: List.generate(
                                                  8,
                                                  (ii) => Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            left: 10,
                                                            right: 10,
                                                            bottom: 2,
                                                            top: 2),
                                                    child: Container(
                                                      height: 4,
                                                      width: 1,
                                                      color: customColors()
                                                          .silverDust,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      )
                                    : const SizedBox(),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          children: [
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 6,
                                                  right: 12,
                                                  bottom: 4),
                                              child: Container(
                                                height: 10,
                                                width: 10,
                                                decoration: BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  color: index == 4 ||
                                                          index == 5
                                                      ? customColors().success
                                                      : customColors()
                                                          .silverDust,
                                                ),
                                              ),
                                            ),
                                            Text(
                                              count3[index].title,
                                              style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyM_SemiBold,
                                                color: count3[index].color,
                                              ),
                                            ),
                                            index == 0 || index == 1
                                                ? tooTip(context, index,
                                                    count3[index].color!)
                                                : const SizedBox(),
                                          ],
                                        ),
                                        Text(
                                          count3[index].date,
                                          style: customTextStyle(
                                            fontStyle: FontStyle.BodyM_SemiBold,
                                            color: FontColor.FontSecondary,
                                          ),
                                        )
                                      ],
                                    ),
                                  ],
                                ),
                              ],
                            );
                          })
                      : screenCount == 4
                          ? ListView.builder(
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              itemCount: count4.length,
                              itemBuilder: (context, index) {
                                _controllers.add(JustTheController());
                                return Stack(
                                  children: [
                                    index != count4.length - 1
                                        ? Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Row(
                                                children: [
                                                  Column(
                                                    children: List.generate(
                                                      8,
                                                      (ii) => Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                left: 10,
                                                                right: 10,
                                                                bottom: 2,
                                                                top: 2),
                                                        child: Container(
                                                          height: 4,
                                                          width: 1,
                                                          color: customColors()
                                                              .silverDust,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          )
                                        : const SizedBox(),
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Row(
                                              children: [
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 6,
                                                          right: 12,
                                                          bottom: 4),
                                                  child: Container(
                                                    height: 10,
                                                    width: 10,
                                                    decoration: BoxDecoration(
                                                      shape: BoxShape.circle,
                                                      color: index == 4 ||
                                                              index == 5
                                                          ? customColors()
                                                              .success
                                                          : customColors()
                                                              .silverDust,
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  count4[index].title,
                                                  style: customTextStyle(
                                                    fontStyle: FontStyle
                                                        .BodyM_SemiBold,
                                                    color: count4[index].color,
                                                  ),
                                                ),
                                                tooTip(context, index,
                                                    count4[index].color!)
                                              ],
                                            ),
                                            Text(
                                              count4[index].date,
                                              style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyM_SemiBold,
                                                color: FontColor.FontSecondary,
                                              ),
                                            )
                                          ],
                                        ),
                                      ],
                                    ),
                                  ],
                                );
                              })
                          : screenCount == 4
                              ? ListView.builder(
                                  shrinkWrap: true,
                                  physics: const NeverScrollableScrollPhysics(),
                                  itemCount: count4.length,
                                  itemBuilder: (context, index) {
                                    return Stack(
                                      children: [
                                        index != count4.length - 1
                                            ? Column(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  Row(
                                                    children: [
                                                      Column(
                                                        children: List.generate(
                                                          8,
                                                          (ii) => Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    left: 10,
                                                                    right: 10,
                                                                    bottom: 2,
                                                                    top: 2),
                                                            child: Container(
                                                              height: 4,
                                                              width: 1,
                                                              color:
                                                                  customColors()
                                                                      .silverDust,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              )
                                            : const SizedBox(),
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Row(
                                                  children: [
                                                    Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              left: 6,
                                                              right: 12,
                                                              bottom: 4),
                                                      child: Container(
                                                        height: 10,
                                                        width: 10,
                                                        decoration:
                                                            BoxDecoration(
                                                          shape:
                                                              BoxShape.circle,
                                                          color: index == 4 ||
                                                                  index == 5
                                                              ? customColors()
                                                                  .success
                                                              : customColors()
                                                                  .silverDust,
                                                        ),
                                                      ),
                                                    ),
                                                    Text(
                                                      count4[index].title,
                                                      style: customTextStyle(
                                                        fontStyle: FontStyle
                                                            .BodyM_SemiBold,
                                                        color:
                                                            count4[index].color,
                                                      ),
                                                    ),
                                                    tooTip(context, index,
                                                        count4[index].color!)
                                                  ],
                                                ),
                                                Text(
                                                  count4[index].date,
                                                  style: customTextStyle(
                                                    fontStyle: FontStyle
                                                        .BodyM_SemiBold,
                                                    color:
                                                        FontColor.FontSecondary,
                                                  ),
                                                )
                                              ],
                                            ),
                                          ],
                                        ),
                                      ],
                                    );
                                  })
                              : const SizedBox(),
          Align(
            alignment: Alignment.bottomCenter,
            child: skipButton(context, "$screenCount/4", () {
              if (screenCount > 1) {
                setState(() {
                  screenCount--;
                });
              }
            }, () {
              if (screenCount < 4) {
                setState(() {
                  screenCount++;
                });
              }
            }),
          ),
        ],
      ),
    );
  }

  Widget tooTip(BuildContext context, int index, FontColor color) {
    return JustTheTooltip(
      backgroundColor: customColors().backgroundSecondary,
      preferredDirection: AxisDirection.down,
      controller: _controllers[index],
      child: InkWell(
        onTap: () {
          _controllers[index].showTooltip();
        },
        child: Padding(
          padding: const EdgeInsets.only(left: 6, top: 4),
          child: Icon(
            Icons.info_outline_rounded,
            size: 13.0,
            color: color == FontColor.Success
                ? customColors().success
                : color == FontColor.Danger
                    ? customColors().danger
                    : customColors().fontPrimary,
          ),
        ),
      ),
      content: Padding(
          padding:
              EdgeInsets.only(top: 16.0, left: 16.0, right: 16.0, bottom: 10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'UPI Mandate Pending',
                style: customTextStyle(
                    fontStyle: FontStyle.BodyM_SemiBold,
                    color: FontColor.FontPrimary),
              ),
              Padding(
                  padding: EdgeInsets.only(top: 16.0, right: 10.0),
                  child: Container(
                    width: 268,
                    child: Text(
                      'The UPI collect request from the bank might be delayed. Accept it to apply whenever you receive the collect request on your UPI app (might take up to end of the day).',
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyS_Regular,
                          color: FontColor.FontPrimary),
                      textAlign: TextAlign.justify,
                    ),
                  )),
            ],
          )),
    );
  }
}

class Model {
  String title;

  FontColor? color;

  String date;

  //Other fields if needed....
  Model({
    required this.title,
    required this.date,
    this.color,
  });
  //initialise other fields so on....
}

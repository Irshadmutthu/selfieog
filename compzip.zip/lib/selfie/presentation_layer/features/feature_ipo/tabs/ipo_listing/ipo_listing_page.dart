import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/ipo_list_model.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/ipo_status_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/ipo/ipo_list_tile.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';

class IpoListingPage extends StatefulWidget {
  const IpoListingPage({Key? key}) : super(key: key);

  @override
  State<IpoListingPage> createState() => _IpoListingPageState();
}

class _IpoListingPageState extends State<IpoListingPage> {
  int? _itemCount = 0;
  bool allVisible = true;
  bool categoryVisible = false;
  String? categoryName;
  List<Map<String, dynamic>> onView = all;

  filterSymbols(int ipoStatus) {
    setState(() {
      switch (ipoStatus) {
        case 0:
          {
            setState(() {
              _itemCount = all.length;
              allVisible = true;
              categoryVisible = false;
              categoryName = "ALL";
              onView = all;
            });
            break;
          }
        case 1:
          {
            setState(() {
              _itemCount = ongoing.length;
              allVisible = false;
              categoryVisible = true;
              categoryName = "Ongoing";
              onView = ongoing;
            });
            break;
          }
        case 2:
          {
            setState(() {
              _itemCount = upcoming.length;
              allVisible = false;
              categoryVisible = true;
              categoryName = "Upcoming";
              onView = upcoming;
            });
            break;
          }
        case 3:
          {
            setState(() {
              _itemCount = closed.length;
              allVisible = false;
              categoryVisible = true;
              categoryName = "Closed";
              onView = closed;
            });
            break;
          }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: SingleChildScrollView(
            child: Column(
              children: [
                InkWell(
                  onTap: () {
                    customBottomSheet(
                      context: context,
                      inputWidget: IpoStatusBottomSheet(
                        onpress: (val) {
                          setState(() {});
                          filterSymbols(ipostatusValue);
                          Navigator.pop(context);
                        },
                      ),
                    );
                  },
                  child: Container(
                    height: 48,
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(4),
                      border:
                          Border.all(color: customColors().backgroundTertiary),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "IPO Status",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                          Row(
                            children: [
                              Text(
                                ipostatusValue == 0
                                    ? "All"
                                    : ipostatusValue == 1
                                        ? "Ongoing"
                                        : ipostatusValue == 2
                                            ? "Upcoming"
                                            : ipostatusValue == 3
                                                ? "Closed"
                                                : "All",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_SemiBold,
                                    color: FontColor.Primary),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 8),
                                child: Image.asset(
                                  "assets/arrow_down.png",
                                  color: customColors().primary,
                                ),
                              )
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Visibility(
                  visible: allVisible,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 20),
                        child: Text(
                          "Ongoing (${ongoing.length})",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Bold,
                              color: FontColor.FontPrimary),
                        ),
                      ),
                      ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: ongoing.length,
                        itemBuilder: (context, index) {
                          return InkWell(
                            onTap: () {
                              context.gNavigationService
                                  .openIpoDetailPage(context);
                            },
                            child: IpoListTile(
                              listItem: ongoing[index],
                            ),
                          );
                        },
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 20),
                        child: Text(
                          "Upcoming (${upcoming.length})",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Bold,
                              color: FontColor.FontPrimary),
                        ),
                      ),
                      ListView.builder(
                        physics: const NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        itemCount: upcoming.length,
                        itemBuilder: (context, index) {
                          return InkWell(
                            onTap: () {
                              context.gNavigationService
                                  .openIpoDetailPage(context);
                            },
                            child: IpoListTile(
                              listItem: upcoming[index],
                            ),
                          );
                        },
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 20),
                        child: Text(
                          "Closed (${closed.length})",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Bold,
                              color: FontColor.FontPrimary),
                        ),
                      ),
                      ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: closed.length,
                        itemBuilder: (context, index) {
                          return InkWell(
                            onTap: () {
                              context.gNavigationService
                                  .openIpoDetailPage(context);
                            },
                            child: IpoListTile(
                              listItem: closed[index],
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
                Visibility(
                  visible: categoryVisible,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 20),
                        child: Text(
                          "$categoryName ($_itemCount)",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Bold,
                              color: FontColor.FontPrimary),
                        ),
                      ),
                      ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: _itemCount,
                        itemBuilder: (context, index) {
                          return InkWell(
                            onTap: () {
                              context.gNavigationService
                                  .openIpoDetailPage(context);
                            },
                            child: IpoListTile(
                              listItem: onView[index],
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

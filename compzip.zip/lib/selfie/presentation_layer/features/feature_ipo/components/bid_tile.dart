import 'package:flutter/material.dart';
import 'package:just_the_tooltip/just_the_tooltip.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/formatters.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

final _form = GlobalKey<FormState>();

class BidTile extends StatefulWidget {
  String title;
  bool FO = true;
  bool isbo;
  List<Map<String, dynamic>> mmarray = [];
  BidTile(
      // ignore: non_constant_identifier_names
      {Key? key,
      required this.title,
      required this.FO,
      required this.mmarray,
      required this.isbo})
      : super(key: key);

  @override
  State<BidTile> createState() => _BidTileState();
}

class _BidTileState extends State<BidTile> {
  TextEditingController lots = TextEditingController(text: "1");
  TextEditingController price = TextEditingController(text: "300");
  JustTheController? controller = JustTheController();
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: customColors().backgroundTertiary)),
      height: 245,
      child: Form(
        key: _form,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(left: 16, top: 13),
              child: Text(
                "Bid",
                style: customTextStyle(
                    fontStyle: FontStyle.BodyL_SemiBold,
                    color: FontColor.FontPrimary),
              ),
            ),
            Divider(
              color: customColors().backgroundTertiary,
              thickness: 1.2,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Expanded(
                    flex: 2,
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Lots",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_Regular,
                                  color: FontColor.FontPrimary),
                            ),
                            Text(
                              "Qty: 3000",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_Regular,
                                  color: FontColor.FontSecondary),
                            ),
                          ],
                        ),
                        CustomTextFormField(
                          controller: lots,
                          keyboardType: TextInputType.number,
                          inputFormatter: [DecimalFormatter()],
                          fieldName: "",
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                      flex: 2,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 16.0),
                        child: CustomTextFormField(
                          validator: Validator.price,
                          controller: price,
                          keyboardType: TextInputType.number,
                          inputFormatter: [DecimalFormatter()],
                          fieldName: "Price",
                        ),
                      ))
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 20.0, right: 0.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 16),
                    child: Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(right: 10),
                          child: EmptyCustomCheckBox(
                            callback: (bool) {},
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(right: 5),
                          child: Text(
                            "Apply Cut-off Price",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_Regular,
                                color: FontColor.FontPrimary),
                          ),
                        ),
                        JustTheTooltip(
                          offset: 2.0,
                          backgroundColor: customColors().backgroundSecondary,
                          preferredDirection: AxisDirection.up,
                          controller: controller,
                          margin: EdgeInsets.symmetric(vertical: 20.0),
                          child: Material(
                              child: Container(
                            height: 22.0,
                            width: 22.0,
                            child: Center(
                                child: InkWell(
                              onTap: () {
                                controller?.showTooltip();
                              },
                              child: Icon(
                                Icons.info_outline_rounded,
                                size: 14.0,
                              ),
                            )),
                          )),
                          content: Container(
                            margin: widget.mmarray[0]['name']
                                    .toString()
                                    .contains(
                                        'Default Percentage for limit Order')
                                ? EdgeInsets.symmetric(horizontal: 39.0)
                                : EdgeInsets.symmetric(horizontal: 16.0),
                            child: Padding(
                                padding: EdgeInsets.only(
                                    top: 16.0,
                                    left: 10.0,
                                    right: 10.0,
                                    bottom: 10.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      "Cut-off Price",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                    Padding(
                                        padding: EdgeInsets.only(
                                            top: 16.0, right: 10.0),
                                        child: Container(
                                          width: 268,
                                          child: Text(
                                            "The cut-off price is the offer price at which the shares get issued to the investors, which could be any price within the price band. In case you select cut-off, you are eligible for allotment at any discovered issue price.",
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyS_Regular,
                                                color: FontColor.FontPrimary),
                                            textAlign: TextAlign.justify,
                                          ),
                                        )),
                                  ],
                                )),
                          ),
                        )
                      ],
                    ),
                  ),

                  // Checkbox(
                  //     activeColor: customColors().primary,
                  //     value: widget.mmarray['value'],
                  //     onChanged: (v) {
                  //       setState(() {
                  //         widget.mmarray['value'] = v;
                  //       });
                  //     })
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                  left: 16, right: 16, top: 10, bottom: 12),
              child: Divider(
                color: customColors().backgroundTertiary,
                thickness: 1.2,
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Total Investment",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_SemiBold,
                        color: FontColor.FontPrimary),
                  ),
                  Text(
                    "90,000",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Bold,
                        color: FontColor.FontPrimary),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

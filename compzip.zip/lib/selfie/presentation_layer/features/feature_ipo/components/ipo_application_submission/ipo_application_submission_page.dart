import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_help_appbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class IpoApplicationSubmission extends StatelessWidget {
  const IpoApplicationSubmission({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
            border: Border(
          top: BorderSide(color: customColors().backgroundTertiary),
        )),
        height: 72,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12.0),
          child: Row(children: [
            Expanded(
              child: BasketButton(
                bordercolor: transparent,
                bgcolor: customColors().primary,
                text: "Close",
                textStyle: customTextStyle(
                    fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
                onpress: () {
                  Navigator.pop(context);
                },
              ),
            ),
          ]),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsets.only(top: height * 0.06),
                child: Center(child: Image.asset('assets/circles_confirm.png')),
              ),
              Padding(
                padding: EdgeInsets.only(top: height * 0.020),
                child: Text(
                  "Application Submitted",
                  textAlign: TextAlign.center,
                  style: customTextStyle(
                      fontStyle: FontStyle.HeaderS_SemiBold,
                      color: FontColor.FontPrimary),
                ),
              ),
              Padding(
                padding:
                    EdgeInsets.only(top: height * 0.09, left: 16, right: 16),
                child: Container(
                  width: width,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(4),
                      border:
                          Border.all(color: customColors().backgroundTertiary)),
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 16, 0, 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Image.asset(
                              "assets/lic.png",
                              height: 40,
                              width: 40,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 16),
                              child: Text(
                                "Life Insurance Corporation\nof India - LIC",
                                maxLines: 2,
                                style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Divider(
                        color: customColors().backgroundTertiary,
                        thickness: 1.2,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 16, right: 28, top: 16, bottom: 30),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Application No.",
                                  style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_Regular,
                                    color: FontColor.FontSecondary,
                                  ),
                                ),
                                const SizedBox(
                                  height: 6,
                                ),
                                Text(
                                  "45829569428",
                                  style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_SemiBold,
                                    color: FontColor.FontPrimary,
                                  ),
                                )
                              ],
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Total Investment",
                                  style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_Regular,
                                    color: FontColor.FontSecondary,
                                  ),
                                ),
                                const SizedBox(
                                  height: 6,
                                ),
                                Text(
                                  "90,000",
                                  style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_SemiBold,
                                    color: FontColor.FontPrimary,
                                  ),
                                )
                              ],
                            )
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 16, right: 28, bottom: 21),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Lots",
                                  style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_Regular,
                                    color: FontColor.FontSecondary,
                                  ),
                                ),
                                Text(
                                  "01",
                                  style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_SemiBold,
                                    color: FontColor.FontPrimary,
                                  ),
                                ),
                              ],
                            ),
                            Container(
                              height: 39,
                              width: 1.2,
                              color: customColors().backgroundTertiary,
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Qty",
                                  style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_Regular,
                                    color: FontColor.FontSecondary,
                                  ),
                                ),
                                Text(
                                  "3000",
                                  style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_SemiBold,
                                    color: FontColor.FontPrimary,
                                  ),
                                ),
                              ],
                            ),
                            Container(
                              height: 39,
                              width: 1.2,
                              color: customColors().backgroundTertiary,
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Applied Price",
                                  style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_Regular,
                                    color: FontColor.FontSecondary,
                                  ),
                                ),
                                Text(
                                  "250",
                                  style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_SemiBold,
                                    color: FontColor.FontPrimary,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(
                    left: 16.0, right: 16.0, top: height * 0.09),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                      color: customColors().backgroundSecondary,
                      borderRadius: BorderRadius.circular(4.0)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 3),
                          child: Icon(
                            Icons.info_outline_rounded,
                            size: 14.0,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 9),
                          child: Text(
                            "Accept the request on your UPI app to complete the\napplication process.",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_Regular,
                                color: FontColor.FontPrimary),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

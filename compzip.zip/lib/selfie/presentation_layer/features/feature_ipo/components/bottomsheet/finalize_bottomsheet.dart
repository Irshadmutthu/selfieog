import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class IpoFinalizeBottomSheet extends StatelessWidget {
  bool positive;
  IpoFinalizeBottomSheet({Key? key, this.positive = true}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Stack(
              alignment: AlignmentDirectional.center,
              children: [
                Container(
                  width: screenSize.width * 0.34,
                  height: screenSize.width * 0.29,
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage("assets/groupimage.png"),
                        fit: BoxFit.fill),
                  ),
                ),
                Container(
                  width: screenSize.width * 0.2,
                  height: screenSize.width * 0.2,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage(positive
                            ? "assets/rating5.png"
                            : "assets/rating2.png"),
                        fit: BoxFit.fill),
                  ),
                ),
              ],
            ),
          ),
        ),
        Center(
          child: Text(
            positive ? "Congratulations!" : "Oh no!",
            style: customTextStyle(
                fontStyle: FontStyle.HeaderS_SemiBold,
                color: FontColor.FontPrimary),
          ),
        ),
        Center(
          child: Padding(
            padding: const EdgeInsets.only(top: 20),
            child: Text(
              positive
                  ? "You were allotted the IPO!!"
                  : "You missed out this time.",
              style: customTextStyle(
                  fontStyle: FontStyle.BodyM_SemiBold,
                  color: FontColor.FontPrimary),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 8, bottom: 15),
          child: Center(
            child: Text(
              positive
                  ? "Your shares will be displayed in your Selfie\nHoldings on the next listing day."
                  : "Any money debited from your account will be\nrefunded within 10 days.",
              textAlign: TextAlign.center,
              style: customTextStyle(
                  fontStyle: FontStyle.BodyL_Regular,
                  color: FontColor.FontSecondary),
            ),
          ),
        ),
        Divider(
          thickness: 1.2,
          color: customColors().backgroundTertiary,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Center(
            child: SizedBox(
              width: 160,
              height: 48,
              child: BasketButton(
                bordercolor: transparent,
                bgcolor: customColors().primary,
                text: "Close",
                textStyle: customTextStyle(
                    fontStyle: FontStyle.BodyL_Bold, color: FontColor.White),
                onpress: () {
                  Navigator.pop(context);
                },
              ),
            ),
          ),
        )
      ],
    );
  }
}

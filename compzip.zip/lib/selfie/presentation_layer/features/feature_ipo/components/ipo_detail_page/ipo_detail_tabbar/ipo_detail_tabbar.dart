// import 'package:flutter/material.dart';
// import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/ipo_detail_page/ipo_detail_tabbar/tabs/overview.dart';
// import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/ipo_detail_page/ipo_detail_tabbar/tabs/status_log.dart';
// import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/settingsAppbar.dart';
// import 'package:selfie_mobile_flutter/theme/styles.dart';

// class IpoDetailTabBar extends StatefulWidget {
//   const IpoDetailTabBar({Key? key}) : super(key: key);

//   @override
//   State<IpoDetailTabBar> createState() => _IpoDetailTabBarState();
// }

// class _IpoDetailTabBarState extends State<IpoDetailTabBar>
//     with SingleTickerProviderStateMixin {
//   int initialIndex = 0;
//   String tabName = "Active";
//   int index = 0;
//   late TabController _controller;

//   List<Widget> alertswidgets = [];

//   List<Tab> tablist = [
//     const Tab(
//       text: "Overview",
//     ),
//     const Tab(
//       text: "Status Log",
//     ),
//   ];

//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     initialIndex = 0;
//     tabName = "Active";
//     _controller = TabController(length: tablist.length, vsync: this);

//     _controller.addListener(() {
//       setState(() {
//         initialIndex = _controller.index;
//       });
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     alertswidgets = [
//       IpoOverView(),
//       IpoStatusLog(),
//     ];

//     return Column(
//       mainAxisAlignment: MainAxisAlignment.start,
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Container(
//           width: MediaQuery.of(context).size.width,
//           decoration: BoxDecoration(
//             border: Border(
//                 bottom: BorderSide(
//                     width: 1.0, color: customColors().backgroundTertiary)),
//           ),
//           child: MediaQuery.removePadding(
//             context: context,
//             removeTop: true,
//             child: TabBar(
//               controller: _controller,
//               tabs: tablist,
//               isScrollable: true,
//               labelStyle: customTextStyle(
//                   fontStyle: FontStyle.BodyL_SemiBold,
//                   color: FontColor.Primary),
//               labelColor: customColors().primary,
//               indicatorSize: TabBarIndicatorSize.label,
//               indicatorColor: customColors().primary,
//               unselectedLabelStyle: customTextStyle(
//                   fontStyle: FontStyle.BodyL_Regular,
//                   color: FontColor.FontSecondary),
//               unselectedLabelColor: customColors().fontSecondary,
//             ),
//           ),
//         ),
//         Expanded(
//           child: TabBarView(
//             children: alertswidgets,
//             controller: _controller,
//           ),
//         ),
//       ],
//     );
//   }
// }

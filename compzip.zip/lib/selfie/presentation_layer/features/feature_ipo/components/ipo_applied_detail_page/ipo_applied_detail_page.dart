import 'package:flutter/material.dart';

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/bottomsheet/finalize_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/ipo_detail_page/ipo_detail_tabbar/ipo_detail_tabbar.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/ipo_detail_page/ipo_detail_tabbar/tabs/overview.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/ipo_detail_page/ipo_detail_tabbar/tabs/status_log.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/tabs/applied/tabs/ipo_applied_app_status.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/tabs/applied/tabs/ipo_applied_overview.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/tabs/applied/tabs/ipo_applied_status_log.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_ipo_appbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class IpoAppliedDetailPage extends StatefulWidget {
  const IpoAppliedDetailPage({Key? key}) : super(key: key);

  @override
  State<IpoAppliedDetailPage> createState() => _IpoAppliedDetailPageState();
}

class _IpoAppliedDetailPageState extends State<IpoAppliedDetailPage>
    with SingleTickerProviderStateMixin {
  int initialIndex = 0;
  String tabName = "Active";
  int index = 0;
  late TabController _controller;

  List<Widget> alertswidgets = [];

  List<Tab> tablist = [
    const Tab(
      text: "Overview",
    ),
    const Tab(
      text: "Status Log",
    ),
    const Tab(
      text: "App. Status",
    ),
  ];

  ScrollController scrollController = ScrollController();

  bool isVisible = true;

  int _selectedIndex = 0;

  int _scrollIndex = 0;

  @override
  initState() {
    super.initState();
    final _scrollController = ScrollController();
    initialIndex = 0;
    _scrollIndex = 0;
    tabName = "Active";
    _controller = TabController(
        length: tablist.length, vsync: this, initialIndex: _selectedIndex);

    _controller.addListener(() {
      setState(() {
        _scrollIndex = _controller.index;
      });
    });

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      customShowModalBottomSheet(
          context: context, inputWidget: IpoFinalizeBottomSheet());
    });
  }

  @override
  Widget build(BuildContext context) {
    _scrollIndex == 2
        ? WidgetsBinding.instance.addPostFrameCallback((_) async {
            customShowModalBottomSheet(
                context: context,
                inputWidget: IpoFinalizeBottomSheet(
                  positive: false,
                ));
          })
        : const SizedBox();
    alertswidgets = [
      IpoAppliedOverView(),
      IpoAppliedStatusLog(),
      IpoAppliedAppStatus(),
    ];
    TextStyle detailStyleOne = customTextStyle(
      fontStyle: FontStyle.BodyM_Regular,
      color: FontColor.FontSecondary,
    );

    TextStyle detailStyleTwo = customTextStyle(
      fontStyle: FontStyle.BodyM_SemiBold,
      color: FontColor.FontPrimary,
    );

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            IpoAppBar(
              title: "IPO Details",
              iconPress: () {
                Navigator.pop(context);
              },
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              color: customColors().backgroundSecondary,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 20, 0, 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Image.asset("assets/lic.png"),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        "Life Insurance Corporation\nof India - LIC",
                        maxLines: 2,
                        style: customTextStyle(
                          fontStyle: FontStyle.BodyL_SemiBold,
                          color: FontColor.FontPrimary,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Divider(
              height: 1,
              thickness: 1.2,
              color: customColors().backgroundTertiary,
            ),
            detailCard(context, detailStyleOne, detailStyleTwo),
            Container(
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                border: Border(
                    bottom: BorderSide(
                        width: 1.0, color: customColors().backgroundTertiary)),
              ),
              child: MediaQuery.removePadding(
                context: context,
                removeTop: true,
                child: TabBar(
                  controller: _controller,
                  tabs: tablist,
                  isScrollable: true,
                  labelStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_SemiBold,
                      color: FontColor.Primary),
                  labelColor: customColors().primary,
                  indicatorSize: TabBarIndicatorSize.label,
                  indicatorColor: customColors().primary,
                  unselectedLabelStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_Regular,
                      color: FontColor.FontSecondary),
                  unselectedLabelColor: customColors().fontSecondary,
                ),
              ),
            ),
            Expanded(
              child: TabBarView(
                children: alertswidgets,
                controller: _controller,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Container detailCard(BuildContext context, TextStyle detailStyleOne,
      TextStyle detailStyleTwo) {
    return Container(
      width: MediaQuery.of(context).size.width,
      color: customColors().backgroundSecondary,
      child: Padding(
        padding: const EdgeInsets.only(left: 16),
        child: Row(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 13,
                ),
                Text(
                  "Date",
                  style: detailStyleOne,
                ),
                const SizedBox(
                  height: 13,
                ),
                Text(
                  "Issue Size",
                  style: detailStyleOne,
                ),
                const SizedBox(
                  height: 13,
                ),
                Text(
                  "Min Investment",
                  style: detailStyleOne,
                ),
                const SizedBox(
                  height: 13,
                ),
                Text(
                  "Min Qty",
                  style: detailStyleOne,
                ),
                const SizedBox(
                  height: 13,
                ),
                Text(
                  "Price Band",
                  style: detailStyleOne,
                ),
                const SizedBox(
                  height: 13,
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(left: 76),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(
                    height: 13,
                  ),
                  Text(
                    "18 Feb’22 - 22 Feb’22",
                    style: detailStyleTwo,
                  ),
                  const SizedBox(
                    height: 13,
                  ),
                  Text(
                    "150 Crore",
                    style: detailStyleTwo,
                  ),
                  const SizedBox(
                    height: 13,
                  ),
                  Text(
                    "50,000.00",
                    style: detailStyleTwo,
                  ),
                  const SizedBox(
                    height: 13,
                  ),
                  Text(
                    "5000",
                    style: detailStyleTwo,
                  ),
                  const SizedBox(
                    height: 13,
                  ),
                  Text(
                    "200-300",
                    style: detailStyleTwo,
                  ),
                  const SizedBox(
                    height: 13,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

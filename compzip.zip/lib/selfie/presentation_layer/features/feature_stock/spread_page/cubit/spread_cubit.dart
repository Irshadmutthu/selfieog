import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'spread_state.dart';

class SpreadCubit extends Cubit<SpreadState> {
  SpreadCubit() : super(SpreadInitial());
}

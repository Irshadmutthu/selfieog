import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

import 'deals_page.dart';

class DealsPageRouteBuilder {
  final ServiceLocator _serviceLocator;

  DealsPageRouteBuilder(this._serviceLocator);

  Widget call(BuildContext context) {
    return MultiRepositoryProvider(providers: [
      RepositoryProvider.value(value: _serviceLocator.tradingApi),
    ], child: DealsPage());
  }
}

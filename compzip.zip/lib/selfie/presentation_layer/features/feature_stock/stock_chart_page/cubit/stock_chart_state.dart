part of 'stock_chart_cubit.dart';

@immutable
abstract class StockChartState {}

class StockChartInitial extends StockChartState {}

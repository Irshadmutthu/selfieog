import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

part 'index_state.dart';

class IndexCubit extends Cubit<IndexState> {
  Instrument instrument;
  String ricAddress = "";
  ServiceLocator serviceLocator;
  late StreamSubscription subscription;

  IndexCubit({required this.serviceLocator, required this.instrument})
      : super(IndexInitial(instrument: instrument)) {
    ricAddress = instrument.getRicAddress();
    subscription = MDS_Controller()
        .marketUpdateStream
        .listen((List<FlairResponseModel> flairResponseModel) {
      updateData(flairResponseModel);
    });
  }

  updateData(List<FlairResponseModel> data) {
    if (!isClosed) {
      emit(IndexInitial(instrument: instrument));
    } else {
      subscription.cancel();
    }
  }

  refresh() {
    if (!isClosed) {
      emit(IndexInitial(instrument: instrument));
    }
  }
}

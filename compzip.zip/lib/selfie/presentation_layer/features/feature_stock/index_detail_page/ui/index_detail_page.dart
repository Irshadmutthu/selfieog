import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/index_detail_page/cubit/index_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/individual_stock_page/components/market_overview_index/market_overview_index.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_stock_appbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_top_tab.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/mbp_status_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/search_filter.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/option_chain_more_action_bottom_sheet/more_action_bottom_sheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/selecting_watchlist_bottomsheet/selecting_watchlist.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_chart/stock_low_heigh_chart.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_page_header/stock_page_header.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/watchlist/market_overview.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';

class IndexDetailPage extends StatefulWidget {
  ServiceLocator serviceLocator;
  Instrument instrument;
  IndexDetailPage(
      {Key? key, required this.instrument, required this.serviceLocator})
      : super(key: key);

  @override
  State<IndexDetailPage> createState() => _IndexDetailPageState();
}

class _IndexDetailPageState extends State<IndexDetailPage> {
  int selectedTab = 0;
  AnimationController? _controller;
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: Column(
        children: [
          CustomStockAppBar(
            onBackPressed: () {
              context.gNavigationService.back(context);
            },
            exchangeName: "INDEX",
            isVisibleCahrtOption: false,
            onMoreActionPressed: () {
              customShowModalBottomSheet(
                context: context,
                inputWidget: MoreActionBottomSheet(
                  onAddWatchList: () {
                    Navigator.pop(context);
                    customShowModalBottomSheet(
                      context: context,
                      inputWidget: SelectingWatchlist(
                        watchlists: UserController().watchlists,
                        symbol: widget.instrument,
                      ),
                    );
                  },
                ),
              );
            },
            onMarketOverviewPressed: () {
              customBottomSheet(
                  controller: _controller,
                  height: .9,
                  minimumHeight: .7,
                  context: context,
                  inputWidget: MarKetOverview());
            },
            title: widget.instrument.securityCode,
          ),
          BlocBuilder<IndexCubit, IndexState>(builder: ((context, state) {
            if (state is IndexInitial) {
              return StockPageHeaderSection(
                  instrument: state.instrument,
                  chartPage: () {
                    context.gNavigationService.openStockChartPage(context);
                  });
            } else {
              return const SizedBox();
            }
          })),
          const SizedBox(height: 10),
          Expanded(
            child: CustomTabBar(
              isScrollable: true,
              onTap: (tab) {
                selectedTab = tab;
                BlocProvider.of<IndexCubit>(context).refresh();
              },
              initialSelected: 0,
              indicatorSize: TabBarIndicatorSize.label,
              tabContent: const [
                "Overview",
                "Research",
                "Analysis",
                "Positions",
                "History"
              ],
              tabBarViewChildern: [
                Column(
                  children: [
                    const SizedBox(height: 30),
                    BlocBuilder<IndexCubit, IndexState>(
                        builder: ((context, state) {
                      if (state is IndexInitial) {
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            MBPStatusListItem(
                                data: state.instrument.openPrice
                                    .toStringAsFixed(
                                        state.instrument.precision),
                                index: 1,
                                title: "Open"),
                            MBPStatusListItem(
                                data: state.instrument.closePrice
                                    .toStringAsFixed(
                                        state.instrument.precision),
                                index: 2,
                                title: "Close"),
                            const SizedBox(height: 30),
                            StockLowHeighChart(
                                instrument: state.instrument,
                                currentValue: state.instrument.lastTrdPrice,
                                endValue: state.instrument.dayHighPrice,
                                startValue: state.instrument.dayLowPrice,
                                startTitile: "Today’s Low",
                                endTitle: "Today’s High"),
                            StockLowHeighChart(
                                instrument: state.instrument,
                                currentValue: state.instrument.lastTrdPrice,
                                endValue: state.instrument.high52Week,
                                startValue: state.instrument.low52Week,
                                startTitile: "52 Weeks Low",
                                endTitle: "52 Weeks High"),
                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 16, bottom: 16, top: 20),
                              child: Text("Pin to Market Overview",
                                  style: customTextStyle(
                                      fontStyle: FontStyle.HeaderXS_Bold,
                                      color: FontColor.FontPrimary)),
                            ),
                            MarketOverviewIndex(
                              instrument: widget.instrument,
                            ),
                          ],
                        );
                      } else {
                        return const SizedBox();
                      }
                    })),
                  ],
                ),
                Center(
                  child: Text(
                    "Comming Soon",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_Bold,
                        color: FontColor.FontSecondary),
                  ),
                ),
                Center(
                  child: Text(
                    "Comming Soon",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_Bold,
                        color: FontColor.FontSecondary),
                  ),
                ),
                Center(
                  child: Text(
                    "Comming Soon",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_Bold,
                        color: FontColor.FontSecondary),
                  ),
                ),
                Center(
                  child: Text(
                    "Comming Soon",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyL_Bold,
                        color: FontColor.FontSecondary),
                  ),
                ),
                //const HistoryTabPage()
              ],
            ),
          ),
        ],
      ),
    );
  }
}

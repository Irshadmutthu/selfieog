import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/featur_symbolsearch/symbol_search/cubit/symbol_search_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/individual_stock_page/components/graphs/geojit_sentiments_graphui.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/individual_stock_page/components/market_overview_index/market_overview_index.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/individual_stock_page/components/mbp/mbp_data.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/individual_stock_page/cubit/stock_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/mbp_status_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_chart/linear_chart.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_chart/stock_low_heigh_chart.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class OverviewTabPage extends StatefulWidget {
  Instrument instrument;
  BuildContext context;

  OverviewTabPage({Key? key, required this.instrument, required this.context})
      : super(key: key) {
    symbolsearch();
  }
  symbolsearch() async {
    if (instrument.type != "CM") return;
    try {
      bool _status = await fillSymbolData(context, instrument);
      if (_status) {
        BlocProvider.of<StockPageCubit>(context).refresh();
      }
    } catch (e) {
      log(e.toString(), time: DateTime.now());
    }
  }

  @override
  State<OverviewTabPage> createState() => _OverviewTabPageState();
}

class _OverviewTabPageState extends State<OverviewTabPage> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 24),
          Padding(
            padding: const EdgeInsets.only(left: 16),
            child: Text("Market by Price (MBP)",
                style: customTextStyle(
                    fontStyle: FontStyle.HeaderXS_Bold,
                    color: FontColor.FontPrimary)),
          ),
          BlocBuilder<StockPageCubit, StockState>(builder: ((context, state) {
            if (state is StockInitial) {
              return Column(
                children: [
                  const Padding(
                    padding: EdgeInsets.all(16.0),
                    child: MBPData(),
                  ),
                  StockLinearChart(
                    totalBuyQty: widget.instrument.totalBuyQty,
                    totalSellQty: widget.instrument.totalSellQty,
                  ),
                  const SizedBox(height: 20),
                  MBPStatusListItem(
                      data: widget.instrument.openPrice
                          .toStringAsFixed(widget.instrument.precision),
                      index: 1,
                      title: "Open"),
                  MBPStatusListItem(
                      data: widget.instrument.closePrice
                          .toStringAsFixed(widget.instrument.precision),
                      index: 2,
                      title: "Close"),
                  MBPStatusListItem(
                      data: widget.instrument.avgTrdPrice
                          .toStringAsFixed(widget.instrument.precision),
                      index: 1,
                      title: "Average Traded Price"),
                  MBPStatusListItem(
                      data: (widget.instrument.avgTrdPrice *
                              widget.instrument.totalTrdQty)
                          .toStringAsFixed(0),
                      index: 2,
                      title: "Volume"),
                  widget.instrument.type == "CM"
                      ? Column(
                          children: [
                            MBPStatusListItem(
                                data: widget.instrument.totalTrdQty
                                    .toStringAsFixed(0),
                                index: 1,
                                title: "Traded Qty"),
                            MBPStatusListItem(
                                data: widget.instrument.lastTrdQty
                                    .toStringAsFixed(0),
                                index: 2,
                                title: "Last Traded Qty"),
                            MBPStatusListItem(
                                data: widget.instrument.isliquid == "Y"
                                    ? "YES"
                                    : "NO",
                                index: 1,
                                title: "Illiquid"),
                            MBPStatusListItem(
                                data: widget.instrument.tradetotrade == 1
                                    ? "YES"
                                    : "NO",
                                index: 2,
                                title: "Trade to Trade"),
                            MBPStatusListItem(
                                data: widget.instrument.isin,
                                index: 1,
                                title: "ISIN"),
                          ],
                        )
                      : const SizedBox(),
                  StockLowHeighChart(
                      instrument: widget.instrument,
                      currentValue: widget.instrument.lastTrdPrice,
                      startValue: widget.instrument.dayLowPrice,
                      endValue: widget.instrument.dayHighPrice,
                      startTitile: "Today’s Low",
                      endTitle: "Today’s High"),
                  widget.instrument.type == "CM"
                      ? StockLowHeighChart(
                          instrument: widget.instrument,
                          currentValue: widget.instrument.lastTrdPrice,
                          startValue: widget.instrument.low52Week,
                          endValue: widget.instrument.high52Week,
                          startTitile: "52 Weeks Low",
                          endTitle: "52 Weeks High")
                      : const SizedBox(),
                  StockLowHeighChart(
                      instrument: widget.instrument,
                      currentValue: widget.instrument.lastTrdPrice,
                      startValue: widget.instrument.lowerCheckLmt,
                      endValue: widget.instrument.upperCheckLmt,
                      startTitile: "Lower Circuit",
                      endTitle: "Upper Circuit"),
                ],
              );
            } else {
              return const SizedBox();
            }
          })),
          const SizedBox(height: 40),
          widget.instrument.type == "CM" ||
                  widget.instrument.type.contains("FUT") ||
                  widget.instrument.type.contains("OPT")
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text("Geojit Sentiments",
                          style: customTextStyle(
                              fontStyle: FontStyle.HeaderXS_Bold,
                              color: FontColor.FontPrimary)),
                    ),
                    GeojitSentimentsGraph(
                        instrument: widget.instrument, context: context),
                    Padding(
                      padding:
                          const EdgeInsets.only(left: 16, bottom: 16, top: 20),
                      child: Text("Pin to Market Overview",
                          style: customTextStyle(
                              fontStyle: FontStyle.HeaderXS_Bold,
                              color: FontColor.FontPrimary)),
                    ),
                    MarketOverviewIndex(
                      instrument: widget.instrument,
                    )
                  ],
                )
              : const SizedBox()

          // const CompanyDetails(),
          // const SizedBox(height: 40),
          // Padding(
          //   padding: const EdgeInsets.only(
          //     left: 16,
          //   ),
          //   child: Text("Announcements",
          //       style: customTextStyle(
          //           fontStyle: FontStyle.HeaderXS_Bold,
          //           color: FontColor.FontPrimary)),
          // ),
          // const AnnouncementListConatiner(),
          // Padding(
          //   padding: const EdgeInsets.only(left: 16, top: 16, right: 16),
          //   child: Row(
          //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //     children: [
          //       Text("Deals",
          //           style: customTextStyle(
          //               fontStyle: FontStyle.HeaderXS_Bold,
          //               color: FontColor.FontPrimary)),
          //       GestureDetector(
          //         onTap: () {
          //           context.gNavigationService.openDealsPage(context);
          //         },
          //         child: Row(
          //           mainAxisAlignment: MainAxisAlignment.center,
          //           crossAxisAlignment: CrossAxisAlignment.center,
          //           children: [
          //             Padding(
          //               padding: const EdgeInsets.only(bottom: 3),
          //               child: Text("View More  ",
          //                   style: customTextStyle(
          //                       fontStyle: FontStyle.BodyL_Bold,
          //                       color: FontColor.Primary)),
          //             ),
          //             Image.asset(
          //               "assets/strokeright.png",
          //             )
          //           ],
          //         ),
          //       ),
          //     ],
          //   ),
          // ),
          // DealsListContainer(dealsList: dealsList),
          // Padding(
          //   padding: const EdgeInsets.only(left: 16, bottom: 16, top: 20),
          //   child: Text("Company News",
          //       style: customTextStyle(
          //           fontStyle: FontStyle.HeaderXS_Bold,
          //           color: FontColor.FontPrimary)),
          // ),
          // ComapnyNewsListItem(
          //   image: "assets/imgone.png",
          //   newshead:
          //       "Stock in review: TCS, Zee Entertainment, Axis bank, ITC...",
          //   source: "ECONOMIC TIMES",
          //   status: "NEGATIVE",
          //   time: "1 HR AGO",
          // ),
          // const SizedBox(height: 8),
          // ComapnyNewsListItem(
          //   image: "assets/imgtwo.png",
          //   newshead: "Metro Brands, HCL Tech, TCS in focus",
          //   source: "ECONOMIC TIMES",
          //   status: "POSITIVE",
          //   time: "1 HR AGO",
          // ),
          // const SizedBox(height: 8),
          // ComapnyNewsListItem(
          //   image: "assets/imgthree.png",
          //   newshead:
          //       "Stocks to watch: Reliance Industries, Zee, Yess Bank, Dish...",
          //   source: "ECONOMIC TIMES",
          //   status: "NUETRAL",
          //   time: "1 HR AGO",
          // ),
          // Padding(
          //   padding: const EdgeInsets.all(16),
          //   child: Row(
          //     mainAxisAlignment: MainAxisAlignment.end,
          //     children: [
          //       InkWell(
          //         onTap: () {},
          //         child: Text("Load More",
          //             style: customTextStyle(
          //                 fontStyle: FontStyle.BodyM_Bold,
          //                 color: FontColor.FontPrimary)),
          //       ),
          //     ],
          //   ),
          // ),
        ],
      ),
    );
  }
}

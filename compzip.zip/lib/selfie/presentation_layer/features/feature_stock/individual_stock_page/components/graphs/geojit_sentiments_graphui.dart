import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';

class GeojitSentimentsGraph extends StatefulWidget {
  Instrument instrument;
  BuildContext context;
  GeojitSentimentsGraph(
      {Key? key, required this.instrument, required this.context})
      : super(key: key);

  @override
  State<GeojitSentimentsGraph> createState() =>
      _GeojitSentimentsGraphState(context: context, instrument: instrument);
}

class _GeojitSentimentsGraphState extends State<GeojitSentimentsGraph> {
  _GeojitSentimentsGraphState(
      {required Instrument instrument, required BuildContext context}) {
    getGeojitSentiments(context, instrument);
  }

  double quantityBought = 0.00;
  double quantitySold = 0.00;
  double clientsBoughttoday = 0.00;
  double clientSoldtoday = 0.00;
  double boughtPerc = 0.00;

  getGeojitSentiments(BuildContext context, Instrument instrument) async {
    try {
      final _res = await context.gTradingApiGateway.getGeojitSentiments(
          venuCode: instrument.venuecode,
          venuScripCode: instrument.scripcode,
          userId: UserController.userController.userId);
      if (_res.errorCode == 0) {
        boughtPerc = (_res.result!.totalBuyQty! /
            ((_res.result!.totalBuyQty)! + (_res.result!.totalSellQty!)));
        quantityBought = boughtPerc * 100;
        quantitySold = 100 - quantityBought;
        clientsBoughttoday = (_res.result!.noOfBuyClient! /
                (_res.result!.noOfBuyClient! + _res.result!.noOfSellClient!)) *
            100;
        clientSoldtoday = 100 - clientsBoughttoday;

        quantityBought.isInfinite ||
                quantityBought.isNaN ||
                quantityBought.isNegative
            ? quantityBought = 0.0
            : quantityBought;
        quantitySold.isInfinite || quantitySold.isNaN || quantitySold.isNegative
            ? quantitySold = 0.0
            : quantitySold;
        clientsBoughttoday.isInfinite ||
                clientsBoughttoday.isNaN ||
                clientsBoughttoday.isNegative
            ? clientsBoughttoday = 0.0
            : clientsBoughttoday;
        clientSoldtoday.isInfinite ||
                clientSoldtoday.isNaN ||
                clientSoldtoday.isNegative
            ? clientSoldtoday = 0.0
            : clientSoldtoday;
        boughtPerc.isInfinite || boughtPerc.isNaN || boughtPerc.isNegative
            ? boughtPerc = 0.0
            : boughtPerc;

        setState(() {});
      }
    } catch (e) {
      log(e.toString(), time: DateTime.now());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              RichText(
                  text: TextSpan(
                      text: "Quantity Bought",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyS_Regular,
                          color: FontColor.FontSecondary),
                      children: [
                    TextSpan(
                        text: " ${quantityBought.toStringAsFixed(2)}%",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.Success))
                  ])),
              RichText(
                  text: TextSpan(
                      text: "${quantitySold.toStringAsFixed(2)}%",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyM_SemiBold,
                          color: FontColor.Danger),
                      children: [
                    TextSpan(
                        text: "  Quantity Sold",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyS_Regular,
                            color: FontColor.FontSecondary))
                  ]))
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 4, top: 8),
            child: LinearPercentIndicator(
              padding: const EdgeInsets.all(0),
              animation: true,
              animationDuration: 1000,
              lineHeight: 12,
              backgroundColor: customColors().danger.withOpacity(0.7),
              progressColor: customColors().success,
              percent: boughtPerc,
              barRadius: const Radius.circular(3),
              alignment: MainAxisAlignment.end,
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              RichText(
                  text: TextSpan(
                      text: "Clients Bought Today",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyS_Regular,
                          color: FontColor.FontSecondary),
                      children: [
                    TextSpan(
                        text: " ${clientsBoughttoday.toStringAsFixed(2)}%",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyS_SemiBold,
                            color: FontColor.FontPrimary))
                  ])),
              RichText(
                  text: TextSpan(
                      text: "${clientSoldtoday.toStringAsFixed(2)}% ",
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyS_SemiBold,
                          color: FontColor.FontPrimary),
                      children: [
                    TextSpan(
                        text: "Client Sold Today",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyS_Regular,
                            color: FontColor.FontSecondary))
                  ]))
            ],
          ),
        ],
      ),
    );
  }
}

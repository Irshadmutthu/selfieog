// import 'package:flutter/material.dart';
// import 'package:selfie_mobile_flutter/app_page_injectable.dart';
// import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
// import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/portfolio_list_item.dart';
// import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/position/position_bottom_sheets.dart';
// import 'package:selfie_mobile_flutter/theme/styles.dart';

// class PositionsTabPage extends StatefulWidget {
//   const PositionsTabPage({Key? key}) : super(key: key);

//   @override
//   State<PositionsTabPage> createState() => _PositionsTabPageState();
// }

// class _PositionsTabPageState extends State<PositionsTabPage> {
//   List<Map<String, dynamic>> PositionSampleList = [
//     {
//       "name": "BANKNIFTY",
//       "OrderType": "INTRADAY",
//       "QUANTITY": 10,
//       "avg": 300.12,
//       "Ltp": 300.34,
//       "badge": "N",
//       "ORDTYPECOLOR": customColors().islandAqua,
//       "sidebarcolor": red200,
//       "PANDL": "-234.66",
//       "pandlcolor": FontColor.Danger,
//       "PANDLPER": "-6.80%",
//       "POSITION": "NO",
//       "date": "23 FEB 38000 CE",
//       "contract": "",
//       "topview": "",
//       "position_type": "Open",
//       "segment_type": "Stock"
//     },
//     {
//       "name": "TCS NOV 1800 CE",
//       "OrderType": "INTRADAY",
//       "QUANTITY": 10,
//       "avg": 300.12,
//       "Ltp": 300.34,
//       "badge": "Y",
//       "ORDTYPECOLOR": customColors().islandAqua,
//       "sidebarcolor": green200,
//       "PANDL": "+10,982.22",
//       "pandlcolor": FontColor.Success,
//       "PANDLPER": "-6.80%",
//       "POSITION": "NO",
//       "date": "",
//       "contract": "",
//       "topview": "",
//       "position_type": "Close",
//       "segment_type": "Currency"
//     },
//     {
//       "name": "HDFC",
//       "OrderType": "INTRADAY",
//       "QUANTITY": 10,
//       "avg": 300.12,
//       "Ltp": 300.34,
//       "badge": "N",
//       "ORDTYPECOLOR": customColors().islandAqua,
//       "sidebarcolor": green200,
//       "PANDL": "+10,982.22",
//       "pandlcolor": FontColor.Success,
//       "PANDLPER": "-6.80%",
//       "POSITION": "NO",
//       "date": "",
//       "topview": "",
//       "position_type": "Todays Trade",
//       "segment_type": "Commodity"
//     },
//   ];
//   @override
//   Widget build(BuildContext context) {
//     return SingleChildScrollView(
//       child: ListView.builder(
//           itemCount: PositionSampleList.length,
//           shrinkWrap: true,
//           physics: const NeverScrollableScrollPhysics(),
//           itemBuilder: (context, index) {
//             return GestureDetector(
//               onTap: () => customShowModalBottomSheet(
//                 context: context,
//                 stock:
//                     PositionSampleList[index].containsValue("Stock") ? "y" : "",
//                 inputWidget: PositionBottomSheet(
//                   index: index,
//                   notify: false,
//                   toggles: false,
//                   future: PositionSampleList[index].containsValue("Stock")
//                       ? false
//                       : true,
//                   onRollTap: () {
//                     context.gNavigationService.openRollOrderPage(
//                       context,
//                       {
//                         "title": "INFY 22DEC - INFY 22JAN FUT",
//                         "type": "Spread"
//                       },
//                     );
//                   },
//                   onOCOTap: () {
//                     context.gNavigationService.openOCOOrderPage(
//                       context,
//                       {
//                         "title": "OCO Order",
//                         "symbol": "ITC Long",
//                         "qty": "100",
//                         "price": "278.80"
//                       },
//                     );
//                   },
//                   onAddMoreTap: () {
//                     context.gNavigationService.openOrderWindowPage(context,
//                         {"title": "TATAPOWER", "type": "Cash", "order": "buy"});
//                   },
//                   onSquareOffTap: () {
//                     // context.gNavigationService.openOrderWindowPage(context,
//                     //     {"title": "TATAPOWER", "type": "Cash", "order": "sell"});
//                   },
//                 ),
//                 ifport: true,
//               ),
//               child: PortfolioListItem(
//                 portfoliolist: PositionSampleList[index],
//               ),
//             );
//           }),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/general_methods.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';
import 'package:trading_api/responses/get_cloud_watch_response.dart';
import 'package:trading_api/utils/utils.dart';

class MarketOverviewIndex extends StatefulWidget {
  Instrument instrument;
  List<String> slotsCollection = [];
  MarketOverviewIndex({Key? key, required this.instrument}) : super(key: key) {
    List.generate(
        UserController.userController.indexList.length,
        (index) => slotsCollection.add(
            UserController.userController.indexList[index].venuescripcode +
                UserController.userController.indexList[index].venuecode));
  }

  @override
  State<MarketOverviewIndex> createState() => _MarketOverviewIndexState();
}

class _MarketOverviewIndexState extends State<MarketOverviewIndex> {
  String selectedIndex = "";
  @override
  Widget build(BuildContext context) {
    return Center(
      child: SizedBox(
        height: 50,
        child: ListView.builder(
            itemCount: 4,
            shrinkWrap: true,
            scrollDirection: Axis.horizontal,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (context, index) => Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                  child: InkWell(
                    onTap: () async {
                      try {
                        if (widget.slotsCollection[index] ==
                            (widget.instrument.scripcode +
                                widget.instrument.venuecode)) return;
                        selectedIndex = widget.slotsCollection[index];
                        widget.slotsCollection[index] =
                            (widget.instrument.scripcode +
                                widget.instrument.venuecode);
                        setState(() {});
                        final response =
                            await GeneralMethods.updateMarketOverviewSlot(
                                context: context,
                                index: index + 1,
                                instrument: widget.instrument);
                        if (response.errorCode == "0") {
                          MDS_Controller.mdsController.unsubscribeSymbol(
                              UserController().indexList[index].getInstrument);
                          UserController.userController.indexList[index] =
                              SymbolData(
                                  instrumentType:
                                      widget.instrument.type.toString(),
                                  sortorder: (index + 1).toString(),
                                  symbolname: widget.instrument.securityCode,
                                  venuecode: widget.instrument.venuecode,
                                  venuescripcode: widget.instrument.scripcode,
                                  watchlistid: "0",
                                  watchsymbolid: "0",
                                  ca: "");
                          MDS_Controller.mdsController
                              .subscribeSymbol(widget.instrument);
                          UserController.userController
                              .indexInstruments[index] = widget.instrument;
                          UserController().controller.add("indexList update");
                        } else {
                          widget.slotsCollection[index] = selectedIndex;
                          setState(() {});
                          ScaffoldMessenger.of(context).showSnackBar(
                              showErrorDialogue(
                                  errorMessage: response
                                      .result2![0].errormessage
                                      .toString()));
                        }
                      } catch (e) {
                        widget.slotsCollection[index] = selectedIndex;
                        setState(() {});
                        ScaffoldMessenger.of(context).showSnackBar(
                            showErrorDialogue(errorMessage: e.toString()));
                      }
                    },
                    child: Container(
                      alignment: Alignment.center,
                      width: 77,
                      height: 32,
                      decoration: BoxDecoration(
                          color: widget.slotsCollection[index] ==
                                  widget.instrument.scripcode +
                                      widget.instrument.venuecode
                              ? customColors().primary
                              : transparent,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                              color: widget.slotsCollection[index] ==
                                      widget.instrument.scripcode +
                                          widget.instrument.venuecode
                                  ? transparent
                                  : customColors().backgroundTertiary)),
                      child: Text("Spot ${index + 1}",
                          style: widget.slotsCollection[index] ==
                                  widget.instrument.scripcode +
                                      widget.instrument.venuecode
                              ? customTextStyle(
                                      fontStyle: FontStyle.BodyM_Bold,
                                      color: FontColor.FontPrimary)
                                  .copyWith(
                                      color: customColors().backgroundPrimary)
                              : customTextStyle(
                                  fontStyle: FontStyle.BodyM_Regular,
                                  color: FontColor.FontPrimary)),
                    ),
                  ),
                )),
      ),
    );
  }
}

extension on SymbolData {
  Instrument get getInstrument => Instrument(
      scripcode: venuescripcode,
      securityCode: symbolname,
      securityName: symbolname,
      series: "",
      venueIndex: getVenueIndex(venuecode),
      type: instrumentType,
      ca: ca,
      subscriptionType: SubscriptionType.watch);
}

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/individual_stock_page/cubit/stock_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_mbp/ask_data_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_mbp/bid_data_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_mbp/bid_title_widget.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class MBPData extends StatelessWidget {
  const MBPData({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<StockPageCubit, StockState>(
      builder: ((context, state) {
        if (state is StockInitial) {
          return Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                      child: Row(
                    children: [
                      Expanded(
                          flex: 3,
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              "QUANTITY",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyS_SemiBold,
                                  color: FontColor.FontSecondary),
                            ),
                          )),
                      Expanded(
                          flex: 2,
                          child: Align(
                            alignment: Alignment.centerRight,
                            child: Text(
                              "BID",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyS_SemiBold,
                                  color: FontColor.FontSecondary),
                            ),
                          ))
                    ],
                  )),
                  const SizedBox(
                    width: 24.0,
                  ),
                  Expanded(
                      child: Row(
                    children: [
                      Expanded(
                          flex: 2,
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              "ASK",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyS_SemiBold,
                                  color: FontColor.FontSecondary),
                            ),
                          )),
                      Expanded(
                          flex: 3,
                          child: Align(
                            alignment: Alignment.centerRight,
                            child: Text(
                              "QUANTITY",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyS_SemiBold,
                                  color: FontColor.FontSecondary),
                            ),
                          )),
                    ],
                  ))
                ],
              ),
              ListView.builder(
                  itemCount: 5,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) {
                    return Container(
                      padding: const EdgeInsets.symmetric(vertical: 8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Expanded(
                              child: Row(
                            children: [
                              Expanded(
                                  flex: 3,
                                  child: Stack(
                                    alignment: Alignment.centerLeft,
                                    children: [
                                      LinearPercentIndicator(
                                        lineHeight: 24.0,
                                        percent: state
                                            .mbpInstrument.bidQtyPerc[index],
                                        backgroundColor: transparent,
                                        fillColor: transparent,
                                        padding: const EdgeInsets.all(0.0),
                                        progressColor: customColors()
                                            .success
                                            .withOpacity(0.2),
                                        barRadius: const Radius.circular(4.0),
                                        animation: true,
                                      ),
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(left: 8.0),
                                        child: Text(
                                          state.mbpInstrument.bestBuyQtys[index]
                                              .toString(),
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyM_Regular,
                                              color: FontColor.FontPrimary),
                                        ),
                                      ),
                                    ],
                                  )),
                              Expanded(
                                  flex: 2,
                                  child: Align(
                                    alignment: Alignment.centerRight,
                                    child: Text(
                                      state.mbpInstrument.bestBuyPrices[index]
                                          .toStringAsFixed(
                                              state.mbpInstrument.precision),
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_Regular,
                                          color: FontColor.FontPrimary),
                                    ),
                                  ))
                            ],
                          )),
                          const SizedBox(
                            width: 24.0,
                          ),
                          Expanded(
                              child: Row(
                            children: [
                              Expanded(
                                  flex: 2,
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      state.mbpInstrument.bestSellPrices[index]
                                          .toStringAsFixed(
                                              state.mbpInstrument.precision),
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_Regular,
                                          color: FontColor.FontPrimary),
                                    ),
                                  )),
                              Expanded(
                                  flex: 3,
                                  child: Stack(
                                    alignment: Alignment.centerRight,
                                    children: [
                                      LinearPercentIndicator(
                                        lineHeight: 24.0,
                                        percent: state
                                            .mbpInstrument.askQtyPerc[index],
                                        isRTL: true,
                                        backgroundColor: transparent,
                                        fillColor: transparent,
                                        padding: const EdgeInsets.all(0.0),
                                        progressColor: customColors()
                                            .danger
                                            .withOpacity(0.2),
                                        barRadius: const Radius.circular(4.0),
                                        animation: true,
                                      ),
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(right: 8.0),
                                        child: Text(
                                          state
                                              .mbpInstrument.bestSellQtys[index]
                                              .toString(),
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyM_Regular,
                                              color: FontColor.FontPrimary),
                                        ),
                                      ),
                                    ],
                                  )),
                            ],
                          ))
                        ],
                      ),
                    );
                  }),
            ],
          );
        } else {
          return const SizedBox();
        }
      }),
    );
  }
}

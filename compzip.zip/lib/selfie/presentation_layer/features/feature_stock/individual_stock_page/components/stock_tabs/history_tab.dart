import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/list_data.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/history_filter_preset_select/filter_preset_select.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_history_listitem.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class HistoryTabPage extends StatefulWidget {
  const HistoryTabPage({Key? key}) : super(key: key);

  @override
  State<HistoryTabPage> createState() => _HistoryTabPageState();
}

class _HistoryTabPageState extends State<HistoryTabPage> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 16, top: 16, right: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("Transaction History",
                  style: customTextStyle(
                      fontStyle: FontStyle.HeaderXS_Bold,
                      color: FontColor.FontPrimary)),
              GestureDetector(
                onTap: () {
                  customShowModalBottomSheet(
                    context: context,
                    inputWidget: FilterPresetSelect(),
                  );
                },
                child: Row(
                  children: [
                    Image.asset(
                      "assets/filter.png",
                      color: customColors().fontPrimary,
                    ),
                    Text("   Filter",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_Regular,
                            color: FontColor.FontSecondary)),
                  ],
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: 200,
          child: ListView.builder(
            physics: const NeverScrollableScrollPhysics(),
            itemCount: stockHistoryList.length,
            itemBuilder: (context, index) {
              return StockHistoryListItem(
                  historyData: stockHistoryList.elementAt(index));
            },
          ),
        ),
      ],
    );
  }
}

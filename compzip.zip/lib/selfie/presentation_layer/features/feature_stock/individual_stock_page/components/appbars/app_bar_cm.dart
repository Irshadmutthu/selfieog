import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/individual_stock_page/cubit/stock_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_stock_appbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/option_chain_more_action_bottom_sheet/more_action_bottom_sheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/selecting_watchlist_bottomsheet/selecting_watchlist.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/watchlist/market_overview.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';

class CMStockPageAppBar extends StatelessWidget {
  BuildContext context;
  Instrument instrument;
  AnimationController controller;
  CMStockPageAppBar(
      {Key? key,
      required this.instrument,
      required this.context,
      required this.controller})
      : super(key: key);

  @override
  Widget build(context) {
    return CustomStockAppBar(
      exchangeName: instrument.venuecode,
      title: instrument.securityCode,
      onBackPressed: () {
        context.read<StockPageCubit>().mbpUnsubscribe();
        context.gNavigationService.back(context);
      },
      onMoreActionPressed: () {
        customShowModalBottomSheet(
          context: context,
          inputWidget: MoreActionBottomSheet(
            onAddWatchList: () {
              Navigator.pop(context);
              customShowModalBottomSheet(
                context: context,
                inputWidget: SelectingWatchlist(
                  watchlists: UserController().watchlists,
                  symbol: instrument,
                ),
              );
            },
          ),
        );
      },
      onMarketOverviewPressed: () {
        customBottomSheet(
            controller: controller,
            height: .9,
            minimumHeight: .7,
            context: context,
            inputWidget: MarKetOverview());
      },
    );
  }
}

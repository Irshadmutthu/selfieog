import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/individual_stock_page/cubit/stock_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/custom_option_and_future.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/option_chain_more_action_bottom_sheet/more_action_bottom_sheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/selecting_watchlist_bottomsheet/selecting_watchlist.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';

class OPTFUTAppbar extends StatelessWidget {
  Instrument instrument;
  OPTFUTAppbar({
    Key? key,
    required this.instrument,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CustomOptionAndFutureAppBar(
      exchangeName: instrument.venuecode,
      title: instrument.securityCode,
      onBackPressed: () {
        context.read<StockPageCubit>().mbpUnsubscribe();
        context.gNavigationService.back(context);
      },
      onMoreActionPressed: () {
        customShowModalBottomSheet(
          context: context,
          inputWidget: MoreActionBottomSheet(
            onAddWatchList: () {
              Navigator.pop(context);

              customShowModalBottomSheet(
                context: context,
                inputWidget: SelectingWatchlist(
                    watchlists: UserController().watchlists,
                    symbol: instrument),
              );
            },
          ),
        );
      },
    );
  }
}

part of 'stock_cubit.dart';

@immutable
abstract class StockState {}

class StockInitial extends StockState {
  final Instrument instrument;
  final MbpInstrument mbpInstrument;
  StockInitial({required this.instrument, required this.mbpInstrument});
}

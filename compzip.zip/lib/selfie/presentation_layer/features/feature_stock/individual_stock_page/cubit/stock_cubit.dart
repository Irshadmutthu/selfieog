import 'dart:async';
import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/mbp_instrument.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
part 'stock_state.dart';

class StockPageCubit extends Cubit<StockState> {
  Instrument instrument;
  String ricAddress = "";
  ServiceLocator serviceLocator;
  MbpInstrument? mbpInstrument;
  late StreamSubscription streamSubscription;
  StockPageCubit({required this.serviceLocator, required this.instrument})
      : super(StockInitial(
            instrument: instrument,
            mbpInstrument: MbpInstrument(scripcode: "0", venueIndex: 0)
              ..updateInstrument())) {
    ricAddress = instrument.getRicAddress();
    MDS_Controller()
        .marketUpdateStream
        .listen((List<FlairResponseModel> flairResponseModel) {
      updateData(flairResponseModel);
    });
    mbpInstrument = MbpInstrument(
        scripcode: instrument.scripcode, venueIndex: instrument.venueIndex)
      ..updateInstrument();
    mbpSubscribe();
    streamSubscription = MDS_Controller().mbpStream.listen((event) {
      if (isClosed) {
        streamSubscription.cancel();
        return;
      }
      if (mbpInstrument != null) {
        mbpInstrument!.updateInstrument();
        if (!isClosed) {
          emit(StockInitial(
              instrument: instrument, mbpInstrument: mbpInstrument!));
        }
      }
    });
  }

  mbpSubscribe() {
    if (mbpInstrument == null) return;
    MDS_Controller().subscribeMbpSymbol(mbpInstrument!);
  }

  mbpUnsubscribe() {
    if (mbpInstrument == null) return;
    MDS_Controller().unsubscribeMbpSymbol(mbpInstrument!);
  }

  refresh() {
    emit(StockInitial(instrument: instrument, mbpInstrument: mbpInstrument!));
  }

  updateData(List<FlairResponseModel> data) {
    for (var element in data) {
      if (element.ric == ricAddress) {
        instrument = element.instrument;
      }
    }
    if (!isClosed) {
      emit(StockInitial(instrument: instrument, mbpInstrument: mbpInstrument!));
    }
  }
}

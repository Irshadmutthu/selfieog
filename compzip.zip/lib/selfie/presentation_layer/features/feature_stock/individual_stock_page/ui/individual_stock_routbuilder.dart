import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/individual_stock_page/cubit/stock_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/individual_stock_page/ui/individual_stock_page.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class IndividualStockPageRouteBuilder {
  final ServiceLocator _serviceLocator;
  final Map<String, dynamic> mapArguments;

  IndividualStockPageRouteBuilder(this._serviceLocator, this.mapArguments);

  Widget call(BuildContext context) {
    return MultiBlocProvider(
        providers: [
          BlocProvider(
              create: (context) => StockPageCubit(
                  serviceLocator: _serviceLocator,
                  instrument: mapArguments["StockDetails"]))
        ],
        child: MultiRepositoryProvider(
            providers: [
              RepositoryProvider.value(value: _serviceLocator.tradingApi),
            ],
            child: IndividualStockPage(
              serviceLocator: _serviceLocator,
              instrument: mapArguments["StockDetails"],
            )));
  }
}

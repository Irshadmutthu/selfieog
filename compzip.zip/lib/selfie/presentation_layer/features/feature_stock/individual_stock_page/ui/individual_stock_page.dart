import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/order_model/Order.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/individual_stock_page/components/appbars/app_bar_cm.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/individual_stock_page/components/appbars/optfut_appbar.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/individual_stock_page/components/stock_tabs/overview_tab.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_stock/individual_stock_page/cubit/stock_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_top_tab.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_execute_btn.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/stock_page_header/stock_page_header.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';
import 'package:trading_api/utils/utils.dart';

class IndividualStockPage extends StatefulWidget {
  ServiceLocator serviceLocator;

  Instrument instrument;
  IndividualStockPage(
      {Key? key, required this.serviceLocator, required this.instrument})
      : super(key: key);

  @override
  State<IndividualStockPage> createState() => _IndividualStockPageState();
}

class _IndividualStockPageState extends State<IndividualStockPage>
    with TickerProviderStateMixin {
  int selectedTab = 0;
  void initState() {
    super.initState();
    _controller = BottomSheet.createAnimationController(this);
    _controller!.duration = const Duration(milliseconds: 400);
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  AnimationController? _controller;

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return WillPopScope(
      onWillPop: () async {
        context.read<StockPageCubit>().mbpUnsubscribe();
        return true;
      },
      child: Scaffold(
          appBar: PreferredSize(
              preferredSize: const Size.fromHeight(0.0),
              child: AppBar(
                elevation: 0,
                backgroundColor: customColors().backgroundPrimary,
              )),
          body: Column(
            children: [
              widget.instrument.type == "CM"
                  ? CMStockPageAppBar(
                      context: context,
                      controller: _controller!,
                      instrument: widget.instrument,
                    )
                  : widget.instrument.type.contains("FUT") ||
                          widget.instrument.type.contains("OPT")
                      ? OPTFUTAppbar(instrument: widget.instrument)
                      : widget.instrument.type.contains("Spreead")
                          ? OPTFUTAppbar(instrument: widget.instrument)
                          : OPTFUTAppbar(instrument: widget.instrument),
              BlocBuilder<StockPageCubit, StockState>(
                  builder: (context, state) {
                if (state is StockInitial) {
                  return StockPageHeaderSection(
                      instrument: state.instrument,
                      chartPage: () {
                        context.gNavigationService.openStockChartPage(context);
                      });
                } else {
                  return Container();
                }
              }),
              const SizedBox(height: 10),
              Expanded(
                child: CustomTabBar(
                  isScrollable: true,
                  onTap: (tab) {
                    selectedTab = tab;
                    BlocProvider.of<StockPageCubit>(context).refresh();
                  },
                  initialSelected: 0,
                  indicatorSize: TabBarIndicatorSize.label,
                  tabContent: const [
                    "Overview",
                    "Research",
                    "Analysis",
                    "Positions",
                    "History"
                  ],
                  tabBarViewChildern: [
                    OverviewTabPage(
                      instrument: widget.instrument,
                      context: context,
                    ),
                    Center(
                      child: Text(
                        "No data available",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_Bold,
                            color: FontColor.FontSecondary),
                      ),
                    ),
                    Center(
                      child: Text(
                        "No data available",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_Bold,
                            color: FontColor.FontSecondary),
                      ),
                    ),
                    Center(
                      child: Text(
                        "No data available",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_Bold,
                            color: FontColor.FontSecondary),
                      ),
                    ),
                    Center(
                      child: Text(
                        "No data available",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_Bold,
                            color: FontColor.FontSecondary),
                      ),
                    ),
                    //const HistoryTabPage()
                  ],
                ),
              ),
            ],
          ),
          bottomNavigationBar: BlocBuilder<StockPageCubit, StockState>(
              builder: (context, state) {
            if (state is StockInitial) {
              return SafeArea(
                child: Container(
                  height: 76,
                  width: screenSize.width * 1,
                  decoration: BoxDecoration(
                    border: Border(
                      top: BorderSide(
                        color: customColors().backgroundTertiary,
                        width: 1,
                      ),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: Row(
                      children: [
                        Expanded(
                          child: StockExecuteButton(
                            text: "Buy",
                            bgColor: customColors().success,
                            onTap: () {
                              OrderModel order = OrderModel(widget.instrument,
                                  UserSettings.userSettings.orderSettings);
                              order.buyOrSell = BUY;

                              context.gNavigationService.openOrderWindowPage(
                                  context, {"order": order});
                            },
                          ),
                        ),
                        const SizedBox(
                          width: 8.0,
                        ),
                        Expanded(
                          child: StockExecuteButton(
                            text: "Sell",
                            bgColor: customColors().danger,
                            onTap: () {
                              OrderModel order = OrderModel(widget.instrument,
                                  UserSettings.userSettings.orderSettings);
                              order.buyOrSell = SELL;

                              context.gNavigationService.openOrderWindowPage(
                                  context, {"order": order});
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            } else {
              return const SizedBox();
            }
          })),
    );
  }
}

import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/order_book_content.dart';

part 'smartfolio_component_state.dart';

class SmartfolioComponentCubit extends Cubit<SmartfolioComponentState> {
  SmartfolioComponentCubit() : super(SmartfolioComponentInitial(smartfolioList: smartfolioList));
  smartfolioSearch() {
    emit(SmartfolioComponentInitial(
        searchVisible: true, smartfolioList:smartfolioList));
  }
}

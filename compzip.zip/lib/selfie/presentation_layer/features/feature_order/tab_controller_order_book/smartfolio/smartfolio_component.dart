import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/smartfolio/bloc/smartfolio_component_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/orderbook_smartfolio_filter_bar.dart';
// import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/order_book_open_filter_bar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/empty_list_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/smartfolio/smartfolio_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/orders_smartfolio_sheet/orders_smartfolio_sheet.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class OrderBookSmartfolioComponent extends StatefulWidget {
  Function(bool) onScrollEvent;
  OrderBookSmartfolioComponent({
    Key? key,
    required this.onScrollEvent,
  }) : super(key: key);

  @override
  State<OrderBookSmartfolioComponent> createState() =>
      _OrderBookSmartfolioComponentState();
}

class _OrderBookSmartfolioComponentState
    extends State<OrderBookSmartfolioComponent> with TickerProviderStateMixin {
  int screenCount = 1;
  ScrollController _scrollBottomBarController = new ScrollController();

  bool isScrollingDown = false;

  void initState() {
    super.initState();
    _controller = BottomSheet.createAnimationController(this);
    _controller!.duration = const Duration(milliseconds: 400);
    myScroll();
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  void myScroll() async {
    _scrollBottomBarController.addListener(() {
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        if (!isScrollingDown) {
          isScrollingDown = true;
          widget.onScrollEvent(false); //hide appbar
        }
      }
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.forward) {
        if (isScrollingDown) {
          isScrollingDown = false;
          widget.onScrollEvent(true); //show appbar
        }
      }
    });
  }

  AnimationController? _controller;

  bool notify = false;
  @override
  Widget build(BuildContext context) {
    // return Container(child: Center(child: Text("Open component"),),);
    return BlocProvider(
        create: (context) => SmartfolioComponentCubit(),
        child: BlocBuilder<SmartfolioComponentCubit, SmartfolioComponentState>(
            builder: (context, state) {
          return Column(
            children: [
              Expanded(
                child: Stack(
                  children: [
                    SingleChildScrollView(
                      controller: _scrollBottomBarController,
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            screenCount == 1
                                ? const Padding(
                                    padding: EdgeInsets.only(top: 100),
                                    child: OrderbookEmptyContainer(
                                        title: "No smartfolio recommendation",
                                        subTitle: "Lorem ipsum dolor sit ame"),
                                  )
                                : BlocBuilder<SmartfolioComponentCubit,
                                        SmartfolioComponentState>(
                                    builder: (context, state) {
                                    if (state is SmartfolioComponentInitial) {
                                      return Column(
                                        children: [
                                          SearchFilterHoldings(
                                            onFilterPress: () {
                                              // customShowModalBottomSheet(
                                              //     context: context,
                                              //     inputWidget: OpenSortFilterList(
                                              //       currentval: filterval,
                                              //       // selectedLocation:
                                              //       //     SortFilterLocation.holding,
                                              //       onPressFilter: (String name) {
                                              //         List<Map<String, dynamic>> list = [];
                                              //         state.holdingList.forEach((element) {
                                              //           if (element.containsValue(name)) {
                                              //             list.add(element);
                                              //           }
                                              //         });

                                              //         BlocProvider.of<OpenComponentCubit>(
                                              //                 context)
                                              //             .updateSortList(list);
                                              //       },
                                              //       onPressReset: () {
                                              //         List<Map<String, dynamic>> list = [];
                                              //         list = List.from(holdingsList2);

                                              //         BlocProvider.of<HoldingsComponentCubit>(
                                              //                 context)
                                              //             .updateSortList(list);
                                              //       },
                                              //     ));
                                              // setState(() {
                                              //   notify = !notify;
                                              // });
                                            },
                                            onSearchPress: () {
                                              BlocProvider.of<
                                                          SmartfolioComponentCubit>(
                                                      context)
                                                  .smartfolioSearch();
                                            },
                                            //TODO filter notification bubbles
                                          ),
                                          ListView.builder(
                                              physics:
                                                  const NeverScrollableScrollPhysics(),
                                              itemCount:
                                                  state.smartfolioList.length,
                                              shrinkWrap: true,
                                              itemBuilder: (context, index) {
                                                return InkWell(
                                                  onTap: () {
                                                    customShowModalBottomSheet(
                                                      context: context,
                                                      inputWidget:
                                                          SmartFolioSheet(),
                                                    );
                                                  },
                                                  child: SmartfolioListItem(
                                                      smartfolioList:
                                                          state.smartfolioList[
                                                              index]),
                                                );
                                              }),
                                        ],
                                      );
                                    } else {
                                      return Container();
                                    }
                                  }),
                            SizedBox(height: 55)
                          ]),
                    ),
                    Align(
                        alignment: Alignment.bottomCenter,
                        child: Container(
                          color: customColors().adBackground,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 12.0, horizontal: 16),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Image.asset("assets/smartfolio_icon.png"),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 8.0),
                                      child: Text(
                                        "Open Smartfolio App",
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyL_SemiBold,
                                            color: FontColor.FontPrimary),
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Padding(
                                      padding:
                                          const EdgeInsets.only(right: 8.0),
                                      child: Text(
                                        "Open",
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyL_SemiBold,
                                            color: FontColor.Primary),
                                      ),
                                    ),
                                    Icon(
                                      Icons.arrow_forward,
                                      color: customColors().primary,
                                    )
                                  ],
                                )
                              ],
                            ),
                          ),
                        )),
                    // Align(
                    //   alignment: Alignment.bottomCenter,
                    //   child: skipButton(context, "$screenCount/2", () {
                    //     if (screenCount > 1) {
                    //       setState(() {
                    //         screenCount--;
                    //       });
                    //     }
                    //   }, () {
                    //     if (screenCount < 2) {
                    //       setState(() {
                    //         screenCount++;
                    //       });
                    //     }
                    //   }),
                    // ),
                  ],
                ),
              ),
            ],
          );
        }));
  }
}

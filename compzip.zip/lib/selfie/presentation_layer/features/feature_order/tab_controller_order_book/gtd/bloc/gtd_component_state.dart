part of 'gtd_component_cubit.dart';

@immutable
abstract class GTDComponentState {}

class GTDComponentInitial extends GTDComponentState {
  List<GTdModel> gtdList;
  final bool searchActive;
  final bool isSearchFinished;
  List<String> filterarrayposition;
  final int filterval;
  String errorMessage;

  GTDComponentInitial(
      {required this.gtdList,
      this.errorMessage = "",
      this.filterval = -1,
      this.isSearchFinished = false,
      this.searchActive = false,
      required this.filterarrayposition});

  GTDComponentInitial copyWith({
    List<GTdModel>? gtdList,
    bool? searchActive,
    bool? filterActive,
    int? filterval,
    final bool? isSearchFinished,
    required List<String> filterarrayposition,
  }) {
    return GTDComponentInitial(
        gtdList: gtdList ?? this.gtdList,
        searchActive: searchActive ?? this.searchActive,
        filterarrayposition: filterarrayposition,
        isSearchFinished: isSearchFinished ?? this.isSearchFinished,
        filterval: filterval ?? this.filterval);
  }
}

class GtdLoadingState extends GTDComponentState {}

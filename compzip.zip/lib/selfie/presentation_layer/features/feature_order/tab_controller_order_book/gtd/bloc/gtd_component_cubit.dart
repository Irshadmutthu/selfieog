import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_book/cubit/order_book_screen_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/gtd/components/gtd_model.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_pages/order_window_page.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';
import 'package:trading_api/requests/cancel_gtd_order.dart';
import 'package:trading_api/responses/order_status_gtd_response.dart';
import 'package:trading_api/responses/order_status_item_response.dart';
part 'gtd_component_state.dart';

class GTDComponentCubit extends Cubit<GTDComponentState> {
  final TradingApiGateway gateway;
  OrderItemOrderGtdResponse? _response;
  List<String> filterarrayposition = [];
  int currentVal = -1;
  List<GTdModel> list = [];

  // List<GTdModel> gtdModelList = [];
  final BuildContext context;
  List<GtdResult3> gtdList = [];
  List<GTdModel> allList = [];
  List<Instrument> instList = [];
  List<OrderStatusResult3> onlineList = [];
  StreamSubscription? streamSubscription;

  GTDComponentCubit({required this.context, required this.gateway})
      : super(GtdLoadingState()) {
    if (UserController().allowGtdRequest) {
      gtdOrderRequest();
    }
    streamSubscription = MDS_Controller()
        .marketUpdateStream
        .listen((List<FlairResponseModel> flairResponseModel) {
      if (!isClosed) {
        data("");
      } else {
        unsubscribeSymbols();
      }
    });
  }

  subscribeSymbols() {
    if (isClosed) return;
    MDS_Controller().subscribeSymbols(instList);
    MDS_Controller().getLatestFeedUpdates(instList);
    data("");
  }

  unsubscribeSymbols() {
    if (instList.isEmpty) return;
    MDS_Controller().unsubscribeSymbols(instList);
  }

  Future<bool> gtdOrderRequest() async {
    try {
      unsubscribeSymbols();
      emit(GtdLoadingState());
      _response =
          await gateway.orderGtdRequest(userCode: UserController().userId);
      if (_response!.errorCode == "0") {
        UserController().allowGtdRequest = false;
        UserController().orderGtdResponse.clear();
        gtdList.clear();
        list.clear();
        instList.clear();
        allList.clear();
        if (_response!.result2[0].errorcode == "0") {
          for (int i = 0; i < _response!.result3.length; i++) {
            gtdList.add(_response!.result3[i]);
          }
          UserController().orderGtdResponse = gtdList;
          UserController().resetorderGtdResponse = gtdList;
          List.generate(gtdList.length, (index) {
            list.add(GTdModel.updateGtdModel(gtdList[index]));
            allList.add(GTdModel.updateGtdModel(gtdList[index]));
            instList.add(list[index].instrument);
          });
          subscribeSymbols();
          context.read<OrderBookScreenCubit>().updateCubit();
          data("");
          return true;
        } else {
          data(_response!.errorMessage.toString());
          return false;
        }
      } else {
        data(_response!.errorMessage.toString());
        return false;
      }
    } catch (e) {
      data(e.toString());
      return false;
    }
  }

  orderTypeUpdate(String val) {
    switch (val) {
      case "MARKET":
        {
          return "MKT";
        }
      case "LIMIT":
        {
          return "LMT";
        }
      case "SL-LIMIT":
        {
          return "STL";
        }
      case "BASKET ORDER":
        {
          return "BO";
        }
      case "CONFIRMED":
        {
          return "Confirmed";
        }
      case "PENDING":
        {
          return "Pending";
        }
      case "SAVED":
        {
          return "Saved";
        }
    }
    return val;
  }

  // List<GtdResult3> closedSort(List<GtdResult3> list, int index) {
  //   switch (index) {
  //     case 0:
  //       list.sort(((a, b) => (a.securitycode!).compareTo(b.securitycode!)));
  //       break;
  //     case 1:
  //       list.sort(((a, b) => (a.securitycode!).compareTo(b.securitycode!)));
  //       list = list.reversed.toList();
  //       break;
  //   }
  //   return list;
  // }

  search(String keyword) async {
    List<GTdModel> searchResult = [];
    searchResult.clear();
    list.forEach(((element) {
      if (element.securitycode.contains(keyword.toUpperCase())) {
        searchResult.add(element);
      }
    }));
    emit((state as GTDComponentInitial).copyWith(
        gtdList: searchResult, filterarrayposition: filterarrayposition));
  }

  // search(String keyword) async {
  //   List<GTdModel> searchResult = [];
  //   // List<GtdResult3> searchSet = UserController().orderGtdResponse;
  //   searchResult.clear();
  //   list.forEach(((element) {
  //     if (element.securitycode.contains(keyword.trim().toUpperCase()) ||
  //         element.securitycode.startsWith(keyword.trim().toUpperCase())) {
  //       searchResult.add(element);
  //     }
  //   }));
  //   // emit((state as GTDComponentInitial).copyWith(
  //   //     gtdList: searchResult, filterarrayposition: filterarrayposition));
  //   data("");
  // }

  newSort(int index) {
    currentVal = index;
    data("");
  }

  newFilter(List<String> el) {
    filterarrayposition = el;
    data("");
  }

  newFilterSort() {
    // List.generate(gtdList.length, (index) {
    //   list.add(GTdModel.updateGtdModel(gtdList[index]));
    // });

    list = List.from(allList);
    list.sort(((a, b) => (b.ordertime).compareTo(a.ordertime)));
    if (filterarrayposition.isNotEmpty) {
      List<GTdModel> finalList = [];
      for (var element in list) {
        for (int i = 0; i < filterarrayposition.length; i++) {
          if (element.producttype.contains(
                  orderTypeUpdate(filterarrayposition[i].toUpperCase())) ||
              element.buyorsell ==
                  orderTypeUpdate(filterarrayposition[i].toUpperCase()) ||
              element.pricecondition ==
                  orderTypeUpdate(filterarrayposition[i].toUpperCase()) ||
              element.statussubcategory ==
                  orderTypeUpdate(filterarrayposition[i].toUpperCase())) {
            finalList.add(element);
          }
        }
        list = finalList;
      }
    }
    if (currentVal != -1) {
      switch (currentVal) {
        case 0:
          list.sort(((a, b) => (a.securitycode).compareTo(b.securitycode)));
          break;
        case 1:
          list.sort(((a, b) => (a.securitycode).compareTo(b.securitycode)));
          list = list.reversed.toList();
          break;
      }
    }
  }

  data(String error) {
    if (isClosed) return;
    if (list.isEmpty) {
      unsubscribeSymbols();
    }
    // list.clear();
    newFilterSort();
    // subscribeSymbols();
    emit(GTDComponentInitial(
      gtdList: list,
      filterarrayposition: filterarrayposition,
      filterval: currentVal,
      errorMessage: error,
      searchActive: false,
    ));
  }

  resetList() {
    filterarrayposition.clear();
    currentVal = -1;
    data("");
  }

  onLoading(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return StreamBuilder(
            stream: Stream.periodic(const Duration(milliseconds: 1)),
            builder: (context, snap) {
              return Dialog(
                child: Container(
                  height: 120,
                  width: 100,
                  color: customColors().backgroundPrimary,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(
                        color: customColors().primary,
                      ),
                    ],
                  ),
                ),
              );
            });
      },
    );
  }

  cancelresult(
    BuildContext context,
    List<GTdModel> list,
    int index,
    bool todayCancel,
    bool gtdCancel,
  ) async {
    onlineList.clear();
    Navigator.of(context).pop(true);
    List<OrderStatusResult3> onlineOrder =
        UserController().orderBookData!.result3;
    for (int i = 0; i < onlineOrder.length; i++) {
      if (onlineOrder[i].tifdate == list[index].tifdate &&
          onlineOrder[i].venuescripcode == list[index].instrument.scripcode) {
        onlineList.add(onlineOrder[i]);
      }
    }
    if (onlineList[0].status == "EXE" || onlineList[0].status == "PEXE") {
      ScaffoldMessenger.of(context).showSnackBar(showErrorDialogue(
          errorMessage: "This GTD order is already executed"));
    } else {
      onLoading(context);
      await orderCancel(
          context: context,
          gtdCancel: gtdCancel,
          todayCancel: todayCancel,
          ordTransId: list[index].ordtransid,
          priceCondition: list[index].priceconditionid,
          producTypeId: int.parse(
            list[index].productid,
          ),
          securityCode: list[index].securitycode,
          tifdate:
              dateConversion(list[index].tifdate, "dd/MMM/yyyy", "yyyy-MM-dd"),
          transId: list[index].transid,
          venueCode: list[index].instrument.venuecode,
          venueScripCode: list[index].instrument.scripcode);
    }
  }

  Future<bool> orderCancel({
    required String transId,
    required String venueCode,
    required String securityCode,
    required String venueScripCode,
    required int producTypeId,
    required String priceCondition,
    required bool gtdCancel,
    required bool todayCancel,
    required BuildContext context,
    required String tifdate,
    required String ordTransId,
  }) async {
    try {
      final _cancelGtdOrder = await context.gTradingApiGateway.cancelGtdRequest(
          cancelOrderRequest: CancelGtdOrder(
        corelationId: DateTime.now().microsecondsSinceEpoch,
        proc: "cancel_offline_order_service",
        intReqObj: CancelGtdIntReqObj(
          cancelOffline: gtdCancel,
          cancelTodays: todayCancel,
          channel: 18,
          ordTransId: ordTransId,
          orderId: null,
          orderType: 28,
          priceCondition: priceCondition,
          proClient: "CLI",
          productType: producTypeId,
          securityCode: securityCode,
          tifCd: 3,
          tifDate: tifdate,
          transId: transId,
          venueCode: venueCode,
          venueScripCode: venueScripCode,
          dtoheader: OrderGTDDtoheader(
            creationTime: DateTime.now().microsecondsSinceEpoch,
            loginId: UserController().userId,
            messageType: 12,
          ),
        ),
      ));
      if (_cancelGtdOrder.errorCode == 0) {
        Navigator.of(context).pop(true);
        Navigator.of(context).pop(true);
        ScaffoldMessenger.of(context).showSnackBar(showSuccessDialogue(
            errorMessage: gtdCancel
                ? "Order succesfully cancelled and GTD order cancelled successfully"
                : "Cancel order sent to exchange"));
        return true;
      } else if (_cancelGtdOrder.errorCode == 2512) {
        Navigator.of(context).pop(true);
        Navigator.of(context).pop(true);
        ScaffoldMessenger.of(context).showSnackBar(showErrorDialogue(
            errorMessage:
                "Order status is neither confirmed or partially executed"));
        return true;
      } else {
        Navigator.of(context).pop(true);
        Navigator.of(context).pop(true);
        ScaffoldMessenger.of(context).showSnackBar(
            showErrorDialogue(errorMessage: "internal server error"));
        return false;
      }
    } catch (e) {
      Navigator.of(context).pop(true);
      Navigator.of(context).pop(true);
      ScaffoldMessenger.of(context).showSnackBar(
          showErrorDialogue(errorMessage: "internal server error"));
      return false;
    }
  }

  // updateSortData(int index) {
  //   List<GtdResult3> list = [];
  //   List<GtdResult3> sortSet = UserController().orderGtdResponse;
  //   list = closedSort(sortSet, index);
  //   emit((state as GTDComponentInitial).copyWith(
  //       gtdList: list,
  //       filterval: index,
  //       filterarrayposition: filterarrayposition));
  // }

  // updateFiltertData(List<String> el) {
  //   List<GtdResult3> filterSet = UserController().orderGtdResponse;
  //   List<GtdResult3> list = [];
  //   filterarrayposition = List.from(el);
  //   if (el.isEmpty) {
  //     emit((state as GTDComponentInitial).copyWith(
  //         gtdList: filterSet, filterarrayposition: filterarrayposition));
  //   } else {
  //     filterSet.forEach((element) {
  //       for (int i = 0; i < el.length; i++) {
  //         if (list.contains(element)) {
  //         } else {
  //           if (element.producttype!
  //                   .contains(orderTypeUpdate(el[i].toUpperCase())) ||
  //               element.buyorsell == orderTypeUpdate(el[i].toUpperCase()) ||
  //               element.pricecondition ==
  //                   orderTypeUpdate(el[i].toUpperCase()) ||
  //               element.statussubcategory ==
  //                   orderTypeUpdate(el[i].toUpperCase())) {
  //             list.add(element);
  //           }
  //         }
  //       }
  //     });
  //     if (list.isEmpty) {
  //       emit((state as GTDComponentInitial)
  //           .copyWith(gtdList: [], filterarrayposition: filterarrayposition));
  //       return;
  //     }
  //     emit((state as GTDComponentInitial)
  //         .copyWith(gtdList: list, filterarrayposition: filterarrayposition));
  //   }
  // }

  // updateData() {
  //   UserController.userController.orderGtdResponse.length;
  //   emit(GTDComponentInitial(
  //       gtdList: UserController().orderGtdResponse,
  //       filterarrayposition: filterarrayposition));
  // }
}

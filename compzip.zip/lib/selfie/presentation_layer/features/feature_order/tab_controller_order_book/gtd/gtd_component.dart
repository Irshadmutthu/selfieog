import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/featur_symbolsearch/symbol_search/cubit/symbol_search_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/components/pop_up.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/components/search_form.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_book/cubit/order_book_screen_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/gtd/bloc/gtd_component_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/gtd/complete_orders/bottom_sheet_header/orders_summary_completed_orders.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/gtd/components/gtd_shimmer.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/order_book_open_filter_bar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/empty_list_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/gtd/gtd_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_calander/table_range.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/fixed_bottom_buttons/fixed_bottom_buttons.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';
import 'package:trading_api/responses/order_status_gtd_response.dart';
import 'package:trading_api/responses/order_status_item_response.dart';
import 'package:trading_api/utils/utils.dart';
import '../../../../../../order_model/Order.dart';
import '../../../../../../utils/user_settings.dart';
import 'components/gtd_filter_sort.dart';

class OrderBookGTDComponent extends StatefulWidget {
  Function(bool) onScrollEvent;
  OrderBookGTDComponent({
    Key? key,
    required this.onScrollEvent,
  }) : super(key: key);

  @override
  State<OrderBookGTDComponent> createState() => _OrderBookGTDComponentState();
}

class _OrderBookGTDComponentState extends State<OrderBookGTDComponent>
    with AutomaticKeepAliveClientMixin<OrderBookGTDComponent> {
  int screenCount = 1;
  ScrollController _scrollBottomBarController = new ScrollController();

  bool isScrollingDown = false;
  late TradingApiGateway _gateway;

  void initState() {
    // TODO: implement initState
    super.initState();
    // _controller = BottomSheet.createAnimationController(this);
    // _controller!.duration = const Duration(milliseconds: 400);
    _gateway = context.gTradingApiGateway;
    myScroll();
  }

  @override
  void dispose() {
    // _controller!.dispose();
    super.dispose();
  }

  final TextEditingController _serach = TextEditingController();

  List<OrderStatusResult3> onlineList = [];

  void myScroll() async {
    _scrollBottomBarController.addListener(() {
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        if (!isScrollingDown) {
          isScrollingDown = true;
          widget.onScrollEvent(false); //hide appbar
        }
      }
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.forward) {
        if (isScrollingDown) {
          isScrollingDown = false;
          widget.onScrollEvent(true); //show appbar
        }
      }
    });
  }

  AnimationController? _controller;
  bool deleteGtdOrder = true;
  bool deleteTodays = true;
  bool argResult = false;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) =>
          GTDComponentCubit(gateway: _gateway, context: context),
      child: BlocConsumer<GTDComponentCubit, GTDComponentState>(
          listener: (context, state) {
        if (state is GTDComponentInitial) {
          // BlocProvider.of<GTDComponentCubit>(context).data();
          if (state.errorMessage != "") {
            ScaffoldMessenger.of(context).showSnackBar(
                showErrorDialogue(errorMessage: state.errorMessage));
          }
        }
      }, builder: (context, state) {
        return RefreshIndicator(
          backgroundColor: customColors().primary,
          onRefresh: () async {
            UserController().allowGtdRequest = true;
            BlocProvider.of<GTDComponentCubit>(context).gtdOrderRequest();
            context.read<OrderBookScreenCubit>().updateCubit();
          },
          child: Column(
            children: [
              BlocBuilder<GTDComponentCubit, GTDComponentState>(
                builder: (context, state) {
                  if (state is GTDComponentInitial) {
                    if (UserController
                        .userController.orderGtdResponse.isNotEmpty) {
                      return Column(
                        children: [
                          Visibility(
                            visible: !state.searchActive,
                            child: SearchFilterHoldings(
                              sortBubble: state.filterval != -1,
                              showBubble: state.filterarrayposition.isNotEmpty,
                              onFilterPress: () {
                                customShowModalBottomSheet(
                                  context: context,
                                  inputWidget: GtdSortFilter(
                                    filterarrayposition:
                                        state.filterarrayposition,
                                    currentval: state.filterval,
                                    selectedTabIndex: 0,
                                    onPresssort: (int index) {
                                      BlocProvider.of<GTDComponentCubit>(
                                              context)
                                          .newSort(index);
                                    },
                                    onPressFilter: (List<String> el) {
                                      BlocProvider.of<GTDComponentCubit>(
                                              context)
                                          .newFilter(el);
                                    },
                                    onPressReset: () {
                                      BlocProvider.of<GTDComponentCubit>(
                                              context)
                                          .resetList();
                                    },
                                  ),
                                );
                              },
                              ononSortPress: () {
                                customShowModalBottomSheet(
                                  context: context,
                                  inputWidget: GtdSortFilter(
                                    filterarrayposition:
                                        state.filterarrayposition,
                                    currentval: state.filterval,
                                    selectedTabIndex: 1,
                                    onPresssort: (int index) {
                                      BlocProvider.of<GTDComponentCubit>(
                                              context)
                                          .newSort(index);
                                    },
                                    onPressFilter: (List<String> el) {
                                      BlocProvider.of<GTDComponentCubit>(
                                              context)
                                          .newFilter(el);
                                    },
                                    onPressReset: () {
                                      BlocProvider.of<GTDComponentCubit>(
                                              context)
                                          .resetList();
                                    },
                                  ),
                                );
                              },
                              onSearchPress: () {
                                BlocProvider.of<GTDComponentCubit>(context)
                                    .emit(state.copyWith(
                                        searchActive: true,
                                        filterActive: false,
                                        filterarrayposition:
                                            state.filterarrayposition));
                              },
                            ),
                          ),
                          Visibility(
                            visible: state.searchActive,
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 8.0),
                              child: OrderbookSearch(
                                onBackPressed: () {
                                  BlocProvider.of<GTDComponentCubit>(context)
                                      .emit(state.copyWith(
                                          searchActive: false,
                                          filterActive: true,
                                          filterarrayposition:
                                              state.filterarrayposition));
                                  BlocProvider.of<GTDComponentCubit>(context)
                                      .data("");
                                },
                                hintText: "Search eg: infy",
                                controller: _serach,
                                onSearch: (String keyword) {
                                  // BlocProvider.of<GTDComponentCubit>(context)
                                  //     .search(keyword);
                                },
                              ),
                            ),
                          ),
                        ],
                      );
                    }
                  }
                  return Container();
                },
              ),
              BlocBuilder<GTDComponentCubit, GTDComponentState>(
                builder: (context, state) {
                  if (state is GtdLoadingState) {
                    return const GtdShimmer();
                  }
                  return BlocBuilder<GTDComponentCubit, GTDComponentState>(
                    builder: (context, state) {
                      if (state is GTDComponentInitial) {
                        if (UserController
                            .userController.orderGtdResponse.isEmpty) {
                          return ListView.builder(
                              physics: const AlwaysScrollableScrollPhysics(),
                              shrinkWrap: true,
                              itemCount: 1,
                              itemBuilder: (context, index) {
                                return Column(
                                  children: const [
                                    Padding(
                                      padding: EdgeInsets.only(top: 100),
                                      child: OrderbookEmptyContainer(
                                          title: "No GTD orders", subTitle: ""),
                                    )
                                  ],
                                );
                              });
                        } else {
                          return Expanded(
                            child: SingleChildScrollView(
                              physics: const ScrollPhysics(
                                  parent: AlwaysScrollableScrollPhysics()),
                              controller: _scrollBottomBarController,
                              child: Column(
                                children: [
                                  ListView.builder(
                                      physics:
                                          const NeverScrollableScrollPhysics(),
                                      itemCount: state.gtdList.length,
                                      shrinkWrap: true,
                                      itemBuilder: (context, index) {
                                        return InkWell(
                                          onTap: () {
                                            Instrument instrument = state
                                                .gtdList
                                                .elementAt(index)
                                                .instrument;
                                            callSymbolSearch(
                                                context, state, instrument);
                                            customBottomSheet(
                                                height: .76,
                                                maxHeight: .89,
                                                context: context,
                                                inputWidget: GtdCompletedOrders(
                                                  orderLogList: state.gtdList,
                                                  overViewList: state.gtdList,
                                                  index: index,
                                                ),
                                                fixedBottomWidget:
                                                    BlocProvider.value(
                                                        value: BlocProvider.of<
                                                                GTDComponentCubit>(
                                                            context),
                                                        child: BlocBuilder<
                                                                GTDComponentCubit,
                                                                GTDComponentState>(
                                                            builder: (context,
                                                                state) {
                                                          if (state
                                                              is GTDComponentInitial) {
                                                            return OdrderBookFixedButton(
                                                              loading: !state
                                                                  .isSearchFinished,
                                                              enable: state
                                                                  .isSearchFinished,
                                                              elevation: true,
                                                              modify: true,
                                                              onReorderClick:
                                                                  () {},
                                                              onmodifyClick:
                                                                  () {
                                                                if (!state
                                                                    .isSearchFinished) {
                                                                  return;
                                                                }
                                                                OrderModel order = OrderModel(
                                                                    instrument,
                                                                    UserSettings
                                                                        .userSettings
                                                                        .orderSettings);

                                                                order.TransId = state
                                                                    .gtdList
                                                                    .elementAt(
                                                                        index)
                                                                    .transid;
                                                                order
                                                                    .qty = VENUE_IN_QTY.elementAt(VENUES_ORDER.indexOf(
                                                                        instrument
                                                                            .venuecode))
                                                                    ? state
                                                                        .gtdList
                                                                        .elementAt(
                                                                            index)
                                                                        .quantity
                                                                    : state.gtdList
                                                                            .elementAt(
                                                                                index)
                                                                            .quantity *
                                                                        instrument
                                                                            .lotsize!;
                                                                if (state
                                                                        .gtdList
                                                                        .elementAt(
                                                                            index)
                                                                        .buyorsell
                                                                        .toString() ==
                                                                    "BUY") {
                                                                  order.buyOrSell =
                                                                      BUY;
                                                                } else {
                                                                  order.buyOrSell =
                                                                      SELL;
                                                                }
                                                                order.isModify =
                                                                    true;
                                                                order.productType =
                                                                    int.parse(state
                                                                        .gtdList
                                                                        .elementAt(
                                                                            index)
                                                                        .productid);
                                                                order.timeCondition =
                                                                    state
                                                                        .gtdList
                                                                        .elementAt(
                                                                            index)
                                                                        .tifcd;
                                                                order.tifDate = state
                                                                    .gtdList
                                                                    .elementAt(
                                                                        index)
                                                                    .tifdate;
                                                                order.priceCondition =
                                                                    getPriceConditionbyId(int.parse(state
                                                                        .gtdList
                                                                        .elementAt(
                                                                            index)
                                                                        .priceconditionid));
                                                                order.triggerPrice = state
                                                                    .gtdList
                                                                    .elementAt(
                                                                        index)
                                                                    .triggerprice
                                                                    .toString();
                                                                order.price = state
                                                                    .gtdList
                                                                    .elementAt(
                                                                        index)
                                                                    .price
                                                                    .toString();

                                                                context
                                                                    .gNavigationService
                                                                    .openOrderWindowPage(
                                                                        context,
                                                                        {
                                                                      "order":
                                                                          order
                                                                    });
                                                              },
                                                              onCancel:
                                                                  () async {
                                                                if (state
                                                                            .gtdList[
                                                                                index]
                                                                            .status ==
                                                                        "SEND" ||
                                                                    state.gtdList[index]
                                                                            .status ==
                                                                        "SAVED") {
                                                                  setState(() {
                                                                    deleteGtdOrder =
                                                                        true;
                                                                    deleteTodays =
                                                                        true;
                                                                  });
                                                                  await showAlertDilogueOrderBook(
                                                                    context:
                                                                        context,
                                                                    negativeButtonName:
                                                                        "Cancel",
                                                                    title: Text(
                                                                      "This ia a gtd order",
                                                                      style: customTextStyle(
                                                                          fontStyle: FontStyle
                                                                              .BodyM_SemiBold,
                                                                          color:
                                                                              FontColor.FontSecondary),
                                                                    ),
                                                                    content: StatefulBuilder(builder:
                                                                        (context,
                                                                            setState) {
                                                                      return SizedBox(
                                                                        height:
                                                                            110,
                                                                        child:
                                                                            Column(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.center,
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.center,
                                                                          children: [
                                                                            Center(
                                                                              child: Text(
                                                                                "Do you want to cancel it ?",
                                                                                style: customTextStyle(fontStyle: FontStyle.BodyM_SemiBold, color: FontColor.FontSecondary),
                                                                              ),
                                                                            ),
                                                                            Padding(
                                                                              padding: const EdgeInsets.only(top: 20),
                                                                              child: Column(
                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                children: [
                                                                                  Row(
                                                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                                                    children: [
                                                                                      // EmptyCustomCheckBox(
                                                                                      //   isSelect: deleteTodays,
                                                                                      //   callback: ((bool todays) {
                                                                                      //     print(todays);
                                                                                      //     setState(() {
                                                                                      //       deleteTodays = todays;
                                                                                      //     });
                                                                                      //   }),
                                                                                      // ),
                                                                                      EmptyCustomCheckBox(
                                                                                        isSelect: deleteTodays,
                                                                                        callback: (bool val) {
                                                                                          setState(() {
                                                                                            deleteTodays = val;
                                                                                          });
                                                                                        },
                                                                                      ),
                                                                                      const SizedBox(
                                                                                        width: 5,
                                                                                      ),
                                                                                      Text(
                                                                                        "Cancel Today's Order",
                                                                                        style: customTextStyle(fontStyle: FontStyle.BodyM_SemiBold, color: FontColor.FontSecondary),
                                                                                      )
                                                                                    ],
                                                                                  ),
                                                                                  Padding(
                                                                                    padding: const EdgeInsets.only(top: 10),
                                                                                    child: Row(
                                                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                                                      children: [
                                                                                        EmptyCustomCheckBox(
                                                                                          isSelect: deleteGtdOrder,
                                                                                          callback: (bool checked) {
                                                                                            setState(() {
                                                                                              deleteGtdOrder = checked;
                                                                                            });
                                                                                          },
                                                                                        ),
                                                                                        const SizedBox(
                                                                                          width: 5,
                                                                                        ),
                                                                                        Text(
                                                                                          "Delete Gtd Order",
                                                                                          style: customTextStyle(fontStyle: FontStyle.BodyM_SemiBold, color: FontColor.FontSecondary),
                                                                                        )
                                                                                      ],
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      );
                                                                    }),
                                                                    onNegativeButtonClick:
                                                                        () {
                                                                      Navigator.of(
                                                                              context)
                                                                          .pop(
                                                                              true);
                                                                    },
                                                                    onPositiveButtonClick:
                                                                        () async {
                                                                      await BlocProvider.of<GTDComponentCubit>(
                                                                              context)
                                                                          .cancelresult(
                                                                        context,
                                                                        state
                                                                            .gtdList,
                                                                        index,
                                                                        deleteTodays,
                                                                        deleteGtdOrder,
                                                                      );
                                                                      BlocProvider.of<GTDComponentCubit>(
                                                                              context)
                                                                          .gtdOrderRequest();
                                                                    },
                                                                  );
                                                                } else {
                                                                  ScaffoldMessenger.of(
                                                                          context)
                                                                      .showSnackBar(showErrorDialogue(
                                                                          errorMessage:
                                                                              "Sorry!! CANCEL not allowed for ${state.gtdList[index].status} orders."));
                                                                }
                                                              },
                                                            );
                                                          } else {
                                                            return Container();
                                                          }
                                                        })));
                                          },
                                          child: GTDListItem(
                                            gtdList: state.gtdList,
                                            index: index,
                                          ),
                                        );
                                      }),
                                ],
                              ),
                            ),
                          );
                        }
                      }
                      return Container();
                    },
                  );
                },
              ),
            ],
          ),
        );
      }),
    );
  }

  // onlineOrder(List<GtdResult3> data, int index) {
  //   onlineList.clear();
  //   List<OrderStatusResult3> onlineOrder =
  //       UserController().orderBookData!.result3;
  //   for (int i = 0; i < onlineOrder.length; i++) {
  //     if (data[index].tifdate == onlineOrder[i].tifdate &&
  //         data[index].venuescripcode == onlineOrder[i].venuescripcode) {
  //       onlineList.add(onlineOrder[i]);
  //     }
  //   }
  // }

  callSymbolSearch(BuildContext context, GTDComponentInitial state,
      Instrument instrument) async {
    context.read<GTDComponentCubit>().emit(state.copyWith(
        isSearchFinished: false,
        filterarrayposition: state.filterarrayposition));
    if (await fillSymbolData(context, instrument)) {
      context.read<GTDComponentCubit>().emit(state.copyWith(
          isSearchFinished: true,
          filterarrayposition: state.filterarrayposition));
    }
  }

  Future<dynamic> showAlertDilogue(
      {required BuildContext context,
      required String content,
      String? positiveButtonName,
      String? negativeButtonName,
      VoidCallback? onPositiveButtonClick,
      VoidCallback? onNegativeButtonClick}) async {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) {
          return AlertDialog(
            backgroundColor: customColors().backgroundPrimary,
            content: Text(
              content,
              style: customTextStyle(
                  fontStyle: FontStyle.BodyM_SemiBold,
                  color: FontColor.FontSecondary),
            ),
            actions: [
              TextButton(
                child: Text(
                  positiveButtonName ?? "OK",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.Danger),
                ),
                onPressed: onPositiveButtonClick,
              ),
              if (negativeButtonName != null)
                TextButton(
                  child: Text(
                    negativeButtonName,
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.Info),
                  ),
                  onPressed: onNegativeButtonClick,
                ),
            ],
          );
        });
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
}

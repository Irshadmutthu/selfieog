import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/gtd/complete_orders/tab_view.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/gtd/components/gtd_model.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/watchlist/custom_watchlist_content/custom_watchlist_content.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:trading_api/responses/order_status_gtd_response.dart';

class GtdCompletedOrders extends StatefulWidget {
  List<GTdModel> overViewList;
  List<GTdModel> orderLogList;
  int index;

  GtdCompletedOrders(
      {Key? key,
      required this.overViewList,
      required this.orderLogList,
      required this.index})
      : super(key: key);

  @override
  State<GtdCompletedOrders> createState() => _GtdCompletedOrdersState();
}

class _GtdCompletedOrdersState extends State<GtdCompletedOrders> {
  late TradingApiGateway _gateway;

  @override
  void initState() {
    super.initState();
    _gateway = context.gTradingApiGateway;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding:
              const EdgeInsets.only(left: 16, right: 16, top: 10, bottom: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Order Summary",
                style: customTextStyle(
                  fontStyle: FontStyle.HeaderXS_SemiBold,
                  color: FontColor.FontPrimary,
                ),
              ),
            ],
          ),
        ),
        Divider(
          height: 0,
          thickness: 1,
          color: customColors().backgroundTertiary,
        ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 0, 0, 4),
                      child: Row(
                        children: [
                          SymbolNameWidget(widget
                              .overViewList[widget.index].securitycode
                              .toString()),
                        ],
                      ),
                    ),
                    Row(
                      children: [
                        getProductTypeWidget(widget
                            .overViewList[widget.index].instrument.venuecode
                            .toString()),
                        const SizedBox(
                          width: 6,
                        ),
                        getProductTypeWidget(widget
                            .overViewList[widget.index].buyorsell
                            .toString()),
                        const SizedBox(
                          width: 6,
                        ),
                        getProductTypeWidget(widget
                            .overViewList[widget.index].producttype
                            .toString())
                      ],
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    widget.overViewList[widget.index].instrument.lastTrdPrice
                        .toStringAsFixed(widget
                            .overViewList[widget.index].instrument.precision),
                    style: customTextStyle(
                      fontStyle: FontStyle.BodyL_SemiBold,
                      color: FontColor.FontPrimary,
                    ),
                  ),
                  const SizedBox(
                    height: 4,
                  ),
                  Text(
                    "(${widget.overViewList[widget.index].instrument.getLtpColor() == customColors().success ? "+" : ""}${widget.overViewList[widget.index].instrument.percChange.toStringAsFixed(2)}%)",
                    style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.Success,
                    ),
                  )
                ],
              )
            ],
          ),
        ),
        GtdOrderBookTabComponents(
          gtdList: widget.overViewList,
          index: widget.index,
        ),
      ],
    );
  }
}

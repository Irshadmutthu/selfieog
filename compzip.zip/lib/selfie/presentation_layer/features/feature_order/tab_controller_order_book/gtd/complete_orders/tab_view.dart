import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/gtd/complete_orders/tabs/order_overview/overview.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/gtd/components/gtd_model.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:trading_api/responses/order_status_gtd_response.dart';

class GtdOrderBookTabComponents extends StatefulWidget {
  List<GTdModel> gtdList;
  int index;
  GtdOrderBookTabComponents(
      {Key? key, required this.gtdList, required this.index})
      : super(key: key);

  @override
  State<GtdOrderBookTabComponents> createState() =>
      _GtdOrderBookTabComponentsState();
}

class _GtdOrderBookTabComponentsState extends State<GtdOrderBookTabComponents>
    with SingleTickerProviderStateMixin {
  final List<Tab> myTabs = const [
    Tab(text: 'Overview'),
  ];
  int selectedTabIndex = 0;
  List<Widget> tabbarView = [];

  late final TabController _tabController =
      TabController(length: myTabs.length, vsync: this);

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    tabbarView = [
      GtdOverViewTab(
        gtdList: widget.gtdList,
        index: widget.index,
      ),
    ];
    return DefaultTabController(
        length: myTabs.length,
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                    border: Border(
                      bottom:
                          BorderSide(color: customColors().backgroundTertiary),
                    ),
                  ),
                  child: TabBar(
                      controller: _tabController,
                      isScrollable: true,
                      indicatorPadding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 0),
                      onTap: (index) {
                        setState(() {
                          selectedTabIndex = index;
                        });
                      },
                      unselectedLabelStyle: customTextStyle(
                          fontStyle: FontStyle.BodyL_Regular,
                          color: FontColor.FontSecondary),
                      labelStyle: customTextStyle(
                          fontStyle: FontStyle.BodyL_SemiBold,
                          color: FontColor.Primary),
                      unselectedLabelColor: customColors().fontSecondary,
                      indicatorColor: customColors().primary,
                      indicatorSize: TabBarIndicatorSize.tab,
                      indicatorWeight: 2,
                      // indicatorPadding: const EdgeInsets.all(10),
                      labelColor: customColors().primary,
                      tabs: myTabs),
                ),
              ],
            ),
            tabbarView[selectedTabIndex]
          ],
        ));
  }
}

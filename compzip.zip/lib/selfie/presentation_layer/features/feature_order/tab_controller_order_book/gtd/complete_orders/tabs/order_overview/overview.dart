import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/conversions/conversions.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/gtd/components/gtd_model.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_window/order_window_pages/order_window_page.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/mbp_status_list_item.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:trading_api/responses/order_status_gtd_response.dart';

class GtdOverViewTab extends StatelessWidget {
  List<GTdModel> gtdList;
  int index;
  GtdOverViewTab({Key? key, required this.gtdList, required this.index})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Order Details",
                style: customTextStyle(
                  fontStyle: FontStyle.HeaderXS_Bold,
                  color: FontColor.FontPrimary,
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  RichText(
                    text: TextSpan(
                      text: 'STATUS: ',
                      style: customTextStyle(
                        fontStyle: FontStyle.TagNameL_SemiBold,
                        color: FontColor.FontSecondary,
                      ),
                    ),
                  ),
                  OrderStatusWidget(text: gtdList[index].status.toString()),
                ],
              )
            ],
          ),
        ),
        // status == OrderStatus.conditional
        //     ? Padding(
        //         padding:
        //             const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        //         child: Container(
        //           height: 34,
        //           decoration: BoxDecoration(
        //             borderRadius: BorderRadius.circular(4),
        //             color: customColors().dodgerBlue.withOpacity(.15),
        //           ),
        //           child: Row(
        //             children: [
        //               Padding(
        //                 padding: const EdgeInsets.only(left: 8.6),
        //                 child: Text(
        //                   "Order Trigger when Spot is greater than 1500",
        //                   style: customTextStyle(
        //                     fontStyle: FontStyle.BodyM_SemiBold,
        //                     color: FontColor.DodgerBlue,
        //                   ),
        //                 ),
        //               ),
        //             ],
        //           ),
        //         ),
        //       )
        //     : const SizedBox(),
        MBPStatusListItem(
          title: "Order Type",
          index: 1,
          data: priceConditionConversion(
                  gtdList[index].priceconditionid.toString())
              .toString(),
        ),
        MBPStatusListItem(
          title: "Limit Price",
          index: 2,
          data: gtdList[index].price.toStringAsFixed(2).toString(),
        ),
        MBPStatusListItem(
            title: "Trigger Price",
            index: 1,
            data: gtdList[index].triggerprice.toStringAsFixed(2).toString()),
        MBPStatusListItem(
            title: "GTD Date",
            index: 2,
            data: gtdList[index].tifdate == ""
                ? ""
                : dateConversion(
                    gtdList[index].tifdate, "dd/MMM/yyyy", "dd/MM/yy")),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Divider(
            thickness: 1.0,
            color: customColors().backgroundTertiary,
          ),
        ),
        MBPStatusListItem(
            title: "Order Qty",
            index: 1,
            data: gtdList[index].quantity.toString()),
        MBPStatusListItem(
          title: "Executed Qty",
          index: 2,
          data: gtdList[index].quantity.toString().isEmpty
              ? ""
              : gtdList[index].quantity.toString(),
        ),
        MBPStatusListItem(title: "Pending Qty", index: 1, data: "0"),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Divider(
            thickness: 1.0,
            color: customColors().backgroundTertiary,
          ),
        ),
        MBPStatusListItem(
            title: "Product",
            index: 1,
            data: gtdList[index].producttype.toString()),
        MBPStatusListItem(
            title: "Validity", index: 2, data: gtdList[index].tifcd.toString()),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          child: Divider(
            thickness: 1.0,
            color: customColors().backgroundTertiary,
          ),
        ),
        MBPStatusListItem(
          title: "Order Time",
          index: 1,
          data: orderbookDateFormat(gtdList[index].ordertime.toString()),
        ),
        MBPStatusListItem(
          title: "Exchange ID",
          index: 1,
          data: "#${gtdList[index].transid.toString()}",
        ),
        const SizedBox(
          height: 10,
        ),
      ],
    );
  }
}

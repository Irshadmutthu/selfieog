import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:trading_api/responses/order_status_gtd_response.dart';
import 'package:trading_api/utils/utils.dart';

class GTdModel {
  Instrument instrument;
  // String venuescripcode;
  int quantity;
  String transid;
  String status;
  String tifcd;
  String ordtransid;
  double price;
  String pricecondition;
  double triggerprice;
  String strikeprice;
  String disclosedquantity;
  String producttype;
  // String venuecode;
  String channel;
  String ordertime;
  String buyorsell;
  String bookedprice;
  String securitycode;
  String expirationdate;
  String tifdate;
  String statusid;
  String productid;
  String statussubcategory;
  String priceconditionid;
  GTdModel({
    required this.instrument,
    // this.venuescripcode = "",
    this.quantity = 0,
    this.transid = "",
    this.status = "",
    this.tifcd = "",
    this.ordtransid = "",
    this.price = 0.00,
    this.pricecondition = "",
    this.triggerprice = 0.00,
    this.strikeprice = "",
    this.disclosedquantity = "",
    this.producttype = "",
    // this.venuecode = "",
    this.channel = "",
    this.ordertime = "",
    this.buyorsell = "",
    this.bookedprice = "",
    this.securitycode = "",
    this.expirationdate = "",
    this.tifdate = "",
    this.productid = "",
    this.statusid = "",
    this.statussubcategory = "",
    this.priceconditionid = "",
  });

  static GTdModel updateGtdModel(GtdResult3 gtd) {
    return GTdModel(
      instrument: Instrument(
          scripcode: gtd.venuescripcode!,
          venueIndex: getVenueIndex(gtd.venuecode!),
          subscriptionType: SubscriptionType.watch,
          securityCode: gtd.securitycode ?? ""),
      // venuescripcode: gtd.venuescripcode!,
      quantity: gtd.quantity!,
      transid: gtd.transid!,
      status: gtd.status!,
      tifcd: gtd.tifcd!,
      ordtransid: gtd.ordtransid!,
      price: gtd.price!,
      pricecondition: gtd.priceconditionid!,
      triggerprice: gtd.triggerprice!,
      strikeprice: gtd.strikeprice!,
      disclosedquantity: gtd.disclosedquantity!,
      producttype: gtd.producttype!,
      // venuecode: gtd.venuecode!,
      channel: gtd.channel!,
      ordertime: gtd.ordertime!,
      buyorsell: gtd.buyorsell!,
      bookedprice: gtd.bookedprice!,
      securitycode: gtd.securitycode!,
      expirationdate: gtd.expirationdate!,
      tifdate: gtd.tifdate!,
      productid: gtd.productid!,
      statusid: gtd.statusid!,
      statussubcategory: gtd.statussubcategory!,
      priceconditionid: gtd.priceconditionid!,
    );
  }
}

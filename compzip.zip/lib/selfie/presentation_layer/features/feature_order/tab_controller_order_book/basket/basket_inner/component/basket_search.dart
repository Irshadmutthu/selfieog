import 'package:flutter/material.dart';

import '../../../../../../../../theme/styles.dart';

class Basket_Search extends StatefulWidget {
  final void Function()? onTap;
  Basket_Search({Key? key, required this.onTap}) : super(key: key);

  @override
  State<Basket_Search> createState() => _Basket_SearchState();
}

class _Basket_SearchState extends State<Basket_Search> {
  @override
  Widget build(BuildContext context) {
    // return SizedBox(
    //   width: MediaQuery.of(context).size.width,
    //   height: 48,
    //   child: TextFormField(
    //     onTap: () => widget.onTap,
    //     autocorrect: true,
    //     decoration: InputDecoration(
    //       prefixIcon: ImageIcon(
    //         const AssetImage("assets/searchicon.png"),
    //         color: customColors().fontPrimary,
    //       ),
    //       // suffixIcon: Visibility(
    //       //   visible: widget.countVisibility,
    //       //   child: Padding(
    //       //     padding: const EdgeInsets.fromLTRB(0, 17, 11, 0),
    //       //     child: Text(
    //       //       "${widget.count.toString()}/50",
    //       //       textAlign: TextAlign.center,
    //       //       style: TextStyle(
    //       //           color: customColors().fontSecondary, fontSize: 12),
    //       //     ),
    //       //   ),
    //       // ),
    //       hintText: 'Search and add',
    //       suffixText: '0/25',
    //       suffixStyle: customTextStyle(
    //           fontStyle: FontStyle.BodyM_SemiBold,
    //           color: FontColor.FontSecondary),
    //       hintStyle:
    //           TextStyle(color: customColors().fontSecondary, fontSize: 12),
    //       filled: true,
    //       fillColor: customColors().backgroundSecondary,
    //       enabledBorder: const OutlineInputBorder(
    //         borderRadius: BorderRadius.all(Radius.circular(4.0)),
    //         borderSide: BorderSide(color: transparent, width: 0),
    //       ),
    //       focusedBorder: const OutlineInputBorder(
    //         borderRadius: BorderRadius.all(Radius.circular(4.0)),
    //         borderSide: BorderSide(color: transparent, width: 0),
    //       ),
    //     ),
    //   ),

    // );
    return Container(
      height: 48,
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
          color: customColors().backgroundSecondary,
          borderRadius: BorderRadius.circular(4.0)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 15.0),
                child: Image.asset(
                  "assets/searchicon.png",
                  color: customColors().fontPrimary,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 12.0),
                child: Text(
                  'Search and add',
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_Regular,
                      color: FontColor.FontSecondary),
                ),
              )
            ],
          ),
          Padding(
            padding: EdgeInsets.only(right: 15.0),
            child: Text(
              '0/25',
              style: customTextStyle(
                  fontStyle: FontStyle.BodyM_SemiBold,
                  color: FontColor.FontSecondary),
            ),
          ),
        ],
      ),
    );
  }
}

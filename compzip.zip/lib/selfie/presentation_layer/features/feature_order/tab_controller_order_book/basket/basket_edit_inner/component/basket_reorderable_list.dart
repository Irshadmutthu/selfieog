import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class BasketReorderableList extends StatefulWidget {
  final List items;
  final void Function()? delete;
  final void Function()? edit;
  const BasketReorderableList(
      {Key? key, required this.items, required this.delete, required this.edit})
      : super(key: key);

  @override
  State<BasketReorderableList> createState() => _BasketReorderableListState();
}

class _BasketReorderableListState extends State<BasketReorderableList> {
  @override
  Widget build(BuildContext context) {
    return ReorderableListView.builder(
        itemBuilder: (context, index) {
          return Card(
            elevation: 0,
            color: customColors().backgroundPrimary,
            key: ValueKey(index),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 20),
                decoration: BoxDecoration(
                    border: Border(
                        bottom: BorderSide(
                            color: customColors().backgroundTertiary))),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Image.asset('assets/reoder.png'),
                        Padding(
                          padding: const EdgeInsets.only(left: 5.0),
                          child: Container(
                            padding: EdgeInsets.only(left: 8.0),
                            decoration: BoxDecoration(
                                border: Border(
                              left: widget.items[index]['ordertype'] == 'buy'
                                  ? BorderSide(color: green200, width: 2)
                                  : BorderSide(
                                      color: customColors().red3, width: 2),
                            )),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 0.0),
                                      child: getProductTypeWidget(
                                          widget.items[index]['ordertype']),
                                    ),
                                    SizedBox(
                                      width: 6,
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 0.0),
                                      child: getProductTypeWidget(
                                          widget.items[index]['producttype']),
                                    ),
                                    SizedBox(
                                      width: 8,
                                    ),
                                  ],
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 10.0),
                                  child: Text(
                                    widget.items[index]["stockname"],
                                    style: TextStyle(
                                        fontFamily: "OpenSansSemiBold",
                                        fontWeight: FontWeight.w600,
                                        fontSize: 14,
                                        color: customColors().fontPrimary),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 10.0),
                                  child: Text(
                                    "Qty: ${widget.items[index]['qty']}",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_SemiBold,
                                        color: FontColor.FontSecondary),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Visibility(
                              visible: widget.items[index]['value'] == ''
                                  ? false
                                  : true,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(
                                    'LTP',
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_Regular,
                                        color: FontColor.FontSecondary),
                                  ),
                                  Text(
                                    '1445.0',
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_Regular,
                                        color: FontColor.FontSecondary),
                                  ),
                                ],
                              ),
                            ),
                            Visibility(
                                visible: widget.items[index]['value'] == '',
                                child: SizedBox(
                                  height: 26,
                                )),
                            widget.items[index]['value'] != ''
                                ? Padding(
                                    padding: const EdgeInsets.only(top: 8.0),
                                    child: Row(
                                      children: [
                                        Text(
                                          "1,242.17 / T-1,250",
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyL_SemiBold,
                                              color: FontColor.FontPrimary),
                                        ),
                                      ],
                                    ),
                                  )
                                : Padding(
                                    padding: const EdgeInsets.only(top: 8.0),
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: [
                                        Text(
                                          'LTP',
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyM_Regular,
                                              color: FontColor.FontSecondary),
                                        ),
                                        Text(
                                          '1445.0',
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyM_Regular,
                                              color: FontColor.FontSecondary),
                                        ),
                                      ],
                                    ),
                                  ),
                            Padding(
                              padding: const EdgeInsets.only(top: 5.0),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(
                                    widget.items[index]['markettype'],
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_SemiBold,
                                        color: FontColor.FontSecondary),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 17.0),
                          child: Column(
                            children: [
                              InkWell(
                                onTap: () {
                                  setState(() {
                                    widget.items.remove(widget.items[index]);
                                  });
                                },
                                child: Image.asset(
                                  "assets/trash.png",
                                  color: customColors().fontSecondary,
                                ),
                              )
                            ],
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ),
            ),
          );
        },
        itemCount: widget.items.length,
        onReorder: onReoder);
    // return ReorderableListView(children: [
    //   Card(
    //     key: ValueKey(0),
    //     child: Row(
    //       mainAxisAlignment: MainAxisAlignment.center,
    //       children: [
    //         Padding(
    //           padding: EdgeInsets.all(12.0),
    //           child: Text("one"),
    //         ),
    //       ],
    //     ),
    //   ),
    //   Card(
    //     key: ValueKey(1),
    //     child: Row(
    //       mainAxisAlignment: MainAxisAlignment.center,
    //       children: [
    //         Padding(
    //           padding: EdgeInsets.all(12.0),
    //           child: Text("two"),
    //         ),
    //       ],
    //     ),
    //   ),
    //   Card(
    //     key: ValueKey(2),
    //     child: Row(
    //       mainAxisAlignment: MainAxisAlignment.center,
    //       children: [
    //         Padding(
    //           padding: EdgeInsets.all(12.0),
    //           child: Text("three"),
    //         ),
    //       ],
    //     ),
    //   ),
    //   Card(
    //     key: ValueKey(3),
    //     child: Row(
    //       mainAxisAlignment: MainAxisAlignment.center,
    //       children: [
    //         Padding(
    //           padding: EdgeInsets.all(12.0),
    //           child: Text("four"),
    //         ),
    //       ],
    //     ),
    //   )
    // ], onReorder: onReoder);

    // ReorderableListView(
    //   shrinkWrap: true,
    //   buildDefaultDragHandles: false,
    //   dragStartBehavior: DragStartBehavior.down,

    //   children: [
    //     for (var i = 0; i < widget.items.length; i++)
    //       Card(
    //         elevation: 0,
    //         color: customColors().backgroundPrimary,
    //         key: ValueKey(widget.items[i]["stockname"]),
    //         child: Container(
    //           padding: const EdgeInsets.symmetric(horizontal: 16),
    //           child: Container(
    //             padding: const EdgeInsets.symmetric(vertical: 20),
    //             decoration: BoxDecoration(
    //                 border: Border(
    //                     bottom: BorderSide(
    //                         color: customColors().backgroundTertiary))),
    //             child: Row(
    //               mainAxisAlignment: MainAxisAlignment.spaceBetween,
    //               children: [
    //                 Expanded(
    //                   child: Row(
    //                     children: [
    //                       // Padding(
    //                       //   padding: const EdgeInsets.only(right: 8),
    //                       //   child: ReorderableDragStartListener(
    //                       //     index: i,
    //                       //     child: Image.asset("assets/reoder.png",
    //                       //         color: customColors().fontTertiary),
    //                       //   ),
    //                       // ),
    //                       Row(
    //                         children: [
    //                           Column(
    //                             children: [
    //                               Text(
    //                                 widget.items[i]["stockname"],
    //                                 style: TextStyle(
    //                                     fontFamily: "OpenSansSemiBold",
    //                                     fontWeight: FontWeight.w600,
    //                                     fontSize: 14,
    //                                     color: customColors().fontPrimary),
    //                               ),
    //                             ],
    //                           )
    //                         ],
    //                       ),
    //                     ],
    //                   ),
    //                 ),
    //                 Row(
    //                   children: [
    //                     InkResponse(
    //                         onTap: widget.edit,
    //                         child: Image.asset(
    //                           "assets/icon.png",
    //                           color: customColors().fontSecondary,
    //                         )),
    //                     const SizedBox(
    //                       width: 16,
    //                     ),
    //                     InkResponse(
    //                         onTap: widget.delete,
    //                         child: Image.asset(
    //                           "assets/trash.png",
    //                           color: customColors().fontSecondary,
    //                         )),
    //                   ],
    //                 )
    //               ],
    //             ),
    //           ),
    //         ),
    //       ),
    //   ],
    //   onReorder: onReoder,
    // );
  }

  onReoder(int oldIndex, int newIndex) {
    setState(() {
      if (newIndex > oldIndex) {
        newIndex -= 1;
      }
      final item = widget.items.removeAt(oldIndex);
      widget.items.insert(newIndex, item);
    });
  }
}

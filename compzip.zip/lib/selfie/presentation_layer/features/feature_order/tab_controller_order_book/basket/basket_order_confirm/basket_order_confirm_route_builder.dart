import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/basket/basket_order_confirm/basket_order_confirm.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class BasketOrderConfirmRouteBuilder {
  final ServiceLocator serviceLocator;
  BasketOrderConfirmRouteBuilder(this.serviceLocator);

  Widget call(BuildContext context) {
    return MultiRepositoryProvider(
        providers: [RepositoryProvider.value(value: serviceLocator.tradingApi)],
        child: BasketOrderConfirm());
  }
}

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

// import '../../../../../../../widgets/custom_app_components/buttons/BasketButton.dart';
// import '../../../../../../../widgets/others/options_widget.dart';

class SymbolDetailDialogue extends StatefulWidget {
  const SymbolDetailDialogue({Key? key}) : super(key: key);

  @override
  State<SymbolDetailDialogue> createState() => _SymbolDetailDialogueState();
}

class _SymbolDetailDialogueState extends State<SymbolDetailDialogue> {
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 15),
            child: Row(
              children: [
                getProductTypeWidget("NSE"),
                Padding(
                  padding: const EdgeInsets.only(left: 3.0),
                  child: getProductTypeWidget("intraday"),
                ),
              ],
            ),
          ),
          const SizedBox(
            height: 4,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "HDFCBANK",
                    style: customTextStyle(
                        fontStyle: FontStyle.HeaderS_SemiBold,
                        color: FontColor.FontPrimary),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: RichText(
                      text: TextSpan(
                          text: "LTP ",
                          style: customTextStyle(
                            fontStyle: FontStyle.BodyM_Regular,
                            color: FontColor.FontSecondary,
                          ),
                          children: <TextSpan>[
                            TextSpan(
                              text: "is greater than ",
                              style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontSecondary,
                              ),
                            ),
                            TextSpan(
                              text: "2400.00",
                              style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontPrimary,
                              ),
                            ),
                          ]),
                    ),
                  ),
                ],
              ),
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Padding(
                          padding: const EdgeInsets.only(right: 6),
                          child: Text(
                            'Qty: ',
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyM_SemiBold,
                                color: FontColor.FontSecondary),
                          )),
                      Text(
                        "1,50,250",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyM_SemiBold,
                            color: FontColor.FontPrimary),
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: RichText(
                      text: TextSpan(
                          text: "LTP: ",
                          style: customTextStyle(
                            fontStyle: FontStyle.HeaderXS_Bold,
                            color: FontColor.FontSecondary,
                          ),
                          children: <TextSpan>[
                            TextSpan(
                              text: "2400.00",
                              style: customTextStyle(
                                fontStyle: FontStyle.HeaderXS_Bold,
                                color: FontColor.FontPrimary,
                              ),
                            ),
                          ]),
                    ),
                  ),
                ],
              )
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(top: 16, bottom: 12),
            child: Divider(
              height: 1,
              color: customColors().backgroundTertiary,
            ),
          ),
          // AlertBottomSheetButton(
          //   modify: false,
          //   reactivate: () {
          //     Navigator.pop(context);
          //   },
          // )
          SizedBox(
            height: screenSize.height * 0.08,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Expanded(
                    flex: 2,
                    child: BasketButton(
                        bgcolor: customColors().backgroundPrimary,
                        bordercolor: customColors().green4,
                        onpress: () {},
                        text: "Duplicate",
                        textStyle: customTextStyle(
                            fontStyle: FontStyle.BodyL_Bold,
                            color: FontColor.Primary)),
                  ),
                  Expanded(
                    flex: 2,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: BasketButton(
                          bgcolor: customColors().primary,
                          text: "Modify",
                          textStyle: customTextStyle(
                              fontStyle: FontStyle.BodyL_Bold,
                              color: FontColor.White)),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}

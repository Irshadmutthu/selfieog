import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/basket/bloc/basket_component_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/order_book_basket_filter_bar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/order_book_open_filter_bar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/basket/basket_emprty_listWidget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/basket/basket_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/smartfolio/smartfolio_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/message_tile.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';

class OrderBookBasketComponent extends StatefulWidget {
  Function(bool) onScrollEvent;
  OrderBookBasketComponent({
    Key? key,
    required this.onScrollEvent,
  }) : super(key: key);

  @override
  State<OrderBookBasketComponent> createState() =>
      _OrderBookBasketComponentState();
}

class _OrderBookBasketComponentState extends State<OrderBookBasketComponent>
    with TickerProviderStateMixin {
  int screenCount = 1;
  ScrollController _scrollBottomBarController = new ScrollController();

  bool isScrollingDown = false;

  void initState() {
    // TODO: implement initState
    super.initState();
    _controller = BottomSheet.createAnimationController(this);
    _controller!.duration = const Duration(milliseconds: 400);
    myScroll();
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  void myScroll() async {
    _scrollBottomBarController.addListener(() {
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        if (!isScrollingDown) {
          isScrollingDown = true;
          widget.onScrollEvent(false); //hide appbar
        }
      }
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.forward) {
        if (isScrollingDown) {
          isScrollingDown = false;
          widget.onScrollEvent(true); //show appbar
        }
      }
    });
  }

  AnimationController? _controller;

  bool notify = false;
  @override
  Widget build(BuildContext context) {
    // return Container(child: Center(child: Text("Open component"),),);
    return BlocProvider(
        create: (context) => BasketComponentCubit(),
        child: BlocBuilder<BasketComponentCubit, BasketComponentState>(
            builder: (context, state) {
          return Column(
            children: [
              Expanded(
                child: Stack(
                  children: [
                    SingleChildScrollView(
                      controller: _scrollBottomBarController,
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            screenCount == 1
                                ? const Padding(
                                    padding: EdgeInsets.only(top: 100),
                                    child: OrderbookBasketEmptyContainer(
                                        title: "No Baskets",
                                        subTitle: "Create a new basket"),
                                  )
                                : BlocBuilder<BasketComponentCubit,
                                        BasketComponentState>(
                                    builder: (context, state) {
                                    if (state is BasketComponentInitial) {
                                      return Column(
                                        children: [
                                          BasketSearchFilterHoldings(
                                            onFilterPress: () {
                                              // customShowModalBottomSheet(
                                              //     context: context,
                                              //     inputWidget: OpenSortFilterList(
                                              //       currentval: filterval,
                                              //       // selectedLocation:
                                              //       //     SortFilterLocation.holding,
                                              //       onPressFilter: (String name) {
                                              //         List<Map<String, dynamic>> list = [];
                                              //         state.holdingList.forEach((element) {
                                              //           if (element.containsValue(name)) {
                                              //             list.add(element);
                                              //           }
                                              //         });

                                              //         BlocProvider.of<OpenComponentCubit>(
                                              //                 context)
                                              //             .updateSortList(list);
                                              //       },
                                              //       onPressReset: () {
                                              //         List<Map<String, dynamic>> list = [];
                                              //         list = List.from(holdingsList2);

                                              //         BlocProvider.of<HoldingsComponentCubit>(
                                              //                 context)
                                              //             .updateSortList(list);
                                              //       },
                                              //     ));
                                              // setState(() {
                                              //   notify = !notify;
                                              // });
                                            },
                                            onSearchPress: () {
                                              BlocProvider.of<
                                                          BasketComponentCubit>(
                                                      context)
                                                  .basketSearch();
                                            },
                                            //TODO filter notification bubbles
                                          ),
                                          ListView.builder(
                                              physics:
                                                  const NeverScrollableScrollPhysics(),
                                              itemCount:
                                                  state.basketList.length,
                                              shrinkWrap: true,
                                              itemBuilder: (context, index) {
                                                return InkWell(
                                                  onLongPress: () {
                                                    context.gNavigationService
                                                        .openMyBasketEdit(
                                                            context);
                                                  },
                                                  onTap: () {
                                                    context.gNavigationService
                                                        .openBaketInnerPage(
                                                            context);
                                                    // customBottomSheet(
                                                    //   fixedBottomWidget: FixedButton(
                                                    //     elevation: true,
                                                    //     addMoreOnTap: () {},
                                                    //     squareOffOnTap: () {},
                                                    //     future: false,
                                                    //     ocoOnTap: () {},
                                                    //   ),
                                                    //   height: .76,
                                                    //   maxHeight: .89,
                                                    //   ifport: true,
                                                    //   context: context,
                                                    //   inputWidget:
                                                    //       const HoildinBottomSheet(),
                                                    // );
                                                  },
                                                  child: BasketListItem(
                                                      basketList: state
                                                          .basketList[index]),
                                                );
                                              }),
                                        ],
                                      );
                                    } else {
                                      return Container();
                                    }
                                  }),
                          ]),
                    ),
                    // Align(
                    //   alignment: Alignment.bottomCenter,
                    //   child: skipButton(context, "$screenCount/2", () {
                    //     if (screenCount > 1) {
                    //       setState(() {
                    //         screenCount--;
                    //       });
                    //     }
                    //   }, () {
                    //     if (screenCount < 2) {
                    //       setState(() {
                    //         screenCount++;
                    //       });
                    //     }
                    //   }),
                    // ),
                  ],
                ),
              ),
              // Expanded(
              //     child: Stack(
              //   children: [
              //     SingleChildScrollView(
              //         controller: _scrollBottomBarController,
              //         child: Column(
              //             mainAxisAlignment: MainAxisAlignment.start,
              //             children: [
              //               BlocBuilder<OpenComponentCubit, OpenComponentState>(
              //                 builder: (context, state) {
              //                   if (state is OpenComponentInitial) {
              //                     if (state.searchVisible) {
              //                       return Column();
              //                     } else {
              //                       return Column();
              //                     }
              //                   } else {
              //                     return Container();
              //                   }
              //                 },
              //               ),
              //             ])),
              //     Align(
              //       alignment: Alignment.bottomCenter,
              //       child: skipButton(context, "$screenCount/2", () {
              //         if (screenCount > 1) {
              //           setState(() {
              //             screenCount--;
              //           });
              //         }
              //       }, () {
              //         if (screenCount < 2) {
              //           setState(() {
              //             screenCount++;
              //           });
              //         }
              //       }),
              //     ),
              //   ],
              // ))
            ],
          );
        }));
  }
}

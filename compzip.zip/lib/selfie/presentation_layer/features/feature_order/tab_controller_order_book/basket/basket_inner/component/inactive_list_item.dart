import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class InactiveListItem extends StatefulWidget {
  Map<String, dynamic> basketinner;
  bool longpress;
  List<String> cklist;
  InactiveListItem(
      {Key? key,
      required this.basketinner,
      required this.longpress,
      required this.cklist})
      : super(key: key);

  @override
  State<InactiveListItem> createState() => _InactiveListItemState();
}

class _InactiveListItemState extends State<InactiveListItem> {
  @override
  Widget build(BuildContext context) {
    return InkWell(
      // onLongPress: widget.onLongPressAction,
      // onTap: widget.onTap,
      child: Container(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
              border: Border(
            bottom:
                BorderSide(color: customColors().backgroundTertiary, width: 1),
          )),
          child: Container(
            padding: EdgeInsets.only(left: 8.0),
            decoration: BoxDecoration(
                border: Border(
              left: widget.basketinner['ordertype'] == 'buy'
                  ? BorderSide(color: green200, width: 2)
                  : BorderSide(color: customColors().red3, width: 2),
            )),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Visibility(
                  // visible: widget.openList.containsKey("topview"),
                  visible: true,
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Row(
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 0.0),
                              child: getProductTypeWidget(
                                  widget.basketinner['ordertype']),
                            ),
                            SizedBox(
                              width: 6,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 0.0),
                              child: getProductTypeWidget(
                                  widget.basketinner['producttype']),
                            ),
                            SizedBox(
                              width: 8,
                            ),
                          ],
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            // Text(
                            //   'LTP',
                            //   style: customTextStyle(
                            //       fontStyle: FontStyle.BodyM_Regular,
                            //       color: FontColor.FontSecondary),
                            // ),
                            // Text(
                            //   '1445.0',
                            //   style: customTextStyle(
                            //       fontStyle: FontStyle.BodyM_Regular,
                            //       color: FontColor.FontSecondary),
                            // ),
                            Padding(
                                padding: const EdgeInsets.only(left: 10.0),
                                child: Text(
                                  widget.basketinner['status'],
                                  style: widget.basketinner['status'] ==
                                          'CONFIRMED'
                                      ? customTextStyle(
                                          fontStyle: FontStyle.BodyM_SemiBold,
                                          color: FontColor.Success)
                                      : customTextStyle(
                                          fontStyle: FontStyle.BodyM_SemiBold,
                                          color: FontColor.Danger),
                                ))
                          ],
                        ),

                        // Row(
                        //   crossAxisAlignment: CrossAxisAlignment.end,
                        //   children: [
                        //   Text("${widget.openList["last_update"]??""}",style: customTextStyle(
                        //       fontStyle: FontStyle.BodyS_SemiBold,
                        //       color: FontColor.FontTertiary),),
                        //       const Padding(
                        //   padding:
                        //        EdgeInsets.only(left: 6.0, right: 6.0),
                        //   child:CustomDot(),),

                        //   getOrderStatusWidget(widget.openList["status"])

                        // ],)
                      ]),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          widget.basketinner['stockname'],
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary),
                        ),

                        Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              'LTP',
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary),
                            ),
                            Text(
                              '1445.0',
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary),
                            ),
                          ],
                        )

                        // Text(
                        //       "${Formats.valueFormat.format( widget.openList["value"])} / T-${Formats.valueFormat.format( widget.openList["total_value"])}",
                        //       style: customTextStyle(
                        //           fontStyle: FontStyle.BodyL_SemiBold,
                        //           color: FontColor.FontPrimary),
                        //     ),
                      ]),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 4.0),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Qty: ${widget.basketinner['qty']}",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.FontSecondary),
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              widget.basketinner['markettype'],
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_SemiBold,
                                  color: FontColor.FontSecondary),
                            ),
                          ],
                        ),
                      ]),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/basket/basket_edit_inner/component/basket_reorderable_list.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/basket/basket_edit_inner/component/edit_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class BasketInnerEdit extends StatefulWidget {
  const BasketInnerEdit({Key? key}) : super(key: key);

  @override
  State<BasketInnerEdit> createState() => _BasketInnerEditState();
}

class _BasketInnerEditState extends State<BasketInnerEdit> {
  List<Map<String, dynamic>> basket_list_content = [
    {
      'ordertype': 'buy',
      'producttype': 'intraday',
      'stockname': 'HDFCBANK',
      'ltp': '1445.50',
      'value': '',
      'totalvalue': '',
      'qty': '1,50,250',
      'markettype': 'Market',
    },
    {
      'ordertype': 'buy',
      'producttype': 'cash',
      'stockname': 'TATAMOTORS',
      'ltp': '1445.50',
      'value': '1445.50',
      'totalvalue': 'T-1445.75',
      'qty': '1,50,250',
      'markettype': 'Limit',
    },
    {
      'ordertype': 'sell',
      'producttype': 'cash',
      'stockname': 'AXISBANK',
      'ltp': '1445.50',
      'value': '1445.50',
      'totalvalue': 'T-1445.75',
      'qty': '1,50,250',
      'markettype': 'SL-Lmt',
    },
    {
      'ordertype': 'buy',
      'producttype': 'intraday',
      'stockname': 'YESBANK',
      'ltp': '1445.50',
      'value': '1445.50',
      'totalvalue': 'T-1445.75',
      'qty': '1,50,250',
      'markettype': 'SL-Mkt',
    }
  ];

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: Column(
        children: [
          Container(
            height: 56,
            width: MediaQuery.of(context).size.width,
            child: Row(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 8),
                  child: IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: const ImageIcon(AssetImage("assets/arrow_left.png"),
                          size: 24)),
                  // child: ,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 12.0),
                  child: Text('Edit Basket'),
                )
              ],
            ),
          ),
          EditBasketNameField(),
          Expanded(
            child: BasketReorderableList(
              edit: () {},
              delete: () {},
              items: basket_list_content,
            ),
          )
        ],
      ),
      bottomNavigationBar: SizedBox(
        height: screenSize.height * 0.13,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Divider(
              thickness: 1.0,
              color: customColors().backgroundTertiary,
            ),
            Padding(
              padding: const EdgeInsets.only(
                  left: 16.0, right: 16.0, top: 8.0, bottom: 12.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Expanded(
                    flex: 2,
                    child: BasketButton(
                        onpress: () {},
                        text: "Cancel",
                        bgcolor: customColors().backgroundPrimary,
                        bordercolor: customColors().primary,
                        textStyle: customTextStyle(
                            fontStyle: FontStyle.BodyL_Bold,
                            color: FontColor.Primary)),
                  ),
                  Expanded(
                    flex: 2,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: BasketButton(
                          onpress: () {},
                          text: "Save Changes",
                          bgcolor: customColors().primary,
                          bordercolor: customColors().primary,
                          textStyle: customTextStyle(
                              fontStyle: FontStyle.BodyL_Bold,
                              color: FontColor.White)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

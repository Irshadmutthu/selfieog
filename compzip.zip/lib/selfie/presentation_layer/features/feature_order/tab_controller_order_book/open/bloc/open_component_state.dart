part of 'open_component_cubit.dart';

@immutable
abstract class OpenComponentState {}

class OpenComponentInitial extends OpenComponentState {
  List<OrderStatusResult3> openList;
  final bool searchActive;
  OrderStatusItemResponse? response;
  final int filterval;
  List<String>? filter_elements;
  String errorMsg;
  bool isSearchFinished;

  List<String> filterarrayposition;
  OpenComponentInitial(
      {this.searchActive = false,
      required this.openList,
      this.response,
      this.filterval = -1,
      required this.filterarrayposition,
      this.filter_elements,
      this.errorMsg = "",
      this.isSearchFinished = false});

  OpenComponentInitial copyWith(
      {List<OrderStatusResult3>? openList,
      bool? searchActive,
      OrderStatusItemResponse? response,
      int? filterval,
      required List<String> filterarrayposition,
      String filterMsg = "",
      bool? isSearchFinished}) {
    return OpenComponentInitial(
        openList: openList ?? this.openList,
        filterarrayposition: filterarrayposition,
        filterval: filterval ?? this.filterval,
        searchActive: searchActive ?? this.searchActive,
        response: response ?? this.response,
        isSearchFinished: isSearchFinished ?? this.isSearchFinished);
  }
}

class OpenLoadingState extends OpenComponentState {}

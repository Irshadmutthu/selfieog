import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/featur_symbolsearch/symbol_search/cubit/symbol_search_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/components/pop_up.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/components/search_form.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_book/cubit/order_book_screen_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_status_bottom_sheet/complete_orders/bottom_sheet_header/order_summary/ui/orders_summary_completed_orders.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/open/bloc/open_component_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/open/components/open_shimmer.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/alert_dialogs.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/order_book_open_filter_bar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/empty_list_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/filter/search_filter_order_book.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/open/open_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/fixed_bottom_buttons/fixed_bottom_buttons.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';
import 'package:trading_api/responses/order_status_item_response.dart';
import 'package:trading_api/utils/utils.dart';
import '../../../../../../order_model/Order.dart';
import '../../../../../../utils/user_settings.dart';

class OrderBookOpenComponent extends StatefulWidget {
  Function(bool) onScrollEvent;
  OrderBookOpenComponent({
    Key? key,
    required this.onScrollEvent,
  }) : super(key: key);

  @override
  State<OrderBookOpenComponent> createState() => _OrderBookOpenComponentState();
}

class _OrderBookOpenComponentState extends State<OrderBookOpenComponent>
    with AutomaticKeepAliveClientMixin<OrderBookOpenComponent> {
  ScrollController _scrollBottomBarController = ScrollController();

  bool isScrollingDown = false;
  bool isSearchFinished = false;
  late TradingApiGateway _gateway;

  void initState() {
    super.initState();
    _gateway = context.gTradingApiGateway;
    // _controller = BottomSheet.createAnimationController(this);
    // _controller!.duration = const Duration(milliseconds: 400);
    myScroll();
  }

  @override
  void dispose() {
    // _controller!.dispose();
    super.dispose();
  }

  bool deleteGtdOrder = true;

  void myScroll() async {
    _scrollBottomBarController.addListener(() {
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        if (!isScrollingDown) {
          isScrollingDown = true;
          widget.onScrollEvent(false); //hide appbar
        }
      }
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.forward) {
        if (isScrollingDown) {
          isScrollingDown = false;
          widget.onScrollEvent(true); //show appbar
        }
      }
    });
  }

  AnimationController? _controller;
  final TextEditingController _serach = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => OpenComponentCubit(gateway: _gateway),
      child: RefreshIndicator(
        backgroundColor: customColors().primary,
        onRefresh: () async {
          UserController().allowOrderbookRequest = true;
          BlocProvider.of<OrderBookScreenCubit>(context).orders();
        },
        child: Column(
          children: [
            BlocListener<OrderBookScreenCubit, OrderBookScreenState>(
              listener: (context, state) {
                if (state is OrderBookScreenInitial) {
                  BlocProvider.of<OpenComponentCubit>(context).data();
                  if (state.errorMsg != "") {
                    ScaffoldMessenger.of(context).showSnackBar(
                        showErrorDialogue(errorMessage: state.errorMsg));
                  }
                }
              },
              child: Container(),
            ),
            BlocBuilder<OrderBookScreenCubit, OrderBookScreenState>(
              builder: (context, state) {
                if (state is OrderBookLoadingState) {
                  return const OpenShimmer();
                }
                return BlocBuilder<OpenComponentCubit, OpenComponentState>(
                  builder: (context, state) {
                    if (state is OpenComponentInitial) {
                      if (UserController.userController.openOrders.isEmpty) {
                        return ListView.builder(
                            physics: const AlwaysScrollableScrollPhysics(),
                            shrinkWrap: true,
                            itemCount: 1,
                            itemBuilder: (context, index) {
                              return Column(
                                children: const [
                                  Padding(
                                    padding: EdgeInsets.only(top: 100),
                                    child: OrderbookEmptyContainer(
                                      title: "No pending orders",
                                      subTitle:
                                          "Place an order from your watchlist",
                                    ),
                                  )
                                ],
                              );
                            });
                      } else {
                        return Expanded(
                          child: Column(
                            children: [
                              Column(
                                children: [
                                  Visibility(
                                    visible: !state.searchActive,
                                    child: SearchFilterHoldings(
                                      showBubble:
                                          state.filterarrayposition.isNotEmpty,
                                      sortBubble: state.filterval != -1,
                                      onFilterPress: () {
                                        customShowModalBottomSheet(
                                          context: context,
                                          inputWidget: OrderSortFilter(
                                            selectedTabIndex: 0,
                                            filterList: state.filter_elements,
                                            filterarrayposition:
                                                state.filterarrayposition,
                                            currentval: state.filterval,
                                            onPresssort: (int index) {
                                              BlocProvider.of<
                                                          OpenComponentCubit>(
                                                      context)
                                                  .newSort(index);
                                            },
                                            onPressFilter: (List<String> el) {
                                              state.filter_elements =
                                                  List.from(el);
                                              BlocProvider.of<
                                                          OpenComponentCubit>(
                                                      context)
                                                  .newFilter(el);
                                            },
                                            onPressReset: () {
                                              BlocProvider.of<
                                                          OpenComponentCubit>(
                                                      context)
                                                  .resetList();
                                            },
                                          ),
                                        );
                                      },
                                      ononSortPress: () {
                                        customShowModalBottomSheet(
                                          context: context,
                                          inputWidget: OrderSortFilter(
                                            selectedTabIndex: 1,
                                            filterList: state.filter_elements,
                                            filterarrayposition:
                                                state.filterarrayposition,
                                            currentval: state.filterval,
                                            onPresssort: (int index) {
                                              BlocProvider.of<
                                                          OpenComponentCubit>(
                                                      context)
                                                  .newSort(index);
                                            },
                                            onPressFilter: (List<String> el) {
                                              state.filter_elements =
                                                  List.from(el);
                                              BlocProvider.of<
                                                          OpenComponentCubit>(
                                                      context)
                                                  .newFilter(el);
                                            },
                                            onPressReset: () {
                                              BlocProvider.of<
                                                          OpenComponentCubit>(
                                                      context)
                                                  .resetList();
                                            },
                                          ),
                                        );
                                      },
                                      onSearchPress: () {
                                        BlocProvider.of<OpenComponentCubit>(
                                                context)
                                            .emit(state.copyWith(
                                                searchActive: true,
                                                filterarrayposition:
                                                    state.filterarrayposition));
                                      },
                                    ),
                                  ),
                                  Visibility(
                                    visible: state.searchActive,
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8),
                                      child: OrderbookSearch(
                                        onBackPressed: () {
                                          BlocProvider.of<OpenComponentCubit>(
                                                  context)
                                              .emit(state.copyWith(
                                                  searchActive: false,
                                                  filterarrayposition: state
                                                      .filterarrayposition));
                                          BlocProvider.of<OpenComponentCubit>(
                                                  context)
                                              .data();
                                        },
                                        hintText: "Search eg: infy",
                                        controller: _serach,
                                        onSearch: (String keyword) {
                                          BlocProvider.of<OpenComponentCubit>(
                                                  context)
                                              .search(keyword);
                                        },
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              Expanded(
                                child: ListView.builder(
                                  itemCount: state.openList.length,
                                  controller: _scrollBottomBarController,
                                  shrinkWrap: true,
                                  physics: const ScrollPhysics(
                                    parent: AlwaysScrollableScrollPhysics(),
                                  ),
                                  itemBuilder: (context, index) {
                                    return InkWell(
                                      onTap: () async {
                                        Instrument instrument = Instrument(
                                            scripcode: state.openList
                                                .elementAt(index)
                                                .venuescripcode!,
                                            venueIndex: getVenueIndex(state
                                                .openList
                                                .elementAt(index)
                                                .venuecode!));
                                        callSymbolSearch(
                                            context, state, instrument);
                                        customBottomSheet(
                                            height: .76,
                                            maxHeight: .89,
                                            context: context,
                                            inputWidget: CompletedOrders(
                                              context: context,
                                              instrument: instrument,
                                              overViewList: state.openList,
                                              orderLogList: state.openList,
                                              index: index,
                                            ),
                                            fixedBottomWidget:
                                                BlocProvider.value(
                                              value: BlocProvider.of<
                                                  OpenComponentCubit>(context),
                                              child: BlocBuilder<
                                                      OpenComponentCubit,
                                                      OpenComponentState>(
                                                  builder: (context, state) {
                                                if (state
                                                    is OpenComponentInitial) {
                                                  return OdrderBookFixedButton(
                                                    loading:
                                                        !state.isSearchFinished,
                                                    enable:
                                                        state.isSearchFinished,
                                                    elevation: true,
                                                    modify: true,
                                                    onCancel: () async {
                                                      if (state.openList
                                                                  .elementAt(
                                                                      index)
                                                                  .status ==
                                                              "CONF" ||
                                                          state.openList
                                                                  .elementAt(
                                                                      index)
                                                                  .status ==
                                                              "PEXE") {
                                                        if (state.openList
                                                            .elementAt(index)
                                                            .tifdate!
                                                            .isEmpty) {
                                                          await showAlertDilogue(
                                                              context: context,
                                                              content:
                                                                  "Do you want to cancel this order ?",
                                                              negativeButtonName:
                                                                  "Cancel",
                                                              onPositiveButtonClick:
                                                                  () async {
                                                                await BlocProvider.of<
                                                                            OpenComponentCubit>(
                                                                        context)
                                                                    .cancelorder(
                                                                        context,
                                                                        state
                                                                            .openList,
                                                                        index);

                                                                BlocProvider.of<
                                                                            OrderBookScreenCubit>(
                                                                        context)
                                                                    .orders();
                                                              },
                                                              onNegativeButtonClick:
                                                                  () {
                                                                Navigator.of(
                                                                        context)
                                                                    .pop(true);
                                                              });
                                                        } else {
                                                          setState(() {
                                                            deleteGtdOrder =
                                                                true;
                                                          });
                                                          await showAlertDilogueOrderBook(
                                                            context: context,
                                                            negativeButtonName:
                                                                "Cancel",
                                                            title: Text(
                                                              "This ia a gtd order",
                                                              style: customTextStyle(
                                                                  fontStyle:
                                                                      FontStyle
                                                                          .BodyM_SemiBold,
                                                                  color: FontColor
                                                                      .FontSecondary),
                                                            ),
                                                            content: StatefulBuilder(
                                                                builder: (context,
                                                                    setState) {
                                                              return SizedBox(
                                                                height: 110,
                                                                child: Column(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .center,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .center,
                                                                  children: [
                                                                    Center(
                                                                      child:
                                                                          Text(
                                                                        "Do you want to cancel it ?",
                                                                        style: customTextStyle(
                                                                            fontStyle:
                                                                                FontStyle.BodyM_SemiBold,
                                                                            color: FontColor.FontSecondary),
                                                                      ),
                                                                    ),
                                                                    Padding(
                                                                      padding: const EdgeInsets
                                                                              .only(
                                                                          top:
                                                                              20),
                                                                      child:
                                                                          Row(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.center,
                                                                        children: [
                                                                          Image
                                                                              .asset(
                                                                            "assets/ic_checkbox_checked.png",
                                                                            height:
                                                                                24,
                                                                            width:
                                                                                24,
                                                                            fit:
                                                                                BoxFit.fill,
                                                                          ),
                                                                          const SizedBox(
                                                                            width:
                                                                                5,
                                                                          ),
                                                                          Text(
                                                                            "Cancel Today's Order",
                                                                            style:
                                                                                customTextStyle(fontStyle: FontStyle.BodyM_SemiBold, color: FontColor.FontSecondary),
                                                                          )
                                                                        ],
                                                                      ),
                                                                    ),
                                                                    Padding(
                                                                      padding: const EdgeInsets
                                                                              .only(
                                                                          top:
                                                                              20),
                                                                      child:
                                                                          Row(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.center,
                                                                        children: [
                                                                          EmptyCustomCheckBox(
                                                                            isSelect:
                                                                                deleteGtdOrder,
                                                                            callback:
                                                                                ((bool checked) {
                                                                              setState(() {
                                                                                deleteGtdOrder = checked;
                                                                              });
                                                                            }),
                                                                          ),
                                                                          const SizedBox(
                                                                            width:
                                                                                5,
                                                                          ),
                                                                          Text(
                                                                            "Delete Gtd Order",
                                                                            style:
                                                                                customTextStyle(fontStyle: FontStyle.BodyM_SemiBold, color: FontColor.FontSecondary),
                                                                          )
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              );
                                                            }),
                                                            onNegativeButtonClick:
                                                                () {
                                                              Navigator.of(
                                                                      context)
                                                                  .pop(true);
                                                            },
                                                            onPositiveButtonClick:
                                                                () async {
                                                              await BlocProvider
                                                                      .of<OpenComponentCubit>(
                                                                          context)
                                                                  .cancelOrderGtd(
                                                                context,
                                                                state.openList,
                                                                index,
                                                                deleteGtdOrder
                                                                    ? false
                                                                    : true,
                                                              );

                                                              BlocProvider.of<
                                                                          OrderBookScreenCubit>(
                                                                      context)
                                                                  .orders();
                                                            },
                                                          );
                                                        }
                                                      } else {
                                                        ScaffoldMessenger.of(
                                                                context)
                                                            .showSnackBar(
                                                                showErrorDialogue(
                                                                    errorMessage:
                                                                        "Sorry!! CANCEL not allowed for ${state.openList.elementAt(index).status} orders."));
                                                      }
                                                    },
                                                    onReorderClick: () {},
                                                    onmodifyClick: () {
                                                      if (!state
                                                          .isSearchFinished) {
                                                        return;
                                                      }
                                                      OrderModel order =
                                                          OrderModel(
                                                              instrument,
                                                              UserSettings
                                                                  .userSettings
                                                                  .orderSettings);

                                                      order.TransId = state
                                                          .openList
                                                          .elementAt(index)
                                                          .transid;
                                                      order.qty = VENUE_IN_QTY
                                                              .elementAt(VENUES_ORDER
                                                                  .indexOf(
                                                                      instrument
                                                                          .venuecode))
                                                          ? state.openList
                                                              .elementAt(index)
                                                              .quantity!
                                                          : state.openList
                                                                  .elementAt(
                                                                      index)
                                                                  .quantity! *
                                                              instrument
                                                                  .lotsize!;
                                                      if (state.openList
                                                              .elementAt(index)
                                                              .buyorsell
                                                              .toString() ==
                                                          "BUY") {
                                                        order.buyOrSell = BUY;
                                                      } else {
                                                        order.buyOrSell = SELL;
                                                      }
                                                      order.isModify = true;
                                                      order.productType = state
                                                          .openList
                                                          .elementAt(index)
                                                          .productId!;
                                                      order.timeCondition =
                                                          state.openList
                                                              .elementAt(index)
                                                              .tifcd!;
                                                      order.tifDate = state
                                                          .openList
                                                          .elementAt(index)
                                                          .tifdate!;
                                                      order.priceCondition =
                                                          getPriceConditionbyId(
                                                              state.openList
                                                                  .elementAt(
                                                                      index)
                                                                  .priceConditionId!);
                                                      order.triggerPrice = state
                                                          .openList
                                                          .elementAt(index)
                                                          .triggerprice
                                                          .toString();
                                                      order.price = state
                                                          .openList
                                                          .elementAt(index)
                                                          .price
                                                          .toString();
                                                      if (state.openList
                                                              .elementAt(index)
                                                              .ordersubtype ==
                                                          "39") {
                                                        order.isOCOOrder = true;
                                                        fillLegValues(
                                                            order,
                                                            state.openList,
                                                            state.openList
                                                                        .elementAt(
                                                                            index)
                                                                        .legno ==
                                                                    "1"
                                                                ? "1"
                                                                : "2");
                                                        context
                                                            .gNavigationService
                                                            .openOCOOrderPage(
                                                                context, {
                                                          "order": order
                                                        });
                                                      } else {
                                                        context
                                                            .gNavigationService
                                                            .openOrderWindowPage(
                                                                context, {
                                                          "order": order
                                                        });
                                                      }
                                                    },
                                                  );
                                                } else {
                                                  return Container();
                                                }
                                              }),
                                            ));
                                      },
                                      onLongPress: () async {
                                        Map<String, dynamic> returnArgs = {
                                          "": ""
                                        };
                                        returnArgs = await context
                                            .gNavigationService
                                            .openOrderOpenLongpressPage(
                                                context, state.openList);
                                        if (returnArgs["isCancelOrder"] ==
                                            true) {
                                          BlocProvider.of<OrderBookScreenCubit>(
                                                  context)
                                              .orders();
                                        }
                                        returnArgs.clear();
                                      },
                                      child: OpenListItem(
                                        openList: state.openList,
                                        index: index,
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ],
                          ),
                        );
                      }
                    } else if (state is OpenLoadingState) {
                      return const OpenShimmer();
                    }
                    return Container();
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;

  void callSymbolSearch(BuildContext context, OpenComponentInitial state,
      Instrument instrument) async {
    context.read<OpenComponentCubit>().emit(state.copyWith(
        isSearchFinished: false,
        filterarrayposition: state.filterarrayposition));
    if (await fillSymbolData(context, instrument)) {
      context.read<OpenComponentCubit>().emit(state.copyWith(
          isSearchFinished: true,
          filterarrayposition: state.filterarrayposition));
    }
  }
}

void fillLegValues(
    OrderModel order, List<OrderStatusResult3> openList, String legNo) {
  for (var element in openList) {
    if (element.transid == order.TransId) {
      if (element.legno != legNo) {
        if (element.legno == "1") {
          order.targetPrice = element.price!;
          order.stoplossPrice = double.parse(order.price);
        } else {
          order.stoplossPrice = element.price!;
          order.targetPrice = double.parse(order.price);
        }
        return;
      }
    }
  }
}

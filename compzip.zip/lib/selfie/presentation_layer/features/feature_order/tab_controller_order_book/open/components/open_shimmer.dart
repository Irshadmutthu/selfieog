import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/utils/shimmer_loader.dart';

class OpenShimmer extends StatelessWidget {
  const OpenShimmer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: ListView.builder(
          shrinkWrap: true,
          itemCount: 10,
          itemBuilder: (context, index) {
            return Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 16),
                // decoration: BoxDecoration(
                //     border: Border(
                //   bottom: BorderSide(
                //       color: customColors().backgroundTertiary, width: 1),
                // )),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Visibility(
                      // visible: widget.closedList.containsKey("topview"),
                      visible: true,
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Row(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 0.0),
                                  child: ShimmerLoader(height: 20, width: 25),
                                ),
                                SizedBox(
                                  width: 6,
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 0.0),
                                  child: ShimmerLoader(height: 20, width: 25),
                                ),
                              ],
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                ShimmerLoader(height: 20, width: 60),

                                const Padding(
                                  padding:
                                      EdgeInsets.only(left: 6.0, right: 6.0),
                                  child: SizedBox(),
                                ),
                                // CustomDotSeparator(),
                                ShimmerLoader(height: 20, width: 25)
                              ],
                            )
                          ]),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            ShimmerLoader(height: 20, width: 180),
                            ShimmerLoader(height: 20, width: 50),
                          ]),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            ShimmerLoader(height: 20, width: 25),
                            ShimmerLoader(height: 20, width: 25)
                          ]),
                    ),
                  ],
                ),
              ),
            );
          }),
    );
  }
}

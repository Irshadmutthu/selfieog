import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/common_cancel_method/cancel_order.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';
import 'package:trading_api/responses/order_status_item_response.dart';
import 'package:trading_api/responses/symbol_details_response.dart';
part 'open_component_state.dart';

class OpenComponentCubit extends Cubit<OpenComponentState> {
  final TradingApiGateway gateway;
  SymbolDetailResponse? _response;
  List<String> filterarrayposition = [];
  int currentVal = -1;
  List<OrderStatusResult3> list = [];

  OpenComponentCubit({
    required this.gateway,
  }) : super(OpenComponentInitial(
            openList: UserController().openOrders, filterarrayposition: []));

  orderTypeUpdate(String val) {
    switch (val) {
      case "MARKET":
        {
          return "MKT";
        }
      case "LIMIT":
        {
          return "LMT";
        }
      case "SL-LIMIT":
        {
          return "STL";
        }
      case "BASKET ORDER":
        {
          return "BO";
        }
      case "CONFIRMED":
        {
          return "Confirmed";
        }
      case "PENDING":
        {
          return "Pending";
        }
      case "SAVED":
        {
          return "Saved";
        }
    }
    return val;
  }

  List<OrderStatusResult3> openSort(List<OrderStatusResult3> list, int index) {
    switch (index) {
      case 0:
        list.sort(((a, b) => (a.securitycode!).compareTo(b.securitycode!)));
        break;
      case 1:
        list.sort(((a, b) => (a.securitycode!).compareTo(b.securitycode!)));
        list = list.reversed.toList();
        break;
    }
    return list;
  }

  search(String keyword) async {
    List<OrderStatusResult3> searchResult = [];
    List<OrderStatusResult3> searchSet = UserController().openOrders;
    searchResult.clear();
    searchSet.forEach(((element) {
      if (element.securitycode1.contains(keyword.trim().toUpperCase()) ||
          element.securitycode1.startsWith(keyword.trim().toUpperCase()) ||
          element.securityname!.contains(keyword.trim().toUpperCase()) ||
          element.securityname!.startsWith(keyword.trim().toUpperCase())) {
        searchResult.add(element);
      }
    }));
    emit((state as OpenComponentInitial).copyWith(
        openList: searchResult, filterarrayposition: filterarrayposition));
  }

  // updateFiltertData(List<String> el) {
  //   List<OrderStatusResult3> filterSet = UserController().openOrders;
  //   List<OrderStatusResult3> list = [];
  //   filterarrayposition = List.from(el);
  //   if (el.isEmpty) {
  //     emit((state as OpenComponentInitial).copyWith(
  //         openList: filterSet, filterarrayposition: filterarrayposition));
  //   } else {
  //     filterSet.forEach(((element) {
  //       for (int i = 0; i < el.length; i++) {
  //         if (list.contains(element)) {
  //         } else {
  //           if (element.producttype!
  //                   .contains(orderTypeUpdate(el[i].toUpperCase())) ||
  //               element.buyorsell == orderTypeUpdate(el[i].toUpperCase()) ||
  //               element.pricecondition ==
  //                   orderTypeUpdate(el[i].toUpperCase()) ||
  //               element.statussubcategory ==
  //                   orderTypeUpdate(el[i].toUpperCase())) {
  //             list.add(element);
  //           }
  //         }
  //       }
  //     }));
  //     if (list.isEmpty) {
  //       emit((state as OpenComponentInitial)
  //           .copyWith(openList: [], filterarrayposition: filterarrayposition));
  //       return;
  //     }
  //     emit((state as OpenComponentInitial)
  //         .copyWith(openList: list, filterarrayposition: filterarrayposition));
  //   }
  // }

  // updateSortData(int index) {
  //   List<OrderStatusResult3> list = [];
  //   List<OrderStatusResult3> sortSet = UserController().openOrders;

  //   list = openSort(sortSet, index);
  //   emit((state as OpenComponentInitial).copyWith(
  //       openList: list,
  //       filterval: index,
  //       filterarrayposition: filterarrayposition));
  // }

  resetList() {
    filterarrayposition.clear();
    currentVal = -1;
    data();
  }

  newSort(int index) {
    currentVal = index;
    data();
  }

  newFilter(List<String> keyword) {
    filterarrayposition = keyword;
    data();
  }

  newFilterSort() {
    list = List.from(UserController().openOrders, growable: true);
    if (filterarrayposition.isNotEmpty) {
      List<OrderStatusResult3> finalList = [];
      for (var element in list) {
        for (int i = 0; i < filterarrayposition.length; i++) {
          if (list.contains(element)) {
          } else {
            if (element.producttype!.contains(
                    orderTypeUpdate(filterarrayposition[i].toUpperCase())) ||
                element.buyorsell ==
                    orderTypeUpdate(filterarrayposition[i].toUpperCase()) ||
                element.pricecondition ==
                    orderTypeUpdate(filterarrayposition[i].toUpperCase()) ||
                element.statussubcategory ==
                    orderTypeUpdate(filterarrayposition[i].toUpperCase())) {
              list.add(element);
            }
          }
        }
        list = finalList;
      }
    }
    if (currentVal != -1) {
      switch (currentVal) {
        case 0:
          list.sort(((a, b) => (a.securitycode!).compareTo(b.securitycode!)));
          break;
        case 1:
          list.sort(((a, b) => (a.securitycode!).compareTo(b.securitycode!)));
          list = list.reversed.toList();
          break;
      }
    }
  }

  // updateData() {
  //   newFilterSort();
  //   // emit((state as OpenComponentInitial)
  //   //     .copyWith(openList: list, filterarrayposition: filterarrayposition));
  // }

  data() {
    newFilterSort();
    if (isClosed) return;
    emit((state as OpenComponentInitial).copyWith(
      openList: list,
      filterarrayposition: filterarrayposition,
      filterval: currentVal,
      searchActive: false,
    ));
  }

  updateData() {
    if (isClosed) return;
    emit((state as OpenComponentInitial).copyWith(
        openList: UserController().openOrders,
        filterarrayposition: filterarrayposition));
  }

  onLoading(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return StreamBuilder(
            stream: Stream.periodic(const Duration(milliseconds: 1)),
            builder: (context, snap) {
              return Dialog(
                child: Container(
                  height: 120,
                  width: 100,
                  color: customColors().backgroundPrimary,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(
                        color: customColors().primary,
                      ),
                    ],
                  ),
                ),
              );
            });
      },
    );
  }

  fillSymbolData(Instrument instrument) async {
    try {
      _response = await gateway.symbolDetailsSearchRequest(
          venuCode: instrument.venuecode, venuScripCode: instrument.scripcode);
      Reclist reclist =
          _response!.searchresp!.elementAt(0).reclist!.elementAt(0);
      instrument.securityCode = reclist.securitycode!;
      instrument.securityName = reclist.symbolname!;
      instrument.series = reclist.series!;
      instrument.type = reclist.instrumenttype!;
      instrument.otherScripCode = reclist.otherScripCode!;
      instrument.otherSeries = reclist.otherseries!;
      instrument.ticksize = reclist.ticksize;
      instrument.lotsize = reclist.marketlot!;
      instrument.displayName = reclist.securitycode1 ?? "";
      instrument.contractDate = reclist.expirationdate!;
    } catch (e) {
      log("Exception caught in fillSymbolData", error: e);
    }
  }

  cancelorder(BuildContext context, List<OrderStatusResult3> openList,
      int index) async {
    bool _status;
    Navigator.of(context).pop(true);
    onLoading(context);
    _status = await orderCancel(
      ignoreOfflineGtd: false,
      transId: openList.elementAt(index).transid!,
      venueCode: openList.elementAt(index).venuecode!,
      orderType: int.parse(openList.elementAt(index).ordertype!),
      securityCode: openList.elementAt(index).securitycode1,
      venueScripCode: openList.elementAt(index).venuescripcode!,
      producTypeId: openList.elementAt(index).productId!,
      priceCondition: openList.elementAt(index).priceConditionId.toString(),
      orderID: openList.elementAt(index).orderId!,
      context: context,
    );
    Navigator.of(context).pop(true);
    Navigator.of(context).pop(true);
    if (_status) {
      ScaffoldMessenger.of(context).showSnackBar(
          showSuccessDialogue(errorMessage: "Cancel order sent to exchange"));
    }
  }

  cancelOrderGtd(BuildContext context, List<OrderStatusResult3> openList,
      int index, bool val) async {
    bool _gtdStatus;
    Navigator.of(context).pop(true);
    onLoading(context);
    _gtdStatus = await orderCancel(
      ignoreOfflineGtd: val,
      transId: openList.elementAt(index).transid!,
      venueCode: openList.elementAt(index).venuecode!,
      orderType: int.parse(openList.elementAt(index).ordertype!),
      securityCode: openList.elementAt(index).securitycode1,
      venueScripCode: openList.elementAt(index).venuescripcode!,
      producTypeId: openList.elementAt(index).productId!,
      priceCondition: openList.elementAt(index).priceConditionId.toString(),
      orderID: openList.elementAt(index).orderId!,
      context: context,
    );
    Navigator.of(context).pop(true);
    Navigator.of(context).pop(true);
    if (_gtdStatus) {
      ScaffoldMessenger.of(context).showSnackBar(showSuccessDialogue(
          errorMessage: val
              ? "Cancel order sent to exchange"
              : "Order succesfully cancelled and GTD order cancelled successfully"));
    }
  }
}

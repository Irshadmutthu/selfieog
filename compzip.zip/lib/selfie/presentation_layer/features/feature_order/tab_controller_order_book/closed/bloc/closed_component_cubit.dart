import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/order_status_item_response.dart';

part 'closed_component_state.dart';

class ClosedComponentCubit extends Cubit<ClosedComponentState> {
  final TradingApiGateway gateway;
  List<String> filterarrayposition = [];
  int currentVal = -1;
  List<OrderStatusResult3> list = [];
  bool isSearchFinished = false;
  ClosedComponentCubit({required this.gateway})
      : super(
          ClosedComponentInitial(
              closedList: UserController().closedOrders,
              filterarrayposition: []),
        );

  orderTypeUpdate(String val) {
    switch (val) {
      case "MARKET":
        {
          return "MKT";
        }
      case "LIMIT":
        {
          return "LMT";
        }
      case "SL-LIMIT":
        {
          return "STL";
        }
      case "BASKET ORDER":
        {
          return "BO";
        }
      case "CONFIRMED":
        {
          return "Confirmed";
        }
      case "PENDING":
        {
          return "Pending";
        }
      case "SAVED":
        {
          return "Saved";
        }
    }
    return val;
  }

  newSort(int index) {
    currentVal = index;
    data();
  }

  newFilter(List<String> keyword) {
    filterarrayposition = keyword;
    data();
  }

  newFilterSort() {
    list = List.from(UserController().closedOrders, growable: true);
    if (filterarrayposition.isNotEmpty) {
      List<OrderStatusResult3> finalList = [];
      for (var element in list) {
        for (int i = 0; i < filterarrayposition.length; i++) {
          if (list.contains(element)) {
          } else {
            if (element.producttype!.contains(
                    orderTypeUpdate(filterarrayposition[i].toUpperCase())) ||
                element.buyorsell ==
                    orderTypeUpdate(filterarrayposition[i].toUpperCase()) ||
                element.pricecondition ==
                    orderTypeUpdate(filterarrayposition[i].toUpperCase()) ||
                element.statussubcategory ==
                    orderTypeUpdate(filterarrayposition[i].toUpperCase())) {
              list.add(element);
            }
          }
        }
        list = finalList;
      }
    }
    if (currentVal != -1) {
      switch (currentVal) {
        case 0:
          list.sort(((a, b) => (a.securitycode!).compareTo(b.securitycode!)));
          break;
        case 1:
          list.sort(((a, b) => (a.securitycode!).compareTo(b.securitycode!)));
          list = list.reversed.toList();
          break;
      }
    }
  }

  // List<OrderStatusResult3> closedSort(
  //     List<OrderStatusResult3> list, int index) {
  //   switch (index) {
  //     case 0:
  //       list.sort(((a, b) => (a.securitycode!).compareTo(b.securitycode!)));
  //       break;
  //     case 1:
  //       list.sort(((a, b) => (a.securitycode!).compareTo(b.securitycode!)));
  //       list = list.reversed.toList();
  //       break;
  //   }
  //   return list;
  // }

  // closedOrdersList() async {
  //   emit(
  //     ClosedComponentInitial(
  //         closedList: UserController().closedOrders,
  //         filterarrayposition: filterarrayposition),
  //   );
  // }

  search(String keyword) async {
    List<OrderStatusResult3> searchResult = [];
    List<OrderStatusResult3> searchSet = UserController().closedOrders;
    searchResult.clear();

    searchSet.forEach(((element) {
      if (element.securitycode1.contains(keyword.trim().toUpperCase()) ||
          element.securitycode1.startsWith(keyword.trim().toUpperCase()) ||
          element.securityname!.startsWith(keyword.trim().toUpperCase()) ||
          element.securityname!.contains(keyword.trim().toUpperCase())) {
        searchResult.add(element);
      }
    }));

    emit((state as ClosedComponentInitial).copyWith(
        closedList: searchResult, filterarrayposition: filterarrayposition));
  }

  resetList() {
    filterarrayposition.clear();
    currentVal = -1;
    data();
  }

  data() {
    newFilterSort();
    emit(
      ClosedComponentInitial(
        closedList: list,
        filterarrayposition: filterarrayposition,
        filterval: currentVal,
        searchActive: false,
      ),
    );
  }

  // updateSortData(int index) {
  //   List<OrderStatusResult3> list = [];
  //   List<OrderStatusResult3> sortSet = UserController().closedOrders;

  //   list = closedSort(sortSet, index);

  //   emit((state as ClosedComponentInitial).copyWith(
  //       closedList: list,
  //       filterval: index,
  //       filterarrayposition: filterarrayposition));
  // }

  // updateFiltertData(List<String> el) {
  //   List<OrderStatusResult3> filterSet = UserController().closedOrders;
  //   List<OrderStatusResult3> list = [];
  //   filterarrayposition = List.from(el);
  //   if (el.isEmpty) {
  //     emit((state as ClosedComponentInitial).copyWith(
  //         closedList: filterSet, filterarrayposition: filterarrayposition));
  //   } else {
  //     filterSet.forEach(((element) {
  //       for (int i = 0; i < el.length; i++) {
  //         if (list.contains(element)) {
  //         } else {
  //           if (element.producttype!
  //                   .contains(orderTypeUpdate(el[i].toUpperCase())) ||
  //               element.buyorsell == orderTypeUpdate(el[i].toUpperCase()) ||
  //               element.pricecondition ==
  //                   orderTypeUpdate(el[i].toUpperCase()) ||
  //               element.statussubcategory ==
  //                   orderTypeUpdate(el[i].toUpperCase())) {
  //             list.add(element);
  //           }
  //         }
  //       }
  //     }));
  //     if (list.isEmpty) {
  //       emit((state as ClosedComponentInitial).copyWith(
  //           closedList: [], filterarrayposition: filterarrayposition));
  //       return;
  //     }
  //     emit((state as ClosedComponentInitial).copyWith(
  //         closedList: list, filterarrayposition: filterarrayposition));
  //   }
  // }

  // updateData() {
  //   emit(
  //     ClosedComponentInitial(
  //         closedList: UserController().closedOrders,
  //         filterarrayposition: filterarrayposition),
  //   );
  // }

}

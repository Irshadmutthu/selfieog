import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/featur_symbolsearch/symbol_search/cubit/symbol_search_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/components/search_form.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_book/cubit/order_book_screen_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_status_bottom_sheet/complete_orders/bottom_sheet_header/order_summary/bloc/cubit/order_summary_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_status_bottom_sheet/complete_orders/bottom_sheet_header/order_summary/ui/orders_summary_completed_orders.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/closed/bloc/closed_component_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/closed/components/closed_shimmer.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/open/components/open_shimmer.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/order_book_open_filter_bar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/closed/closed_list_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/empty_list_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/filter/search_filter_order_book.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/fixed_bottom_buttons/fixed_bottom_buttons.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/utils/utils.dart';
import '../../../../../../mds_controller.dart/mds_model.dart/instrument.dart';
import '../../../../../../order_model/Order.dart';
import '../../../../../../utils/user_settings.dart';

class OrderBookClosedComponent extends StatefulWidget {
  Function(bool) onScrollEvent;
  OrderBookClosedComponent({
    Key? key,
    required this.onScrollEvent,
  }) : super(key: key);

  @override
  State<OrderBookClosedComponent> createState() =>
      _OrderBookClosedComponentState();
}

class _OrderBookClosedComponentState extends State<OrderBookClosedComponent>
    with AutomaticKeepAliveClientMixin<OrderBookClosedComponent> {
  ScrollController _scrollBottomBarController = new ScrollController();
  // bool isSearchFinished = false;
  bool isScrollingDown = false;
  late TradingApiGateway _gateway;

  void initState() {
    // TODO: implement initState
    super.initState();
    _gateway = context.gTradingApiGateway;
    //_controller = BottomSheet.createAnimationController(this);
    // _controller!.duration = const Duration(milliseconds: 400);

    myScroll();
  }

  @override
  void dispose() {
    // _controller!.dispose();
    super.dispose();
  }

  void myScroll() async {
    _scrollBottomBarController.addListener(() {
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        if (!isScrollingDown) {
          isScrollingDown = true;
          widget.onScrollEvent(false); //hide appbar
        }
      }
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.forward) {
        if (isScrollingDown) {
          isScrollingDown = false;
          widget.onScrollEvent(true); //show appbar
        }
      }
    });
  }

  AnimationController? _controller;

  bool search = false;
  bool showFilter = true;
  final TextEditingController _serach = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => ClosedComponentCubit(gateway: _gateway),
      child: RefreshIndicator(
        backgroundColor: customColors().primary,
        onRefresh: () async {
          UserController().allowOrderbookRequest = true;
          BlocProvider.of<OrderBookScreenCubit>(context).orders();
          // BlocProvider.of<ClosedComponentCubit>(context).data();
        },
        child: Column(
          children: [
            BlocListener<OrderBookScreenCubit, OrderBookScreenState>(
              listener: (context, state) {
                if (state is OrderBookScreenInitial) {
                  BlocProvider.of<ClosedComponentCubit>(context).data();
                }
              },
              child: Container(),
            ),
            BlocBuilder<OrderBookScreenCubit, OrderBookScreenState>(
              builder: (context, state) {
                if (state is OrderBookLoadingState) {
                  return const ClosedShimmer();
                }
                return BlocBuilder<ClosedComponentCubit, ClosedComponentState>(
                  builder: (context, state) {
                    if (state is ClosedComponentInitial) {
                      if (UserController().closedOrders.isEmpty) {
                        return ListView.builder(
                            physics: const AlwaysScrollableScrollPhysics(),
                            shrinkWrap: true,
                            itemCount: 1,
                            itemBuilder: (context, index) {
                              return Column(
                                children: const [
                                  Padding(
                                    padding: EdgeInsets.only(top: 100),
                                    child: OrderbookEmptyContainer(
                                        title: "No closed orders",
                                        subTitle: ""),
                                  )
                                ],
                              );
                            });
                      } else {
                        return Expanded(
                          child: Column(
                            children: [
                              Column(
                                children: [
                                  Visibility(
                                    visible: !state.searchActive,
                                    child: SearchFilterHoldings(
                                      sortBubble: state.filterval != -1,
                                      showBubble:
                                          state.filterarrayposition.isNotEmpty,
                                      onFilterPress: () {
                                        customShowModalBottomSheet(
                                          context: context,
                                          inputWidget: OrderSortFilter(
                                            filterarrayposition:
                                                state.filterarrayposition,
                                            currentval: state.filterval,
                                            selectedTabIndex: 0,
                                            onPresssort: (int index) {
                                              BlocProvider.of<
                                                          ClosedComponentCubit>(
                                                      context)
                                                  .newSort(index);
                                            },
                                            onPressFilter: (List<String> el) {
                                              BlocProvider.of<
                                                          ClosedComponentCubit>(
                                                      context)
                                                  .newFilter(el);
                                            },
                                            onPressReset: () {
                                              BlocProvider.of<
                                                          ClosedComponentCubit>(
                                                      context)
                                                  .resetList();
                                            },
                                          ),
                                        );
                                      },
                                      ononSortPress: () {
                                        customShowModalBottomSheet(
                                          context: context,
                                          inputWidget: OrderSortFilter(
                                            filterarrayposition:
                                                state.filterarrayposition,
                                            currentval: state.filterval,
                                            selectedTabIndex: 1,
                                            onPresssort: (int index) {
                                              BlocProvider.of<
                                                          ClosedComponentCubit>(
                                                      context)
                                                  .newSort(index);
                                            },
                                            onPressFilter: (List<String> el) {
                                              BlocProvider.of<
                                                          ClosedComponentCubit>(
                                                      context)
                                                  .newFilter(el);
                                            },
                                            onPressReset: () {
                                              BlocProvider.of<
                                                          ClosedComponentCubit>(
                                                      context)
                                                  .resetList();
                                            },
                                          ),
                                        );
                                      },
                                      onSearchPress: () {
                                        BlocProvider.of<ClosedComponentCubit>(
                                                context)
                                            .emit(state.copyWith(
                                                searchActive: true,
                                                filterarrayposition:
                                                    state.filterarrayposition));
                                      },
                                    ),
                                  ),
                                  Visibility(
                                    visible: state.searchActive,
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.0),
                                      child: OrderbookSearch(
                                        onBackPressed: () {
                                          BlocProvider.of<ClosedComponentCubit>(
                                                  context)
                                              .emit(state.copyWith(
                                                  searchActive: false,
                                                  filterarrayposition: state
                                                      .filterarrayposition));
                                          BlocProvider.of<ClosedComponentCubit>(
                                                  context)
                                              .data();
                                        },
                                        hintText: "Search eg: infy",
                                        controller: _serach,
                                        onSearch: (String keyword) {
                                          BlocProvider.of<ClosedComponentCubit>(
                                                  context)
                                              .search(keyword);
                                        },
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              Expanded(
                                child: ListView.builder(
                                    controller: _scrollBottomBarController,
                                    physics: const ScrollPhysics(
                                        parent:
                                            AlwaysScrollableScrollPhysics()),
                                    itemCount: state.closedList.length,
                                    shrinkWrap: true,
                                    itemBuilder: (context, index) {
                                      return InkWell(
                                        onTap: () async {
                                          Instrument instrument = Instrument(
                                              scripcode: state.closedList
                                                  .elementAt(index)
                                                  .venuescripcode!,
                                              venueIndex: getVenueIndex(state
                                                  .closedList
                                                  .elementAt(index)
                                                  .venuecode!));

                                          callSymbolSearch(
                                              context, state, instrument);
                                          customBottomSheet(
                                            height: .76,
                                            maxHeight: .89,
                                            context: context,
                                            inputWidget: CompletedOrders(
                                              context: context,
                                              instrument: instrument,
                                              overViewList: state.closedList,
                                              orderLogList: state.closedList,
                                              index: index,
                                            ),
                                            fixedBottomWidget:
                                                BlocProvider.value(
                                              value: BlocProvider.of<
                                                      ClosedComponentCubit>(
                                                  context),
                                              child: BlocBuilder<
                                                      ClosedComponentCubit,
                                                      ClosedComponentState>(
                                                  builder: (context, state) {
                                                if (state
                                                    is ClosedComponentInitial) {
                                                  return OdrderBookFixedButton(
                                                    loading:
                                                        !state.isSearchFinished,
                                                    enable:
                                                        state.isSearchFinished,
                                                    elevation: true,
                                                    modify: false,
                                                    onReorderClick: () {
                                                      if (!state
                                                          .isSearchFinished) {
                                                        return;
                                                      }
                                                      OrderModel order =
                                                          OrderModel(
                                                              instrument,
                                                              UserSettings
                                                                  .userSettings
                                                                  .orderSettings);

                                                      order.TransId = state
                                                          .closedList
                                                          .elementAt(index)
                                                          .transid;
                                                      order.qty = VENUE_IN_QTY
                                                              .elementAt(VENUES_ORDER
                                                                  .indexOf(
                                                                      instrument
                                                                          .venuecode))
                                                          ? state.closedList
                                                              .elementAt(index)
                                                              .quantity!
                                                          : state.closedList
                                                                  .elementAt(
                                                                      index)
                                                                  .quantity! *
                                                              instrument
                                                                  .lotsize!;
                                                      if (state.closedList
                                                              .elementAt(index)
                                                              .buyorsell
                                                              .toString() ==
                                                          "BUY") {
                                                        order.buyOrSell = BUY;
                                                      } else {
                                                        order.buyOrSell = SELL;
                                                      }
                                                      order.isReorder = true;
                                                      order.productType = state
                                                          .closedList
                                                          .elementAt(index)
                                                          .productId!;
                                                      order.timeCondition =
                                                          state.closedList
                                                              .elementAt(index)
                                                              .tifcd!;
                                                      order.priceCondition =
                                                          getPriceConditionbyId(
                                                              state.closedList
                                                                  .elementAt(
                                                                      index)
                                                                  .priceConditionId!);
                                                      order.triggerPrice = state
                                                          .closedList
                                                          .elementAt(index)
                                                          .triggerprice
                                                          .toString();
                                                      order.price = state
                                                          .closedList
                                                          .elementAt(index)
                                                          .price
                                                          .toString();
                                                      context.gNavigationService
                                                          .openOrderWindowPage(
                                                              context,
                                                              {"order": order});
                                                    },
                                                    onmodifyClick: () {},
                                                    onCancel: () {},
                                                  );
                                                }
                                                return Container();
                                              }),
                                            ),
                                          );
                                        },
                                        child: ClosedListTile(
                                          closedList: state.closedList,
                                          index: index,
                                        ),
                                      );
                                    }),
                              ),
                            ],
                          ),
                        );
                      }
                    } else if (state is ClosedLoadingState) {
                      return const OpenShimmer();
                    }
                    return Container();
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  callSymbolSearch(BuildContext context, ClosedComponentInitial state,
      Instrument instrument) async {
    context
        .read<ClosedComponentCubit>()
        .emit(state.copyWith(isSearchFinished: false));
    if (await fillSymbolData(context, instrument)) {
      context
          .read<ClosedComponentCubit>()
          .emit(state.copyWith(isSearchFinished: true));
    }
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
}

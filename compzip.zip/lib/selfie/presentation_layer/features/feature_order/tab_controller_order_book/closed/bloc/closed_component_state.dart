part of 'closed_component_cubit.dart';

@immutable
abstract class ClosedComponentState {}

class ClosedComponentInitial extends ClosedComponentState {
  final List<OrderStatusResult3> closedList;
  final bool searchActive;
  final int filterval;
  final bool isSearchFinished;
  List<String> filterarrayposition;
  ClosedComponentInitial({
    this.closedList = const [],
    this.searchActive = false,
    this.filterval = -1,
    this.isSearchFinished = false,
    this.filterarrayposition = const [],
  });

  ClosedComponentInitial copyWith(
      {final List<OrderStatusResult3>? closedList,
      final bool? searchActive,
      final int? filterval,
      final bool? isSearchFinished,
      List<String>? filterarrayposition}) {
    return ClosedComponentInitial(
      closedList: closedList ?? this.closedList,
      filterarrayposition: filterarrayposition ?? this.filterarrayposition,
      filterval: filterval ?? this.filterval,
      isSearchFinished: isSearchFinished ?? this.isSearchFinished,
      searchActive: searchActive ?? this.searchActive,
    );
  }
}

class ClosedLoadingState extends ClosedComponentState {}

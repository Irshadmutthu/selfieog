import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_open_cancel_page/cubit/order_open_cancel_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_open_cancel_page/order_open_cancel_page.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:trading_api/responses/order_status_item_response.dart';

class OrderOpenCancelPageRoute {
  final ServiceLocator _serviceLocator;
  final List<OrderStatusResult3> data;

  OrderOpenCancelPageRoute(this._serviceLocator, this.data);

  // Widget call(BuildContext context) {
  //   return MultiRepositoryProvider(
  //       providers: [
  //         RepositoryProvider.value(
  //             value: _serviceLocator.navigationService),
  //         RepositoryProvider.value(value: _serviceLocator)
  //       ],
  //       child: OrderOpenCancelPage(
  //         data: data,
  //       ));
  // }
  Widget call(BuildContext context) {
    return MultiBlocProvider(
        providers: [
          BlocProvider(
            create: (context) => OrderOpenCancelCubit(
                serviceLocator: _serviceLocator, list: data,context: context),
          )
        ],
        child: MultiRepositoryProvider(
            providers: [
              RepositoryProvider.value(
                  value: _serviceLocator.navigationService),
              RepositoryProvider.value(value: _serviceLocator)
            ],
            child: OrderOpenCancelPage(
              data: data,
            )));
  }
}

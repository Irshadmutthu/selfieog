import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_open_cancel_page/cubit/order_open_cancel_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/open/open_list_item_selected.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';
import 'package:trading_api/responses/order_status_item_response.dart';

class OrderOpenCancelPage extends StatefulWidget {
  final List<OrderStatusResult3> data;

  const OrderOpenCancelPage({Key? key, required this.data}) : super(key: key);

  @override
  State<OrderOpenCancelPage> createState() => _OrderOpenCancelPageState();
}

class _OrderOpenCancelPageState extends State<OrderOpenCancelPage> {
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return BlocConsumer<OrderOpenCancelCubit, OrderOpenCancelState>(
        listener: (context, state) {
      if (state is OrderOpenCancelInitial) {
        if (state.errorMsg != "") {
          ScaffoldMessenger.of(context)
              .showSnackBar(showErrorDialogue(errorMessage: state.errorMsg));
        }
      }
    }, builder: (context, state) {
      return WillPopScope(
        onWillPop: () async {
          await BlocProvider.of<OrderOpenCancelCubit>(context)
              .willPopScopeWork(context);
          return false;
        },
        child: Scaffold(
          appBar: PreferredSize(
              preferredSize: const Size.fromHeight(0.0),
              child: AppBar(
                elevation: 0,
                backgroundColor: customColors().backgroundPrimary,
              )),
          bottomNavigationBar: Padding(
            padding: const EdgeInsets.only(bottom: 12.0),
            child: SizedBox(
              height: screenSize.height * 0.13,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Divider(
                    thickness: 1.0,
                    color: customColors().backgroundTertiary,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(
                        left: 16.0, right: 16.0, top: 8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (state is OrderOpenCancelInitial)
                          Expanded(
                            flex: 2,
                            child: Padding(
                              padding: const EdgeInsets.only(left: 8.0),
                              child: AbsorbPointer(
                                absorbing:
                                    BlocProvider.of<OrderOpenCancelCubit>(
                                                    context)
                                                .selectedCount ==
                                            0
                                        ? true
                                        : false,
                                child: BasketButton(
                                    onpress: () {
                                      BlocProvider.of<OrderOpenCancelCubit>(
                                              context)
                                          .cancelOrder(state.statusList,
                                              state.list, context);
                                    },
                                    text:
                                        "Cancel Orders (${BlocProvider.of<OrderOpenCancelCubit>(context).selectedCount})",
                                    bgcolor:
                                        BlocProvider.of<OrderOpenCancelCubit>(
                                                        context)
                                                    .selectedCount ==
                                                0
                                            ? customColors()
                                                .danger
                                                .withOpacity(0.4)
                                            : customColors().danger,
                                    bordercolor:
                                        BlocProvider.of<OrderOpenCancelCubit>(
                                                        context)
                                                    .selectedCount ==
                                                0
                                            ? customColors()
                                                .danger
                                                .withOpacity(0.1)
                                            : customColors().danger,
                                    textStyle: customTextStyle(
                                        fontStyle: FontStyle.BodyL_Bold,
                                        color: FontColor.White)),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          body: BlocBuilder<OrderOpenCancelCubit, OrderOpenCancelState>(
            builder: (context, state) {
              if (state is OrderOpenCancelInitial) {
                return Column(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                          border: Border(
                              bottom: BorderSide(
                                  width: 2.0,
                                  color: customColors().backgroundTertiary))),
                      child: Padding(
                        padding: EdgeInsets.only(
                            top: screenSize.height * .04, left: 16, bottom: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            InkWell(
                              onTap: () {
                                BlocProvider.of<OrderOpenCancelCubit>(context)
                                    .willPopScopeWork(context);
                              },
                              child: Image.asset(
                                "assets/arrow_left.png",
                                color: customColors().fontPrimary,
                              ),
                            ),
                            const SizedBox(width: 6),
                            Expanded(
                              child: SizedBox(
                                width: double.maxFinite,
                                child: Row(
                                  children: [
                                    Text(
                                      BlocProvider.of<OrderOpenCancelCubit>(
                                                  context)
                                              .selectedCount
                                              .toString() +
                                          "/" +
                                          widget.data.length.toString(),
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyL_SemiBold,
                                          color: FontColor.FontPrimary),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 8.0),
                                      child: Text(
                                        "Selected",
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyL_SemiBold,
                                            color: FontColor.FontSecondary),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(right: 11),
                              child: Row(
                                children: [
                                  Text(
                                    "All",
                                    style: customTextStyle(
                                        fontStyle: FontStyle.BodyL_Regular,
                                        color: FontColor.FontPrimary),
                                  ),
                                  const SizedBox(
                                    width: 5,
                                  ),
                                  EmptyCustomCheckBox(
                                    isSelect: state.isSelected,
                                    callback: (bool val) {
                                      BlocProvider.of<OrderOpenCancelCubit>(
                                              context)
                                          .selectAll(val, state.list);
                                    },
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    BlocBuilder<OrderOpenCancelCubit, OrderOpenCancelState>(
                      builder: (context, state) {
                        return Expanded(
                          child: SingleChildScrollView(
                            child: Column(
                              children: [
                                if (state is OrderOpenCancelInitial)
                                  Padding(
                                    padding: const EdgeInsets.only(top: 5.0),
                                    child: ListView.builder(
                                        itemCount: state.list.length,
                                        shrinkWrap: true,
                                        physics:
                                            const NeverScrollableScrollPhysics(),
                                        itemBuilder: (context, index) {
                                          return OpenListItemSelected(
                                            index: index,
                                            openSamples: state.list,
                                            selected: state.statusList,
                                          );
                                        }),
                                  ),
                              ],
                            ),
                          ),
                        );
                      },
                    )
                  ],
                );
              } else if (state is OrderCancelLoadingState) {
                return StreamBuilder(
                    stream: Stream.periodic(const Duration(milliseconds: 10)),
                    builder: (context, snapshot) {
                      return Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Center(
                            child: CircularProgressIndicator(
                              backgroundColor: Colors.black,
                              color: Colors.green,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 10),
                            child: Text(
                              BlocProvider.of<OrderOpenCancelCubit>(context)
                                      .listCount
                                      .toString() +
                                  "/" +
                                  BlocProvider.of<OrderOpenCancelCubit>(context)
                                      .selectedCount
                                      .toString(),
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary),
                            ),
                          ),
                        ],
                      );
                    });
              }
              return Container();
            },
          ),
        ),
      );
    });
  }
}

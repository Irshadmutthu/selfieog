import 'dart:async';
import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/common_cancel_method/cancel_order.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/alert_dialogs.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';
import 'package:trading_api/responses/order_status_item_response.dart';
part 'order_open_cancel_state.dart';

class OrderOpenCancelCubit extends Cubit<OrderOpenCancelState> {
  final ServiceLocator serviceLocator;
  bool isCancelOrder = false;
  bool isSelect = false;
  List<OrderStatusResult3> list;
  int selectedCount = 0;
  List<bool> statusList = [];
  int listCount = 0;
  int updateCount = 0;
  OrderOpenCancelCubit(
      {required this.serviceLocator,
      required this.list,
      required BuildContext context})
      : super(OrderCancelLoadingState()) {
    statusList = List.generate(list.length, (index) => false);

    emit(OrderOpenCancelInitial(
        list: list,
        statusList: statusList,
        errorMsg: "",
        isLoading: false,
        isSelected: isSelect));
  }

  selectAll(bool selected, List<OrderStatusResult3> list) {
    selectedCount = 0;
    for (int i = 0; i < list.length; i++) {
      // if (list[i].status == "CONF" || list[i].status == "PEXE") {
      selected ? selectedCount += 1 : selectedCount;
      statusList[i] = selected;
      // }
    }
    isSelect = selectedCount == statusList.length;
    emit(OrderOpenCancelInitial(
        list: list,
        statusList: statusList,
        errorMsg: "",
        isLoading: false,
        isSelected: isSelect));
  }

  selectItem(
      {required bool selected,
      required int index,
      required List<OrderStatusResult3> list}) {
    selected ? selectedCount += 1 : selectedCount -= 1;
    isSelect = selectedCount == statusList.length;
    statusList[index] = selected;
    emit(OrderOpenCancelInitial(
        list: list,
        statusList: statusList,
        errorMsg: "",
        isLoading: false,
        isSelected: isSelect));
  }

  onLoading(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return StreamBuilder(
            stream: Stream.periodic(const Duration(milliseconds: 1)),
            builder: (context, snap) {
              return Dialog(
                child: Container(
                  height: 120,
                  width: 100,
                  color: customColors().backgroundPrimary,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(
                        color: customColors().primary,
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      Text(
                        "$listCount / $selectedCount",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_SemiBold,
                            color: FontColor.FontPrimary),
                      ),
                    ],
                  ),
                ),
              );
            });
      },
    );
  }

  willPopScopeWork(BuildContext context) async {
    if (selectedCount == 0) {
      serviceLocator.navigationService
          .back(context, arg: {"isCancelOrder": false});
    } else {
      await showAlertDilogue(
          context: context,
          content: "Do you want to cancel?",
          negativeButtonName: "Cancel",
          onPositiveButtonClick: () async {
            Navigator.of(context).pop(true);
            serviceLocator.navigationService
                .back(context, arg: {"isCancelOrder": isCancelOrder});
          },
          onNegativeButtonClick: () {
            Navigator.of(context).pop(true);
          });
    }
  }

  cancelOrder(List<bool> statusList, List<OrderStatusResult3> list,
      BuildContext context) async {
    bool _status;
    List<OrderStatusResult3> finalList = [];
    await showAlertDilogue(
        context: context,
        content: "Do you want to cancel the order ?",
        negativeButtonName: "Cancel",
        onPositiveButtonClick: () async {
          Navigator.of(context).pop(true);
          onLoading(context);
          list.forEach(((element) {
            if (element.status == "CONF" || element.status == "PEXE") {
              finalList.add(element);
            }
          }));
          listCount = 0;
          for (int i = 0; i < finalList.length; i++) {
            if (statusList[i] == true) {
              _status = await orderCancel(
                ignoreOfflineGtd: false,
                orderID: list[i].orderId!,
                orderType: int.parse(list[i].ordertype!),
                priceCondition: list[i].pricecondition!,
                producTypeId: list[i].productId!,
                securityCode: list[i].securitycode1,
                transId: list[i].transid!,
                venueCode: list[i].venuecode!,
                venueScripCode: list[i].venuescripcode!,
                context: context,
              );
              listCount += 1;
              if (_status == false) {
                listCount = 0;
                ScaffoldMessenger.of(context).showSnackBar(
                    showErrorDialogue(errorMessage: "internal server error"));
                Navigator.pop(context);
                serviceLocator.navigationService
                    .back(context, arg: {"isCancelOrder": true});
                return;
              } else {
                isCancelOrder = true;
              }
            }
          }
          ScaffoldMessenger.of(context).showSnackBar(showSuccessDialogue(
              errorMessage: "Cancel order sent to exchange"));
          Navigator.pop(context);
          serviceLocator.navigationService
              .back(context, arg: {"isCancelOrder": isCancelOrder});
        },
        onNegativeButtonClick: () {
          Navigator.of(context).pop(true);
        });
  }
}

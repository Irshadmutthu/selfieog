part of 'order_open_cancel_cubit.dart';

@immutable
abstract class OrderOpenCancelState {}

class OrderOpenCancelInitial extends OrderOpenCancelState {
  final String errorMsg;
  List<OrderStatusResult3> list;
  final List<bool> statusList;
  bool isLoading;
  bool isSelected;

  OrderOpenCancelInitial(
      {this.errorMsg = "",
      required this.list,
      required this.statusList,
      required this.isLoading,
      required this.isSelected});
}

class OrderCancelLoadingState extends OrderOpenCancelState {}

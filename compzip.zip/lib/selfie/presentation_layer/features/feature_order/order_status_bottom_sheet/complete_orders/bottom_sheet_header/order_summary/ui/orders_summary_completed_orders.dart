import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_status_bottom_sheet/complete_orders/bottom_sheet_header/order_summary/bloc/cubit/order_summary_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_status_bottom_sheet/complete_orders/tab_view.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/watchlist/custom_watchlist_content/custom_watchlist_content.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:trading_api/responses/order_status_item_response.dart';

class CompletedOrders extends StatefulWidget {
  BuildContext context;
  List<OrderStatusResult3> overViewList;
  List<OrderStatusResult3> orderLogList;
  int index;
  Instrument instrument;
  CompletedOrders(
      {Key? key,
      required this.context,
      required this.overViewList,
      required this.orderLogList,
      required this.index,
      required this.instrument})
      : super(key: key);

  @override
  State<CompletedOrders> createState() => _CompletedOrdersState();
}

class _CompletedOrdersState extends State<CompletedOrders> {
  late TradingApiGateway _gateway;

  @override
  void initState() {
    super.initState();
    _gateway = context.gTradingApiGateway;
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => OrderSummaryCubit(
        instrument: widget.instrument,
      ),
      child: Column(
        children: [
          Padding(
            padding:
                const EdgeInsets.only(left: 16, right: 16, top: 10, bottom: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Order Summary",
                  style: customTextStyle(
                    fontStyle: FontStyle.HeaderXS_SemiBold,
                    color: FontColor.FontPrimary,
                  ),
                ),
              ],
            ),
          ),
          Divider(
            height: 0,
            thickness: 1,
            color: customColors().backgroundTertiary,
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 0, 0, 4),
                      child: SizedBox(
                        width: MediaQuery.of(context).size.width * 0.7,
                        child: Row(
                          children: [
                            SymbolNameWidget(widget
                                .overViewList[widget.index].securitycode1
                                .toString()),
                          ],
                        ),
                      ),
                    ),
                    Row(
                      children: [
                        getProductTypeWidget(widget
                            .overViewList[widget.index].venuecode
                            .toString()),
                        const SizedBox(
                          width: 6,
                        ),
                        getProductTypeWidget(widget
                            .overViewList[widget.index].buyorsell
                            .toString()),
                        const SizedBox(
                          width: 6,
                        ),
                        getProductTypeWidget(widget
                            .overViewList[widget.index].producttype
                            .toString())
                      ],
                    ),
                  ],
                ),
                BlocBuilder<OrderSummaryCubit, OrderSummaryState>(
                  builder: (context, state) {
                    if (state is OrderSummaryInitial) {
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            state.instrument.lastTrdPrice
                                .toStringAsFixed(state.instrument.precision),
                            style: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.FontPrimary,
                            ),
                          ),
                          const SizedBox(
                            height: 4,
                          ),
                          Row(
                            children: [
                              state.instrument.getLtpColor() ==
                                      customColors().success
                                  ? Text("+",
                                      style: customTextStyle(
                                        fontStyle: FontStyle.BodyM_SemiBold,
                                      ).copyWith(
                                          color:
                                              state.instrument.getLtpColor()))
                                  : Container(),
                              Text(
                                state.instrument.changePrice.toStringAsFixed(
                                    state.instrument.precision),
                                style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_SemiBold,
                                ).copyWith(
                                    color: state.instrument.getLtpColor()),
                              ),
                              Text(
                                  "(${state.instrument.getLtpColor() == customColors().success ? "+" : ""}${state.instrument.percChange.toStringAsFixed(2)}%)",
                                  style: customTextStyle(
                                    fontStyle: FontStyle.BodyM_SemiBold,
                                  ).copyWith(
                                      color: state.instrument.getLtpColor())),
                            ],
                          )
                        ],
                      );
                    }
                    return Container();
                  },
                )
              ],
            ),
          ),
          OrderBookTabComponents(
            orderViewList: widget.overViewList,
            index: widget.index,
          ),
        ],
      ),
    );
  }
}

part of 'order_summary_cubit.dart';

@immutable
abstract class OrderSummaryState {}

class OrderSummaryInitial extends OrderSummaryState {
  final Instrument instrument;

  OrderSummaryInitial({required this.instrument});
}

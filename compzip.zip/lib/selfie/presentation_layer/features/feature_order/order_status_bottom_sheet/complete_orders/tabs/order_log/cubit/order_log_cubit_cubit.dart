import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/order_log_response.dart';
import 'package:trading_api/responses/order_status_item_response.dart';
part 'order_log_cubit_state.dart';

class OrderLogCubitCubit extends Cubit<OrderLogCubitState> {
  final TradingApiGateway gateway;
  OrderItemOrderLogResponse? _response;
  List<OrderStatusResult3> list;
  int index;

  OrderLogCubitCubit(
      {required this.gateway, required this.list, required this.index})
      : super(OrderLogCubitInitial(
            orderLsit: UserController().orderLogResponse)) {
    if (UserController.userController.orderLogResponse.isEmpty) {
      orderLogRequest();
    }
  }

  List<OrderLogData> demo = [];

  orderLogRequest() async {
    try {
      emit(OrderLogLoadingState());
      UserController().orderLogResponse.clear();
      _response = await gateway.orderLogRequest(
        venueCode: list[index].venuecode.toString(),
        userId: UserController().userId,
        transId: list[index].transid.toString(),
        securityCode: list[index].securitycode.toString(),
      );
      demo.clear();
      if (_response!.errorCode == 0) {
        for (int i = _response!.reportData!.length - 1; i > -1; i--) {
          demo.add(_response!.reportData![i]);
          UserController().orderLogResponse = demo;
        }
        emit(
          OrderLogCubitInitial(
              orderLsit: UserController().orderLogResponse, errorMsg: ""),
        );
      }
    } catch (e) {
      emit(
        OrderLogCubitInitial(
            orderLsit: UserController().orderLogResponse,
            errorMsg: e.toString()),
      );
    }
  }

  updateData() {
    emit(OrderLogCubitInitial(orderLsit: UserController().orderLogResponse));
  }
}

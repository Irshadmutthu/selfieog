// part of 'bottom_sheet_header_cubit.dart';

// @immutable
// abstract class BottomSheetHeaderState {}

// class BottomSheetHeaderInitial extends BottomSheetHeaderState {
//   List<OrderLogData> orderLogData;
//   BottomSheetHeaderInitial({required this.orderLogData});
// }

// class BottomHeaderErrorState extends BottomSheetHeaderState {
//   String errorMsg;
//   BottomHeaderErrorState({required this.errorMsg});

// }

// class BottomHeaderLoadingState extends BottomSheetHeaderState {}
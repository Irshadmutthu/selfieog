import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
part 'order_summary_state.dart';

class OrderSummaryCubit extends Cubit<OrderSummaryState> {
  final Instrument instrument;
  late StreamSubscription strSub;

  OrderSummaryCubit({required this.instrument})
      : super(OrderSummaryInitial(
          instrument: instrument,
        )) {
    getFeedUpdate();
  }

  getFeedUpdate() {
    MDS_Controller.mdsController.subscribeSymbol(instrument);
    strSub = MDS_Controller.mdsController.marketUpdateStream.listen((event) {
      if (!isClosed) {
        emit(OrderSummaryInitial(instrument: instrument));
      } else {
        MDS_Controller.mdsController.unsubscribeSymbol(instrument);
        strSub.cancel();
      }
    });
  }
}

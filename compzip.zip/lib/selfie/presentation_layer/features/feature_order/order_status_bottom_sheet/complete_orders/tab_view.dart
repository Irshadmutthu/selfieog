import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_status_bottom_sheet/complete_orders/tabs/order_log/order_log.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_status_bottom_sheet/complete_orders/tabs/order_overview/overview.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/order_status_item_response.dart';

class OrderBookTabComponents extends StatefulWidget {
  List<OrderStatusResult3> orderViewList;
  int index;
  OrderBookTabComponents(
      {Key? key, required this.orderViewList, required this.index})
      : super(key: key);

  @override
  State<OrderBookTabComponents> createState() => _OrderBookTabComponentsState();
}

class _OrderBookTabComponentsState extends State<OrderBookTabComponents>
    with SingleTickerProviderStateMixin {
  final List<Tab> myTabs = const [
    Tab(text: 'Overview'),
    Tab(text: 'Order Log'),
  ];
  int selectedTabIndex = 0;
  List<Widget> tabbarView = [];

  late final TabController _tabController =
      TabController(length: myTabs.length, vsync: this);

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    UserController().orderLogResponse.clear();
  }

  @override
  Widget build(BuildContext context) {
    tabbarView = [
      OverViewTab(
        ordeList: widget.orderViewList,
        index: widget.index,
      ),
      OrderLogTab(
        index: widget.index,
        orderViewList: widget.orderViewList,
      ),
    ];
    return DefaultTabController(
        length: myTabs.length,
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                    border: Border(
                      bottom:
                          BorderSide(color: customColors().backgroundTertiary),
                    ),
                  ),
                  child: TabBar(
                      controller: _tabController,
                      isScrollable: true,
                      indicatorPadding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 0),
                      onTap: (index) {
                        setState(() {
                          selectedTabIndex = index;
                        });
                      },
                      unselectedLabelStyle: customTextStyle(
                          fontStyle: FontStyle.BodyL_Regular,
                          color: FontColor.FontSecondary),
                      labelStyle: customTextStyle(
                          fontStyle: FontStyle.BodyL_SemiBold,
                          color: FontColor.Primary),
                      unselectedLabelColor: customColors().fontSecondary,
                      indicatorColor: customColors().primary,
                      indicatorSize: TabBarIndicatorSize.tab,
                      indicatorWeight: 2,
                      // indicatorPadding: const EdgeInsets.all(10),
                      labelColor: customColors().primary,
                      tabs: myTabs),
                ),
              ],
            ),
            tabbarView[selectedTabIndex]
          ],
        ));
  }
}

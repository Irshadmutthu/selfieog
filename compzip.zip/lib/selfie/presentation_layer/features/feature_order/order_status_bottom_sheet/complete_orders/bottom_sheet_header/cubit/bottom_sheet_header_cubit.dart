
// import 'package:bloc/bloc.dart';
// import 'package:meta/meta.dart';
// import 'package:selfie_mobile_flutter/services/api_gateway.dart';
// import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
// import 'package:trading_api/responses/order_log_response.dart';
// import 'package:trading_api/responses/order_status_item_response.dart';
// part 'bottom_sheet_header_state.dart';

// class BottomSheetHeaderCubit extends Cubit<BottomSheetHeaderState> {
//   OrderItemOrderLogResponse? _response;
//   final TradingApiGateway gateway;
//   List<OrderStatusResult3> list;
//   int index;

//   BottomSheetHeaderCubit(
//       {required this.gateway, required this.list, required this.index})
//       : super(BottomSheetHeaderInitial(
//             orderLogData: UserController().orderLogResponse)) {
//     orderLogRequest();
//   }

//   List<OrderLogData> demo = [];

//   orderLogRequest() async {
//     emit(BottomHeaderLoadingState());
//     _response = await gateway.orderLogRequest(
//       venueCode: list[index].venuecode.toString(),
//       userId: UserController().userId,
//       transId: list[index].transid.toString(),
//       securityCode: list[index].securitycode.toString(),
//     );
//     demo.clear();

//     if (_response!.errorCode == 0) {
//       for (int i = 0; i < _response!.reportData!.length; i++) {
//         demo.add(_response!.reportData![i]);
//         UserController().orderLogResponse = demo;
//       }
//       emit(
//         BottomSheetHeaderInitial(
//             orderLogData: UserController().orderLogResponse),
//       );
//     }
//   }
// }

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/conversions/conversions.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_status_bottom_sheet/complete_orders/tabs/order_log/cubit/order_log_cubit_cubit.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';
import 'package:trading_api/responses/order_status_item_response.dart';

class OrderLogTab extends StatefulWidget {
  List<OrderStatusResult3> orderViewList;
  int index;
  OrderLogTab({Key? key, required this.orderViewList, required this.index})
      : super(key: key);

  @override
  State<OrderLogTab> createState() => _OrderLogTabState();
}

class _OrderLogTabState extends State<OrderLogTab> {
  late TradingApiGateway _gateway;

  @override
  void initState() {
    super.initState();
    _gateway = context.gTradingApiGateway;
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => OrderLogCubitCubit(
          gateway: _gateway, list: widget.orderViewList, index: widget.index),
      child: BlocConsumer<OrderLogCubitCubit, OrderLogCubitState>(
        listener: (context, state) {
          if (state is OrderLogCubitInitial) {
            if (state.errorMsg != "") {
              ScaffoldMessenger.of(context).showSnackBar(
                  showErrorDialogue(errorMessage: state.errorMsg));
            }
          }
        },
        builder: (context, state) {
          return Column(
            children: [
              BlocBuilder<OrderLogCubitCubit, OrderLogCubitState>(
                builder: (context, state) {
                  if (state is OrderLogCubitInitial) {
                    return Padding(
                      padding: const EdgeInsets.only(
                          left: 11, right: 16, top: 20, bottom: 6),
                      child: SizedBox(
                        height: state.orderLsit.length.toDouble() * 79,
                        child: ListView.builder(
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: state.orderLsit.length,
                          itemBuilder: (context, index) => Stack(
                            children: [
                              index != state.orderLsit.length - 1
                                  ? Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Row(
                                          children: [
                                            Column(
                                              children: List.generate(
                                                9,
                                                (ii) => Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 10,
                                                          right: 10,
                                                          bottom: 2,
                                                          top: 2),
                                                  child: Container(
                                                    height: 4,
                                                    width: 1,
                                                    color: customColors()
                                                        .silverDust,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    )
                                  : const SizedBox(),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                left: 6, right: 12, bottom: 4),
                                            child: Container(
                                              height: 10,
                                              width: 10,
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                color:
                                                    customColors().silverDust,
                                              ),
                                            ),
                                          ),
                                          // Text(
                                          //   // list[index].title,
                                          //   // "${state.orderLsit[index]["TIFCD"]}",
                                          //   orderTypesConverstion(state
                                          //           .orderLsit[index].ordertype
                                          //           .toString())
                                          //       .toString(),
                                          //   style: customTextStyle(
                                          //     fontStyle:
                                          //         FontStyle.BodyM_SemiBold,
                                          //     color: FontColor.FontPrimary,
                                          //   ),
                                          // )
                                          Text(
                                            // list[index].title,
                                            // "${state.orderLsit[index]["TIFCD"]}",
                                            orderLogConversion(state
                                                    .orderLsit[index].ordertype
                                                    .toString())
                                                .toString(),
                                            style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyM_SemiBold,
                                              color: orderLogColor(
                                                orderLogConversion(state
                                                    .orderLsit[index].ordertype
                                                    .toString()),
                                              ),
                                            ),
                                          )
                                        ],
                                      ),
                                      Text(
                                        state.orderLsit[index].lastupdatedon
                                            .toString()
                                            .substring(10, 19),
                                        style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_SemiBold,
                                          color: FontColor.FontSecondary,
                                        ),
                                      )
                                    ],
                                  ),
                                  // Padding(
                                  //   padding: const EdgeInsets.only(left: 28, top: 4),
                                  //   child: RichText(
                                  //     text: TextSpan(
                                  //       text: '${list[index].subTitle} ',
                                  //       style: customTextStyle(
                                  //           fontStyle: FontStyle.BodyM_Regular,
                                  //           color: FontColor.FontSecondary),
                                  //       children: <TextSpan>[
                                  //         TextSpan(
                                  //           text: list[index].price,
                                  //           style: customTextStyle(
                                  //             fontStyle: FontStyle.BodyM_SemiBold,
                                  //             color: FontColor.FontSecondary,
                                  //           ),
                                  //         ),
                                  //       ],
                                  //     ),
                                  //   ),
                                  // )
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  } else if (state is OrderLogLoadingState) {
                    return Padding(
                      padding: EdgeInsets.only(
                          top: MediaQuery.of(context).size.height * 0.1),
                      child: CircularProgressIndicator(
                        color: customColors().primary,
                      ),
                    );
                  }
                  return Container();
                },
              ),
            ],
          );
        },
      ),
    );
  }

  orderLogColor(String val) {
    switch (val) {
      case "Cancelled":
      case "Rejected":
        return FontColor.Danger;
      case "Confirmed":
      case "Executed":
        return FontColor.Success;
      default:
        return FontColor.FontPrimary;
    }
  }
}

class Model {
  String title;
  String subTitle;
  String time;
  FontColor? color;
  String? price;

  //Other fields if needed....
  Model({
    required this.title,
    required this.subTitle,
    required this.time,
    this.price,
    this.color,
  });
  //initialise other fields so on....
}

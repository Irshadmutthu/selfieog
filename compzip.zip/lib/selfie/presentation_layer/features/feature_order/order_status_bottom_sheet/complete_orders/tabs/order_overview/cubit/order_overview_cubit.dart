import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:trading_api/responses/order_status_item_response.dart';


part 'order_overview_state.dart';

class OrderOverviewCubit extends Cubit<OrderOverviewState> {
  List<OrderStatusResult3> list;
  OrderOverviewCubit({required this.list})
      : super(OrderOverviewInitial(orderList: list)) {
    ordrOverViewList();
  }

  ordrOverViewList() {
    emit(
      OrderOverviewInitial(
        orderList: list,
      ),
    );
  }
}

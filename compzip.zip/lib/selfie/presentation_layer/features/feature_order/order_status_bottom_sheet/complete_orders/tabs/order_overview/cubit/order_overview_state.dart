part of 'order_overview_cubit.dart';

@immutable
abstract class OrderOverviewState {}

class OrderOverviewInitial extends OrderOverviewState {
  List<OrderStatusResult3> orderList;
  OrderOverviewInitial({required this.orderList});
}

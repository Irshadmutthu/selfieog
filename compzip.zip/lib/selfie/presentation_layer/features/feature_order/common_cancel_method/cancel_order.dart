import 'dart:developer';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';
import 'package:trading_api/requests/cancel_gtd_order.dart';
import 'package:trading_api/requests/cancel_order_request.dart';

Future<bool> orderCancel({
  required String transId,
  required String venueCode,
  required int orderType,
  required String securityCode,
  required String venueScripCode,
  required int producTypeId,
  required String priceCondition,
  required String orderID,
  required bool ignoreOfflineGtd,
  required BuildContext context,
}) async {
  try {
    final _cancelResponse = await context.gTradingApiGateway.cancelOrderRequest(
      cancelOrderRequest: CancelOrderRequest(
        proc: "new_order_service",
        corelationId: DateTime.now().microsecondsSinceEpoch,
        intReqObj: CancelIntReqObj(
          venueCode: venueCode,
          transId: transId,
          orderType: 3,
          securityCode: securityCode,
          venueScripCode: venueScripCode,
          channel: 18,
          productType: producTypeId,
          priceCondition: priceCondition,
          proClient: "CLI",
          tifCd: ignoreOfflineGtd ? 3 : null,
          orderId: orderID,
          goodtilldate: null,
          misc1: "0",
          ignoreOfflineGtd: ignoreOfflineGtd,
          legNo: "0",
          dtoheader: CancelDtoheader(
            loginId: UserController().userId,
            creationTime: DateTime.now().microsecondsSinceEpoch,
            messageType: 12,
          ),
        ),
      ),
    );
    if (_cancelResponse.errorCode == 0) {
      return true;
    } else {
      return false;
    }
  } catch (e) {
    ScaffoldMessenger.of(context)
        .showSnackBar(showErrorDialogue(errorMessage: e.toString()));
    log(e.toString(), time: DateTime.now());
    return false;
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

class OrderbookSearch extends StatefulWidget {
  final void Function() onBackPressed;
  final void Function(String) onSearch;
  final void Function(List<Map<String, dynamic>>)? onSearchResult;
  final String hintText;
  TextEditingController controller;

  OrderbookSearch(
      {Key? key,
      required this.onBackPressed,
      required this.onSearch,
      this.hintText = " Search Eg: Nifty, Infy",
      required this.controller,
      this.onSearchResult})
      : super(key: key);

  @override
  State<OrderbookSearch> createState() => _OrderbookSearchState();
}

class _OrderbookSearchState extends State<OrderbookSearch> {
  bool _clearbtn = false;
  _enableClose() {
    setState(() {
      _clearbtn = true;
    });
  }

  _disableClose() {
    setState(() {
      _clearbtn = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    double mheight = MediaQuery.of(context).size.height * 1.222;

    return Container(
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
          border: Border(
              bottom: BorderSide(
                  width: 1.0, color: customColors().backgroundTertiary))),
      child: Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            IconButton(
              onPressed: () {
                widget.onBackPressed();
                widget.controller.clear();
              },
              icon: Icon(
                Icons.arrow_back,
                color: customColors().fontPrimary,
              ),
            ),
            Expanded(
              child: SizedBox(
                width: double.maxFinite,
                child: TextFormField(
                  autofocus: true,
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(
                        RegExp(r'^[A-Za-z 0-9]+')),
                  ],
                  controller: widget.controller,
                  decoration: InputDecoration(
                    hintText: widget.hintText,
                    hintStyle: customTextStyle(
                        fontStyle: FontStyle.BodyL_Regular,
                        color: FontColor.FontTertiary),
                    filled: true,
                    fillColor: customColors().backgroundPrimary,
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                  ),
                  autocorrect: true,
                  showCursor: true,
                  onChanged: (v) {
                    widget.onSearch(v);
                    if (v.isNotEmpty) {
                      _enableClose();
                    } else {
                      _disableClose();
                    }
                  },
                  cursorColor: customColors().fontPrimary,
                  onTap: () => {
                    if (widget.controller.text.isNotEmpty) {_enableClose()}
                  },
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyL_Regular,
                      color: FontColor.FontPrimary),
                ),
              ),
            ),
            Visibility(
              visible: _clearbtn,
              child: IconButton(
                icon: ImageIcon(const AssetImage("assets/close.png"),
                    color: customColors().fontPrimary),
                onPressed: () {
                  widget.controller.clear();
                  widget.onSearch(widget.controller.text);
                  _disableClose();
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

Future<dynamic> showAlertDilogueOrderBook(
    {required BuildContext context,
    required Widget content,
    required Widget title,
    String? positiveButtonName,
    String? negativeButtonName,
    VoidCallback? onPositiveButtonClick,
    VoidCallback? onNegativeButtonClick}) async {
  return showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: customColors().backgroundPrimary,
          title: title,
          content: content,
          actions: [
            TextButton(
              child: Text(
                positiveButtonName ?? "OK",
                style: customTextStyle(
                    fontStyle: FontStyle.BodyM_SemiBold,
                    color: FontColor.Danger),
              ),
              onPressed: onPositiveButtonClick,
            ),
            TextButton(
              child: Text(
                negativeButtonName ?? "Cancel",
                style: customTextStyle(
                    fontStyle: FontStyle.BodyM_SemiBold, color: FontColor.Info),
              ),
              onPressed: onNegativeButtonClick,
            ),
          ],
        );
      });
}

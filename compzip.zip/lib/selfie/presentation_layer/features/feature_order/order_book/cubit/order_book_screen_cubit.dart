import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/bloc_navigation/navigation_cubit.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/order_status_item_response.dart';
part 'order_book_screen_state.dart';

class OrderBookScreenCubit extends Cubit<OrderBookScreenState> {
  OrderStatusItemResponse? _response;
  final TradingApiGateway gateway;
  BuildContext context;
  List<OrderStatusResult3> openOrdersResponse = [];
  List<OrderStatusResult3> closedOrdersResponse = [];

  List<String> openOrderStatus = [
    "PEND",
    "SE",
    "CONF",
    "PEXE",
    "OPEN",
    "INCOMPLTE",
    "SAVED",
    "QUEUED",
    "SEND",
  ];

  List<String> closedOrderStatus = [
    "EXE",
    "PEXE",
    "PEXECAN",
    "CAN",
    "REJ",
    "CLBV",
    "PECLBV",
    "SOTR",
    "COMPLTE",
    "OMS_REJECT",
    "ORDER_REPLY_TIME_OUT",
    "DELETED",
    "TRIGGERED",
    "CLBOMS",
    "INPROC"
  ];

  OrderBookScreenCubit({required this.gateway, required this.context})
      : super(OrderBookScreenInitial()) {
    BlocProvider.of<NavigationCubit>(context)
        .adcontroller
        .stream
        .listen((event) {
      if (event == 2 && UserController().allowOrderbookRequest) {
        orders();
      }
    });
    MDS_Controller().orderStatusStream.listen((event) {
      String orderStatus = event.getOrderStatus;
      switch (orderStatus) {
        case 'CANCELLED':
        case 'CONFIRMED':
        case 'EXECUTED':
          {
            if (isClosed) break;
            UserController().allowOrderbookRequest = true;
            orders();
            break;
          }
      }
    });
  }

  Future<bool> orders() async {
    try {
      if (!isClosed) {
        emit(OrderBookLoadingState());
      }
      _response =
          await gateway.orderStatusRequest(userCode: UserController().userId);
      UserController().orderBookData = _response;
      if (_response!.errorCode == "0") {
        UserController().allowOrderbookRequest = false;
        UserController().resetClosedOrders.clear();
        UserController().resetOpenOrders.clear();
        UserController().openOrders.clear();
        UserController().closedOrders.clear();
        openOrdersResponse.clear();
        closedOrdersResponse.clear();
        if (_response!.result2[0].errorcode == "0") {
          if (UserController().orderBookData!.result3.isEmpty) {
            emit(OrderBookScreenInitial());
            return false;
          }
          for (int i = 0;
              i < UserController().orderBookData!.result3.length;
              i++) {
            if (openOrderStatus.contains(UserController()
                .orderBookData!
                .result3[i]
                .status
                .toString()
                .toUpperCase())) {
              openOrdersResponse
                  .add(UserController().orderBookData!.result3[i]);
              UserController()
                  .resetOpenOrders
                  .add(UserController().orderBookData!.result3[i]);
            }
            if (closedOrderStatus.contains(UserController()
                .orderBookData!
                .result3[i]
                .status
                .toString()
                .toUpperCase())) {
              closedOrdersResponse
                  .add(UserController().orderBookData!.result3[i]);
              UserController()
                  .resetClosedOrders
                  .add(UserController().orderBookData!.result3[i]);
            }
          }
          UserController().openOrders = openOrdersResponse;
          UserController().closedOrders = closedOrdersResponse;
          emit(
            OrderBookScreenInitial(),
          );
          return true;
        } else {
          emit(
            OrderBookScreenInitial(
                errorMsg: _response!.result2[0].errormessage),
          );
          return false;
        }
      } else {
        emit(
          OrderBookScreenInitial(errorMsg: _response!.errorMessage),
        );
        return false;
      }
    } catch (e) {
      emit(
        OrderBookScreenInitial(errorMsg: e.toString()),
      );
      return false;
    }
  }

  updateCubit() {
    emit(OrderBookScreenInitial());
  }
}

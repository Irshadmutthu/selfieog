part of 'order_book_screen_cubit.dart';

@immutable
abstract class OrderBookScreenState {}

class OrderBookScreenInitial extends OrderBookScreenState {
  String errorMsg;
  OrderBookScreenInitial({
    this.errorMsg = "",
  });
}

class OrderBookLoadingState extends OrderBookScreenState {}

class OrderBookErrorState extends OrderBookScreenState {
  String errorMsg;
  OrderBookErrorState({
    this.errorMsg = "",
  });
}

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_book/cubit/order_book_screen_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/basket/basket_component.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/closed/closed_component.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/gtd/gtd_component.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/open/open_component.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/tab_controller_order_book/smartfolio/smartfolio_component.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarMain.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_top_tab.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/watchlist/market_overview.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/text/order.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';

class OrderBookScreen extends StatefulWidget {
  const OrderBookScreen({Key? key}) : super(key: key);

  @override
  State<OrderBookScreen> createState() => _OrderBookScreenState();
}

class _OrderBookScreenState extends State<OrderBookScreen>
    with TickerProviderStateMixin {
  bool _showAppbar = true;
  late TradingApiGateway _gateway;

  void initState() {
    super.initState();
    _gateway = context.gTradingApiGateway;
    _controller = BottomSheet.createAnimationController(this);
    _controller!.duration = const Duration(milliseconds: 400);
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  AnimationController? _controller;
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) =>
          OrderBookScreenCubit(gateway: _gateway, context: context),
      child: BlocBuilder<OrderBookScreenCubit, OrderBookScreenState>(
          builder: (context, state) {
        return Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            AnimatedContainer(
              margin: const EdgeInsets.only(top: 8.0),
              height: !_showAppbar ? 0 : 58,
              curve: Curves.easeInOut,
              duration: const Duration(milliseconds: 400),
              child: CustomAppBarMain(
                title: orderBookTitle,
                endIcon: InkWell(
                  onTap: () {
                    customBottomSheet(
                        controller: _controller,
                        height: .9,
                        minimumHeight: .7,
                        context: context,
                        inputWidget: MarKetOverview());
                  },
                  child: const Padding(
                    padding: EdgeInsets.only(right: 16),
                    child: ImageIcon(
                      AssetImage("assets/frame.png"),
                      size: 24,
                    ),
                  ),
                ),
                onTapTitle: () {},
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: CustomTabBar(
                  initialSelected: 0,
                  isScrollable: true,
                  tabContent: [
                    UserController().openOrders.length > 0
                        ? "Open (${UserController().openOrders.length})"
                        : "Open",
                    UserController().closedOrders.length > 0
                        ? "Closed (${UserController().closedOrders.length})"
                        : "Closed",
                    UserController().orderGtdResponse.length > 0
                        ? "GTD (${UserController().orderGtdResponse.length})"
                        : "GTD",
                    "Baskets",
                    "Smartfolio"
                  ],
                  tabBarViewChildern: [
                    OrderBookOpenComponent(onScrollEvent: (bool showAppBar) {
                      // setState(() {
                      //   _showAppbar = showAppBar;
                      // });
                    }),
                    OrderBookClosedComponent(onScrollEvent: (bool showAppBar) {
                      // setState(() {
                      //   _showAppbar = showAppBar;
                      // });
                    }),
                    OrderBookGTDComponent(onScrollEvent: (bool showAppBar) {
                      // setState(() {
                      //   _showAppbar = showAppBar;
                      // });
                    }),
                    OrderBookBasketComponent(onScrollEvent: (bool showAppBar) {
                      // setState(() {
                      //   _showAppbar = showAppBar;
                      // });
                    }),
                    OrderBookSmartfolioComponent(
                        onScrollEvent: (bool showAppBar) {
                      // setState(() {
                      //   _showAppbar = showAppBar;
                      // });
                    }),
                  ]),
            ),
          ],
        );
      }),
    );
  }
}

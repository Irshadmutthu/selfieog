import 'dart:ffi';

import 'package:intl/intl.dart';

orderbookDateFormat(String date) {
  // date in = '2022-06-28 10:07:36 ';
  // date ou = '28 Jun 2022 10:07';
  DateTime parseDate = DateFormat("yyyy-MM-dd HH:mm:ss").parse(date);
  date = DateFormat('dd MMM yyyy hh:mm a')
      .format(DateTime.parse(parseDate.toString()));
  return date;
}

gtdDateFormat(String date) {
  // date in = '2022-06-16 18:27:12.097';
  // date ou = '28 Jun 2022 10:07';
  DateTime parseDate = DateFormat("yyyy-MM-dd HH:mm:ss").parse(date);
  date = DateFormat('dd/MM/yyyy').format(DateTime.parse(parseDate.toString()));
  return date;
}

int passwordExpiryDays(String dateStr) {
  try {
    String expire_date = dateStr.split(" ").elementAt(2) +
        "/" +
        dateStr.split(" ").elementAt(1) +
        "/" +
        dateStr.split(" ").elementAt(5);

    DateTime parseDate = DateFormat("dd/MMM/yyyy").parse(expire_date);
    return parseDate.difference(DateTime.now()).inDays;
  } catch (e) {
    return 500;
  }
}

orderTypesConverstion(String orderType) {
  switch (orderType) {
    case "1":
      {
        return "NEW_ORDER";
      }

    case "2":
      {
        return "MODIFY_ORDER";
      }
    case "3":
      {
        return "CANCEL_ORDER";
      }
    case "4":
      {
        return "MODIFY_ORDER";
      }
    case "5":
      {
        return "CANCELLED";
      }
    case "6":
      {
        return "NEW_ORDER_SE";
      }
    case "7":
      {
        return "MODIFY_ORDER_SE";
      }
    case "8":
      {
        return "CANCEL_ORDER_SE";
      }
    case "9":
      {
        return "NEW_ORDER_CONFIRM";
      }
    case "10":
      {
        return "MODIFY_ORDER_CONFIRM";
      }
    case "11":
      {
        return "CANCEL_ORDER_CONFIRM";
      }
    case "12":
      {
        return "CANCELLED_BY_VENUE";
      }
    case "13":
      {
        return "ORDER_EXECUTION";
      }
    case "14":
      {
        return "ORPHAN_EXECUTION";
      }

    case "15":
      {
        return "NEW_ORDER_REJECT";
      }
    case "16":
      {
        return "MODIFY_ORDER_REJECT";
      }

    case "17":
      {
        return "CANCEL_ORDER_REJECT";
      }
    case "18":
      {
        return "STOP_LOSS_TRIGGER";
      }

    case "19":
      {
        return "ORDER_STATUS";
      }

    case "20":
      {
        return "USER_LOGIN";
      }

    case "21":
      {
        return "OTO_NEW_ORDER";
      }

    case "22":
      {
        return "OTO_MODIFY_ORDER";
      }

    case "23":
      {
        return "OTO_CANCEL_ORDER";
      }

    case "24":
      {
        return "SUSPEND_ORDER_CONFIRM";
      }

    case "25":
      {
        return "ORDER_SYNC_RESPONSE";
      }

    case "26":
      {
        return "OFFLINE_NEW_ORDER";
      }
    case "27":
      {
        return "OFFLINE_MODIFY_ORDER";
      }
    case "28":
      {
        return "OFFLINE_NEW_ORDER";
      }
    case "29":
      {
        return "CONVERT_MKT_TO_LMT";
      }
    case "30":
      {
        return "MODIFY_CONFIRM_BY_VENUE";
      }
    case "31":
      {
        return "CODE_CORRECTED";
      }
    case "32":
      {
        return "CONDITIONAL_CANCEL_ORDER";
      }
    case "33":
      {
        return "MULTI_LEG_ORDER";
      }
    case "34":
      {
        return "SMART_PLUS_ORDER";
      }
    case "35":
      {
        return "SPREAD_NEW_ORDER";
      }
    case "36":
      {
        return "SPREAD_MODIFY_ORDER";
      }
    case "37":
      {
        return "SPREAD_CANCEL_ORDER";
      }
    case "41":
      {
        return "SMART_PLUS_MODIFY_ORDER";
      }
    case "42":
      {
        return "SMART_PLUS_CANCEL_ORDER";
      }
    case "43":
      {
        return "TRAILED";
      }
    case "44":
      {
        return "ALGO_CANCEL_ORDER";
      }
  }
  return orderType;
}

orderLogConversion(String val) {
  switch (val) {
    case "1":
      {
        return "Placed";
      }

    case "2":
      {
        return "Modify";
      }
    case "3":
      {
        return "Cancelled";
      }
    case "4":
      {
        return "Modify";
      }
    case "5":
      {
        return "Cancelled";
      }
    case "6":
      {
        return "Placed";
      }
    case "7":
      {
        return "Modify";
      }
    case "8":
      {
        return "Cancelled";
      }
    case "9":
      {
        return "Confirmed";
      }
    case "10":
      {
        return "Modify Confirmed";
      }
    case "11":
      {
        return "Cancel Confirmed";
      }
    case "12":
      {
        return "Venue Cancelled";
      }
    case "13":
      {
        return "Executed";
      }
    case "14":
      {
        return "Orphan Executed";
      }

    case "15":
      {
        return "Rejected";
      }
    case "16":
      {
        return "Modify Rejected";
      }

    case "17":
      {
        return "Cancel Rejected";
      }
    case "18":
      {
        return "Stop Loss Triggered";
      }

    case "19":
      {
        return "Order Status";
      }

    case "20":
      {
        return "User Login";
      }

    case "21":
      {
        return "OTO Placed";
      }

    case "22":
      {
        return "OTO Modify";
      }

    case "23":
      {
        return "OTO Cancelled";
      }

    case "24":
      {
        return "Suspend Confirmed";
      }

    case "25":
      {
        return "Order Sync";
      }

    case "26":
      {
        return "Offline Order";
      }
    case "27":
      {
        return "Offline Modify";
      }
    case "28":
      {
        return "Offline Order";
      }
    case "29":
      {
        return "Convert MKT to LMT";
      }
    case "30":
      {
        return "Venue Modify";
      }
    case "31":
      {
        return "Code Corrected";
      }
    case "32":
      {
        return "Conditional Cancelled";
      }
    case "33":
      {
        return "Multi Leg Order";
      }
    case "34":
      {
        return "Smart Plus Order";
      }
    case "35":
      {
        return "Placed";
      }
    case "36":
      {
        return "Modify";
      }
    case "37":
      {
        return "Cancelled";
      }
    case "41":
      {
        return "Modify";
      }
    case "42":
      {
        return "Cancelled";
      }
    case "43":
      {
        return "Trailed";
      }
    case "44":
      {
        return "Cancelled";
      }
  }
}

priceConditionConverstion(String priceType) {
  switch (priceType) {
    case "1":
      {
        return "MKT";
      }

    case "2":
      {
        return "LMT";
      }
    case "3":
      {
        return "STL";
      }
    case "4":
      {
        return "MIT";
      }
    case "5":
      {
        return "BLO";
      }
    case "6":
      {
        return "STLM";
      }
  }
}

priceCondition(String priceCondition, int index) {
  switch (priceCondition) {
    case "MKT":
      {
        return "Mkt";
      }
    case "LMT":
      {
        return "Lmt";
      }
    case "STL":
      {
        return "SL-Lmt";
      }
    case "STLM":
      {
        return "SL-Mkt";
      }
    case "MIT":
      {
        return "Mit";
      }
    default:
      return priceCondition;
  }
}

priceConditionConversion(String priceCondition) {
  switch (priceCondition) {
    case "1":
      {
        return "Market";
      }

    case "2":
      {
        return "Limit";
      }
    case "3":
      {
        return "Stop Loss Limit";
      }
    case "4":
      {
        return "MIT";
      }
    case "5":
      {
        return "BLO";
      }
    case "6":
      {
        return "Stop Loss Market";
      }
    default:
      return "";
  }
}

orderTypeConversion(String priceCondition, int index) {
  switch (priceCondition) {
    case "MKT":
      {
        return "";
      }
    case "LMT":
      {
        return "Lmt";
      }
    case "STL":
      {
        return "SL-Lmt";
      }
    case "STLM":
      {
        return "SL-Mkt";
      }
    case "MIT":
      {
        return "Mit";
      }
    default:
      return priceCondition;
  }
}

orderStatusConverstion(String priceType) {
  switch (priceType) {
    case "1":
      {
        return "MKT";
      }

    case "2":
      {
        return "LMT";
      }
    case "3":
      {
        return "STL";
      }
    case "4":
      {
        return "MIT";
      }
    case "5":
      {
        return "BLO";
      }
    case "6":
      {
        return "STLM";
      }
  }
}

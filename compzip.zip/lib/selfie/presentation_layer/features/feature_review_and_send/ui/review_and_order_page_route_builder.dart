import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/order_model/Order.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_review_and_send/ui/cubit/review_order_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_review_and_send/ui/remarks/ui/remark_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_review_and_send/ui/reviewandorderpage.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class ReviewAndOrderPageRouteBuilder {
  final ServiceLocator _serviceLocator;
  final OrderModel order;

  ReviewAndOrderPageRouteBuilder(this._serviceLocator, this.order);

  Widget call(BuildContext context) {
    return MultiBlocProvider(
        providers: [
        
          BlocProvider(
              create: (context) =>
                  ReviewOrderCubit(apiGateway: _serviceLocator.tradingApi))
        ],
        child: MultiRepositoryProvider(
            providers: [
              RepositoryProvider.value(
                  value: _serviceLocator.navigationService),
              RepositoryProvider<CubitsLocator>.value(value: _serviceLocator),
            ],
            child: ReviewAndOrderPage(
              order: order,
            )));
  }
}

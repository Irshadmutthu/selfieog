// import 'dart:developer';
// import 'dart:ffi';

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/order_model/Order.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_review_and_send/ui/cubit/review_order_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/watchlist/custom_watchlist_content/custom_watchlist_content.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/requests/oco_order_request.dart';
import 'package:trading_api/requests/offline_gtd_request.dart';
import 'package:trading_api/utils/utils.dart';
import 'package:trading_api/requests/order_request.dart';
import 'package:trading_api/responses/order_response.dart';
import '../../../../../mds_controller.dart/mds_controller.dart';
import '../../../../widgets/custom_app_components/appbar/customAppbarInner.dart';
import '../../../../widgets/default_order_settings/default_order_settings_values.dart';
import '../../../../widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';

class ReviewAndOrderPage extends StatefulWidget {
  OrderModel order;
  ReviewAndOrderPage({Key? key, required this.order
      // required this.ismarket,
      // required this.isbo,
      // required this.issl,
      // required this.isslm,
      // required this.timecondition,
      // required this.isoco,
      // required this.isco,
      // required this.isspliorder
      })
      : super(key: key);

  @override
  State<ReviewAndOrderPage> createState() => _ReviewAndOrderPageState();
  // bool ismarket;
  // bool isbo;
  // bool issl;
  // bool isslm;
  // String timecondition;
  // bool isoco;
  // bool isspliorder;
  // bool isco;
}

class _ReviewAndOrderPageState extends State<ReviewAndOrderPage> {
  double translateX = 0.0;
  int screenCount = 1;
  double translateY = 0.0;
  double myWidth = 0;
  Color bgColor = customColors().backgroundSecondary;
  bool rdb1 = false, rdb2 = false;
  Map<String, String> list = {
    "Quantity": "100",
    "Order Type": "Market",
    "Product Type": "Cash",
    "Time Condition": "Day",
  };
  bool ismarket = true;
  bool isbo = true;
  bool issl = false;
  bool isslm = false;
  String timecondition = "Day";
  String orderType = "Market";
  String trigerPrice = "271.12";
  String symbol = "HDFCBANK"; //120.12
  bool isoco = false;
  bool isspliorder = false;
  bool isco = false;
  bool showremark = false;
  String quntity = "100";
  bool isoffline = false;
  bool isOrderPlacingAllowed = false;
  bool isCreditChargingAllowed = false;
  bool isSplitOrderAllowed = false;
  double total = 0;
  bool loading = false;
  StreamSubscription? streamSubscription;

  onOrderPlaceClick(bool val) {
    setState(() {
      isOrderPlacingAllowed = val;
    });
  }

  onCreditChargeClick(bool val) {
    setState(() {
      isCreditChargingAllowed = val;
    });
  }

  onSpliOrderClick(bool val) {
    setState(() {
      isSplitOrderAllowed = val;
    });
  }

  @override
  void initState() {
    ismarket = widget.order.priceCondition == "Market";
    isbo = false;
    issl = widget.order.priceCondition == "Stop Loss Limit";

    isslm = widget.order.priceCondition == "Stop Loss Market";

    timecondition = widget.order.timeCondition;
    if (timecondition == "GTD") {
      timecondition = timecondition + "-" + widget.order.tifDate;
    }
    orderType = widget.order.priceCondition;
    trigerPrice = widget.order.triggerPrice;
    symbol = widget.order.instrument.displayName!.isNotEmpty
        ? widget.order.instrument.displayName!
        : widget.order.instrument.securityCode; //120.12
    isoco = widget.order.isOCOOrder;
    isspliorder = false;
    isco = false;
    showremark = false;
    quntity = widget.order.lots > 0
        ? widget.order.lots.toString() + " Lots"
        : widget.order.qty.toString();
    isOrderPlacingAllowed = false;
    isCreditChargingAllowed = false;
    isSplitOrderAllowed = false;
    initializeSubscriptionListner();
  }

  @override
  void dispose() {
    if (streamSubscription != null) {
      streamSubscription!.cancel();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    bgColor = customColors().backgroundSecondary;
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: SafeArea(
        child: Column(children: [
          loading
              ? LinearProgressIndicator(
                  minHeight: 6.0,

                  color: customColors().primary.withOpacity(0.8),

                  backgroundColor: customColors().primary.withOpacity(0.2),

                  // value: controller.value,
                )
              : const SizedBox(
                  height: 6,
                ),
          CustomAppBarInner(
              title: "Order Confirmation",
              endIcon: EndIcon.Empty,
              onBackPressed: () {
                context.gNavigationService.back(context);
              }),
          Expanded(
            child: SingleChildScrollView(
              child: Stack(
                children: [
                  Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: EdgeInsets.symmetric(vertical: 8),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border(
                                  bottom: BorderSide(
                                      color: customColors().backgroundTertiary),
                                )),
                                child: Padding(
                                  padding: const EdgeInsets.only(bottom: 16.0),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        child: Column(
                                          children: [
                                            Row(
                                              children: [
                                                SymbolNameWidget(
                                                  symbol,
                                                ),
                                              ],
                                            ),
                                            const SizedBox(
                                              height: 4,
                                            ),
                                            Row(
                                              children: [
                                                getProductTypeWidget(widget
                                                    .order
                                                    .instrument
                                                    .venuecode),
                                                const SizedBox(
                                                  width: 6,
                                                ),
                                                getProductTypeWidget(
                                                    widget.order.buyOrSell == 1
                                                        ? "BUY"
                                                        : "SELL"),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.end,
                                        children: [
                                          Row(
                                            children: [
                                              Text(
                                                widget.order.instrument
                                                    .lastTrdPrice
                                                    .toStringAsFixed(widget
                                                        .order
                                                        .instrument
                                                        .precision),
                                                style: customTextStyle(
                                                    fontStyle: FontStyle
                                                        .BodyL_SemiBold,
                                                    color:
                                                        FontColor.FontPrimary),
                                              ),
                                              const SizedBox(
                                                width: 4,
                                              ),
                                              SizedBox(
                                                width: 16,
                                                height: 16,
                                                child: widget
                                                        .order.instrument.change
                                                        .toString()
                                                        .contains("-")
                                                    ? Image.asset(
                                                        "assets/pricedecrease.png")
                                                    : Image.asset(
                                                        "assets/priceincrease.png"),
                                              )
                                            ],
                                          ),
                                          const SizedBox(
                                            height: 4,
                                          ),
                                          Text(
                                            widget.order.instrument.changePrice
                                                    .toStringAsFixed(widget
                                                        .order
                                                        .instrument
                                                        .precision) +
                                                "(" +
                                                widget.order.instrument.change
                                                    .toStringAsFixed(widget
                                                        .order
                                                        .instrument
                                                        .precision) +
                                                "%)",
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyM_SemiBold,
                                                color: widget
                                                        .order.instrument.change
                                                        .toString()
                                                        .contains("-")
                                                    ? FontColor.Danger
                                                    : FontColor.Success),
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Visibility(
                                visible: isoco,
                                child: Text(
                                  widget.order.buyOrSell == SELL
                                      ? "OCO Sell Order"
                                      : "OCO Buy Order",
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_Bold,
                                      color: FontColor.FontPrimary),
                                )),
                            Container(
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              child: Column(
                                children: [
                                  Container(
                                    color: getbgcolor(true),
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            "Quantity",
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyM_Regular,
                                                color: FontColor.FontSecondary),
                                          ),
                                          Text(
                                            quntity,
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyM_SemiBold,
                                                color: FontColor.FontPrimary),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                  Visibility(
                                    visible: !isoco,
                                    child: Column(
                                      children: [
                                        Container(
                                          color: getbgcolor(true),
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Text(
                                                  "Order Type",
                                                  style: customTextStyle(
                                                      fontStyle: FontStyle
                                                          .BodyM_Regular,
                                                      color: FontColor
                                                          .FontSecondary),
                                                ),
                                                Text(
                                                  orderType,
                                                  style: customTextStyle(
                                                      fontStyle: FontStyle
                                                          .BodyM_SemiBold,
                                                      color: FontColor
                                                          .FontPrimary),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                        Visibility(
                                          visible: ismarket ? false : !isslm,
                                          child: Container(
                                            color: getbgcolor(!ismarket),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Text(
                                                    "Limit Price",
                                                    style: customTextStyle(
                                                        fontStyle: FontStyle
                                                            .BodyM_Regular,
                                                        color: FontColor
                                                            .FontSecondary),
                                                  ),
                                                  Text(
                                                    widget.order.price,
                                                    style: customTextStyle(
                                                        fontStyle: FontStyle
                                                            .BodyM_SemiBold,
                                                        color: FontColor
                                                            .FontPrimary),
                                                  )
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          color: getbgcolor(true),
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Text(
                                                  "Product Type",
                                                  style: customTextStyle(
                                                      fontStyle: FontStyle
                                                          .BodyM_Regular,
                                                      color: FontColor
                                                          .FontSecondary),
                                                ),
                                                Text(
                                                  productSettingslist[widget
                                                      .order
                                                      .productType]["name"],
                                                  style: customTextStyle(
                                                      fontStyle: FontStyle
                                                          .BodyM_SemiBold,
                                                      color: FontColor
                                                          .FontPrimary),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                        Container(
                                          color: getbgcolor(true),
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Text(
                                                  "Time Condition",
                                                  style: customTextStyle(
                                                      fontStyle: FontStyle
                                                          .BodyM_Regular,
                                                      color: FontColor
                                                          .FontSecondary),
                                                ),
                                                Text(
                                                  timecondition,
                                                  style: customTextStyle(
                                                      fontStyle: FontStyle
                                                          .BodyM_SemiBold,
                                                      color: FontColor
                                                          .FontPrimary),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                        Visibility(
                                          visible: issl || isslm,
                                          child: Container(
                                            color: getbgcolor(true),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Text(
                                                    "Triggered Price",
                                                    style: customTextStyle(
                                                        fontStyle: FontStyle
                                                            .BodyM_Regular,
                                                        color: FontColor
                                                            .FontSecondary),
                                                  ),
                                                  Text(
                                                    trigerPrice,
                                                    style: customTextStyle(
                                                        fontStyle: FontStyle
                                                            .BodyM_SemiBold,
                                                        color: FontColor
                                                            .FontPrimary),
                                                  )
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                        // totalWidget()
                                      ],
                                    ),
                                  ),

                                  // ListView.builder(
                                  //     physics:
                                  //         const NeverScrollableScrollPhysics(),
                                  //     itemCount: 4,
                                  //     shrinkWrap: true,
                                  //     itemBuilder: (context, index) {
                                  //       return reviewTile(
                                  //           "name", "value", index);
                                  //     }),
                                ],
                              ),
                            ),
                            Visibility(
                              visible: isbo,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding:
                                        const EdgeInsets.symmetric(vertical: 8),
                                    child: Row(
                                      children: [
                                        Text(
                                          "Bracket Order ",
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.HeaderXS_Bold,
                                              color: FontColor.FontPrimary),
                                        ),
                                        Text(
                                          "(Sell)",
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyL_SemiBold,
                                              color: FontColor.Danger),
                                        ),
                                      ],
                                    ),
                                  ),
                                  smartorderwidget(),
                                ],
                              ),
                            ),
                            splitOrderwidget(isspliorder),
                            Visibility(
                                visible: isco,
                                child: Column(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.0, horizontal: 0),
                                      child: Divider(
                                        thickness: 1.0,
                                        color:
                                            customColors().backgroundTertiary,
                                      ),
                                    ),
                                    Container(
                                      color: customColors().backgroundPrimary,
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              "Condition is",
                                              style: customTextStyle(
                                                  fontStyle:
                                                      FontStyle.BodyM_Regular,
                                                  color:
                                                      FontColor.FontSecondary),
                                            ),
                                            Text(
                                              "Greater Than",
                                              style: customTextStyle(
                                                  fontStyle:
                                                      FontStyle.BodyM_SemiBold,
                                                  color: FontColor.FontPrimary),
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                    Container(
                                      color: customColors().backgroundSecondary,
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              "Trigger Price",
                                              style: customTextStyle(
                                                  fontStyle:
                                                      FontStyle.BodyM_Regular,
                                                  color:
                                                      FontColor.FontSecondary),
                                            ),
                                            Text(
                                              "213.12",
                                              style: customTextStyle(
                                                  fontStyle:
                                                      FontStyle.BodyM_SemiBold,
                                                  color: FontColor.FontPrimary),
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                    // totalWidget()
                                  ],
                                )),
                            // ignore: dead_code
                            isoco ? smartorderwidget() : totalWidget()
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8.0),
                        child: Divider(
                          thickness: 1.0,
                          color: customColors().backgroundTertiary,
                        ),
                      ),
                      Visibility(
                        visible: false,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 0.0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 8, horizontal: 16.0),
                                child: InkWell(
                                  onTap: () {
                                    context.gNavigationService.OpenRemarkPage(
                                        context); //OpenConfirmPage
                                  },
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Flip Plug",
                                        style: customTextStyle(
                                            fontStyle: FontStyle.HeaderXS_Bold,
                                            color: FontColor.FontPrimary),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Visibility(
                                visible: (!ismarket && !issl) || isspliorder,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 16.0),
                                      child: Text("Confirm",
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyL_SemiBold,
                                              color: FontColor.FontPrimary)),
                                    ),
                                    Visibility(
                                      visible: !isspliorder,
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(
                                            vertical: 11.0, horizontal: 16),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Row(
                                              children: [
                                                EmptyCustomCheckBox(
                                                    callback:
                                                        onOrderPlaceClick),
                                                const SizedBox(
                                                  width: 10,
                                                ),
                                                Text(
                                                    "Allow exchange to place order on your behalf",
                                                    style: customTextStyle(
                                                        fontStyle: FontStyle
                                                            .BodyM_Regular,
                                                        color: FontColor
                                                            .FontPrimary)),
                                              ],
                                            ),
                                            const SizedBox(
                                              height: 16,
                                            ),
                                            Row(
                                              children: [
                                                EmptyCustomCheckBox(
                                                    callback:
                                                        onCreditChargeClick),
                                                const SizedBox(
                                                  width: 10,
                                                ),
                                                Expanded(
                                                  child: Text(
                                                    "Allow exchange to credit your account with charges",
                                                    style: customTextStyle(
                                                        fontStyle: FontStyle
                                                            .BodyM_Regular,
                                                        color: FontColor
                                                            .FontPrimary),
                                                  ),
                                                ),
                                              ],
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                    Visibility(
                                      visible: isspliorder,
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(
                                            vertical: 11.0, horizontal: 16),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Row(
                                              children: [
                                                EmptyCustomCheckBox(
                                                    callback: onSpliOrderClick),
                                                const SizedBox(
                                                  width: 10,
                                                ),
                                                Column(
                                                  children: [
                                                    Text("Split Order",
                                                        style: customTextStyle(
                                                            fontStyle: FontStyle
                                                                .BodyM_Regular,
                                                            color: FontColor
                                                                .FontPrimary)),
                                                  ],
                                                ),
                                              ],
                                            ),
                                            Container(
                                              padding:
                                                  EdgeInsets.only(left: 34),
                                              child: Column(
                                                children: [
                                                  Text(
                                                      "The quantity of the order exceeds the limit set by the exchange. As a result, your order will be split into 4 individual order.",
                                                      style: customTextStyle(
                                                          fontStyle: FontStyle
                                                              .BodyM_Regular,
                                                          color: FontColor
                                                              .FontSecondary)),
                                                  const SizedBox(
                                                    height: 24,
                                                  ),
                                                  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Text("Note: ",
                                                          style: customTextStyle(
                                                              fontStyle: FontStyle
                                                                  .BodyM_SemiBold,
                                                              color: FontColor
                                                                  .FontSecondary)),
                                                      Expanded(
                                                        child: Text(
                                                            "Brokerage will be charged on each Split Order.",
                                                            style: customTextStyle(
                                                                fontStyle: FontStyle
                                                                    .BodyM_Regular,
                                                                color: FontColor
                                                                    .FontSecondary)),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 8,
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.0, horizontal: 16.0),
                                      child: Text("Others",
                                          style: customTextStyle(
                                              fontStyle:
                                                  FontStyle.BodyL_SemiBold,
                                              color: FontColor.FontPrimary)),
                                    ),
                                  ],
                                ),
                              ),
                              Visibility(
                                visible: isspliorder || showremark,
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16.0),
                                  child: Container(
                                    padding: const EdgeInsets.all(16.0),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: customColors()
                                                .warning
                                                .withOpacity(.20)),
                                        borderRadius: BorderRadius.circular(4),
                                        color: customColors()
                                            .warning
                                            .withOpacity(.10)),
                                    child: Text(
                                        "TATAPOWER (BSE) is a trade to trade category stock. You will be able to sell the stocks bought today only after the stocks are settled in your demat account (T+2 days).",
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyM_Regular,
                                            color: FontColor.FontPrimary)),
                                  ),
                                ),
                              ),
                              Visibility(
                                visible: false,
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16.0),
                                  child: Container(
                                    padding: const EdgeInsets.only(left: 7.86),
                                    decoration: BoxDecoration(
                                        border: Border(
                                      left: BorderSide(
                                          color: customColors().accent,
                                          width: 3.93),
                                    )),
                                    child: Text(
                                        "TATAPOWER (BSE) is a trade to trade category stock. You will be able to sell the stocks bought today only after the stocks are settled in your demat account (T+2 days).",
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyM_Regular,
                                            color: FontColor.FontPrimary)),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 41,
                      ),
                    ],
                  ),
                  // Align(
                  //   alignment: Alignment.bottomCenter,
                  //   child: skipButton(context, "$screenCount/8", () {
                  //     if (screenCount > 1) {
                  //       setState(() {
                  //         screenCount--;
                  //         setStateSwitch(screenCount);
                  //       });
                  //     }
                  //   }, () {
                  //     if (screenCount < 8) {
                  //       setState(() {
                  //         screenCount++;
                  //         setStateSwitch(screenCount);
                  //       });
                  //     }
                  //   }),
                  // ),
                ],
              ),
            ),
          ),
          Container(
            decoration: BoxDecoration(
                border: Border(
                    top: BorderSide(color: customColors().backgroundTertiary))),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: BasketButton(
              enabled: isOrderPlacingAllowed && isCreditChargingAllowed
                  ? isSplitOrderAllowed
                  : loading
                      ? false
                      : true,
              onpress: () async {
                if (loading) return;
                setState(() {
                  loading = true;
                });
                OrderResponse response;
                if (!widget.order.tifDate.isNotEmpty &&
                    widget.order.isModify &&
                    isoffline) {
                  response = await BlocProvider.of<ReviewOrderCubit>(context)
                      .sendGTDOfflineorderRequest(
                          orderRquest: GtdModifyOffline(
                              proc: "modify_offline_order_gtd",
                              corelationId:
                                  DateTime.now().microsecondsSinceEpoch,
                              intReqObj: IntGTDReqObj(
                                  dtoheader: OGtdDtoheader(
                                      creationTime:
                                          DateTime.now().microsecondsSinceEpoch,
                                      loginId: UserController().userId,
                                      messageType: 11),
                                  disclosedQty: widget.order.discloseQty,
                                  price: widget.order.price,
                                  priceCondition: getPriceCondition(
                                          widget.order.priceCondition)
                                      .toString(),
                                  quantity: widget.order.qty,
                                  tifcd: widget.order.tifcd,
                                  tifdate:
                                      doDateConversion(widget.order.tifDate),
                                  tradingMode: "OFFLINE",
                                  transId: widget.order.TransId,
                                  triggerPrice: widget
                                          .order.triggerPrice.isNotEmpty
                                      ? double.parse(widget.order.triggerPrice)
                                      : 0,
                                  userCode: UserController().userId)));
                } else {
                  if (!widget.order.isOCOOrder) {
                    response = await BlocProvider.of<ReviewOrderCubit>(context)
                        .sendNeworderRequest(
                            orderRquest: OrderRquest(
                                proc: "new_order_service",
                                intReqObj: SendOrderIntReqObj(
                                  buySell: widget.order.buyOrSell.toString(),
                                  channel: 18,
                                  discloseQty: widget.order.discloseQty,
                                  expirationDate: doDateConversion(
                                      widget.order.instrument.contractDate),
                                  gid: 0,
                                  goodtilldate:
                                      changeDateFormat(widget.order.tifDate),
                                  instrumentType: widget.order.instrument.type,
                                  ioc: '0',
                                  lots: widget.order.lots,
                                  ltPrice: widget.order.price,
                                  moh: ' ',
                                  orderType: widget.order.isModify
                                      ? 2
                                      : 1, //widget.order.OrderType
                                  price: widget.order.price,
                                  priceCondition: getPriceCondition(
                                          widget.order.priceCondition)
                                      .toString(),
                                  proClient: 'CLI',
                                  productType: getProductTypeId(PRODUCT_TYPES[
                                          widget.order.instrument.venueIndex]![
                                      widget.order.productType]["name"]),
                                  qty: widget.order.instrument.venueIndex ==
                                              7 ||
                                          widget.order.instrument.venueIndex ==
                                              6
                                      ? widget.order.lots.toString()
                                      : widget.order.qty.toString(),
                                  qtyChange: widget.order.qtyChange,
                                  securityCode:
                                      widget.order.instrument.securityCode,
                                  segment: widget.order.segment,
                                  series: widget.order.instrument.series,
                                  strikePrice: 0,
                                  tifCd: widget.order.timeCondition,
                                  transId: widget.order.TransId ?? " ",
                                  triggerPrice: widget.order.triggerPrice,
                                  venueCode: widget.order.instrument.venuecode,
                                  venueScripCode:
                                      widget.order.instrument.scripcode,
                                  dtoheader: OrderDtoheader(
                                      loginId: UserController().userId,
                                      creationTime:
                                          DateTime.now().microsecondsSinceEpoch,
                                      messageType:
                                          widget.order.isModify ? 11 : 10),
                                ),
                                corelationId:
                                    DateTime.now().microsecondsSinceEpoch));
                  } else {
                    response = await BlocProvider.of<ReviewOrderCubit>(context)
                        .sendOCOorderRequest(
                            orderRquest: OcoOrderRequest(
                      corelationId: DateTime.now().microsecondsSinceEpoch,
                      intReqObj: SendOcoIntReqObj(
                          venueScripCode: widget.order.instrument.scripcode,
                          body: null,
                          channel: 18,
                          currencyCode: "",
                          discloseQty: "",
                          dtoheader: DtoOCOheader(
                              creationTime:
                                  DateTime.now().microsecondsSinceEpoch,
                              loginId: UserController().userId,
                              messageType: widget.order.isModify ? 11 : 91),
                          enteringUserCode: UserController().userId,
                          goodTillDate: "",
                          indexOrSymbol: 2,
                          ioc: "",
                          mktPhaseCd: "",
                          noLegs: 2,
                          noOfLegs: 0,
                          priceCondition: widget.order.isModify
                              ? getPriceCondition(widget.order.priceCondition)
                                  .toString()
                              : null,
                          price:
                              widget.order.isModify ? widget.order.price : null,
                          orderLegs: [
                            OrderLeg(
                                smartPlusOrderLeg: SmartPlusOrderLeg(
                                    style: "",
                                    venueCode:
                                        widget.order.instrument.venuecode,
                                    venueScripCode:
                                        widget.order.instrument.scripcode,
                                    securityCode:
                                        widget.order.instrument.securityCode,
                                    series: widget.order.instrument.series,
                                    instrumentType:
                                        widget.order.instrument.type,
                                    strikePrice: 0,
                                    productType: 1,
                                    orderingUserCode: UserController().userId,
                                    segment: 1,
                                    priceCondition: getPriceCondition(
                                            widget.order.priceCondition)
                                        .toString(),
                                    expirationDate: "",
                                    price: widget.order.targetPrice.toString(),
                                    triggerPrice: "",
                                    tifCd: "DAY",
                                    qty: widget.order.qty.toString(),
                                    buySell: widget.order.buyOrSell.toString(),
                                    legNo: 1,
                                    orderStatus: 0,
                                    priceType: 1,
                                    condition: "GE",
                                    goodTillDate: "",
                                    totalLegNo: 0,
                                    noOfLegs: 0,
                                    eventType: "",
                                    orderType: widget.order.isModify ? 41 : 34,
                                    orderSubType: 39,
                                    targetPrice:
                                        widget.order.targetPrice.toString(),
                                    stoplossPrice:
                                        widget.order.stoplossPrice.toString())),
                            OrderLeg(
                                smartPlusOrderLeg: SmartPlusOrderLeg(
                                    style: "",
                                    venueCode:
                                        widget.order.instrument.venuecode,
                                    venueScripCode:
                                        widget.order.instrument.scripcode,
                                    securityCode:
                                        widget.order.instrument.securityCode,
                                    series: widget.order.instrument.series,
                                    instrumentType:
                                        widget.order.instrument.type,
                                    strikePrice: 0,
                                    productType: 1,
                                    orderingUserCode: UserController().userId,
                                    segment: 1,
                                    priceCondition: "1",
                                    expirationDate: "",
                                    price:
                                        widget.order.stoplossPrice.toString(),
                                    triggerPrice: "",
                                    tifCd: "DAY",
                                    qty: widget.order.qty.toString(),
                                    buySell: widget.order.buyOrSell.toString(),
                                    legNo: 2,
                                    orderStatus: 0,
                                    priceType: 1,
                                    condition: "LE",
                                    goodTillDate: "",
                                    totalLegNo: 0,
                                    noOfLegs: 0,
                                    eventType: "",
                                    orderType: widget.order.isModify ? 41 : 34,
                                    orderSubType: 39,
                                    targetPrice:
                                        widget.order.targetPrice.toString(),
                                    stoplossPrice:
                                        widget.order.stoplossPrice.toString()))
                          ],
                          orderSubType: 39,
                          orderType: widget.order.isModify ? 41 : 34,
                          orderingUserCode: UserController().userId,
                          proClient: "CLI",
                          productType: 1,
                          series: widget.order.instrument.series,
                          terminalId: 0,
                          tifCd: widget.order.timeCondition,
                          transId: widget.order.TransId,
                          venueCode: widget.order.instrument.venuecode),
                      proc: "new_order_service",
                    ));
                  }
                }
                setState(() {
                  loading = false;
                });

                context.gNavigationService
                    .OpenConfirmPage(context, {"OrderResponse": response});
              },
              textStyle: customTextStyle(
                  fontStyle: FontStyle.BodyL_SemiBold, color: FontColor.White),
              text: "Place Order",
              bgcolor: widget.order.buyOrSell == 1
                  ? customColors().success
                  : customColors().danger,
            ),
          )
        ]),
      ),
    );
  }

  // getfontcolor(String status) {
  //   switch (status) {
  //     case "NSE":
  //       return FontColor.Crisps;
  //     case "SELL":
  //       return FontColor.Danger;
  //     case "BUY":
  //       return FontColor.Success;
  //     case "NFO":
  //       return FontColor.Purple;
  //     default:
  //   }
  // }

  // getbackcolor(String status) {
  //   switch (status) {
  //     case "NSE":
  //       return customColors().crisps.withOpacity(0.15);
  //     case "SELL":
  //       return customColors().danger.withOpacity(0.15);
  //     case "BUY":
  //       return customColors().success.withOpacity(0.15);
  //     case "NFO":
  //       return customColors().mattPurple.withOpacity(0.15);
  //     default:
  //   }
  // }
  void initializeSubscriptionListner() {
    streamSubscription = MDS_Controller()
        .marketUpdateStream
        .listen((List<FlairResponseModel> flairResponseModel) {
      for (var element in flairResponseModel) {
        if (widget.order.instrument.getRicAddress() == element.ric) {
          setState(() {
            widget.order.instrument.lastTrdPrice =
                element.instrument.lastTrdPrice;
            widget.order.instrument.percChange = element.instrument.percChange;
            widget.order.instrument.changePrice =
                element.instrument.changePrice;
          });
        }
      }
    });
  }

  Widget reviewTile(String name, String value, int index) {
    return Container(
      color: index % 2 != 0
          ? customColors().backgroundSecondary
          : customColors().backgroundPrimary,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              name,
              style: customTextStyle(
                  fontStyle: FontStyle.BodyM_Regular,
                  color: FontColor.FontSecondary),
            ),
            Text(
              value,
              style: customTextStyle(
                  fontStyle: FontStyle.BodyM_SemiBold,
                  color: FontColor.FontPrimary),
            )
          ],
        ),
      ),
    );
  }

  getbgcolor(bool visibility) {
    if (visibility) {
      if (bgColor == customColors().backgroundPrimary) {
        bgColor = customColors().backgroundSecondary;
      } else {
        bgColor = customColors().backgroundPrimary;
      }
    }
    return bgColor;
  }

  smartorderwidget() {
    return Column(
      children: [
        Container(
          color: customColors().backgroundSecondary,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Target Price",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_Regular,
                      color: FontColor.FontSecondary),
                ),
                Text(
                  widget.order.targetPrice
                      .toStringAsFixed(widget.order.instrument.precision),
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontPrimary),
                )
              ],
            ),
          ),
        ),
        Container(
          color: customColors().backgroundPrimary,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Stoploss Price",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_Regular,
                      color: FontColor.FontSecondary),
                ),
                Text(
                  widget.order.stoplossPrice
                      .toStringAsFixed(widget.order.instrument.precision),
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontPrimary),
                )
              ],
            ),
          ),
        ),
      ],
    );
  }

  totalWidget() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 0),
          child: Divider(
            thickness: 1.0,
            color: customColors().backgroundTertiary,
          ),
        ),
        Container(
          color: customColors().backgroundPrimary,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Total Cost",
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_Regular,
                      color: FontColor.FontSecondary),
                ),
                Text(
                  (widget.order.qty * double.parse(widget.order.price))
                      .toStringAsFixed(2),
                  style: customTextStyle(
                      fontStyle: FontStyle.BodyM_SemiBold,
                      color: FontColor.FontPrimary),
                )
              ],
            ),
          ),
        ),
      ],
    );
  }

  splitOrderwidget(bool issplit) {
    return Visibility(
      visible: issplit,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 0),
            child: Divider(
              thickness: 1.0,
              color: customColors().backgroundTertiary,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Text(
              "Split Order ",
              style: customTextStyle(
                  fontStyle: FontStyle.HeaderXS_Bold,
                  color: FontColor.FontPrimary),
            ),
          ),
          Container(
            color: customColors().backgroundPrimary,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Order 1",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontSecondary),
                  ),
                  Text(
                    "90 Lots",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontPrimary),
                  )
                ],
              ),
            ),
          ),
          Container(
            color: customColors().backgroundSecondary,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Order 2",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontSecondary),
                  ),
                  Text(
                    "10 Lots",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontPrimary),
                  )
                ],
              ),
            ),
          ),
          Container(
            color: customColors().backgroundPrimary,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Order 3",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontSecondary),
                  ),
                  Text(
                    "90 Lots",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontPrimary),
                  )
                ],
              ),
            ),
          ),
          Container(
            color: customColors().backgroundSecondary,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Order 4",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_Regular,
                        color: FontColor.FontSecondary),
                  ),
                  Text(
                    "10 Lots",
                    style: customTextStyle(
                        fontStyle: FontStyle.BodyM_SemiBold,
                        color: FontColor.FontPrimary),
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void setStateSwitch(int screenCount) {
    switch (screenCount) {
      case 1:
        quntity = "100";
        ismarket = true;
        isbo = true;
        issl = false;
        isslm = false;
        timecondition = "Day";
        orderType = "Market";
        trigerPrice = "271.12"; //120.12
        symbol = "HDFCBANK";
        isoco = false;
        isspliorder = false;
        isco = false;
        showremark = false;
        break;
      case 2:
        quntity = "100";
        ismarket = true;
        isbo = true;
        issl = false;
        isslm = false;
        timecondition = "Day";
        orderType = "Market";
        trigerPrice = "271.12"; //120.12
        symbol = "HDFCBANK";
        isoco = false;
        isspliorder = false;
        isco = false;
        showremark = true;
        break;
      case 3:
        quntity = "100";
        ismarket = false;
        isbo = false;
        issl = false;
        isslm = false;
        timecondition = "GTD - 22/09/22";
        orderType = "Limit";
        trigerPrice = "271.12"; //120.12
        symbol = "HDFCBANK";
        isoco = false;
        isspliorder = false;
        isco = false;
        showremark = true;
        break;
      case 4:
        quntity = "100";
        ismarket = false;
        isbo = false;
        issl = true;
        isslm = false;
        timecondition = "GTD - 22/09/22";
        orderType = "Limit";
        trigerPrice = "271.12"; //120.12
        symbol = "HDFCBANK";
        isoco = false;
        isspliorder = false;
        isco = false;
        showremark = true;
        break;
      case 5:
        quntity = "100";
        ismarket = true;
        isbo = false;
        issl = false;
        isslm = true;
        timecondition = "GTD - 22/09/22";
        orderType = "Market";
        isoco = false;
        trigerPrice = "120.12"; //120.12
        symbol = "HDFCBANK";
        isspliorder = false;
        isco = false;
        showremark = true;
        break;
      case 6:
        quntity = "100";
        ismarket = true;
        isbo = false;
        issl = false;
        isslm = false;
        timecondition = "Day";
        orderType = "Market";
        trigerPrice = "271.12"; //120.12
        symbol = "ITC Long 100";
        isoco = true;
        isspliorder = false;
        isco = false;
        showremark = true;
        break;
      case 7:
        quntity = "100";
        ismarket = true;
        isbo = false;
        issl = false;
        isslm = false;
        timecondition = "Conditional  - Day";
        orderType = "Market";
        trigerPrice = "271.12"; //120.12
        symbol = "AMBUJACEM";
        isoco = false;
        isspliorder = false;
        isco = true;
        showremark = true;
        break;
      case 8:
        quntity = "100 Lots";
        ismarket = true;
        isbo = false;
        issl = false;
        isslm = false;
        timecondition = "Day";
        orderType = "Market";
        trigerPrice = "271.12"; //120.12
        symbol = "BANKNIFT MAR FUT";
        isoco = false;
        isspliorder = true;
        isco = false;
        showremark = true;
        break;
      default:
    }
  }
}

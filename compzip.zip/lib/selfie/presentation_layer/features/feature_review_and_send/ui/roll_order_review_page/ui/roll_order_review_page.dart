import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/order_book/custom_bottom_strip.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';

import '../../../../../../../theme/styles.dart';
import '../../../../../../widgets/custom_app_components/appbar/customAppbarInner.dart';
import '../../../../../../widgets/order_book/custom_bottom_strip.dart';
import '../../../../../../widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';

class RollOrderReviewPage extends StatefulWidget {
  const RollOrderReviewPage({Key? key}) : super(key: key);

  @override
  State<RollOrderReviewPage> createState() => _RollOrderReviewPageState();
}

class _RollOrderReviewPageState extends State<RollOrderReviewPage> {
  bool isOrderPlacingAllowed = false;
  bool isCreditChargingAllowed = false;
  onOrderPlaceClick(bool val) {
    setState(() {
      isOrderPlacingAllowed = val;
    });
  }

  onCreditChargeClick(bool val) {
    setState(() {
      isCreditChargingAllowed = val;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: PreferredSize(
            preferredSize: const Size.fromHeight(0.0),
            child: AppBar(
              elevation: 0,
              backgroundColor: customColors().backgroundPrimary,
            )),
        body: SafeArea(
          child: Column(children: [
            CustomAppBarInner(
                title: "Order Confirmation",
                endIcon: EndIcon.Empty,
                onBackPressed: () {
                  context.gNavigationService.back(context);
                }),
            Expanded(
                child: Container(
                    child: SingleChildScrollView(
                        child: Column(children: [
              Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: Container(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Expanded(
                                  flex: 3,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          getProductTypeWidget("SELL"),
                                          const SizedBox(
                                            width: 6,
                                          ),
                                          getProductTypeWidget("CASH"),
                                        ],
                                      ),
                                      const SizedBox(
                                        height: 8,
                                      ),
                                      Text(
                                        'BANKNIFTY MAR FUT',
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyL_SemiBold,
                                            color: FontColor.FontPrimary),
                                      ),
                                    ],
                                  ),
                                ),
                                Expanded(
                                  flex: 2,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          Text(
                                            "LIMIT",
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyM_Regular,
                                                color: FontColor.FontSecondary),
                                          ),
                                          const SizedBox(
                                            height: 8,
                                          ),
                                          Text(
                                            "0.1575",
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyM_SemiBold,
                                                color: FontColor.FontPrimary),
                                          ),
                                        ],
                                      ),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          Text(
                                            "LOTS",
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.TagNameS_SemiBold,
                                                color: FontColor.FontSecondary),
                                          ),
                                          const SizedBox(
                                            height: 8,
                                          ),
                                          Text(
                                            "1",
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyM_SemiBold,
                                                color: FontColor.FontPrimary),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: Container(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Expanded(
                                  flex: 3,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          getProductTypeWidget("SELL"),
                                          const SizedBox(
                                            width: 6,
                                          ),
                                          getProductTypeWidget("CASH"),
                                        ],
                                      ),
                                      const SizedBox(
                                        height: 8,
                                      ),
                                      Text(
                                        'BANKNIFTY MAR FUT',
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyL_SemiBold,
                                            color: FontColor.FontPrimary),
                                      ),
                                    ],
                                  ),
                                ),
                                Expanded(
                                  flex: 2,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          Text(
                                            "LIMIT",
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyM_Regular,
                                                color: FontColor.FontSecondary),
                                          ),
                                          const SizedBox(
                                            height: 8,
                                          ),
                                          Text(
                                            "-",
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyM_SemiBold,
                                                color: FontColor.FontPrimary),
                                          ),
                                        ],
                                      ),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          Text(
                                            "LOTS",
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.TagNameS_SemiBold,
                                                color: FontColor.FontSecondary),
                                          ),
                                          const SizedBox(
                                            height: 8,
                                          ),
                                          Text(
                                            "1",
                                            style: customTextStyle(
                                                fontStyle:
                                                    FontStyle.BodyM_SemiBold,
                                                color: FontColor.FontPrimary),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ])),
              const SizedBox(
                height: 16,
              ),
              Divider(
                thickness: 1.0,
                color: customColors().backgroundTertiary,
              ),
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 16, horizontal: 16.0),
                      child: InkWell(
                        onTap: () {
                          context.gNavigationService
                              .OpenRemarkPage(context); //OpenConfirmPage
                        },
                        child: Text(
                          "Flip Plug",
                          style: customTextStyle(
                              fontStyle: FontStyle.HeaderXS_Bold,
                              color: FontColor.FontPrimary),
                        ),
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16.0),
                          child: Text("Confirm",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary)),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 11.0, horizontal: 16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  EmptyCustomCheckBox(
                                      callback: onOrderPlaceClick),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                      "Allow exchange to place order on your behalf",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_Regular,
                                          color: FontColor.FontPrimary)),
                                ],
                              ),
                              const SizedBox(
                                height: 16,
                              ),
                              Row(
                                children: [
                                  EmptyCustomCheckBox(
                                      callback: onCreditChargeClick),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                      "Allow exchange to credit your account with charges",
                                      style: customTextStyle(
                                          fontStyle: FontStyle.BodyM_Regular,
                                          color: FontColor.FontPrimary)),
                                ],
                              )
                            ],
                          ),
                        ),
                        const SizedBox(
                          height: 8,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 8.0, horizontal: 16.0),
                          child: Text("Others",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary)),
                        ),
                      ],
                    ),
                    Visibility(
                      visible: true,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Container(
                          padding: EdgeInsets.only(left: 7.86),
                          decoration: BoxDecoration(
                              border: Border(
                            left: BorderSide(
                                color: customColors().accent.withOpacity(.5),
                                width: 3.93),
                          )),
                          child: Text(
                              "TATAPOWER (BSE) is a trade to trade category stock. You will be able to sell the stocks bought today only after the stocks are settled in your demat account (T+2 days).",
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyM_Regular,
                                  color: FontColor.FontPrimary)),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ])))),
            const CustomBottomStrip(
              fundOrMargin: FundOrMargin.MARGIN,
              required: "15,000",
              available: "21,000",
              refreshIcon: true,
            ),
            Container(
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                child: BasketButton(
                  enabled: isOrderPlacingAllowed && isCreditChargingAllowed,
                  textStyle: customTextStyle(
                      fontStyle: FontStyle.BodyL_SemiBold,
                      color: FontColor.White),
                  text: "Place Roll Order",
                  bgcolor: customColors().success,
                  onpress: () {
                    // context.gNavigationService.OpenConfirmPage(context);
                  },
                ))
          ]),
        ));
  }
}

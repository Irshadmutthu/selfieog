import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:trading_api/requests/oco_order_request.dart';
import 'package:trading_api/requests/order_request.dart';
import 'package:trading_api/responses/order_response.dart';

import '../../../../../../services/api_gateway.dart';

part 'review_order_state.dart';

class ReviewOrderCubit extends Cubit<ReviewOrderState> {
  TradingApiGateway apiGateway;
  late OrderResponse _response;
  ReviewOrderCubit({required this.apiGateway}) : super(ReviewOrderInitial());
  Future<OrderResponse> sendNeworderRequest(
      {required OrderRquest orderRquest}) async {
    _response = await apiGateway.newOrderRequest(orderRquest: orderRquest);
    return _response;
  }

  Future<OrderResponse> sendOCOorderRequest(
      {required OcoOrderRequest orderRquest}) async {
    _response = await apiGateway.ocoOrderRequest(orderRequest: orderRquest);
    return _response;
  }

  Future<OrderResponse> sendGTDOfflineorderRequest(
      {required orderRquest}) async {
    _response =
        await apiGateway.gtdOfflineModifyRequest(orderRquest: orderRquest);
    return _response;
  }
}

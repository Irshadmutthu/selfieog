part of 'review_order_cubit.dart';

@immutable
abstract class ReviewOrderState {}

class ReviewOrderInitial extends ReviewOrderState {}

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_settings/ui/order_settings.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

class OrderSettingsRouteBuilder {
  final ServiceLocator _serviceLocator;

  OrderSettingsRouteBuilder(this._serviceLocator);

  Widget call(BuildContext context) {
    return MultiRepositoryProvider(providers: [
      RepositoryProvider.value(value: _serviceLocator.tradingApi)
    ], child: OrderSettingsPage());
  }
}

import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/constants/prefefence_utils.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/settingsAppbar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/default_order_settings_values.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_settings/order_settings_components/options_container.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_settings/order_settings_components/stocks_container.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';

import '../order_settings_components/future_container.dart';

class OrderSettingsPage extends StatefulWidget {
  const OrderSettingsPage({Key? key}) : super(key: key);

  @override
  State<OrderSettingsPage> createState() => _OrderSettingsPageState();
}

class _OrderSettingsPageState extends State<OrderSettingsPage>
    with SingleTickerProviderStateMixin {
  int initialIndex = 0;
  String tabName = "Stocks";
  int index = 0;
  late TabController _controller;

  List<Widget> settingswidgets = [];

  List<Tab> tablist = [
    const Tab(
      text: "Stocks",
    ),
    const Tab(
      text: "Futures",
    ),
    const Tab(
      text: "Options",
    )
  ];
  @override
  void initState() {
    super.initState();
    initialIndex = 0;
    tabName = "Stocks";
    _controller = TabController(length: tablist.length, vsync: this);

    _controller.addListener(() {
      setState(() {
        initialIndex = _controller.index;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    List<Map<String, dynamic>> optionorderlist = List.from(ordersdropdownlist);

    settingswidgets = [
      StocksContainer(
        changeAction: (changedOrderSettings) {},
      ),
      FutureContainer(
        changeAction: (changedOrderSettings) {},
      ),
      OptionsContainer(
        changeAction: (changedOrderSettings) {},
      ),
    ];
    Size screenSize = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: customColors().backgroundPrimary,
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SettingsAppbar(
                  title: "Default Order Setting",
                  onBackPressed: () {
                    Navigator.pop(context);
                  },
                  buttonname: "Reset",
                  onResetPressed: () {
                    resetSettings(initialIndex);
                  },
                ),
                Container(
                  width: screenSize.width,
                  decoration: BoxDecoration(
                    border: Border(
                        bottom: BorderSide(
                            width: 1.0,
                            color: customColors().backgroundTertiary)),
                  ),
                  child: TabBar(
                    onTap: (value) {
                      initialIndex = value;
                    },
                    controller: _controller,
                    tabs: tablist,
                    isScrollable: true,
                    labelStyle: customTextStyle(
                        fontStyle: FontStyle.BodyL_SemiBold,
                        color: FontColor.Primary),
                    labelColor: customColors().primary,
                    indicatorSize: TabBarIndicatorSize.label,
                    indicatorColor: customColors().primary,
                    unselectedLabelStyle: customTextStyle(
                        fontStyle: FontStyle.BodyL_Regular,
                        color: FontColor.FontSecondary),
                    unselectedLabelColor: customColors().fontSecondary,
                  ),
                ),
                Expanded(
                  child: TabBarView(
                    children: settingswidgets,
                    controller: _controller,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: screenSize.width,
            decoration: BoxDecoration(
                color: customColors().backgroundPrimary,
                border: Border(
                    top: BorderSide(
                        width: 1.0, color: customColors().backgroundTertiary))),
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 16.0, right: 16.0, bottom: 25.0, top: 5.0),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Expanded(
                        flex: 2,
                        child: BasketButton(
                          textStyle: customTextStyle(
                              fontStyle: FontStyle.BodyL_SemiBold,
                              color: FontColor.Primary),
                          text: "Cancel",
                          bgcolor: customColors().backgroundPrimary,
                          bordercolor: customColors().primary,
                          onpress: () {
                            Navigator.of(context).pop();
                          },
                        )),
                    Expanded(
                        flex: 2,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 8.0),
                          child: BasketButton(
                            textStyle: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.White),
                            text: "Save",
                            bgcolor: customColors().primary,
                            bordercolor: customColors().primary,
                            onpress: () async {
                              switch (initialIndex) {
                                case 0:
                                  {
                                    bool validationStatus = StocksContainer
                                        .stocksContainerglobalKey.currentState!
                                        .saveStockData();
                                    if (validationStatus == true) {
                                      await PreferenceUtils.storeDataToShared(
                                          UserController.userController.userId,
                                          UserSettings.userSettings
                                              .toJsonString());
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(showSuccessDialogue(
                                              errorMessage:
                                                  "Stocks saved successfully."));
                                    }
                                  }
                                  break;
                                case 1:
                                  {
                                    bool validationStatus = FutureContainer
                                        .futureContainerglobalKey.currentState!
                                        .saveFutureData();
                                    if (validationStatus == true) {
                                      await PreferenceUtils.storeDataToShared(
                                          UserController.userController.userId,
                                          UserSettings.userSettings
                                              .toJsonString());
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(showSuccessDialogue(
                                              errorMessage:
                                                  "Future saved successfully."));
                                    }
                                  }
                                  break;
                                case 2:
                                  {
                                    bool validationStatus = OptionsContainer
                                        .optionsContainerglobalKey.currentState!
                                        .saveOptionData();
                                    if (validationStatus == true) {
                                      await PreferenceUtils.storeDataToShared(
                                          UserController.userController.userId,
                                          UserSettings.userSettings
                                              .toJsonString());
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(showSuccessDialogue(
                                              errorMessage:
                                                  "Options saved successfully."));
                                    }
                                  }
                                  break;
                              }
                            },
                          ),
                        ))
                  ]),
            ),
          ),
        ],
      ),
    );
  }

  resetSettings(int index) async {
    switch (index) {
      case 0:
        {
          StocksContainer.stocksContainerglobalKey.currentState!
              .resetStocksData();
        }
        break;
      case 1:
        {
          FutureContainer.futureContainerglobalKey.currentState!
              .resetFutureData();
        }
        break;
      case 2:
        {
          OptionsContainer.optionsContainerglobalKey.currentState!
              .resetOptionsData();
        }
        break;
    }
    await PreferenceUtils.storeDataToShared(
        UserController.userController.userId,
        UserSettings.userSettings.toJsonString());
    setState(() {});
  }
}

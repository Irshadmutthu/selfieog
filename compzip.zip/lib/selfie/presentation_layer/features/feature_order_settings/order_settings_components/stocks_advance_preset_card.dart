import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_the_tooltip/just_the_tooltip.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/utils/order_settings.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';

class StocksPresetCard extends StatefulWidget {
  static final GlobalKey<_StocksPresetCardState> stockPresetglobalKey =
      GlobalKey();
  OrderSettings resetOrderSettings;
  StocksPresetCard({Key? key, required this.resetOrderSettings})
      : super(key: stockPresetglobalKey);

  @override
  State<StocksPresetCard> createState() => _StocksPresetCardState();
}

class _StocksPresetCardState extends State<StocksPresetCard> {
  OrderSettings newOrder = OrderSettings();
  String? userData;
  TextEditingController ovcontroller = TextEditingController();
  TextEditingController mvcontroller = TextEditingController();
  TextEditingController botcontroller = TextEditingController();
  TextEditingController boscontroller = TextEditingController();
  TextEditingController limitOrderPercentagecontroller =
      TextEditingController();
  bool isSwitched = false;
  List tooltipControllerList = [];
  JustTheController? controller = JustTheController();
  JustTheController? controller2 = JustTheController();
  late GlobalKey<FormState> ovFormKey = GlobalKey<FormState>();
  late GlobalKey<FormState> mvFormKey = GlobalKey<FormState>();
  final _boTakeProfitformKey = GlobalKey<FormState>();
  final _boStoplossformKey = GlobalKey<FormState>();
  final _limitorderformKey = GlobalKey<FormState>();
  @override
  void initState() {
    loadStockPresetData();

    super.initState();
  }

  Widget build(BuildContext context) {
    mvcontroller.selection = TextSelection.fromPosition(
        TextPosition(offset: mvcontroller.text.length));
    buildExpanded1() {
      return MediaQuery.removePadding(
        context: context,
        removeTop: true,
        child: SingleChildScrollView(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: <
                  Widget>[
            Padding(
              padding: const EdgeInsets.only(left: 16.0, right: 16.0),
              child: Divider(
                color: customColors().backgroundTertiary,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                left: 16.0,
                right: 16.0,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                    height: 97,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Form(
                          key: ovFormKey,
                          child: Expanded(
                              flex: 2,
                              child: CustomTextFormField(
                                textAlign: TextAlign.end,
                                controller: ovcontroller,
                                keyboardType: TextInputType.number,
                                validator: Validator.minimumValueLimit,
                                minimumValueLimit: 1,
                                inputFormatter: [
                                  FilteringTextInputFormatter.digitsOnly
                                ],
                                fieldName: "Order Value (Apox)",
                                onChange: (value) async {
                                  if (!(ovFormKey.currentState!.validate())) {
                                    newOrder.stocksOrderValue = 1;
                                  } else
                                    newOrder.stocksOrderValue =
                                        int.tryParse(value)!;
                                },
                              )),
                        ),
                        Form(
                          key: mvFormKey,
                          child: Expanded(
                              flex: 2,
                              child: Padding(
                                padding: const EdgeInsets.only(left: 16.0),
                                child: CustomTextFormField(
                                  textAlign: TextAlign.end,
                                  controller: mvcontroller,
                                  keyboardType: TextInputType.number,
                                  fieldName: "Max Order Value",
                                  validator: Validator.minimumValueLimit,
                                  minimumValueLimit: 1,
                                  inputFormatter: [
                                    FilteringTextInputFormatter.digitsOnly
                                  ],
                                  onChange: (value) async {
                                    if (!(mvFormKey.currentState!.validate()))
                                      newOrder.stocksMaxOrderValue = 1;
                                    else
                                      newOrder.stocksMaxOrderValue =
                                          int.tryParse(value)!;
                                  },
                                ),
                              )),
                        )
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Form(
                          key: _boTakeProfitformKey,
                          child: Expanded(
                              flex: 2,
                              child: CustomTextFormField(
                                validator: Validator.minimumDecimalValueLimit,
                                minimumDecimalValueLimit: .01,
                                textAlign: TextAlign.end,
                                keyboardType:
                                    const TextInputType.numberWithOptions(
                                        decimal: true),
                                controller: botcontroller,
                                fieldName: "BO - Take Profit %",
                                inputFormatter: [
                                  FilteringTextInputFormatter.allow(
                                      RegExp(r'(^\d*\.?\d{0,2})'))
                                ],
                                onChange: (value) async {
                                  if (!(_boTakeProfitformKey.currentState!
                                      .validate())) {}
                                  if (value.isEmpty) {
                                    newOrder.stocksBoTakeProfit = 0;
                                  } else if (double.tryParse(value) == null) {
                                  } else {
                                    newOrder.stocksBoTakeProfit =
                                        double.tryParse(value)!;
                                  }
                                },
                              )),
                        ),
                        // SizedBox(
                        //   width: 16,
                        // ),
                        Form(
                          key: _boStoplossformKey,
                          child: Expanded(
                            flex: 2,
                            child: Padding(
                              padding: const EdgeInsets.only(left: 16.0),
                              child: CustomTextFormField(
                                validator: Validator.minimumDecimalValueLimit,
                                minimumDecimalValueLimit: .01,
                                textAlign: TextAlign.end,
                                controller: boscontroller,
                                keyboardType: TextInputType.numberWithOptions(
                                    decimal: true),
                                fieldName: "BO - Stop Loss %",
                                inputFormatter: [
                                  FilteringTextInputFormatter.allow(
                                      RegExp(r'(^\d*\.?\d{0,2})'))
                                ],
                                onChange: (value) async {
                                  if (!(_boStoplossformKey.currentState!
                                      .validate())) {}

                                  if (value.isEmpty) {
                                    newOrder.stocksBoStopLoss = 0;
                                  } else if (double.tryParse(value) == null) {
                                  } else {
                                    newOrder.stocksBoStopLoss =
                                        double.tryParse(value)!;
                                  }
                                },
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  for (int index = 0;
                      index < tooltipControllerList.length;
                      index++)
                    Padding(
                      padding: const EdgeInsets.only(top: 20.0, right: 0.0),
                      child: Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Text(
                                  tooltipControllerList[index]['name'],
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_Regular,
                                      color: FontColor.FontPrimary),
                                ),
                                JustTheTooltip(
                                  offset: 2.0,
                                  backgroundColor:
                                      customColors().backgroundSecondary,
                                  preferredDirection: AxisDirection.up,
                                  controller: tooltipControllerList[index]
                                      ["controller"],
                                  margin:
                                      EdgeInsets.only(left: 32.0, right: 32.0),
                                  child: Material(
                                      child: Container(
                                    height: 22.0,
                                    width: 22.0,
                                    child: Center(
                                        child: InkWell(
                                      onTap: () {
                                        tooltipControllerList[index]
                                                ["controller"]
                                            ?.showTooltip();
                                      },
                                      child: Icon(
                                        Icons.info_outline_rounded,
                                        size: 14.0,
                                      ),
                                    )),
                                  )),
                                  content: Container(
                                    child: Padding(
                                        padding: const EdgeInsets.only(
                                            top: 16.0,
                                            left: 10.0,
                                            right: 8.0,
                                            bottom: 10.0),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Text(
                                              tooltipControllerList[index]
                                                  ['name'],
                                              style: customTextStyle(
                                                  fontStyle:
                                                      FontStyle.BodyM_SemiBold,
                                                  color: FontColor.FontPrimary),
                                            ),
                                            Padding(
                                                padding: EdgeInsets.only(
                                                    top: 16.0, right: 10.0),
                                                child: Container(
                                                  child: Text(
                                                    tooltipControllerList[index]
                                                        ['content'],
                                                    style: customTextStyle(
                                                        fontStyle: FontStyle
                                                            .BodyS_Regular,
                                                        color: FontColor
                                                            .FontPrimary),
                                                    textAlign:
                                                        TextAlign.justify,
                                                  ),
                                                )),
                                          ],
                                        )),
                                  ),
                                )
                              ],
                            ),
                            EmptyCustomCheckBox(
                              isSelect: tooltipControllerList[index]["status"],
                              callback: (checkValue) async {
                                storeStatusToLocalStorage(
                                    index: index, value: checkValue);
                              },
                            )
                          ],
                        ),
                      ),
                    ),
                  Padding(
                    padding: const EdgeInsets.only(top: 18.0),
                    child: Row(
                      children: [
                        Visibility(
                          visible:
                              newOrder.stocksDefaultPercentageLimitOrderStatus,
                          child: Form(
                            key: _limitorderformKey,
                            child: Expanded(
                              flex: 1,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Expanded(
                                    flex: 2,
                                    child: CustomTextFormField(
                                      validator:
                                          Validator.minimumDecimalValueLimit,
                                      minimumDecimalValueLimit: .01,
                                      textAlign: TextAlign.end,
                                      controller:
                                          limitOrderPercentagecontroller,
                                      keyboardType:
                                          TextInputType.numberWithOptions(
                                              decimal: true),
                                      fieldName: "",
                                      inputFormatter: [
                                        FilteringTextInputFormatter.allow(
                                            RegExp(r'(^\d*\.?\d{0,2})'))
                                      ],
                                      onChange: (value) async {
                                        if (!(_limitorderformKey.currentState!
                                            .validate())) {}

                                        if (value.isEmpty) {
                                          newOrder
                                              .stocksDefaultPercentageLimitOrder = 0;
                                        } else if (double.tryParse(value) ==
                                            null) {
                                        } else {
                                          newOrder.stocksDefaultPercentageLimitOrder =
                                              double.tryParse(value)!;
                                        }
                                      },
                                      sufixWidget: Text(
                                        '%',
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyL_SemiBold,
                                            color: FontColor.FontSecondary),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Expanded(flex: 1, child: SizedBox())
                      ],
                    ),
                  ),
                  Container(
                    height: 16.0,
                  )
                ],
              ),
            ),
          ]),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(
        top: 16.0,
      ),
      child: ExpandableNotifier(
          child: ScrollOnExpand(
        child: Container(
          decoration: BoxDecoration(
              border: Border.all(color: customColors().backgroundTertiary),
              borderRadius: BorderRadius.circular(4.0)),
          child: MediaQuery.removePadding(
            context: context,
            removeTop: true,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Builder(builder: (context) {
                  return InkWell(
                    onTap: () {
                      toggleSwitch(!isSwitched);
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(left: 16.0),
                          child: Text(
                            "Advanced Preset",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                        ),
                        Switch(
                          value: isSwitched,
                          onChanged: (value) {
                            toggleSwitch(value);
                          },
                          activeColor: customColors().primary,
                          activeTrackColor: customColors().backgroundTertiary,
                        )
                      ],
                    ),
                  );
                }),
                Visibility(
                  visible: isSwitched,
                  child: buildExpanded1(),
                ),
              ],
            ),
          ),
        ),
      )),
    );
  }

  storeStatusToLocalStorage({required int index, required bool value}) async {
    switch (index) {
      case 0:
        newOrder.stocksReviewOrderAndSendStatus = value;
        break;
      case 1:
        newOrder.stocksDefaultPercentageLimitOrderStatus = value;
        if (newOrder.stocksDefaultPercentageLimitOrderStatus == false) {
          newOrder.stocksDefaultPercentageLimitOrder = 0;
          limitOrderPercentagecontroller.text = double.tryParse("0").toString();
        }
        setState(() {});
        break;
      default:
        break;
    }
  }

  void toggleSwitch(bool value) async {
    setState(() {
      isSwitched = (isSwitched == false) ? true : false;
    });
    newOrder.stocksAdvancePreset = value;
  }

  restStockPrest() {
    isSwitched = UserSettings.userSettings.orderSettings.stocksAdvancePreset =
        widget.resetOrderSettings.stocksAdvancePreset;
    UserSettings.userSettings.orderSettings.stocksOrderValue =
        widget.resetOrderSettings.stocksOrderValue;
    UserSettings.userSettings.orderSettings.stocksMaxOrderValue =
        widget.resetOrderSettings.stocksMaxOrderValue;
    UserSettings.userSettings.orderSettings.stocksBoTakeProfit =
        widget.resetOrderSettings.stocksBoTakeProfit;
    UserSettings.userSettings.orderSettings.stocksBoStopLoss =
        widget.resetOrderSettings.stocksBoStopLoss;
    ovcontroller.text =
        UserSettings.userSettings.orderSettings.stocksOrderValue.toString();
    mvcontroller.text = Formats.valueFormat
        .format(UserSettings.userSettings.orderSettings.stocksMaxOrderValue)
        .toString();
    botcontroller.text = (double.tryParse(UserSettings
                .userSettings.orderSettings.stocksBoTakeProfit
                .toString())!
            .toStringAsFixed(2))
        .toString();
    boscontroller.text = (double.tryParse(UserSettings
                .userSettings.orderSettings.stocksBoStopLoss
                .toString())!
            .toStringAsFixed(2))
        .toString();
    tooltipControllerList[0]["status"] =
        UserSettings.userSettings.orderSettings.stocksReviewOrderAndSendStatus =
            widget.resetOrderSettings.stocksReviewOrderAndSendStatus;
    tooltipControllerList[1]["status"] = UserSettings.userSettings.orderSettings
            .stocksDefaultPercentageLimitOrderStatus =
        widget.resetOrderSettings.stocksDefaultPercentageLimitOrderStatus;
    UserSettings.userSettings.orderSettings.stocksDefaultPercentageLimitOrder =
        widget.resetOrderSettings.stocksDefaultPercentageLimitOrder;
    limitOrderPercentagecontroller.text = UserSettings
        .userSettings.orderSettings.stocksDefaultPercentageLimitOrder
        .toString();
  }

  loadStockPresetData() {
    newOrder = UserSettings.userSettings.orderSettings.copyWith();
    isSwitched = newOrder.stocksAdvancePreset;
    ovcontroller.text = newOrder.stocksOrderValue.toString();
    mvcontroller.text =
        Formats.valueFormat.format(newOrder.stocksMaxOrderValue).toString();
    botcontroller.text =
        (double.tryParse(newOrder.stocksBoTakeProfit.toString())!
                .toStringAsFixed(2))
            .toString();
    boscontroller.text = (double.tryParse(newOrder.stocksBoStopLoss.toString())!
            .toStringAsFixed(2))
        .toString();
    tooltipControllerList = [
      {
        "controller": controller,
        "status": newOrder.stocksReviewOrderAndSendStatus,
        "name": "Review order and send",
        "value": false,
        "content": "You will be able to review your order before placing it."
      },
      {
        "controller": controller2,
        "status": newOrder.stocksDefaultPercentageLimitOrderStatus,
        "name": "Default percentage for limit order",
        "value": false,
        "content":
            "Limit price will be calculated based on this value if its checked"
      }
    ];
    limitOrderPercentagecontroller.text =
        newOrder.stocksDefaultPercentageLimitOrder.toString();
  }

  saveStockPresetData() {
    if (newOrder.stocksAdvancePreset == true) {
      // _limitorderformKey
      if (!(_boTakeProfitformKey.currentState!.validate())) {}
      if (!(_boStoplossformKey.currentState!.validate())) {}
      if (newOrder.stocksDefaultPercentageLimitOrderStatus == true) {
        if (!(_limitorderformKey.currentState!.validate())) {}
      }

      if (!((_boTakeProfitformKey.currentState!.validate()) &&
          (_boStoplossformKey.currentState!.validate()) &&
          (newOrder.stocksDefaultPercentageLimitOrderStatus == false ||
              (newOrder.stocksDefaultPercentageLimitOrderStatus == true &&
                  _limitorderformKey.currentState!.validate())))) {
        return false;
      }
    }
    UserSettings.userSettings.orderSettings.stocksAdvancePreset =
        newOrder.stocksAdvancePreset;
    UserSettings.userSettings.orderSettings.stocksReviewOrderAndSendStatus =
        newOrder.stocksReviewOrderAndSendStatus;
    tooltipControllerList[1]["status"] = UserSettings.userSettings.orderSettings
            .stocksDefaultPercentageLimitOrderStatus =
        newOrder.stocksDefaultPercentageLimitOrderStatus;
    UserSettings.userSettings.orderSettings.stocksDefaultPercentageLimitOrder =
        newOrder.stocksDefaultPercentageLimitOrder;
    UserSettings.userSettings.orderSettings.stocksBoStopLoss =
        newOrder.stocksBoStopLoss;
    UserSettings.userSettings.orderSettings.stocksBoTakeProfit =
        newOrder.stocksBoTakeProfit;
    UserSettings.userSettings.orderSettings.stocksMaxOrderValue =
        newOrder.stocksMaxOrderValue;
    UserSettings.userSettings.orderSettings.stocksOrderValue =
        newOrder.stocksOrderValue;
    return true;
  }
}

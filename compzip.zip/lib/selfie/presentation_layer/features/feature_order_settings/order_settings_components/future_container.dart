import 'package:flutter/material.dart';
import 'package:just_the_tooltip/just_the_tooltip.dart';
// import 'package:selfie_mobile_flutter/constants/prefefence_utils.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_settings/order_settings_components/future_advance_preset_card.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/default_order_settings_values.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/order_window_settings_bottom_sheet.dart';
// import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/preset_card.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/settings_list_panel.dart';
// import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/order_settings.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';

class FutureContainer extends StatefulWidget {
  static final GlobalKey<_FutureContainerState> futureContainerglobalKey =
      GlobalKey();
  Function(OrderSettings) changeAction;
  FutureContainer({
    Key? key,
    required this.changeAction,
  }) : super(key: futureContainerglobalKey);

  @override
  State<FutureContainer> createState() => _FutureContainerState();
}

class _FutureContainerState extends State<FutureContainer> {
  OrderSettings newOrder = OrderSettings();
  OrderSettings resetOrderSettings = OrderSettings().copyWith();

  int? _order;
  int? _type;
  int? _producttype;
  JustTheController? controller = JustTheController();
  JustTheController? controller2 = JustTheController();
  JustTheController? controller3 = JustTheController();
  @override
  void initState() {
    loadFutureData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
          left: 16.0, right: 16.0, top: 20.0, bottom: 16.0),
      child: SingleChildScrollView(
          physics: const ScrollPhysics(),
          child: Column(
            children: [
              InkWell(
                onTap: () {
                  customShowModalBottomSheet(
                      context: context,
                      inputWidget: OrderSettingsSheetComponent(
                          settingsVisibilityStatus: false,
                          orderSettingsSheetType: OrderSettingsSheetType.ORDER,
                          selected: _order!,
                          onChanged: updateorder,
                          list: ordersdropdownlist));
                },
                child: SettongsListPanel(
                  title: "Order",
                  optionName: ordersdropdownlist[_order!]["name"],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 16.0),
                child: InkWell(
                  onTap: () {
                    customShowModalBottomSheet(
                        context: context,
                        inputWidget: OrderSettingsSheetComponent(
                            settingsVisibilityStatus: false,
                            orderSettingsSheetType: OrderSettingsSheetType.TYPE,
                            selected: _type!,
                            onChanged: updatetype,
                            list: typsettingslist));
                  },
                  child: SettongsListPanel(
                    title: "Type",
                    optionName: typsettingslist[_type!]["name"],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 16.0),
                child: InkWell(
                  onTap: () {
                    customShowModalBottomSheet(
                        context: context,
                        inputWidget: OrderSettingsSheetComponent(
                            settingsVisibilityStatus: false,
                            orderSettingsSheetType:
                                OrderSettingsSheetType.PRODUCT,
                            selected: _producttype!,
                            onChanged: updateproducttype,
                            list: futureproductSettingslist));
                  },
                  child: SettongsListPanel(
                    title: "Product Type",
                    optionName: futureproductSettingslist[_producttype!]
                        ["name"],
                  ),
                ),
              ),
              FuturePresetCard(
                resetOrderSettings: resetOrderSettings,
              ),
              const SizedBox(
                height: 80.0,
              )
            ],
          )),
    );
  }

  void updateorder(int value) async {
    newOrder.futureOrder = value;

    setState(() {
      _order = value;
    });
  }

  void updatetype(int value) async {
    newOrder.futureType = value;

    setState(() {
      _type = value;
    });
  }

  void updateproducttype(int value) async {
    newOrder.futureProductType = value;

    setState(() {
      _producttype = value;
    });
  }

  resetFutureData() async {
    _order = UserSettings.userSettings.orderSettings.futureOrder =
        resetOrderSettings.futureOrder;
    _type = UserSettings.userSettings.orderSettings.futureType =
        resetOrderSettings.futureType;
    _producttype = UserSettings.userSettings.orderSettings.futureProductType =
        resetOrderSettings.futureProductType;
    FuturePresetCard.futurePresetglobalKey.currentState!.restFuturePrest();
  }

  loadFutureData() async {
    newOrder = UserSettings.userSettings.orderSettings.copyWith();
    _order = newOrder.futureOrder;
    _type = newOrder.futureType;
    _producttype = newOrder.futureProductType;
  }

  saveFutureData() {
    UserSettings.userSettings.orderSettings.futureOrder = newOrder.futureOrder;
    UserSettings.userSettings.orderSettings.futureType = newOrder.futureType;
    UserSettings.userSettings.orderSettings.futureProductType =
        newOrder.futureProductType;
    bool validationStatus = FuturePresetCard.futurePresetglobalKey.currentState!
        .saveFuturePresetData();
    return validationStatus;
  }
}

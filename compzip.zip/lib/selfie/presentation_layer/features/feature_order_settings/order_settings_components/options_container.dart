import 'package:flutter/material.dart';
import 'package:just_the_tooltip/just_the_tooltip.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_settings/order_settings_components/options_advance_preset_card.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/default_order_settings_values.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/order_window_settings_bottom_sheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/settings_list_panel.dart';
import 'package:selfie_mobile_flutter/utils/order_settings.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';

class OptionsContainer extends StatefulWidget {
  static final GlobalKey<_OptionsContainerState> optionsContainerglobalKey =
      GlobalKey();

  Function(OrderSettings) changeAction;
  OptionsContainer({
    Key? key,
    required this.changeAction,
  }) : super(key: optionsContainerglobalKey);

  @override
  State<OptionsContainer> createState() => _OptionsContainerState();
}

class _OptionsContainerState extends State<OptionsContainer> {
  OrderSettings newOrder = OrderSettings();
  OrderSettings resetOrderSettings = OrderSettings().copyWith();
  int? _order;
  int? _type;
  int? _product;
  JustTheController? controller = JustTheController();
  JustTheController? controller2 = JustTheController();
  JustTheController? controller3 = JustTheController();
  @override
  void initState() {
    loadOptionData();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
          left: 16.0, right: 16.0, top: 20.0, bottom: 16.0),
      child: SingleChildScrollView(
          physics: const ScrollPhysics(),
          child: Column(
            children: [
              InkWell(
                  onTap: () {
                    customShowModalBottomSheet(
                        context: context,
                        inputWidget: OrderSettingsSheetComponent(
                            settingsVisibilityStatus: false,
                            orderSettingsSheetType:
                                OrderSettingsSheetType.ORDER,
                            selected: _order!,
                            onChanged: updateorder,
                            list: ordersdropdownlist));
                  },
                  child: SettongsListPanel(
                      title: "Order",
                      optionName: ordersdropdownlist[_order!]["name"])),
              Padding(
                padding: const EdgeInsets.only(top: 16.0),
                child: InkWell(
                  onTap: () {
                    customShowModalBottomSheet(
                        context: context,
                        inputWidget: OrderSettingsSheetComponent(
                            settingsVisibilityStatus: false,
                            orderSettingsSheetType: OrderSettingsSheetType.TYPE,
                            selected: _type!,
                            onChanged: updatetype,
                            list: typsettingslist));
                  },
                  child: SettongsListPanel(
                    title: "Type",
                    optionName: typsettingslist[_type!]["name"],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 16.0),
                child: InkWell(
                  onTap: () {
                    customShowModalBottomSheet(
                        context: context,
                        inputWidget: OrderSettingsSheetComponent(
                            settingsVisibilityStatus: false,
                            orderSettingsSheetType:
                                OrderSettingsSheetType.PRODUCT,
                            selected: _product!,
                            onChanged: updateproduct,
                            list: futureproductSettingslist));
                  },
                  child: SettongsListPanel(
                    title: "Product",
                    optionName: futureproductSettingslist[_product!]["name"],
                  ),
                ),
              ),
              OptionsPresetCard(
                resetOrderSettings: resetOrderSettings,
              ),
              const SizedBox(
                height: 80.0,
              )
            ],
          )),
    );
  }

  void updateorder(int value) async {
    newOrder.optionOrder = value;
    setState(() {
      _order = value;
    });
  }

  void updatetype(int value) async {
    newOrder.optionType = value;
    setState(() {
      _type = value;
    });
  }

  void updateproduct(int value) async {
    newOrder.optionProductType = value;
    setState(() {
      _product = value;
    });
  }

  resetOptionsData() {
    _order = UserSettings.userSettings.orderSettings.optionOrder =
        resetOrderSettings.optionOrder;
    _type = UserSettings.userSettings.orderSettings.optionType =
        resetOrderSettings.optionType;
    _product = UserSettings.userSettings.orderSettings.optionProductType =
        resetOrderSettings.optionProductType;
    OptionsPresetCard.optionPresetglobalKey.currentState!.restOptionPrest();
  }

  loadOptionData() async {
    newOrder = UserSettings.userSettings.orderSettings.copyWith();
    _order = newOrder.optionOrder;
    _type = newOrder.optionType;
    _product = newOrder.optionProductType;
  }

  saveOptionData() {
    UserSettings.userSettings.orderSettings.optionOrder = newOrder.optionOrder;
    UserSettings.userSettings.orderSettings.optionType = newOrder.optionType;
    UserSettings.userSettings.orderSettings.optionProductType =
        newOrder.optionProductType;
    bool validationStatus = OptionsPresetCard
        .optionPresetglobalKey.currentState!
        .saveOptionPresetData();
    return validationStatus;
  }
}

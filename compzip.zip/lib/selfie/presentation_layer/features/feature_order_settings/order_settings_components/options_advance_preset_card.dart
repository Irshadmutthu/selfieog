import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_the_tooltip/just_the_tooltip.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/utils/order_settings.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';

class OptionsPresetCard extends StatefulWidget {
  static final GlobalKey<_OptionPresetCardState> optionPresetglobalKey =
      GlobalKey();
  OrderSettings resetOrderSettings;
  OptionsPresetCard({Key? key, required this.resetOrderSettings})
      : super(key: optionPresetglobalKey);

  @override
  State<OptionsPresetCard> createState() => _OptionPresetCardState();
}

class _OptionPresetCardState extends State<OptionsPresetCard> {
  OrderSettings newOrder = OrderSettings();
  String? userData;
  TextEditingController ovcontroller = TextEditingController();
  TextEditingController mvcontroller = TextEditingController();
  JustTheController? controller = JustTheController();
  JustTheController? controller2 = JustTheController();
  JustTheController? controller3 = JustTheController();
  late GlobalKey<FormState> ovFormKey = GlobalKey<FormState>();
  late GlobalKey<FormState> mvFormKey = GlobalKey<FormState>();
  final _limitorderformKey = GlobalKey<FormState>();
  TextEditingController limitOrderPercentagecontroller =
      TextEditingController(text: "");
  bool isSwitched = false;
  List tooltipControllerList = [];

  @override
  void initState() {
    loadOptionPresetData();
    super.initState();
  }

  Widget build(BuildContext context) {
    mvcontroller.selection = TextSelection.fromPosition(
        TextPosition(offset: mvcontroller.text.length));
    buildExpanded1() {
      return MediaQuery.removePadding(
        context: context,
        removeTop: true,
        child: SingleChildScrollView(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: <
                  Widget>[
            Padding(
              padding: const EdgeInsets.only(left: 16.0, right: 16.0),
              child: Divider(
                color: customColors().backgroundTertiary,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                left: 16.0,
                right: 16.0,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Form(
                        key: ovFormKey,
                        child: Expanded(
                            flex: 2,
                            child: CustomTextFormField(
                              controller: ovcontroller,
                              textAlign: TextAlign.end,
                              keyboardType: TextInputType.number,
                              validator: Validator.minimumValueLimit,
                              minimumValueLimit: 1,
                              inputFormatter: [
                                FilteringTextInputFormatter.digitsOnly
                              ],
                              fieldName: "Default Order (Lots)",
                              onChange: (value) async {
                                if (!(ovFormKey.currentState!.validate())) {
                                  newOrder.optionDefaultLot = 1;
                                } else {
                                  newOrder.optionDefaultLot =
                                      int.tryParse(value)!;
                                }
                              },
                            )),
                      ),
                      Form(
                        key: mvFormKey,
                        child: Expanded(
                            flex: 2,
                            child: Padding(
                              padding: const EdgeInsets.only(left: 16.0),
                              child: CustomTextFormField(
                                textAlign: TextAlign.end,
                                controller: mvcontroller,
                                keyboardType: TextInputType.number,
                                inputFormatter: [
                                  FilteringTextInputFormatter.digitsOnly
                                ],
                                fieldName: "Max Lots",
                                validator: Validator.minimumValueLimit,
                                minimumValueLimit: 1,
                                onChange: (value) async {
                                  if (!(mvFormKey.currentState!.validate())) {
                                    newOrder.optionMaxLot = 20;
                                  } else {
                                    newOrder.optionMaxLot =
                                        int.tryParse(value)!;
                                  }
                                },
                              ),
                            )),
                      )
                    ],
                  ),
                  for (int index = 0;
                      index < tooltipControllerList.length;
                      index++)
                    Padding(
                      padding: const EdgeInsets.only(top: 20.0, right: 0.0),
                      child: Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Text(
                                  tooltipControllerList[index]['name'],
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_Regular,
                                      color: FontColor.FontPrimary),
                                ),
                                JustTheTooltip(
                                  offset: 2.0,
                                  backgroundColor:
                                      customColors().backgroundSecondary,
                                  preferredDirection: AxisDirection.up,
                                  controller: tooltipControllerList[index]
                                      ["controller"],
                                  margin:
                                      EdgeInsets.only(left: 32.0, right: 32.0),
                                  child: Material(
                                      child: Container(
                                    height: 22.0,
                                    width: 22.0,
                                    child: Center(
                                        child: InkWell(
                                      onTap: () {
                                        tooltipControllerList[index]
                                                ["controller"]
                                            ?.showTooltip();
                                      },
                                      child: Icon(
                                        Icons.info_outline_rounded,
                                        size: 14.0,
                                      ),
                                    )),
                                  )),
                                  content: Container(
                                    child: Padding(
                                        padding: const EdgeInsets.only(
                                            top: 16.0,
                                            left: 10.0,
                                            right: 8.0,
                                            bottom: 10.0),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Text(
                                              tooltipControllerList[index]
                                                  ['name'],
                                              style: customTextStyle(
                                                  fontStyle:
                                                      FontStyle.BodyM_SemiBold,
                                                  color: FontColor.FontPrimary),
                                            ),
                                            Padding(
                                                padding: EdgeInsets.only(
                                                    top: 16.0, right: 10.0),
                                                child: Container(
                                                  child: Text(
                                                    tooltipControllerList[index]
                                                        ['content'],
                                                    style: customTextStyle(
                                                        fontStyle: FontStyle
                                                            .BodyS_Regular,
                                                        color: FontColor
                                                            .FontPrimary),
                                                    textAlign:
                                                        TextAlign.justify,
                                                  ),
                                                )),
                                          ],
                                        )),
                                  ),
                                )
                              ],
                            ),
                            EmptyCustomCheckBox(
                              isSelect: tooltipControllerList[index]["status"],
                              callback: (checkValue) async {
                                storeStatusToLocalStorage(
                                    index: index, value: checkValue);
                              },
                            )
                          ],
                        ),
                      ),
                    ),
                  Padding(
                    padding: const EdgeInsets.only(top: 18.0),
                    child: Row(
                      children: [
                        Visibility(
                          visible:
                              newOrder.optionDefaultPercentageLimitOrderStatus,
                          child: Form(
                            key: _limitorderformKey,
                            child: Expanded(
                              flex: 1,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Expanded(
                                    flex: 2,
                                    child: CustomTextFormField(
                                      validator:
                                          Validator.minimumDecimalValueLimit,
                                      minimumDecimalValueLimit: .01,
                                      textAlign: TextAlign.end,
                                      controller:
                                          limitOrderPercentagecontroller,
                                      keyboardType:
                                          TextInputType.numberWithOptions(
                                              decimal: true),
                                      fieldName: "",
                                      inputFormatter: [
                                        FilteringTextInputFormatter.allow(
                                            RegExp(r'(^\d*\.?\d{0,2})'))
                                      ],
                                      onChange: (value) async {
                                        if (!(_limitorderformKey.currentState!
                                            .validate())) {}

                                        if (value.isEmpty) {
                                          newOrder
                                              .optionDefaultPercentageLimitOrder = 0;
                                        } else if (double.tryParse(value) ==
                                            null) {
                                        } else {
                                          newOrder.optionDefaultPercentageLimitOrder =
                                              double.tryParse(value)!;
                                        }
                                      },
                                      sufixWidget: Text(
                                        '%',
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyL_SemiBold,
                                            color: FontColor.FontSecondary),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Expanded(flex: 1, child: SizedBox())
                      ],
                    ),
                  ),
                  Container(
                    height: 16.0,
                  )
                ],
              ),
            ),
          ]),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(
        top: 16.0,
      ),
      child: ExpandableNotifier(
          child: ScrollOnExpand(
        child: Container(
          decoration: BoxDecoration(
              border: Border.all(color: customColors().backgroundTertiary),
              borderRadius: BorderRadius.circular(4.0)),
          child: MediaQuery.removePadding(
            context: context,
            removeTop: true,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Builder(builder: (context) {
                  return InkWell(
                    onTap: () {
                      toggleSwitch(!isSwitched);
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(left: 16.0),
                          child: Text(
                            "Advanced Preset",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                        ),
                        Switch(
                          value: isSwitched,
                          onChanged: (value) async {
                            toggleSwitch(value);
                          },
                          activeColor: customColors().primary,
                          activeTrackColor: customColors().backgroundTertiary,
                        )
                      ],
                    ),
                  );
                }),
                Visibility(
                  visible: isSwitched,
                  child: buildExpanded1(),
                ),
              ],
            ),
          ),
        ),
      )),
    );
  }

  storeStatusToLocalStorage({required int index, required bool value}) async {
    switch (index) {
      case 0:
        newOrder.optionReviewOrderAndSendStatus = value;
        break;
      case 1:
        newOrder.optionAllowSplitOrderStatus = value;
        break;
      case 2:
        newOrder.optionDefaultPercentageLimitOrderStatus = value;
        if (newOrder.optionDefaultPercentageLimitOrderStatus == false) {
          newOrder.optionDefaultPercentageLimitOrder = 0;
          limitOrderPercentagecontroller.text = double.tryParse("0").toString();
        }
        setState(() {});
        break;
      default:
        break;
    }
  }

  void toggleSwitch(bool value) async {
    setState(() {
      isSwitched = (isSwitched == false) ? true : false;
    });

    newOrder.optionAdvancePreset = value;
  }

  restOptionPrest() {
    isSwitched = UserSettings.userSettings.orderSettings.optionAdvancePreset =
        widget.resetOrderSettings.optionAdvancePreset;
    UserSettings.userSettings.orderSettings.optionDefaultLot =
        widget.resetOrderSettings.optionDefaultLot;
    UserSettings.userSettings.orderSettings.optionMaxLot =
        widget.resetOrderSettings.optionMaxLot;
    ovcontroller.text =
        UserSettings.userSettings.orderSettings.optionDefaultLot.toString();
    mvcontroller.text = Formats.valueFormat
        .format(UserSettings.userSettings.orderSettings.optionMaxLot)
        .toString();
    tooltipControllerList[0]["status"] =
        UserSettings.userSettings.orderSettings.optionReviewOrderAndSendStatus =
            widget.resetOrderSettings.optionReviewOrderAndSendStatus;
    tooltipControllerList[1]["status"] =
        UserSettings.userSettings.orderSettings.optionAllowSplitOrderStatus =
            widget.resetOrderSettings.optionAllowSplitOrderStatus;
    tooltipControllerList[2]["status"] = UserSettings.userSettings.orderSettings
            .optionDefaultPercentageLimitOrderStatus =
        widget.resetOrderSettings.optionDefaultPercentageLimitOrderStatus;
    limitOrderPercentagecontroller.text = UserSettings
        .userSettings.orderSettings.optionDefaultPercentageLimitOrder
        .toString();
  }

  loadOptionPresetData() {
    newOrder = UserSettings.userSettings.orderSettings.copyWith();

    isSwitched = newOrder.optionAdvancePreset;
    ovcontroller.text = newOrder.optionDefaultLot.toString();
    mvcontroller.text =
        Formats.valueFormat.format(newOrder.optionMaxLot).toString();

    tooltipControllerList = [
      {
        "controller": controller,
        "status": newOrder.optionReviewOrderAndSendStatus,
        "name": "Review order and send",
        "value": false,
        "content": "You will be able to review your order before placing it."
      },
      {
        "controller": controller2,
        "status": newOrder.optionAllowSplitOrderStatus,
        "name": "Allow split orders",
        "value": false,
        "content":
            "Limit price will be calculated based on this value if its checked"
      },
      {
        "controller": controller3,
        "status": newOrder.optionDefaultPercentageLimitOrderStatus,
        "name": "Default percentage for limit order",
        "value": false,
        "content":
            "Limit price will be calculated based on this value if its checked"
      }
    ];
    limitOrderPercentagecontroller.text =
        newOrder.optionDefaultPercentageLimitOrder.toString();
  }

  saveOptionPresetData() {
    if (newOrder.optionAdvancePreset == true) {
      if (newOrder.optionDefaultPercentageLimitOrderStatus == true) {
        if (!(_limitorderformKey.currentState!.validate())) {}
      }
      if (!(newOrder.optionDefaultPercentageLimitOrderStatus == false ||
          (newOrder.optionDefaultPercentageLimitOrderStatus == true &&
              _limitorderformKey.currentState!.validate()))) {
        return false;
      }
    }
    UserSettings.userSettings.orderSettings.optionAdvancePreset =
        newOrder.optionAdvancePreset;
    UserSettings.userSettings.orderSettings.optionDefaultLot =
        newOrder.optionDefaultLot;
    UserSettings.userSettings.orderSettings.optionMaxLot =
        newOrder.optionMaxLot;
    UserSettings.userSettings.orderSettings.optionDefaultPercentageLimitOrder =
        newOrder.optionDefaultPercentageLimitOrder;
    UserSettings.userSettings.orderSettings.optionReviewOrderAndSendStatus =
        newOrder.optionReviewOrderAndSendStatus;
    UserSettings.userSettings.orderSettings.optionAllowSplitOrderStatus =
        newOrder.optionAllowSplitOrderStatus;
    tooltipControllerList[2]["status"] = UserSettings.userSettings.orderSettings
            .optionDefaultPercentageLimitOrderStatus =
        newOrder.optionDefaultPercentageLimitOrderStatus;
    return true;
  }
}

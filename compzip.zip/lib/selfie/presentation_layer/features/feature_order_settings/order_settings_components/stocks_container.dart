import 'package:flutter/material.dart';
import 'package:just_the_tooltip/just_the_tooltip.dart';
import 'package:selfie_mobile_flutter/constants/prefefence_utils.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order_settings/order_settings_components/stocks_advance_preset_card.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/default_order_settings_values.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/order_window_settings_bottom_sheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/settings_list_panel.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/order_settings.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';

class StocksContainer extends StatefulWidget {
  static final GlobalKey<_StocksContainerState> stocksContainerglobalKey =
      GlobalKey();
  Function(OrderSettings) changeAction;
  StocksContainer({
    Key? key,
    required this.changeAction,
  }) : super(key: stocksContainerglobalKey);

  @override
  State<StocksContainer> createState() => _StocksContainerState();
}

class _StocksContainerState extends State<StocksContainer> {
  OrderSettings newOrder = OrderSettings();
  OrderSettings resetOrderSettings = OrderSettings().copyWith();
  bool isSwitched = false;
  int? _exchange;
  int? _order;
  int? _type;
  int? _productType;
  JustTheController? controller = JustTheController();
  JustTheController? controller2 = JustTheController();
  @override
  void initState() {
    loadStockData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
          left: 16.0, right: 16.0, top: 20.0, bottom: 16.0),
      child: SingleChildScrollView(
        physics: const ScrollPhysics(),
        child: Column(
          children: [
            InkWell(
              onTap: () {
                customShowModalBottomSheet(
                    context: context,
                    inputWidget: OrderSettingsSheetComponent(
                        settingsVisibilityStatus: false,
                        orderSettingsSheetType: OrderSettingsSheetType.EXCHANGE,
                        selected: _exchange!,
                        onChanged: updateexchange,
                        list: exchanglist));
              },
              child: SettongsListPanel(
                title: "Exchange",
                optionName: exchanglist[_exchange!]["name"],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 16.0),
              child: InkWell(
                onTap: () {
                  customShowModalBottomSheet(
                      context: context,
                      inputWidget: OrderSettingsSheetComponent(
                          settingsVisibilityStatus: false,
                          orderSettingsSheetType: OrderSettingsSheetType.ORDER,
                          selected: _order!,
                          onChanged: updateorder,
                          list: ordersdropdownlist));
                },
                child: SettongsListPanel(
                    title: "Order",
                    optionName: ordersdropdownlist[_order!]["name"]),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 16.0),
              child: InkWell(
                onTap: () {
                  customShowModalBottomSheet(
                      context: context,
                      inputWidget: OrderSettingsSheetComponent(
                          settingsVisibilityStatus: false,
                          orderSettingsSheetType: OrderSettingsSheetType.TYPE,
                          selected: _type!,
                          onChanged: updateextype,
                          list: typsettingslist));
                },
                child: SettongsListPanel(
                  title: "Type",
                  optionName: typsettingslist[_type!]["name"],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 16.0),
              child: InkWell(
                onTap: () {
                  customShowModalBottomSheet(
                      context: context,
                      inputWidget: OrderSettingsSheetComponent(
                          settingsVisibilityStatus: false,
                          orderSettingsSheetType:
                              OrderSettingsSheetType.PRODUCT,
                          selected: _productType!,
                          onChanged: updateexproducttype,
                          list: stockproductSettingslist));
                },
                child: SettongsListPanel(
                  title: "Product Type",
                  optionName: stockproductSettingslist[_productType!]["name"],
                ),
              ),
            ),
            StocksPresetCard(
              resetOrderSettings: resetOrderSettings,
            ),
            const SizedBox(
              height: 80.0,
            )
          ],
        ),
      ),
    );
  }

  void updateexchange(int value) async {
    newOrder.stockExchange = value;
    setState(() {
      _exchange = value;
    });
  }

  void updateorder(int value) async {
    newOrder.stockOrder = value;
    setState(() {
      _order = value;
    });
  }

  void updateextype(int value) async {
    newOrder.stocksType = value;
    setState(() {
      _type = value;
    });
  }

  void updateexproducttype(int value) async {
    newOrder.stocksProductType = value;
    setState(() {
      _productType = value;
    });
  }

  resetStocksData() async {
    _exchange = UserSettings.userSettings.orderSettings.stockExchange =
        resetOrderSettings.stockExchange;

    _order = UserSettings.userSettings.orderSettings.stockOrder =
        resetOrderSettings.stockOrder;
    _type = UserSettings.userSettings.orderSettings.stocksType =
        resetOrderSettings.stocksType;
    _productType = UserSettings.userSettings.orderSettings.stocksProductType =
        resetOrderSettings.stocksProductType;
    StocksPresetCard.stockPresetglobalKey.currentState!.restStockPrest();
    await PreferenceUtils.storeDataToShared(
        UserController.userController.userId,
        UserSettings.userSettings.toJsonString());
  }

  loadStockData() async {
    newOrder = UserSettings.userSettings.orderSettings.copyWith();
    _exchange = newOrder.stockExchange;
    _order = newOrder.stockOrder;
    _type = newOrder.stocksType;
    _productType = newOrder.stocksProductType;
  }

  saveStockData() {
    ///true if validated,false if not validated
    UserSettings.userSettings.orderSettings.stockExchange =
        newOrder.stockExchange;
    UserSettings.userSettings.orderSettings.stockOrder = newOrder.stockOrder;
    UserSettings.userSettings.orderSettings.stocksType = newOrder.stocksType;
    UserSettings.userSettings.orderSettings.stocksProductType =
        newOrder.stocksProductType;
    bool validationStatus = StocksPresetCard.stockPresetglobalKey.currentState!
        .saveStockPresetData();
    return validationStatus;
  }
}

class PresetCardStorageDataModel {
  PresetCardStorageDataModel({required this.orderValue});

  int orderValue;
}

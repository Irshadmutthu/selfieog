import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_the_tooltip/just_the_tooltip.dart';
import 'package:selfie_mobile_flutter/constants/formaters.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/custom_text_form_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/stock/empty_custom_checkbox/empty_custom_checkbox.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/utils/order_settings.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';

class FuturePresetCard extends StatefulWidget {
  static final GlobalKey<_FuturePresetCardState> futurePresetglobalKey =
      GlobalKey();
  OrderSettings resetOrderSettings;
  FuturePresetCard({Key? key, required this.resetOrderSettings})
      : super(key: futurePresetglobalKey);

  @override
  State<FuturePresetCard> createState() => _FuturePresetCardState();
}

class _FuturePresetCardState extends State<FuturePresetCard> {
  OrderSettings newOrder = OrderSettings();
  String? userData;
  TextEditingController ovcontroller = TextEditingController();
  TextEditingController mvcontroller = TextEditingController();
  JustTheController? controller = JustTheController();
  JustTheController? controller2 = JustTheController();
  JustTheController? controller3 = JustTheController();

  late GlobalKey<FormState> ovFormKey = GlobalKey<FormState>();
  late GlobalKey<FormState> mvFormKey = GlobalKey<FormState>();
  final _limitorderformKey = GlobalKey<FormState>();

  TextEditingController limitOrderPercentagecontroller =
      TextEditingController(text: "");
  bool isSwitched = false;
  List tooltipControllerList = [];
  @override
  void initState() {
    loadFuturePresetData();
    super.initState();
  }

  Widget build(BuildContext context) {
    mvcontroller.selection = TextSelection.fromPosition(
        TextPosition(offset: mvcontroller.text.length));
    buildExpanded1() {
      return MediaQuery.removePadding(
        context: context,
        removeTop: true,
        child: SingleChildScrollView(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: <
                  Widget>[
            Padding(
              padding: const EdgeInsets.only(left: 16.0, right: 16.0),
              child: Divider(
                color: customColors().backgroundTertiary,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                left: 16.0,
                right: 16.0,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Form(
                        key: ovFormKey,
                        child: Expanded(
                            flex: 2,
                            child: CustomTextFormField(
                              controller: ovcontroller,
                              keyboardType: TextInputType.number,
                              validator: Validator.minimumValueLimit,
                              minimumValueLimit: 1,
                              inputFormatter: [
                                FilteringTextInputFormatter.digitsOnly
                              ],
                              fieldName: "Default Order (Lots)",
                              onChange: (value) async {
                                if (!(ovFormKey.currentState!.validate())) {
                                  newOrder.futureDefaultLot = 1;
                                } else {
                                  newOrder.futureDefaultLot =
                                      int.tryParse(value)!;
                                }
                              },
                            )),
                      ),
                      Form(
                        key: mvFormKey,
                        child: Expanded(
                            flex: 2,
                            child: Padding(
                              padding: const EdgeInsets.only(left: 16.0),
                              child: CustomTextFormField(
                                controller: mvcontroller,
                                keyboardType: TextInputType.number,
                                validator: Validator.minimumValueLimit,
                                minimumValueLimit: 1,
                                inputFormatter: [
                                  FilteringTextInputFormatter.digitsOnly
                                ],
                                fieldName: "Max Lots",
                                onChange: (value) async {
                                  if (!(mvFormKey.currentState!.validate())) {
                                    newOrder.futureMaxLot = 1;
                                  } else {
                                    newOrder.futureMaxLot =
                                        int.tryParse(value)!;
                                  }
                                },
                              ),
                            )),
                      )
                    ],
                  ),
                  for (int index = 0;
                      index < tooltipControllerList.length;
                      index++)
                    Padding(
                      padding: const EdgeInsets.only(top: 20.0, right: 0.0),
                      child: Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Text(
                                  tooltipControllerList[index]['name'],
                                  style: customTextStyle(
                                      fontStyle: FontStyle.BodyL_Regular,
                                      color: FontColor.FontPrimary),
                                ),
                                JustTheTooltip(
                                  offset: 2.0,
                                  backgroundColor:
                                      customColors().backgroundSecondary,
                                  preferredDirection: AxisDirection.up,
                                  controller: tooltipControllerList[index]
                                      ["controller"],
                                  margin:
                                      EdgeInsets.only(left: 32.0, right: 32.0),
                                  child: Material(
                                      child: Container(
                                    height: 22.0,
                                    width: 22.0,
                                    child: Center(
                                        child: InkWell(
                                      onTap: () {
                                        tooltipControllerList[index]
                                                ["controller"]
                                            ?.showTooltip();
                                      },
                                      child: Icon(
                                        Icons.info_outline_rounded,
                                        size: 14.0,
                                      ),
                                    )),
                                  )),
                                  content: Container(
                                    child: Padding(
                                        padding: const EdgeInsets.only(
                                            top: 16.0,
                                            left: 10.0,
                                            right: 8.0,
                                            bottom: 10.0),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Text(
                                              tooltipControllerList[index]
                                                  ['name'],
                                              style: customTextStyle(
                                                  fontStyle:
                                                      FontStyle.BodyM_SemiBold,
                                                  color: FontColor.FontPrimary),
                                            ),
                                            Padding(
                                                padding: EdgeInsets.only(
                                                    top: 16.0, right: 10.0),
                                                child: Container(
                                                  child: Text(
                                                    tooltipControllerList[index]
                                                        ['content'],
                                                    style: customTextStyle(
                                                        fontStyle: FontStyle
                                                            .BodyS_Regular,
                                                        color: FontColor
                                                            .FontPrimary),
                                                    textAlign:
                                                        TextAlign.justify,
                                                  ),
                                                )),
                                          ],
                                        )),
                                  ),
                                )
                              ],
                            ),
                            EmptyCustomCheckBox(
                              isSelect: tooltipControllerList[index]["status"],
                              callback: (checkValue) async {
                                storeStatusToLocalStorage(
                                    index: index, value: checkValue);
                              },
                            )
                          ],
                        ),
                      ),
                    ),
                  Padding(
                    padding: const EdgeInsets.only(top: 18.0),
                    child: Row(
                      children: [
                        Visibility(
                          visible:
                              newOrder.futureDefaultPercentageLimitOrderStatus,
                          child: Form(
                            key: _limitorderformKey,
                            child: Expanded(
                              flex: 1,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Expanded(
                                    flex: 2,
                                    child: CustomTextFormField(
                                      validator:
                                          Validator.minimumDecimalValueLimit,
                                      minimumDecimalValueLimit: .01,
                                      textAlign: TextAlign.end,
                                      controller:
                                          limitOrderPercentagecontroller,
                                      keyboardType:
                                          TextInputType.numberWithOptions(
                                              decimal: true),
                                      fieldName: "",
                                      inputFormatter: [
                                        FilteringTextInputFormatter.allow(
                                            RegExp(r'(^\d*\.?\d{0,2})'))
                                      ],
                                      onChange: (value) async {
                                        if (!(_limitorderformKey.currentState!
                                            .validate())) {}

                                        if (value.isEmpty) {
                                          newOrder
                                              .futureDefaultPercentageLimitOrder = 0;
                                        } else if (double.tryParse(value) ==
                                            null) {
                                        } else {
                                          newOrder.futureDefaultPercentageLimitOrder =
                                              double.tryParse(value)!;
                                        }
                                      },
                                      sufixWidget: Text(
                                        '%',
                                        style: customTextStyle(
                                            fontStyle: FontStyle.BodyL_SemiBold,
                                            color: FontColor.FontSecondary),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Expanded(flex: 1, child: SizedBox())
                      ],
                    ),
                  ),
                  Container(
                    height: 16.0,
                  )
                ],
              ),
            ),
          ]),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(
        top: 16.0,
      ),
      child: ExpandableNotifier(
          child: ScrollOnExpand(
        child: Container(
          decoration: BoxDecoration(
              border: Border.all(color: customColors().backgroundTertiary),
              borderRadius: BorderRadius.circular(4.0)),
          child: MediaQuery.removePadding(
            context: context,
            removeTop: true,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Builder(builder: (context) {
                  return InkWell(
                    onTap: () {
                      toggleSwitch(!isSwitched);
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(left: 16.0),
                          child: Text(
                            "Advanced Preset",
                            style: customTextStyle(
                                fontStyle: FontStyle.BodyL_SemiBold,
                                color: FontColor.FontPrimary),
                          ),
                        ),
                        Switch(
                          value: isSwitched,
                          onChanged: (value) async {
                            toggleSwitch(value);
                          },
                          activeColor: customColors().primary,
                          activeTrackColor: customColors().backgroundTertiary,
                        )
                      ],
                    ),
                  );
                }),
                Visibility(
                  visible: isSwitched,
                  child: buildExpanded1(),
                ),
              ],
            ),
          ),
        ),
      )),
    );
  }

  storeStatusToLocalStorage({required int index, required bool value}) async {
    switch (index) {
      case 0:
        newOrder.futureReviewOrderAndSendStatus = value;
        break;
      case 1:
        newOrder.futureAllowSplitOrderStatus = value;
        break;
      case 2:
        newOrder.futureDefaultPercentageLimitOrderStatus = value;
        if (newOrder.futureDefaultPercentageLimitOrderStatus == false) {
          newOrder.futureDefaultPercentageLimitOrder = 0;
          limitOrderPercentagecontroller.text = double.tryParse("0").toString();
        }
        setState(() {});
        break;
      default:
        break;
    }
  }

  void toggleSwitch(bool value) async {
    setState(() {
      isSwitched = (isSwitched == false) ? true : false;
    });
    newOrder.futureAdvancePreset = value;
  }

  restFuturePrest() {
    isSwitched = UserSettings.userSettings.orderSettings.futureAdvancePreset =
        widget.resetOrderSettings.futureAdvancePreset;
    UserSettings.userSettings.orderSettings.futureDefaultLot =
        widget.resetOrderSettings.futureDefaultLot;
    UserSettings.userSettings.orderSettings.futureMaxLot =
        widget.resetOrderSettings.futureMaxLot;
    ovcontroller.text =
        UserSettings.userSettings.orderSettings.futureDefaultLot.toString();
    mvcontroller.text = Formats.valueFormat
        .format(UserSettings.userSettings.orderSettings.futureMaxLot)
        .toString();
    tooltipControllerList[0]["status"] =
        UserSettings.userSettings.orderSettings.futureReviewOrderAndSendStatus =
            widget.resetOrderSettings.futureReviewOrderAndSendStatus;
    tooltipControllerList[1]["status"] =
        UserSettings.userSettings.orderSettings.futureAllowSplitOrderStatus =
            widget.resetOrderSettings.futureAllowSplitOrderStatus;
    tooltipControllerList[2]["status"] = UserSettings.userSettings.orderSettings
            .futureDefaultPercentageLimitOrderStatus =
        widget.resetOrderSettings.futureDefaultPercentageLimitOrderStatus;
    limitOrderPercentagecontroller.text = UserSettings
        .userSettings.orderSettings.futureDefaultPercentageLimitOrder
        .toString();
  }

  loadFuturePresetData() {
    newOrder = UserSettings.userSettings.orderSettings.copyWith();
    isSwitched = newOrder.futureAdvancePreset;
    ovcontroller.text = newOrder.futureDefaultLot.toString();
    mvcontroller.text =
        Formats.valueFormat.format(newOrder.futureMaxLot).toString();
    tooltipControllerList = [
      {
        "controller": controller,
        "status": newOrder.futureReviewOrderAndSendStatus,
        "name": "Review order and send",
        "value": false,
        "content": "You will be able to review your order before placing it."
      },
      {
        "controller": controller2,
        "status": newOrder.futureAllowSplitOrderStatus,
        "name": "Allow split orders",
        "value": false,
        "content":
            "Limit price will be calculated based on this value if its checked"
      },
      {
        "controller": controller3,
        "status": newOrder.futureDefaultPercentageLimitOrderStatus,
        "name": "Default percentage for limit order",
        "value": false,
        "content":
            "Limit price will be calculated based on this value if its checked"
      }
    ];
    limitOrderPercentagecontroller.text =
        newOrder.futureDefaultPercentageLimitOrder.toString();
  }

  saveFuturePresetData() {
    if (newOrder.futureAdvancePreset == true) {
      if (newOrder.futureDefaultPercentageLimitOrderStatus == true) {
        if (!(_limitorderformKey.currentState!.validate())) {}
      }
      if (!(newOrder.futureDefaultPercentageLimitOrderStatus == false ||
          (newOrder.futureDefaultPercentageLimitOrderStatus == true &&
              _limitorderformKey.currentState!.validate()))) {
        return false;
      }
    }
    UserSettings.userSettings.orderSettings.futureAdvancePreset =
        newOrder.futureAdvancePreset;
    UserSettings.userSettings.orderSettings.futureDefaultLot =
        newOrder.futureDefaultLot;
    UserSettings.userSettings.orderSettings.futureMaxLot =
        newOrder.futureMaxLot;
    UserSettings.userSettings.orderSettings.futureDefaultPercentageLimitOrder =
        newOrder.futureDefaultPercentageLimitOrder;
    UserSettings.userSettings.orderSettings.futureReviewOrderAndSendStatus =
        newOrder.futureReviewOrderAndSendStatus;
    UserSettings.userSettings.orderSettings.futureAllowSplitOrderStatus =
        newOrder.futureAllowSplitOrderStatus;
    tooltipControllerList[2]["status"] = UserSettings.userSettings.orderSettings
            .futureDefaultPercentageLimitOrderStatus =
        newOrder.futureDefaultPercentageLimitOrderStatus;
    return true;
  }
}

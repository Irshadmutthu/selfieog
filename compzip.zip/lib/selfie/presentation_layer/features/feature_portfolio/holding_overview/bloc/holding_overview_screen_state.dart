import 'package:trading_api/responses/portfolio_responce.dart';

abstract class HoldingOverViewScreenState {}

class HoldingOverViewScreenInitial extends HoldingOverViewScreenState {
  PortfolioResponce holdingresponce;
  double totalinvested = 0.0;
  double totalCurrentInvested = 0.0;
  double todaysPl = 0.0;
  double todyasPlPercentage = 0.0;
  double pl = 0.0;
  double plPercentage = 0.0;
  Map<String, dynamic> overviewlist = {};
  HoldingOverViewScreenInitial(
      {required this.holdingresponce,
      required this.totalinvested,
      required this.totalCurrentInvested,
      required this.todaysPl,
      required this.todyasPlPercentage,
      required this.pl,
      required this.plPercentage,
      required this.overviewlist});
}

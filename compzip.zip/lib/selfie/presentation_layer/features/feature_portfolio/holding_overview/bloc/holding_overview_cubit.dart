import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:flutter/widgets.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/portfolio_model/Portfolio.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/bloc/holding_overview_screen_state.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/portfolio_responce.dart';

class HoldingOverviewScreenCubit extends Cubit<HoldingOverViewScreenState> {
  BuildContext context;
  Map<String, dynamic> overviewlist = {};

  HoldingOverviewScreenCubit(this.context)
      : super(HoldingOverViewScreenInitial(
            holdingresponce: UserController().portfolioresetresponce,
            pl: 0.0,
            plPercentage: 0.0,
            totalinvested: 0.0,
            totalCurrentInvested: 0.0,
            todaysPl: 0.0,
            todyasPlPercentage: 0,
            overviewlist: {})) {
    updateData();
    // context.read<NavigationCubit>().adcontroller.stream.listen((event) {
    //   if (!isClosed) {
    //     if (event != 5) {
    //       unsubscribeSymbols();
    //     } else {
    //       updateData();
    //     }
    //   }
    // });
  }

  // unsubscribeSymbols() {
  //   List<Instrument> feedList =
  //       List.generate(holdata.length, (index) => holdata[index].instrument);
  //   if (feedList.isEmpty) return;
  //   MDS_Controller().unsubscribeSymbols(feedList);
  // }

  double totalPl = 0.0;
  double totalPercentage = 0.0;
  double totalinvested = 0.0;
  double todaysPl = 0.00;
  double avg = 0.0;
  double ltp = 0.0;
  double pl = 0.0;
  double totalCurrentInvest = 0.0;
  List<HoldingModel> equiylist = [];
  List equdata = [];
  List<HoldingModel> etflist = [];
  List etfdata = [];
  List<HoldingModel> bondlist = [];
  List bonddata = [];
  List<HoldingModel> mutualfundlist = [];
  List mutualdata = [];
  double totalEquityInvest = 0.0;
  double totalEquityCurrent = 0.0;
  double totalTodayInvested = 0.0;
  double totalTodayPercentage = 0.0;
  double equityPl = 0.0;
  double investAmount = 0.0;
  double currentAmount = 0.0;
  List<HoldingModel> holdata = [];
  StreamSubscription? streamSubscription;

  openinitial() {
    holdata.forEach((element) {
      element.investedAmount = element.avgrate * element.availablenetqty;
      element.currentAmount =
          element.instrument.lastTrdPrice * element.availablenetqty;
      // print(
      //     "qty = ${element.availablenetqty} x ltp = ${element.instrument!.lastTrdPrice}");
      // print("currentAmount = ${element.currentAmount}");
      if (element.categorydesc == "Bond") {
        bondlist.add(element);
      } else if (element.categorydesc == "Mutual Funds Units") {
        mutualfundlist.add(element);
      } else if (element.categorydesc == "ETF") {
        etflist.add(element);
      } else {
        equiylist.add(element);
      }
    });

    equdata = equtydata(equiylist);
    etfdata = etfdatalist(etflist);
    bonddata = bonds(bondlist);
    mutualdata = mutualfunds(mutualfundlist);
    overviewlist.addAll({"Equity": equdata});
    overviewlist.addAll({"Etf": etfdata});
    overviewlist.addAll({"Bond": bonddata});
    overviewlist.addAll({"MutualFunds": mutualdata});
  }

  emitdata() {
    totalCurrentInvest = 0.0;
    todaysPl = 0.0;
    totalPl = 0.0;
    totalTodayPercentage = 0.0;
    equdata.clear();
    equiylist.clear();
    mutualfundlist.clear();
    etflist.clear();
    bondlist.clear();

    holdata.forEach((element) {
      totalCurrentInvest = totalCurrentInvest + element.currentAmount;
      // print("## current = " + element.currentAmount.toString());
      // print("## total current = " + totalCurrentInvest.toString());
      todaysPl = todaysPl +
          ((element.instrument.lastTrdPrice - element.instrument.closePrice) *
              element.availablenetqty);
      if ((element.instrument.closePrice * element.availablenetqty) != 0) {
        totalTodayPercentage = (todaysPl * 100) /
            (element.instrument.closePrice * element.availablenetqty);
      } else {
        totalTodayPercentage = 0.00;
      }

      totalPl = totalPl + element.gtepl();
    });
    // print("holdings length =" + holdata.length.toString());
    // print("totalCurrentInvest = $totalCurrentInvest");
    // print("totalinvested = $totalinvested");
    // totalPl = totalCurrentInvest - totalinvested;
    // print("totalPl = $totalPl");
    totalPercentage = (totalPl * 100) / totalinvested;

    openinitial();
    // print("totalPercentage = $totalPercentage");

    emit(HoldingOverViewScreenInitial(
      holdingresponce: UserController().portfolioresponce,
      totalinvested: totalinvested,
      pl: totalPl,
      plPercentage: totalPercentage,
      totalCurrentInvested: totalCurrentInvest,
      todaysPl: todaysPl,
      overviewlist: overviewlist,
      todyasPlPercentage: totalTodayPercentage,
    ));
  }

  subscribedata() {
    streamSubscription = MDS_Controller()
        .marketUpdateStream
        .listen((List<FlairResponseModel> flairResponseModel) {
      openinitial();

      if (!isClosed) emitdata();
    });
    // MDS_Controller().subscribeSymbols(
    //     List.generate(holdata.length, (index) => holdata[index].instrument!));
    // List<Instrument> list = MDS_Controller().subscribeSymbols(
    //     List.generate(holdata.length, (index) => holdata[index].instrument!));
    // for (var i = 0; i < list.length; i++) {
    //   holdata[i].instrument = list[i];
    // }
    // openinitial();
    // emitdata();
    List<Instrument> list = [];

    for (var element in holdata) {
      list.add(element.instrument);
    }
    if (list.isNotEmpty) MDS_Controller().getLatestFeedUpdates(list);
    // List<Instrument> list = MDS_Controller().subscribeSymbols(List.generate(
    //     holdinglist.length, (index) => holdinglist[index].instrument!));
    // print(index);
    for (var i = 0; i < list.length; i++) {
      holdata[i].instrument = list[i];
    }
    openinitial();
    emitdata();
  }

  updateData() {
    totalinvested = 0.0;
    totalCurrentInvest = 0.0;
    totalPl = 0.0;
    holdata.clear();
    if (isClosed) return;
    List.generate(UserController().portfolioresponce.result3.length, (index) {
      holdata.add(HoldingModel.updateHoldingModel(
          UserController().portfolioresponce.result3[index]));

      totalinvested = totalinvested +
          (holdata[index].availablenetqty * holdata[index].avgrate);
      // totalTodayInvested =
      //     totalTodayInvested + holdata[index].todaysInvestedAmount;
    });
    subscribedata();
    //   emitdata(positionlist);
  }

  List equtydata(List<HoldingModel> equiylist) {
    List equdata = [];
    double totalIquityInvest = 0.0;
    double totalEquityCurrent = 0.0;
    double equityPlPercentage = 0.0;
    for (HoldingModel element in equiylist) {
      // print("invested" + element.investedAmount.toString());
      totalIquityInvest = totalIquityInvest + element.investedAmount;
      totalEquityCurrent = totalEquityCurrent + element.currentAmount;
      equityPl = equityPl + element.pl;
    }
    // equiylist.forEach((element) {
    //   totalIquityInvest = totalIquityInvest + element.investedAmount;
    //   totalEquityCurrent = totalEquityCurrent + element.currentAmount;
    //   equityPl = equityPl + element.pl;
    // });
    double equitypercentage = ((equiylist.length) / (holdata.length)) * 100;
    int percentage = equitypercentage.isNaN ? 0 : equitypercentage.round();

    // print("equity pl" + (totalEquityCurrent - totalIquityInvest).toString());
    // print("equity invest" + totalIquityInvest.toString());
    // print("totalequitycurrent" + totalEquityCurrent.toString());

    equityPlPercentage =
        ((totalEquityCurrent - totalIquityInvest) / totalEquityCurrent).isNaN ||
                ((totalEquityCurrent - totalIquityInvest) / totalEquityCurrent)
                    .isInfinite
            ? 0.0
            : ((totalEquityCurrent - totalIquityInvest) / totalEquityCurrent) *
                100;
    String investAmount = amountAsString(totalIquityInvest);
    String currentAmount = amountAsString(totalEquityCurrent);
    equdata.add(investAmount);
    equdata.add(currentAmount);
    equdata.add(equityPlPercentage.toStringAsFixed(2));
    equdata.add(percentage);
    equdata.add(equiylist);
    return equdata;
  }

  List etfdatalist(List<HoldingModel> etflist) {
    List etfdata = [];
    double totalEtfInvest = 0.0;
    double totalEtfCurrent = 0.0;
    double etfPlPercentage = 0.0;
    double etfPl = 0.0;
    for (HoldingModel element in etflist) {
      totalEtfInvest = totalEtfInvest + element.investedAmount;
      totalEtfCurrent = totalEtfCurrent + element.currentAmount;
      etfPl = etfPl + element.pl;
    }
    // etflist.forEach((element) {
    //   totalEtfInvest = totalEtfInvest + element.investedAmount;
    //   totalEtfCurrent = totalEtfCurrent + element.currentAmount;
    //   etfPl = etfPl + element.pl;
    // });
    double etfpercentage = ((etflist.length) /
            (UserController().portfolioresponce.result3.length)) *
        100;
    int percentage = etfpercentage.isNaN ? 0 : etfpercentage.round();
    etfPlPercentage = ((totalEtfCurrent - totalEtfInvest) / totalEtfCurrent)
                .isNaN ||
            ((totalEtfCurrent - totalEtfInvest) / totalEtfCurrent).isInfinite
        ? 0.0
        : ((totalEtfCurrent - totalEtfInvest) / totalEtfCurrent) * 100;
    etfdata.add(amountAsString(totalEtfInvest));
    etfdata.add(amountAsString(totalEtfCurrent));
    etfdata.add(etfPlPercentage.toStringAsFixed(2));
    etfdata.add(percentage);
    etfdata.add(etflist);
    return etfdata;
  }

  List bonds(List<HoldingModel> bondlist) {
    List bonddata = [];
    double totalBondInvest = 0.0;
    double totalBondCurrent = 0.0;
    double bondPl = 0.0;
    double bondPlPercentage = 0.0;
    List<Intraday> holdata = UserController().portfolioresponce.result3;
    for (HoldingModel element in bondlist) {
      totalBondInvest = totalBondInvest + element.investedAmount;
      totalBondCurrent = totalBondCurrent + element.currentAmount;
      bondPl = bondPl + element.pl;
    }
    // bondlist.forEach((element) {
    //   totalBondInvest = totalBondInvest + element.investedAmount;
    //   totalBondCurrent = totalBondCurrent + element.currentAmount;
    //   bondPl = bondPl + element.pl;
    // });
    bondPlPercentage = ((totalBondCurrent - totalBondInvest) / totalBondCurrent)
                .isNaN ||
            ((totalBondCurrent - totalBondInvest) / totalBondCurrent).isInfinite
        ? 0.0
        : ((totalBondCurrent - totalBondInvest) / totalBondCurrent) * 100;
    double bondpercentage = (((bondlist.length) / (holdata.length)) * 100).isNaN
        ? 0
        : (((bondlist.length) / (holdata.length)) * 100);
    bonddata.add(amountAsString(totalBondInvest));
    bonddata.add(amountAsString(totalBondCurrent));
    bonddata.add(bondPlPercentage.toStringAsFixed(2));
    bonddata.add(bondlist);
    bonddata.add(bondpercentage.round());
    return bonddata;
  }

  List mutualfunds(List<HoldingModel> mutuallist) {
    List mutualdata = [];
    double totalMutualInvest = 0.0;
    double totalMutualCurrent = 0.0;
    double mutualPl = 0.0;
    double mutualPlPercentage = 0.0;
    for (HoldingModel element in mutuallist) {
      totalMutualInvest = totalMutualInvest + element.investedAmount;
      totalMutualCurrent = totalMutualCurrent + element.currentAmount;
      mutualPl = mutualPl + element.pl;
    }
    // mutuallist.forEach((element) {
    //   totalMutualInvest = totalMutualInvest + element.investedAmount;
    //   totalMutualCurrent = totalMutualCurrent + element.currentAmount;
    //   mutualPl = mutualPl + element.pl;
    // });

    if (totalMutualCurrent != 0) {
      mutualPlPercentage = ((totalMutualCurrent - totalMutualInvest) /
                      totalMutualCurrent)
                  .isNaN ||
              ((totalMutualCurrent - totalMutualInvest) / totalMutualCurrent)
                  .isInfinite
          ? 0.0
          : ((totalMutualCurrent - totalMutualInvest) / totalMutualCurrent) *
              100;
    } else {
      mutualPlPercentage = 0.00;
    }

    double mutualpercentage =
        (((mutuallist.length) / (holdata.length)) * 100).isNaN ||
                (((mutuallist.length) / (holdata.length)) * 100).isInfinite
            ? 0
            : (((mutuallist.length) / (holdata.length)) * 100);
    mutualdata.add(amountAsString(totalMutualInvest));
    mutualdata.add(amountAsString(totalMutualCurrent));
    mutualdata.add(mutualPlPercentage.toStringAsFixed(2));
    mutualdata.add(mutuallist);
    mutualdata.add(mutualpercentage.round());
    return mutualdata;
  }

  // List otherlist(List<Intraday> otherlist) {
  //   List otherdata = [];
  //   double total_other_invest = 0.0;
  //   double total_other_current = 0.0;
  //   double other_pl = 0.0;
  //   double other_pl_percentage = 0.0;
  //   List<Intraday> holdata = UserController().portfolioresponce.result3;
  //   otherlist.forEach((element) {
  //     total_other_invest = total_other_invest + element.invested_amount;
  //     total_other_current = total_other_current + element.current_amount;
  //     other_pl = other_pl + element.pl;
  //   });
  //   String invest_amount = amount_as_string(total_other_invest);
  //   String current_amount = amount_as_string(total_other_current);
  //   other_pl_percentage = ((other_pl * 100) / total_other_invest.round()).isNaN
  //       ? 0.0
  //       : (other_pl * 100) / total_other_invest;
  //   double otherpercentage = ((otherlist.length) / (holdata.length)) * 100;
  //   otherdata.add(invest_amount);
  //   otherdata.add(current_amount);
  //   otherdata.add(other_pl_percentage.toStringAsFixed(2));
  //   otherdata.add(otherlist);
  //   otherdata.add(otherpercentage.round());
  //   return otherdata;
  // }

  String amountAsString(double amount) {
    var investAmount = "0";
    if (amount >= 10000000) {
      investAmount = ((amount / 100000000) * 10).toStringAsFixed(2) + "Cr";
    } else if (amount >= 100000) {
      investAmount = ((amount / 1000000) * 10).toStringAsFixed(2) + "L";
    } else if (amount >= 1000) {
      investAmount = ((amount / 10000) * 10).toStringAsFixed(2) + "K";
    } else {
      investAmount = amount.toStringAsFixed(2).toString();
    }
    return investAmount;
  }
}

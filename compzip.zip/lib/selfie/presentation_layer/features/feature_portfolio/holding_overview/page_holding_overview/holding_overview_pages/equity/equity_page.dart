import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/constants/enums.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/page_holding_overview/holding_overview_pages/equity/bloc/equity_list_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/page_holding_overview/holding_overview_pages/equity/bloc/equity_list_page_state.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/page_holding_overview/holding_overview_pages/equity/equity_list_tile.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/my_portfolio/bloc/my_portfolio_screen_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/my_portfolio/tab_component_holdings/bloc/holdings_component_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/portfolio_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/portfolio_holding_filter_bar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/position_search_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/sort.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/holdings/holdings_tile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/holdings/holdings_widgets.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/portfolio_card/holdings_card.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';

import '../../../../../../bloc_navigation/navigation_cubit.dart';

class EquityPage extends StatefulWidget {
  const EquityPage({Key? key}) : super(key: key);

  @override
  State<EquityPage> createState() => _EquityPageState();
}

class _EquityPageState extends State<EquityPage>
    with AutomaticKeepAliveClientMixin<EquityPage> {
  final _editcontroller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;

    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (context) => EquityListCubit(context)),
      ],
      child: ListView(
        children: [
          SingleChildScrollView(
            child: Column(
              children: [
                BlocListener<NavigationCubit, NavigationState>(
                  listener: (context, state) {
                    if (state is WatchlistIndexState)
                      BlocProvider.of<EquityListCubit>(context).updateData();
                  },
                  child: Container(),
                ),
                BlocBuilder<EquityListCubit, EquityListPageState>(
                    builder: (context, state) {
                  if (state is EquityListInitialState) {
                    return Column(
                      children: [
                        state.equitylist.isEmpty &&
                                state.filterarrayposition.isNotEmpty
                            ? Column(
                                children: [
                                  const SizedBox(
                                    height: 16,
                                  ),
                                  HoldingsCard(
                                    amount: state.total_pl,
                                    percentage: state.totla_pl_percentage
                                        .toStringAsFixed(2),
                                    height: screenSize.height * 0.13,
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                ],
                              )
                            : SizedBox(),
                        state.equitylist.isNotEmpty &&
                                state.searchvisible == false
                            ? Column(
                                children: [
                                  const SizedBox(
                                    height: 16,
                                  ),
                                  HoldingsCard(
                                    amount: state.total_pl,
                                    percentage: state.totla_pl_percentage
                                        .toStringAsFixed(2),
                                    height: screenSize.height * 0.13,
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                ],
                              )
                            : SizedBox(),
                        Column(
                          children: [
                            if (state.equitylist.isEmpty &&
                                !state.searchvisible)
                              SingleChildScrollView(
                                child: Column(children: [
                                  if (state.filterarrayposition.isNotEmpty)
                                    Column(
                                      children: [
                                        SearchFilterHoldings(
                                          showInsights: false,
                                          showBubble: state
                                              .filterarrayposition.isNotEmpty,
                                          showBubbleSort: state.filterval != -1,
                                          onSearchPress: () {
                                            BlocProvider.of<EquityListCubit>(
                                                    context)
                                                .opensearch();
                                          },
                                          onFilterPress: () {
                                            customShowModalBottomSheet(
                                                context: context,
                                                inputWidget: PortfolioSortList(
                                                  currentval: state.filterval,
                                                  filterlist:
                                                      state.filter_elements,
                                                  filterarrayposition:
                                                      state.filterarrayposition,
                                                  selectedLocation:
                                                      SortFilterLocation
                                                          .holding,
                                                  onPressFilter:
                                                      (List<String> el) {
                                                    state.filter_elements =
                                                        List.from(el);
                                                    BlocProvider.of<
                                                                EquityListCubit>(
                                                            context)
                                                        .updatefilterlist(el,
                                                            state.filterval);
                                                  },
                                                  onPressSort: (int index) {
                                                    BlocProvider.of<
                                                                EquityListCubit>(
                                                            context)
                                                        .updatesortlist(index);
                                                    Navigator.pop(context);
                                                  },
                                                  onPressReset: () {
                                                    BlocProvider.of<
                                                                EquityListCubit>(
                                                            context)
                                                        .resetfilter();
                                                    //     filterarrayposition.clear();
                                                    Navigator.pop(context);
                                                  },
                                                ));
                                          },
                                          onSortPress: () {
                                            customShowModalBottomSheet(
                                                context: context,
                                                inputWidget: PortfolioSortList(
                                                  currentval: state.filterval,
                                                  filterarrayposition:
                                                      state.filterarrayposition,
                                                  filterlist:
                                                      state.filter_elements,
                                                  selectedLocation:
                                                      SortFilterLocation
                                                          .holding,
                                                  selectedTabIndex: 1,
                                                  onPressFilter:
                                                      (List<String> elements) {
                                                    state.filter_elements =
                                                        List.from(elements);
                                                    BlocProvider.of<
                                                                EquityListCubit>(
                                                            context)
                                                        .updatefilterlist(
                                                            elements,
                                                            state.filterval);
                                                  },
                                                  onPressSort: (int value) {
                                                    BlocProvider.of<
                                                                EquityListCubit>(
                                                            context)
                                                        .updatesortlist(value);
                                                    Navigator.pop(context);
                                                  },
                                                  onPressReset: () {
                                                    BlocProvider.of<
                                                                EquityListCubit>(
                                                            context)
                                                        .resetfilter();
                                                    //       filterarrayposition.clear();
                                                    Navigator.pop(context);
                                                  },
                                                ));
                                          },
                                        ),
                                      ],
                                    )
                                  else
                                    Column(
                                      children: [
                                        const SizedBox(
                                          height: 6,
                                        ),
                                        Padding(
                                          padding: EdgeInsets.only(top: 100),
                                          child:
                                              emptyContainerPortfolioHoldings(
                                                  context),
                                        )
                                      ],
                                    )
                                ]),
                              )
                            else if (state.searchvisible)
                              SingleChildScrollView(
                                child: Column(children: [
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 8.0),
                                    child: Position_Search_Field(
                                        onBackPressed: () {
                                          _editcontroller.clear();
                                          BlocProvider.of<EquityListCubit>(
                                                  context)
                                              .resetfilter();
                                        },
                                        hintText: "Search eg: infy",
                                        controller: _editcontroller,
                                        onSearch: (String keyword) {
                                          if (keyword.isEmpty) {
                                            BlocProvider.of<EquityListCubit>(
                                                    context)
                                                .updateSearchList(keyword);
                                          } else {
                                            BlocProvider.of<EquityListCubit>(
                                                    context)
                                                .updateSearchList(keyword);
                                          }
                                        }),
                                  ),
                                  ListView.builder(
                                      physics:
                                          const NeverScrollableScrollPhysics(),
                                      itemCount: state.equitylist.length,
                                      shrinkWrap: true,
                                      itemBuilder: (context, index) {
                                        return EquityListTile(
                                          reportData: state.equitylist[index],
                                        );
                                      }),
                                ]),
                              )
                            else if (state.searchvisible == false)
                              SingleChildScrollView(
                                child: Column(
                                  children: [
                                    SearchFilterHoldings(
                                      showInsights: false,
                                      showBubble:
                                          state.filterarrayposition.isNotEmpty,
                                      showBubbleSort: state.filterval != -1,
                                      onSearchPress: () {
                                        BlocProvider.of<EquityListCubit>(
                                                context)
                                            .opensearch();
                                      },
                                      onFilterPress: () {
                                        customShowModalBottomSheet(
                                            context: context,
                                            inputWidget: PortfolioSortList(
                                              currentval: state.filterval,
                                              filterlist: state.filter_elements,
                                              filterarrayposition:
                                                  state.filterarrayposition,
                                              selectedLocation:
                                                  SortFilterLocation.holding,
                                              onPressFilter: (List<String> el) {
                                                state.filter_elements =
                                                    List.from(el);
                                                BlocProvider.of<
                                                            EquityListCubit>(
                                                        context)
                                                    .updatefilterlist(
                                                        el, state.filterval);
                                              },
                                              onPressSort: (int index) {
                                                BlocProvider.of<
                                                            EquityListCubit>(
                                                        context)
                                                    .updatesortlist(index);
                                                Navigator.pop(context);
                                              },
                                              onPressReset: () {
                                                BlocProvider.of<
                                                            EquityListCubit>(
                                                        context)
                                                    .resetfilter();
                                                //     filterarrayposition.clear();
                                                Navigator.pop(context);
                                              },
                                            ));
                                      },
                                      onSortPress: () {
                                        customShowModalBottomSheet(
                                            context: context,
                                            inputWidget: PortfolioSortList(
                                              currentval: state.filterval,
                                              filterarrayposition:
                                                  state.filterarrayposition,
                                              filterlist: state.filter_elements,
                                              selectedLocation:
                                                  SortFilterLocation.holding,
                                              selectedTabIndex: 1,
                                              onPressFilter:
                                                  (List<String> elements) {
                                                state.filter_elements =
                                                    List.from(elements);
                                                BlocProvider.of<
                                                            EquityListCubit>(
                                                        context)
                                                    .updatefilterlist(elements,
                                                        state.filterval);
                                              },
                                              onPressSort: (int value) {
                                                BlocProvider.of<
                                                            EquityListCubit>(
                                                        context)
                                                    .updatesortlist(value);
                                                Navigator.pop(context);
                                              },
                                              onPressReset: () {
                                                BlocProvider.of<
                                                            EquityListCubit>(
                                                        context)
                                                    .resetfilter();
                                                //       filterarrayposition.clear();
                                                Navigator.pop(context);
                                              },
                                            ));
                                      },
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 8.0),
                                      child: ListView.builder(
                                          physics:
                                              const NeverScrollableScrollPhysics(),
                                          itemCount: state.equitylist.length,
                                          shrinkWrap: true,
                                          itemBuilder: (context, index) {
                                            return EquityListTile(
                                              reportData:
                                                  state.equitylist[index],
                                            );
                                          }),
                                    ),
                                  ],
                                ),
                              )
                          ],
                        )
                      ],
                    );
                  } else {
                    return Container();
                  }
                })
              ],
            ),
          )
        ],
      ),
    );

    // return BlocProvider(
    //   create: (context) => EquityListCubit(),
    //   child: BlocBuilder<EquityListCubit, EquityListPageState>(
    //       builder: (context, state) {
    //     return SingleChildScrollView(
    //       child: Column(
    //         mainAxisAlignment: MainAxisAlignment.start,
    //         crossAxisAlignment: CrossAxisAlignment.center,
    //         children: [
    //           BlocListener<NavigationCubit, NavigationState>(
    //             listener: (context, state) {
    //               BlocProvider.of<EquityListCubit>(context)
    //                   .equitycalculation(false);
    //             },
    //             child: Container(),
    //           ),
    //           if (state is EquityListInitialState)
    //             Column(
    //               children: [
    //                 state.equitylist.isNotEmpty &&
    //                             state.searchvisible == false ||
    //                         state.filterarrayposition.isNotEmpty
    //                     ? Column(
    //                         children: [
    //                           const SizedBox(
    //                             height: 6,
    //                           ),
    //                           HoldingsCard(
    //                             amount: state.total_pl,
    //                             percentage: state.totla_pl_percentage
    //                                 .toStringAsFixed(2),
    //                             height: screenSize.height * 0.13,
    //                             equity: "y",
    //                           ),
    //                           const SizedBox(
    //                             height: 6,
    //                           ),
    //                         ],
    //                       )
    //                     : SizedBox(),
    //                 state.equitylist.isNotEmpty
    //                     ? Column(
    //                         mainAxisAlignment: MainAxisAlignment.start,
    //                         crossAxisAlignment: CrossAxisAlignment.center,
    //                         children: [
    //                           const SizedBox(height: 20),
    //                           if (state.searchvisible == false)
    //                             Column(
    //                               children: [
    //                                 SearchFilterHoldings(
    //                                   showInsights: false,
    //                                   showBubble:
    //                                       state.filterarrayposition.isNotEmpty,
    //                                   onSearchPress: () {
    //                                     BlocProvider.of<EquityListCubit>(
    //                                             context)
    //                                         .opensearch(state.equitylist);
    //                                   },
    //                                   onFilterPress: () {
    //                                     customShowModalBottomSheet(
    //                                         context: context,
    //                                         inputWidget: PortfolioSortList(
    //                                           currentval: state.filterval,
    //                                           filterlist: state.filter_elements,
    //                                           filterarrayposition:
    //                                               state.filterarrayposition,
    //                                           selectedLocation:
    //                                               SortFilterLocation.holding,
    //                                           onPressFilter: (List<String> el) {
    //                                             state.filter_elements =
    //                                                 List.from(el);
    //                                             BlocProvider.of<
    //                                                         EquityListCubit>(
    //                                                     context)
    //                                                 .updatefilterlist(el);
    //                                           },
    //                                           onPressSort: (int index) {
    //                                             BlocProvider.of<
    //                                                         EquityListCubit>(
    //                                                     context)
    //                                                 .updatesortlist(index);
    //                                             Navigator.pop(context);
    //                                           },
    //                                           onPressReset: () {
    //                                             BlocProvider.of<
    //                                                         EquityListCubit>(
    //                                                     context)
    //                                                 .resetfilter();
    //                                             Navigator.pop(context);
    //                                           },
    //                                         ));
    //                                   },
    //                                   onSortPress: () {
    //                                     customShowModalBottomSheet(
    //                                         context: context,
    //                                         inputWidget: PortfolioSortList(
    //                                           currentval: state.filterval,
    //                                           filterarrayposition:
    //                                               state.filterarrayposition,
    //                                           filterlist: state.filter_elements,
    //                                           selectedLocation:
    //                                               SortFilterLocation.holding,
    //                                           selectedTabIndex: 1,
    //                                           onPressFilter:
    //                                               (List<String> elements) {
    //                                             state.filter_elements =
    //                                                 List.from(elements);
    //                                             BlocProvider.of<
    //                                                         EquityListCubit>(
    //                                                     context)
    //                                                 .updatefilterlist(elements);
    //                                           },
    //                                           onPressSort: (int value) {
    //                                             BlocProvider.of<
    //                                                         EquityListCubit>(
    //                                                     context)
    //                                                 .updatesortlist(value);
    //                                             Navigator.pop(context);
    //                                           },
    //                                           onPressReset: () {
    //                                             BlocProvider.of<
    //                                                         EquityListCubit>(
    //                                                     context)
    //                                                 .resetfilter();
    //                                             //       filterarrayposition.clear();
    //                                             Navigator.pop(context);
    //                                           },
    //                                         ));
    //                                   },
    //                                 ),
    //                               ],
    //                             ),
    //                           if (state.searchvisible)
    //                             Position_Search_Field(
    //                               onBackPressed: () {
    //                                 BlocProvider.of<EquityListCubit>(context)
    //                                     .equitycalculation(false);
    //                               },
    //                               onSearch: (keyword) {
    //                                 BlocProvider.of<EquityListCubit>(context)
    //                                     .updateSearchList(keyword);
    //                               },
    //                               hintText: "Search eg: infy",
    //                               controller: _editcontroller,
    //                             ),
    //                           ListView.builder(
    //                               physics: const NeverScrollableScrollPhysics(),
    //                               itemCount: state.equitylist.length,
    //                               shrinkWrap: true,
    //                               itemBuilder: (context, index) {
    //                                 return EquityListTile(
    //                                   reportData: state.equitylist[index],
    //                                 );
    //                               }),
    //                         ],
    //                       )
    //                     : Column(
    //                         mainAxisAlignment: MainAxisAlignment.start,
    //                         crossAxisAlignment: CrossAxisAlignment.center,
    //                         children: [
    //                           state.filterarrayposition.isNotEmpty
    //                               ? SearchFilterHoldings(
    //                                   showInsights: false,
    //                                   showBubble:
    //                                       state.filterarrayposition.isNotEmpty,
    //                                   onSearchPress: () {
    //                                     BlocProvider.of<EquityListCubit>(
    //                                             context)
    //                                         .opensearch(state.equitylist);
    //                                   },
    //                                   onFilterPress: () {
    //                                     customShowModalBottomSheet(
    //                                         context: context,
    //                                         inputWidget: PortfolioSortList(
    //                                           currentval: state.filterval,
    //                                           filterlist: state.filter_elements,
    //                                           filterarrayposition:
    //                                               state.filterarrayposition,
    //                                           selectedLocation:
    //                                               SortFilterLocation.holding,
    //                                           onPressFilter: (List<String> el) {
    //                                             state.filter_elements =
    //                                                 List.from(el);
    //                                             BlocProvider.of<
    //                                                         EquityListCubit>(
    //                                                     context)
    //                                                 .updatefilterlist(el);
    //                                           },
    //                                           onPressSort: (int index) {
    //                                             BlocProvider.of<
    //                                                         EquityListCubit>(
    //                                                     context)
    //                                                 .updatesortlist(index);
    //                                             Navigator.pop(context);
    //                                           },
    //                                           onPressReset: () {
    //                                             BlocProvider.of<
    //                                                         EquityListCubit>(
    //                                                     context)
    //                                                 .resetfilter();
    //                                             Navigator.pop(context);
    //                                           },
    //                                         ));
    //                                   },
    //                                   onSortPress: () {
    //                                     customShowModalBottomSheet(
    //                                         context: context,
    //                                         inputWidget: PortfolioSortList(
    //                                           currentval: state.filterval,
    //                                           filterarrayposition:
    //                                               state.filterarrayposition,
    //                                           filterlist: state.filter_elements,
    //                                           selectedLocation:
    //                                               SortFilterLocation.holding,
    //                                           selectedTabIndex: 1,
    //                                           onPressFilter:
    //                                               (List<String> elements) {
    //                                             state.filter_elements =
    //                                                 List.from(elements);
    //                                             BlocProvider.of<
    //                                                         EquityListCubit>(
    //                                                     context)
    //                                                 .updatefilterlist(elements);
    //                                           },
    //                                           onPressSort: (int value) {
    //                                             print(
    //                                                 "value" + value.toString());
    //                                             BlocProvider.of<
    //                                                         EquityListCubit>(
    //                                                     context)
    //                                                 .updatesortlist(value);
    //                                             Navigator.pop(context);
    //                                           },
    //                                           onPressReset: () {
    //                                             BlocProvider.of<
    //                                                         EquityListCubit>(
    //                                                     context)
    //                                                 .resetfilter();
    //                                             //       filterarrayposition.clear();
    //                                             Navigator.pop(context);
    //                                           },
    //                                         ));
    //                                   },
    //                                 )
    //                               : SizedBox(),
    //                           state.filterarrayposition.isEmpty
    //                               ? Padding(
    //                                   padding: EdgeInsets.only(top: 100),
    //                                   child: emptyContainerPortfolioHoldings(
    //                                       context),
    //                                 )
    //                               : SizedBox()
    //                         ],
    //                       )
    //               ],
    //             ),
    //           if (state is EquityListEmptyState)
    //             Column(
    //               mainAxisAlignment: MainAxisAlignment.start,
    //               crossAxisAlignment: CrossAxisAlignment.center,
    //               children: [
    //                 const SizedBox(
    //                   height: 6,
    //                 ),
    //                 Padding(
    //                   padding: EdgeInsets.only(top: 100),
    //                   child: emptyContainerPortfolioHoldings(context),
    //                 )
    //               ],
    //             )
    //         ],
    //       ),
    //     );
    //   }),
    // );
  }

  @override
  bool get wantKeepAlive => true;
}

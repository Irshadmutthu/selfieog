// ignore_for_file: unused_import

import 'dart:async';
import 'dart:math';

import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/portfolio_model/Portfolio.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/bloc_navigation/navigation_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/page_holding_overview/holding_overview_pages/equity/bloc/equity_list_page_state.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/portfolio_responce.dart';

class EquityListCubit extends Cubit<EquityListPageState> {
  double totalPl = 0.00;
  double totalPercentage = 0.00;
  List<HoldingModel> equitylist = [];
  double totalinvested = 0.0;
  double totalCurrent = 0.00;
  List<String> filterarrayposition = [];
  int filtersvalue = -1;
  List<Intraday> list = [];
  bool searchvisible = false;
  List<String> defaultSortOrder = [];
  StreamSubscription? streamSubscription;
  double totalCurrentInvest = 0.0;
  BuildContext context;

  EquityListCubit(this.context) : super(EquityListEmptyState()) {
    updateData();
    // context.read<NavigationCubit>().adcontroller.stream.listen((event) {
    //   if (!isClosed) {
    //     if (event != 6) {
    //       unsubscribeData();
    //     } else {
    //       updateData();
    //     }
    //   }
    // });
  }

  opensearch() {
    searchvisible = true;
    emitdata(equitylist);
  }

  resetfilter() {
    filterarrayposition.clear();
    filtersvalue = -1;
    searchvisible = false;
    //   equitycalculation(false);
    List<HoldingModel> list = [];

    defaultSortOrder.forEach((ric) {
      for (var element in equitylist) {
        if (ric == element.instrument.getRicAddress()) {
          list.add(element);
        }
      }
    });
    equitylist = list;
    emitdata(equitylist);
  }

  updateSearchList(String key) {
    List<HoldingModel>? searchabledata = [];
    searchabledata.clear();
    equitylist.forEach((element) {
      if (element.securitycode1.startsWith(key.toUpperCase()) ||
          element.securitycode1.contains(key.toUpperCase())) {
        searchabledata.add(element);
      }
    });
    emitdata(searchabledata);
  }

  List<HoldingModel> updatesortfilter(List<HoldingModel> myequitylist) {
    // list =
    //     List.from(UserController().portfolioresponce.result3, growable: true);

    List<HoldingModel> realList = myequitylist;
    List<HoldingModel> finalList = [];

    if (filterarrayposition.isNotEmpty) {
      for (var element in realList) {
        for (int i = 0; i < filterarrayposition.length; i++) {
          if (element.producttype == filterarrayposition[i].toUpperCase() ||
              element.producttype
                  .endsWith(filterarrayposition[i].toUpperCase())) {
            finalList.add(element);
          }
        }
      }
      realList = List.from(finalList);
    }
    if (filtersvalue != -1) {
      switch (filtersvalue) {
        case 0:
          realList.sort(((a, b) => (a.instrument.securityCode)
              .compareTo(b.instrument.securityCode)));
          break;
        case 1:
          realList.sort(((a, b) => (b.instrument.securityCode)
              .compareTo(a.instrument.securityCode)));
          break;
        case 2:
          realList.sort(((a, b) => a.pl.compareTo(b.pl)));
          break;
        case 3:
          realList.sort(((a, b) => b.pl.compareTo(a.pl)));
          break;
        case 4:
          realList.sort(((a, b) => a.plPercentage.compareTo(b.plPercentage)));
          break;
        case 5:
          realList.sort(((a, b) => a.plPercentage.compareTo(a.plPercentage)));
          break;
        case 6:
          realList
              .sort(((a, b) => a.investedAmount.compareTo(b.investedAmount)));
          break;
        case 7:
          realList
              .sort(((a, b) => (b.investedAmount).compareTo(a.investedAmount)));
          break;
      }
    }
    return realList;
    // for (Intraday element in list) {
    //   if (element.categorydesc != "Bond" &&
    //       element.categorydesc != "Mutual Funds Units" &&
    //       element.categorydesc != "ETF") {
    //     if (filterarrayposition.isNotEmpty) {
    //       for (int i = 0; i < filterarrayposition.length; i++) {
    //         if (element.producttype ==
    //                 filterarrayposition[i].toUpperCase().toString() ||
    //             element.producttype
    //                 .endsWith(filterarrayposition[i].toUpperCase())) {
    //           finalList.add(element);
    //           // totalPl = totalPl + element.pl;
    //           // totalinvested = totalinvested + element.investedAmount;
    //           // totalCurrent = totalCurrent + element.currentAmount;
    //           // totalPercentage =
    //           //     ((totalCurrent - totalinvested) / totalCurrent) * 100;
    //         }
    //       }
    //       list = finalList;
    //     }
    //     if (filtersvalue != -1) {
    //       switch (filtersvalue) {
    //         case 0:
    //           list.sort(((a, b) => (a.securitycode).compareTo(b.securitycode)));
    //           break;
    //         case 1:
    //           list.sort(((a, b) => (a.securitycode).compareTo(b.securitycode)));
    //           list = list.reversed.toList();
    //           break;
    //         case 2:
    //           list.sort(((a, b) => a.pl.compareTo(b.pl)));
    //           break;
    //         case 3:
    //           list.sort(((a, b) => a.pl.compareTo(b.pl)));
    //           list = list.reversed.toList();
    //           break;
    //         case 4:
    //           list.sort(((a, b) => a.plPercentage.compareTo(b.plPercentage)));
    //           break;
    //         case 5:
    //           list.sort(((a, b) => a.plPercentage.compareTo(b.plPercentage)));
    //           list = list.reversed.toList();
    //           break;
    //         case 6:
    //           list.sort(
    //               ((a, b) => a.investedAmount.compareTo(b.investedAmount)));
    //           break;
    //         case 7:
    //           list.sort(
    //               ((a, b) => (a.investedAmount).compareTo(b.investedAmount)));
    //           list = list.reversed.toList();
    //           break;
    //       }
    //     }
    //   }
    // }
  }

  updatesortlist(int index) {
    filtersvalue = index;
    // equitycalculation(false);
    emitdata(equitylist);
  }

  updatefilterlist(List<String> productlist, int filtervalue) {
    filterarrayposition = productlist;
    // equitycalculation(false);
    emitdata(equitylist);
  }

  openinitial(List<Intraday> equitylist) {}

  subscribedata() {
    if (isClosed) return;
    streamSubscription = MDS_Controller()
        .marketUpdateStream
        .listen((List<FlairResponseModel> flairResponseModel) {
      if (searchvisible == false) {
        // for (HoldingModel holdingelement in equitylist) {}
        emitdata(equitylist);
      } else {
        return;
      }
    });
    // List<Instrument> list = MDS_Controller().subscribeSymbols(List.generate(
    //     equitylist.length, (index) => equitylist[index].instrument!));
    // for (var i = 0; i < list.length; i++) {
    //   equitylist[i].instrument = list[i];
    // }
    // emitdata(equitylist);
    List<Instrument> list = [];

    for (var element in equitylist) {
      list.add(element.instrument);
    }

    if (list.isNotEmpty) MDS_Controller().getLatestFeedUpdates(list);

    // List<Instrument> list = MDS_Controller().subscribeSymbols(List.generate(
    //     holdinglist.length, (index) => holdinglist[index].instrument!));
    // print(index);
    for (var i = 0; i < list.length; i++) {
      equitylist[i].instrument = list[i];
    }
    emitdata(equitylist);
  }

  // unsubscribeData() {
  //   if (!isClosed) {
  //     List<Instrument> list = [];
  //     for (var element in equitylist) {
  //       list.add(element.instrument);
  //     }
  //     if (list.isNotEmpty) MDS_Controller().unsubscribeSymbols(list);
  //   }
  // }

  emitdata(List<HoldingModel> holdlist) {
    double totlaPl = 0.0;
    double totalPercentage = 0.0;
    double totalinvested = 0.0;
    double totalCurrent = 0.00;
    List<HoldingModel> completelist = [];
    if (searchvisible == false) {
      completelist = updatesortfilter(holdlist);
    } else {
      completelist = holdlist;
    }

    totalCurrentInvest = 0.0;
    for (var element in completelist) {
      totalinvested =
          totalinvested + (element.availablenetqty * element.avgrate);
      totalCurrentInvest = totalCurrentInvest +
          (element.availablenetqty * element.instrument.lastTrdPrice);
      element.pl = (element.availablenetqty * element.instrument.lastTrdPrice) -
          (element.availablenetqty * element.avgrate);

      element.plPercentage = ((element.pl * 100) /
                      (element.avgrate * element.availablenetqty))
                  .isNaN ||
              ((element.pl * 100) / (element.avgrate * element.availablenetqty))
                  .isInfinite
          ? 0.00
          : (element.pl * 100) / (element.avgrate * element.availablenetqty);

      // print("## total invested = ${totalinvested}");
      // print("## total current amount = ${totalCurrentInvest}");

      totalPercentage = (totalPl * 100) / totalinvested;
    }

    totalPl = totalCurrentInvest - totalinvested;
    if (!isClosed) {
      emit(EquityListInitialState(
          equitylist: completelist,
          total_pl: totalPl,
          totla_pl_percentage: totalPercentage,
          searchvisible: searchvisible,
          filterarrayposition: filterarrayposition,
          filterval: filtersvalue));
    }
  }

  // equitycalculation(bool searchvisible) {
  //   if (isClosed) return;
  //   equitylist.clear();
  //   totalPl = 0.00;
  //   totalinvested = 0.00;
  //   totalPercentage = 0.00;
  //   totalCurrent = 0.00;

  //   updatesortfilter();

  //   for (Intraday element in list) {
  //     if (element.categorydesc != "Bond" &&
  //         element.categorydesc != "Mutual Funds Units" &&
  //         element.categorydesc != "ETF") {
  //       equitylist.add(element);

  //       totalPl = totalPl + element.pl;
  //       totalinvested = totalinvested + element.investedAmount;
  //       totalCurrent = totalCurrent + element.currentAmount;
  //       totalPercentage = ((totalCurrent - totalinvested) / totalCurrent) * 100;
  //     }
  //   }

  //   emit(EquityListInitialState(
  //       equitylist: equitylist,
  //       total_pl: totalPl,
  //       totla_pl_percentage: totalPercentage,
  //       searchvisible: searchvisible,
  //       filterarrayposition: filterarrayposition,
  //       filterval: filtersvalue));
  // }

  List<String> getDefaultSortOrder() {
    defaultSortOrder.clear();
    equitylist.forEach((element) {
      defaultSortOrder.add(element.instrument.getRicAddress());
    });
    return defaultSortOrder;
  }

  updateData() {
    if (isClosed) return;
    equitylist.clear();
    List.generate(UserController().portfolioresponce.result3.length, (index) {
      if (UserController().portfolioresponce.result3[index].categorydesc !=
              "Bond" &&
          UserController().portfolioresponce.result3[index].categorydesc !=
              "Mutual Funds Units" &&
          UserController().portfolioresponce.result3[index].categorydesc !=
              "ETF") {
        equitylist.add(HoldingModel.updateHoldingModel(
            UserController().portfolioresponce.result3[index]));
      }
    });
    // for (Intraday element in list) {
    //   if (element.categorydesc != "Bond" &&
    //       element.categorydesc != "Mutual Funds Units" &&
    //       element.categorydesc != "ETF") {
    //     equitylist.add(element);

    //     // totalPl = totalPl + element.pl;
    //     // totalinvested = totalinvested + element.investedAmount;
    //     // totalCurrent = totalCurrent + element.currentAmount;
    //     // totalPercentage = ((totalCurrent - totalinvested) / totalCurrent) * 100;
    //   }
    // }
    defaultSortOrder = getDefaultSortOrder();
    subscribedata();
    //   emitdata(positionlist);
  }
}

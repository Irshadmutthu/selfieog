// ignore_for_file: non_constant_identifier_names

import 'package:selfie_mobile_flutter/portfolio_model/Portfolio.dart';
import 'package:trading_api/responses/portfolio_responce.dart';

abstract class EquityListPageState {}

class EquityListInitialState extends EquityListPageState {
  List<HoldingModel> equitylist = [];
  double total_pl = 0.00;
  double totla_pl_percentage = 0.00;
  final bool searchvisible;
  List<String>? filter_elements;
  List<String> filterarrayposition = [];
  final int filterval;
  EquityListInitialState(
      {required this.equitylist,
      required this.total_pl,
      required this.totla_pl_percentage,
      this.searchvisible = false,
      this.filter_elements,
      required this.filterarrayposition,
      required this.filterval});
}

class EquityListEmptyState extends EquityListPageState {}

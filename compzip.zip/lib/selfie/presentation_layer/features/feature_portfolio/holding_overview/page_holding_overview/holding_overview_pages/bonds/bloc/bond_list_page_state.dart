import 'package:selfie_mobile_flutter/portfolio_model/Portfolio.dart';
import 'package:trading_api/responses/portfolio_responce.dart';

abstract class BondListPageState {}

class BondListInitialState extends BondListPageState {
  List<HoldingModel> bondlist = [];
  double totalPl = 0.00;
  double totlaPlPercentage = 0.00;
  final bool searchvisible;
  List<String>? filterElements;
  List<String> filterarrayposition = [];
  final int filterval;

  BondListInitialState(
      {required this.bondlist,
      required this.totalPl,
      required this.totlaPlPercentage,
      this.filterElements,
      this.searchvisible = false,
      required this.filterarrayposition,
      required this.filterval});
}

class BondListEmptyState extends BondListPageState {}

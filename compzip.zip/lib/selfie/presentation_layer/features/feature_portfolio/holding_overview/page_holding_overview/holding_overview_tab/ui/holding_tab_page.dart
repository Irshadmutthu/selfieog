import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/bloc_navigation/navigation_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/page_holding_overview/holding_overview_pages/bonds/bonds_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/page_holding_overview/holding_overview_pages/equity/equity_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/page_holding_overview/holding_overview_pages/etfs/etfs_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/page_holding_overview/holding_overview_pages/mutual_funds/mutual_fund.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_top_tab.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';

const List<String> holdingTabItem = ["Equity", "ETFs", "Bonds", "Mutual Funds"];
function(int a, [String? b]) {
  List a = [];
  a.sort();
}

class HoldingTabPage extends StatelessWidget {
  final int tabIndex;
  final String tabName;
  const HoldingTabPage(
      {Key? key, required this.tabIndex, required this.tabName})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomAppBarInner(
              title: "Holdings",
              onBackPressed: () {
                // context.gNavigationService.back(context);
                BlocProvider.of<NavigationCubit>(context).updateWatchList(5);
              }),
          Expanded(
            child: CustomTabBar(
              isScrollable: true,
              tabContent: holdingTabItem,
              selected: tabIndex,
              tabBarViewChildern: const [
                EquityPage(),
                ETFSPage(),
                BondsPage(),
                MutualFundPage(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}


// class HoldingTabPage extends StatelessWidget {
//   int tabIndex = 0;
//   String tabName = "";
//   HoldingTabPage({Key? key, required Map<String, dynamic> args})
//       : super(key: key) {
//     tabIndex = args["tabIndex"] ?? 0;
//     tabName = args["pageName"] ?? "";
//   }

//   @override
//   Widget build(BuildContext context) {
//     // print("from holding tab" + widget.mapArguments.toString());
//     return Scaffold(
//       appBar: PreferredSize(
//           preferredSize: const Size.fromHeight(0.0),
//           child: AppBar(
//             elevation: 0,
//             backgroundColor: customColors().backgroundPrimary,
//           )),
//       body: Column(
//         mainAxisAlignment: MainAxisAlignment.start,
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           CustomAppBarInner(
//               title: "Holdings",
//               onBackPressed: () {
//                 // context.gNavigationService.back(context);
//                 BlocProvider.of<NavigationCubit>(context).updateWatchList(5);
//               }),
//           Expanded(
//             child: CustomTabBar(
//               isScrollable: true,
//               tabContent: holdingTabItem,
//               selected: tabIndex,
//               tabBarViewChildern: const [
//                 EquityPage(),
//                 ETFSPage(),
//                 BondsPage(),
//                 MutualFundPage(),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

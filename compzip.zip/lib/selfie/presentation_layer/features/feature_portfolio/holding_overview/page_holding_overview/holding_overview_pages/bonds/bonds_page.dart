import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/constants/enums.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/bloc_navigation/navigation_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/bloc/holding_overview_screen_state.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/page_holding_overview/holding_overview_pages/bonds/bloc/bond_list_page_state.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/portfolio_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/portfolio_holding_filter_bar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/search_inisights_type_filter.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/position_search_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/sort.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/holdings/holdings_etf_tile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/holdings/holdings_widgets.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/portfolio_card/holdings_card.dart';

import 'bloc/bond_list_cubit.dart';

class BondsPage extends StatefulWidget {
  const BondsPage({Key? key}) : super(key: key);

  @override
  State<BondsPage> createState() => _BondsPageState();
}

class _BondsPageState extends State<BondsPage>
    with AutomaticKeepAliveClientMixin<BondsPage> {
  final _editcontroller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;

    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (context) => BondListCubit()),
      ],
      child: SingleChildScrollView(
        physics: ScrollPhysics(),
        child: Column(
          children: [
            SingleChildScrollView(
              physics: ScrollPhysics(),
              child: Column(
                children: [
                  BlocListener<NavigationCubit, NavigationState>(
                    listener: (context, state) {
                      if (state is WatchlistIndexState)
                        BlocProvider.of<BondListCubit>(context).updatedata();
                    },
                    child: Container(),
                  ),
                  BlocBuilder<BondListCubit, BondListPageState>(
                      builder: (context, state) {
                    if (state is BondListInitialState) {
                      return Column(
                        children: [
                          state.bondlist.isEmpty &&
                                  state.filterarrayposition.isNotEmpty
                              ? Column(
                                  children: [
                                    const SizedBox(
                                      height: 16,
                                    ),
                                    HoldingsCard(
                                      amount: state.totalPl,
                                      percentage: state.totlaPlPercentage
                                          .toStringAsFixed(2),
                                      height: screenSize.height * 0.13,
                                    ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                  ],
                                )
                              : SizedBox(),
                          state.bondlist.isNotEmpty &&
                                  state.searchvisible == false
                              ? Column(
                                  children: [
                                    const SizedBox(
                                      height: 16,
                                    ),
                                    HoldingsCard(
                                      amount: state.totalPl,
                                      percentage: state.totlaPlPercentage
                                          .toStringAsFixed(2),
                                      height: screenSize.height * 0.13,
                                    ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                  ],
                                )
                              : SizedBox(),
                          Column(
                            children: [
                              if (state.bondlist.isEmpty &&
                                  !state.searchvisible)
                                SingleChildScrollView(
                                  child: Column(children: [
                                    if (state.filterarrayposition.isNotEmpty)
                                      Column(
                                        children: [
                                          SearchFilterHoldings(
                                            showInsights: false,
                                            showBubble: state
                                                .filterarrayposition.isNotEmpty,
                                            showBubbleSort:
                                                state.filterval != -1,
                                            onSearchPress: () {
                                              BlocProvider.of<BondListCubit>(
                                                      context)
                                                  .opensearch();
                                            },
                                            onFilterPress: () {
                                              customShowModalBottomSheet(
                                                  context: context,
                                                  inputWidget:
                                                      PortfolioSortList(
                                                    currentval: state.filterval,
                                                    filterlist:
                                                        state.filterElements,
                                                    filterarrayposition: state
                                                        .filterarrayposition,
                                                    selectedLocation:
                                                        SortFilterLocation
                                                            .holding,
                                                    onPressFilter:
                                                        (List<String> el) {
                                                      state.filterElements =
                                                          List.from(el);
                                                      BlocProvider.of<
                                                                  BondListCubit>(
                                                              context)
                                                          .updateFilterlist(el);
                                                    },
                                                    onPressSort: (int index) {
                                                      BlocProvider.of<
                                                                  BondListCubit>(
                                                              context)
                                                          .updateSortList(
                                                              index);
                                                      Navigator.pop(context);
                                                    },
                                                    onPressReset: () {
                                                      BlocProvider.of<
                                                                  BondListCubit>(
                                                              context)
                                                          .resetfilter();
                                                      //     filterarrayposition.clear();
                                                      Navigator.pop(context);
                                                    },
                                                  ));
                                            },
                                            onSortPress: () {
                                              customShowModalBottomSheet(
                                                  context: context,
                                                  inputWidget:
                                                      PortfolioSortList(
                                                    currentval: state.filterval,
                                                    filterarrayposition: state
                                                        .filterarrayposition,
                                                    filterlist:
                                                        state.filterElements,
                                                    selectedLocation:
                                                        SortFilterLocation
                                                            .holding,
                                                    selectedTabIndex: 1,
                                                    onPressFilter: (List<String>
                                                        elements) {
                                                      state.filterElements =
                                                          List.from(elements);
                                                      BlocProvider.of<
                                                                  BondListCubit>(
                                                              context)
                                                          .updateFilterlist(
                                                              elements);
                                                    },
                                                    onPressSort: (int value) {
                                                      BlocProvider.of<
                                                                  BondListCubit>(
                                                              context)
                                                          .updateSortList(
                                                              value);
                                                      Navigator.pop(context);
                                                    },
                                                    onPressReset: () {
                                                      BlocProvider.of<
                                                                  BondListCubit>(
                                                              context)
                                                          .resetfilter();
                                                      //       filterarrayposition.clear();
                                                      Navigator.pop(context);
                                                    },
                                                  ));
                                            },
                                          ),
                                        ],
                                      )
                                    else
                                      Column(
                                        children: [
                                          const SizedBox(
                                            height: 6,
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(top: 100),
                                            child:
                                                emptyContainerPortfolioHoldings(
                                                    context),
                                          )
                                        ],
                                      )
                                  ]),
                                )
                              else if (state.searchvisible)
                                SingleChildScrollView(
                                  physics: ScrollPhysics(),
                                  child: Column(children: [
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.0),
                                      child: Position_Search_Field(
                                          onBackPressed: () {
                                            _editcontroller.clear();
                                            BlocProvider.of<BondListCubit>(
                                                    context)
                                                .resetfilter();
                                          },
                                          hintText: "Search eg: infy",
                                          controller: _editcontroller,
                                          onSearch: (String keyword) {
                                            if (keyword.isEmpty) {
                                              BlocProvider.of<BondListCubit>(
                                                      context)
                                                  .updatesearch(keyword);
                                            } else {
                                              BlocProvider.of<BondListCubit>(
                                                      context)
                                                  .updatesearch(keyword);
                                            }
                                          }),
                                    ),
                                    ListView.builder(
                                        physics:
                                            const NeverScrollableScrollPhysics(),
                                        itemCount: state.bondlist.length,
                                        shrinkWrap: true,
                                        itemBuilder: (context, index) {
                                          return HoldingsETF_Tile(
                                            etflist: state.bondlist[index],
                                          );
                                        }),
                                  ]),
                                )
                              else if (state.searchvisible == false)
                                SingleChildScrollView(
                                  physics: ScrollPhysics(),
                                  child: Column(
                                    children: [
                                      SearchFilterHoldings(
                                        showInsights: false,
                                        showBubble: state
                                            .filterarrayposition.isNotEmpty,
                                        showBubbleSort: state.filterval != -1,
                                        onSearchPress: () {
                                          BlocProvider.of<BondListCubit>(
                                                  context)
                                              .opensearch();
                                        },
                                        onFilterPress: () {
                                          customShowModalBottomSheet(
                                              context: context,
                                              inputWidget: PortfolioSortList(
                                                currentval: state.filterval,
                                                filterlist:
                                                    state.filterElements,
                                                filterarrayposition:
                                                    state.filterarrayposition,
                                                selectedLocation:
                                                    SortFilterLocation.holding,
                                                onPressFilter:
                                                    (List<String> el) {
                                                  state.filterElements =
                                                      List.from(el);
                                                  BlocProvider.of<
                                                              BondListCubit>(
                                                          context)
                                                      .updateFilterlist(el);
                                                },
                                                onPressSort: (int index) {
                                                  BlocProvider.of<
                                                              BondListCubit>(
                                                          context)
                                                      .updateSortList(index);
                                                  Navigator.pop(context);
                                                },
                                                onPressReset: () {
                                                  BlocProvider.of<
                                                              BondListCubit>(
                                                          context)
                                                      .resetfilter();
                                                  //     filterarrayposition.clear();
                                                  Navigator.pop(context);
                                                },
                                              ));
                                        },
                                        onSortPress: () {
                                          customShowModalBottomSheet(
                                              context: context,
                                              inputWidget: PortfolioSortList(
                                                currentval: state.filterval,
                                                filterarrayposition:
                                                    state.filterarrayposition,
                                                filterlist:
                                                    state.filterElements,
                                                selectedLocation:
                                                    SortFilterLocation.holding,
                                                selectedTabIndex: 1,
                                                onPressFilter:
                                                    (List<String> elements) {
                                                  state.filterElements =
                                                      List.from(elements);
                                                  BlocProvider.of<
                                                              BondListCubit>(
                                                          context)
                                                      .updateFilterlist(
                                                          elements);
                                                },
                                                onPressSort: (int value) {
                                                  BlocProvider.of<
                                                              BondListCubit>(
                                                          context)
                                                      .updateSortList(value);
                                                  Navigator.pop(context);
                                                },
                                                onPressReset: () {
                                                  BlocProvider.of<
                                                              BondListCubit>(
                                                          context)
                                                      .resetfilter();
                                                  //       filterarrayposition.clear();
                                                  Navigator.pop(context);
                                                },
                                              ));
                                        },
                                      ),
                                      ListView.builder(
                                          physics:
                                              const NeverScrollableScrollPhysics(),
                                          itemCount: state.bondlist.length,
                                          shrinkWrap: true,
                                          itemBuilder: (context, index) {
                                            //  return Text(state.bondlist[index].instrument!.lastTrdPrice.toString());
                                            return HoldingsETF_Tile(
                                              etflist: state.bondlist[index],
                                            );
                                          }),
                                    ],
                                  ),
                                )
                            ],
                          )
                        ],
                      );
                    } else {
                      return Container();
                    }
                  })
                ],
              ),
            )
          ],
        ),
      ),
    );

    // return SingleChildScrollView(
    //   child: Column(
    //     mainAxisAlignment: MainAxisAlignment.start,
    //     crossAxisAlignment: CrossAxisAlignment.center,
    //     children: [
    //       const SizedBox(height: 20),
    //       // HoldingsCard(
    //       //   amount: 123890.54,
    //       //   percentage: "10.10",
    //       //   status: true,
    //       //   height: screenSize.height * 0.13,
    //       // ),
    //       // const SizedBox(height: 24),
    //       // SearchFilterHoldings(showInsights: false),
    //       // ListView.builder(
    //       //     physics: const NeverScrollableScrollPhysics(),
    //       //     itemCount: holdingsBonds.length,
    //       //     shrinkWrap: true,
    //       //     itemBuilder: (context, index) {
    //       //       return HoldingsETF_Tile(
    //       //         Portfoliolist: holdingsBonds[index],
    //       //       );
    //       //     }),
    //       const SizedBox(
    //         height: 6,
    //       ),
    //       Padding(
    //         padding: EdgeInsets.only(top: 100),
    //         child: emptyContainerPortfolioHoldings(context),
    //       )
    //     ],
    //   ),
    // );
  }

  @override
  bool get wantKeepAlive => true;
}

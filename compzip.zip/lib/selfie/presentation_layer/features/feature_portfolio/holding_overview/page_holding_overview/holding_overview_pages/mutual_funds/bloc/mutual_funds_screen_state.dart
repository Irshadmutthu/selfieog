import 'package:selfie_mobile_flutter/portfolio_model/Portfolio.dart';
import 'package:trading_api/responses/portfolio_responce.dart';

abstract class MutualFundsListPageState {}

class MutualFundsInitialState extends MutualFundsListPageState {
  List<HoldingModel> mutallist = [];
  double totalPl = 0.00;
  double totlaPlPercentage = 0.00;
  final bool searchvisible;
  List<String>? filterElements;
  List<String> filterarrayposition = [];
  final int filterval;

  MutualFundsInitialState(
      {required this.mutallist,
      required this.totalPl,
      required this.totlaPlPercentage,
      this.filterElements,
      this.searchvisible = false,
      required this.filterarrayposition,
      required this.filterval});
}

class MutualFundsEmptyState extends MutualFundsListPageState {}

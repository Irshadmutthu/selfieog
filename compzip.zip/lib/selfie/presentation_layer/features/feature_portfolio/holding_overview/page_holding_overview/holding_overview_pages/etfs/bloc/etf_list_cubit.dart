import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/portfolio_model/Portfolio.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/page_holding_overview/holding_overview_pages/etfs/bloc/etf_list_page_state.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/portfolio_content.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/portfolio_responce.dart';

class EtfListCubit extends Cubit<EtfListPageState> {
  double totalPl = 0.00;
  double totalPercentage = 0.00;
  List<Intraday> list = [];
  List<HoldingModel> etflist = [];
  double totalinvested = 0.0;
  double totalCurrent = 0.00;
  int filteredvalue = -1;
  List<String> filterarrayposition = [];
  List<String> defaultSortOrder = [];
  StreamSubscription? streamSubscription;
  bool searchvisible = false;
  double totalCurrentInvest = 0.0;
  EtfListCubit() : super(EtfListEmptyState()) {
    // etfcalculations(false);
    updatedata();
  }

  resetfilter() {
    filterarrayposition.clear();
    filteredvalue = -1;
    searchvisible = false;
    //   equitycalculation(false);
    List<HoldingModel> list = [];

    defaultSortOrder.forEach((ric) {
      for (var element in etflist) {
        if (ric == element.instrument.getRicAddress()) {
          list.add(element);
        }
      }
    });
    etflist = list;
    emitdata(etflist);
  }

  List<HoldingModel> updatesortfilter(List<HoldingModel> myetflist) {
    // list =
    //     List.from(UserController().portfolioresponce.result3, growable: true);

    List<HoldingModel> realList = myetflist;

    List<HoldingModel> finalList = [];

    if (filterarrayposition.isNotEmpty) {
      for (var element in realList) {
        for (int i = 0; i < filterarrayposition.length; i++) {
          if (element.producttype == filterarrayposition[i].toUpperCase() ||
              element.producttype
                  .endsWith(filterarrayposition[i].toUpperCase())) {
            finalList.add(element);
          }
        }
      }
      realList = List.from(finalList);
    }
    if (filteredvalue != -1) {
      switch (filteredvalue) {
        case 0:
          realList.sort(((a, b) => (a.instrument.securityCode)
              .compareTo(b.instrument.securityCode)));
          break;
        case 1:
          realList.sort(((a, b) => (b.instrument.securityCode)
              .compareTo(a.instrument.securityCode)));
          break;
        case 2:
          realList.sort(((a, b) => a.pl.compareTo(b.pl)));
          break;
        case 3:
          realList.sort(((a, b) => b.pl.compareTo(a.pl)));
          break;
        case 4:
          realList.sort(((a, b) => a.plPercentage.compareTo(b.plPercentage)));
          break;
        case 5:
          realList.sort(((a, b) => a.plPercentage.compareTo(a.plPercentage)));
          break;
        case 6:
          realList
              .sort(((a, b) => a.investedAmount.compareTo(b.investedAmount)));
          break;
        case 7:
          realList
              .sort(((a, b) => (b.investedAmount).compareTo(a.investedAmount)));
          break;
      }
    }
    return realList;
    // for (Intraday element in list) {
    //   if (element.categorydesc == "ETF") {
    //     if (filterarrayposition.isNotEmpty) {
    //       for (int i = 0; i < filterarrayposition.length; i++) {
    //         if (element.producttype ==
    //                 filterarrayposition[i].toUpperCase().toString() ||
    //             element.producttype
    //                 .endsWith(filterarrayposition[i].toUpperCase())) {
    //           finalList.add(element);
    //           // totalPl = totalPl + element.pl;
    //           // totalinvested = totalinvested + element.investedAmount;
    //           // totalCurrent = totalCurrent + element.currentAmount;
    //           // totalPercentage =
    //           //     ((totalCurrent - totalinvested) / totalCurrent) * 100;
    //         }
    //       }
    //       list = finalList;
    //     }
    //     if (filteredvalue != -1) {
    //       switch (filteredvalue) {
    //         case 0:
    //           list.sort(((a, b) => (a.securitycode).compareTo(b.securitycode)));
    //           break;
    //         case 1:
    //           list.sort(((a, b) => (a.securitycode).compareTo(b.securitycode)));
    //           list = list.reversed.toList();
    //           break;
    //         case 2:
    //           list.sort(((a, b) => a.pl.compareTo(b.pl)));
    //           break;
    //         case 3:
    //           list.sort(((a, b) => a.pl.compareTo(b.pl)));
    //           list = list.reversed.toList();
    //           break;
    //         case 4:
    //           list.sort(((a, b) => a.plPercentage.compareTo(b.plPercentage)));
    //           break;
    //         case 5:
    //           list.sort(((a, b) => a.plPercentage.compareTo(b.plPercentage)));
    //           list = list.reversed.toList();
    //           break;
    //         case 6:
    //           list.sort(
    //               ((a, b) => a.investedAmount.compareTo(b.investedAmount)));
    //           break;
    //         case 7:
    //           list.sort(
    //               ((a, b) => (a.investedAmount).compareTo(b.investedAmount)));
    //           list = list.reversed.toList();
    //           break;
    //       }
    //     }
    //   }
    // }
  }

  updateFilterlist(List<String> productlist, int filtervalue) {
    filterarrayposition = productlist;
    emitdata(etflist);
  }

  updateSortList(int index) {
    filteredvalue = index;
    emitdata(etflist);
  }

  opensearch() {
    searchvisible = true;
    emitdata(etflist);
  }

  updatesearch(String key) {
    List<HoldingModel>? searchabledata = [];
    searchabledata.clear();
    etflist.forEach((element) {
      if (element.securitycode1.startsWith(key.toUpperCase()) ||
          element.securitycode1.contains(key.toUpperCase())) {
        searchabledata.add(element);
      }
    });
    emitdata(searchabledata);
    //  etfcalculations(true);
  }

  // etfcalculations(bool searchval) {
  //   if (isClosed) return;
  //   etflist.clear();
  //   totalPl = 0.00;
  //   totalinvested = 0.00;
  //   totalPercentage = 0.00;
  //   totalCurrent = 0.00;

  //   updatesortfilter();

  //   // for (Holding element in list) {
  //   //   if (element.categorydesc == "ETF") {
  //   //     etflist.add(element);

  //   //     totalPl = totalPl + element.pl;
  //   //     totalinvested = totalinvested + element.investedAmount;
  //   //     totalCurrent = totalCurrent + element.currentAmount;
  //   //     totalPercentage = ((totalinvested - totalCurrent) / totalCurrent) * 100;
  //   //   }
  //   // }

  //   emit(EtfListInitialState(
  //       etflist: etflist,
  //       totalPl: totalPl,
  //       totlaPlPercentage: totalPercentage,
  //       filterarrayposition: filterarrayposition,
  //       filterval: filteredvalue,
  //       searchvisible: searchval));
  // }

  subscribedata() {
    if (isClosed) return;
    streamSubscription = MDS_Controller()
        .marketUpdateStream
        .listen((List<FlairResponseModel> flairResponseModel) {
      if (searchvisible == false) {
        emitdata(etflist);
      } else {
        return;
      }
    });
    // List<Instrument> list = MDS_Controller().subscribeSymbols(
    //     List.generate(etflist.length, (index) => etflist[index].instrument!));
    // for (var i = 0; i < list.length; i++) {
    //   etflist[i].instrument = list[i];
    // }
    // emitdata(etflist);
    List<Instrument> list = [];

    for (var element in etflist) {
      list.add(element.instrument);
    }
    MDS_Controller().subscribeSymbols(list);
    // List<Instrument> list = MDS_Controller().subscribeSymbols(List.generate(
    //     holdinglist.length, (index) => holdinglist[index].instrument!));
    // print(index);
    for (var i = 0; i < list.length; i++) {
      etflist[i].instrument = list[i];
    }
    emitdata(etflist);
  }

  List<String> getDefaultSortOrder() {
    defaultSortOrder.clear();
    etflist.forEach((element) {
      defaultSortOrder.add(element.instrument.getRicAddress());
    });
    return defaultSortOrder;
  }

  emitdata(List<HoldingModel> holdlist) {
    double totlaPl = 0.0;
    double totalPercentage = 0.0;
    double totalinvested = 0.0;
    double totalCurrent = 0.00;
    List<HoldingModel> completelist = [];
    if (searchvisible == false) {
      completelist = updatesortfilter(holdlist);
    } else {
      completelist = holdlist;
    }

    totalCurrentInvest = 0.0;
    for (var element in completelist) {
      totalinvested =
          totalinvested + (element.availablenetqty * element.avgrate);
      totalCurrentInvest = totalCurrentInvest +
          (element.availablenetqty * element.instrument.lastTrdPrice);
      element.pl = (element.availablenetqty * element.instrument.lastTrdPrice) -
          (element.availablenetqty * element.avgrate);

      element.plPercentage = ((element.pl * 100) /
                      (element.avgrate * element.availablenetqty))
                  .isNaN ||
              ((element.pl * 100) / (element.avgrate * element.availablenetqty))
                  .isInfinite
          ? 0.00
          : (element.pl * 100) / (element.avgrate * element.availablenetqty);
      totalPercentage = (totalPl * 100) / totalinvested;
    }
    totalPl = totalCurrentInvest - totalinvested;
    if (!isClosed) {
      emit(EtfListInitialState(
          etflist: completelist,
          totalPl: totalPl,
          totlaPlPercentage: totalPercentage,
          filterarrayposition: filterarrayposition,
          filterval: filteredvalue,
          searchvisible: searchvisible));
    }
  }

  updatedata() {
    if (isClosed) return;
    etflist.clear();
    List.generate(UserController().portfolioresponce.result3.length, (index) {
      if (UserController().portfolioresponce.result3[index].categorydesc ==
          "ETF") {
        etflist.add(HoldingModel.updateHoldingModel(
            UserController().portfolioresponce.result3[index]));
      }
    });
    defaultSortOrder = getDefaultSortOrder();
    subscribedata();
  }
}

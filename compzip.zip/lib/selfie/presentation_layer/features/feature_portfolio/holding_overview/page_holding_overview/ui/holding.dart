import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/bloc_navigation/navigation_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/bloc/holding_overview_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/bloc/holding_overview_screen_state.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/my_portfolio/bloc/my_portfolio_screen_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/my_portfolio/tab_component_holdings/bloc/holdings_component_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarInner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/card_items/card_item.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/portfolio_card/invetment_card.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/portfolio_card/profit_and_loss_details.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';

class HoldingPage extends StatefulWidget {
  const HoldingPage({Key? key}) : super(key: key);

  @override
  State<HoldingPage> createState() => _HoldingPageState();
}

class _HoldingPageState extends State<HoldingPage> {
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => HoldingOverviewScreenCubit(context),
        ),
      ],
      child:
          BlocBuilder<HoldingOverviewScreenCubit, HoldingOverViewScreenState>(
              builder: (context, state) {
        return Scaffold(
          appBar: PreferredSize(
              preferredSize: const Size.fromHeight(0.0),
              child: AppBar(
                elevation: 0,
                backgroundColor: customColors().backgroundPrimary,
              )),
          body: SingleChildScrollView(
            child: Column(
              children: [
                BlocListener<NavigationCubit, NavigationState>(
                  listener: (context, state) {
                    if (state is WatchlistIndexState) {
                      BlocProvider.of<HoldingOverviewScreenCubit>(context)
                          .updateData();
                    }
                  },
                  child: Container(),
                ),
                if (state is HoldingOverViewScreenInitial)
                  Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 5),
                        child: CustomAppBarInner(
                            title: "Holding Overview",
                            onBackPressed: () {
                              BlocProvider.of<NavigationCubit>(context)
                                  .updateWatchList(1);
                            }),
                      ),
                      const SizedBox(height: 5),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            InvestmentDetailCard(
                              amount: state.totalinvested,
                              title: "INVESTED",
                              height: screenSize.height * 0.12,
                              width: screenSize.width * 0.44,
                            ),
                            const Expanded(child: SizedBox(width: 12)),
                            InvestmentDetailCard(
                              amount: state.totalCurrentInvested,
                              title: "CURRENT",
                              width: screenSize.width * 0.44,
                              height: screenSize.height * 0.12,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: ProfitAndLossDetails(
                          todayAmount: state.todaysPl,
                          todayStatus: false,
                          todayPercentage:
                              state.todyasPlPercentage.toStringAsFixed(2),
                          totalAmount: state.pl,
                          totalPercentage: state.plPercentage.toString(),
                          totalStatus: true,
                          height: screenSize.height * 0.14,
                        ),
                      ),
                      const SizedBox(height: 20),
                      CardItem(
                        color: customColors().mattPurple,
                        current: state.overviewlist.isEmpty
                            ? "0"
                            : state.overviewlist["Equity"][1],
                        profitLoss: state.overviewlist.isEmpty
                            ? "0"
                            : state.overviewlist["Equity"][2].toString(),
                        invested: state.overviewlist.isEmpty
                            ? "0"
                            : state.overviewlist["Equity"][0],
                        holdingPercentage: state.overviewlist.isEmpty
                            ? "0"
                            : state.overviewlist["Equity"][3].toString(),
                        category: "Equity",
                        onPress: () {
                          BlocProvider.of<NavigationCubit>(context)
                              .updateWatchList(6,
                                  args: {"tabIndex": 0, "pageName": "Equity"});
                          // context.gNavigationService.openEquityPage(
                          //     context, {"tabIndex": 0, "pageName": "Equity"});
                        },
                        stockcount: state.overviewlist.isEmpty
                            ? "0"
                            : state.overviewlist["Equity"][4].length.toString(),
                        stockType: "Stocks",
                        icon: "assets/filled_arrow.png",
                      ),
                      const SizedBox(height: 17),
                      CardItem(
                        color: customColors().dodgerBlue,
                        invested: state.overviewlist.isEmpty
                            ? "0"
                            : state.overviewlist["Etf"][0].toString(),
                        current: state.overviewlist.isEmpty
                            ? "0"
                            : state.overviewlist["Etf"][1].toString(),
                        profitLoss: state.overviewlist.isEmpty
                            ? "0"
                            : state.overviewlist["Etf"][2].toString(),
                        holdingPercentage: state.overviewlist.isEmpty
                            ? "0"
                            : state.overviewlist["Etf"][3].toString(),
                        category: "ETFs",
                        change: "N",
                        onPress: () {
                          BlocProvider.of<NavigationCubit>(context)
                              .updateWatchList(6,
                                  args: {"tabIndex": 1, "pageName": "ETFs"});
                          // context.gNavigationService.openEquityPage(
                          //     context, {"tabIndex": 1, "pageName": "ETFs"});
                        },
                        stockcount: state.overviewlist.isEmpty
                            ? "0"
                            : state.overviewlist["Etf"][4].length.toString(),
                        stockType: "ETFs",
                        icon: "assets/filled_arrow.png",
                      ),
                      const SizedBox(height: 17),
                      CardItem(
                        color: customColors().pacificBlue,
                        invested: state.overviewlist.isEmpty
                            ? "0"
                            : state.overviewlist["Bond"][0],
                        current: state.overviewlist.isEmpty
                            ? "0"
                            : state.overviewlist["Bond"][1],
                        profitLoss: state.overviewlist.isEmpty
                            ? "0"
                            : state.overviewlist["Bond"][2].toString(),
                        isProfit: false,
                        holdingPercentage: state.overviewlist.isEmpty
                            ? "0"
                            : state.overviewlist["Bond"][4].toString(),
                        category: "Bonds",
                        onPress: () {
                          BlocProvider.of<NavigationCubit>(context)
                              .updateWatchList(6,
                                  args: {"tabIndex": 2, "pageName": "Bonds"});

                          // context.gNavigationService.openEquityPage(
                          //     context, {"tabIndex": 2, "pageName": "Bonds"});
                        },
                        stockcount: state.overviewlist.isEmpty
                            ? "0"
                            : state.overviewlist["Bond"][3].length.toString(),
                        stockType: "Bonds",
                        icon: "assets/filled_arrow.png",
                      ),
                      const SizedBox(height: 17),
                      CardItem(
                        color: customColors().islandAqua,
                        invested: state.overviewlist.isEmpty
                            ? "0"
                            : state.overviewlist["MutualFunds"][0],
                        current: state.overviewlist.isEmpty
                            ? "0"
                            : state.overviewlist["MutualFunds"][1],
                        profitLoss: state.overviewlist.isEmpty
                            ? "0"
                            : state.overviewlist["MutualFunds"][2].toString(),
                        holdingPercentage: state.overviewlist.isEmpty
                            ? "0"
                            : state.overviewlist["MutualFunds"][4].toString(),
                        category: "Mutual Funds",
                        onPress: () {
                          BlocProvider.of<NavigationCubit>(context)
                              .updateWatchList(6, args: {
                            "tabIndex": 3,
                            "pageName": "Mutual Funds"
                          });

                          // context.gNavigationService.openEquityPage(
                          //     context, {"tabIndex": 3, "pageName": "Mutual Funds"});
                        },
                        stockcount: state.overviewlist.isEmpty
                            ? "0"
                            : state.overviewlist["MutualFunds"][3].length
                                .toString(),
                        stockType: "Funds",
                        icon: "assets/filled_arrow.png",
                      ),
                      const SizedBox(height: 17),
                      const SizedBox(height: 17),
                    ],
                  )
              ],
            ),
          ),
        );
      }),
    );
  }
}

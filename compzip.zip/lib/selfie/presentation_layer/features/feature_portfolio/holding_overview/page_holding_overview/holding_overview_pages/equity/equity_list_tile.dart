import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/portfolio_model/Portfolio.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_dot.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/options_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/watchlist/custom_watchlist_content/custom_watchlist_content.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:trading_api/responses/portfolio_responce.dart';

import '../../../../../../../../utils/common_prop.dart';

class EquityListTile extends StatefulWidget {
  HoldingModel reportData;
  EquityListTile({Key? key, required this.reportData}) : super(key: key);

  @override
  State<EquityListTile> createState() => _EquityListTileState();
}

class _EquityListTileState extends State<EquityListTile> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
            border: Border(
          bottom:
              BorderSide(color: customColors().backgroundTertiary, width: 1),
        )),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 0.0),
                        child: getProductTypeWidget(
                            widget.reportData.producttype.toString()),
                      ),
                    ],
                  ),
                  Text(
                    getFeedText(widget.reportData.plPercentage),
                    style: customTextStyle(
                      fontStyle: FontStyle.BodyM_Regular,
                      color: getFeedColor(widget.reportData.plPercentage),
                    ),
                  )
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    SymbolName(widget.reportData.securitycode1.toString()),
                    Text(
                      getFeedText(widget.reportData.pl),
                      style: customTextStyle(
                          fontStyle: FontStyle.BodyL_SemiBold,
                          color: getFeedColor(widget.reportData.pl)),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.only(top: 4.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          widget.reportData.availablenetqty.toInt().toString(),
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.FontSecondary),
                        ),
                        Text(
                          " Qty",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_Regular,
                              color: FontColor.FontTertiary),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                          child: CustomDot(color: customColors().fontSecondary),
                        ),
                        Text(
                          "Avg ",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_Regular,
                              color: FontColor.FontTertiary),
                        ),
                        Text(
                          widget.reportData.avgrate.toString(),
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.FontSecondary),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Text(
                          "LTP ",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_Regular,
                              color: FontColor.FontTertiary),
                        ),
                        Text(
                          widget.reportData.instrument.lastTrdPrice
                              .toStringAsFixed(
                                  widget.reportData.instrument.precision),
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyM_SemiBold,
                              color: FontColor.FontSecondary),
                        )
                      ],
                    )
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

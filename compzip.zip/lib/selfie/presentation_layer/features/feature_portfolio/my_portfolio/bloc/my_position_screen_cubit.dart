import 'dart:async';
import 'package:flutter/material.dart';
import 'package:bloc/bloc.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/portfolio_model/Portfolio.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/bloc_navigation/navigation_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_ipo/components/ipo_list_model.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/my_portfolio/bloc/position_screen_state.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/portfolio_responce.dart';
import 'package:trading_api/responses/symbol_details_response.dart';

class MyPositionScreenCubit extends Cubit<PositionScreenState> {
  TradingApiGateway apiGateway;
  PortfolioResponce? positionResponce;
  SymbolDetailResponse? response;
  List<Map<String, dynamic>> positionResponceMap = [];
  Map<String, List<PositionModel>> mapPositionlist = {};
  List<String> filterarrayposition = [];
  int filteredvalue = -1;
  bool searchvisible = false;
  List<Result4> list = [];
  double totlaPl = 0.0;
  double totalPercentage = 0.0;
  double totalinvested = 0.0;
  double totalTodayspl = 0.0;
  double totalCurrent = 0.00;
  List<PositionModel> positionlist = [];
  List<String> defaultSortOrder = [];
  StreamSubscription? streamSubscription;
  BuildContext mycontext;
  double totalCurrentInvest = 0.0;
  MyPositionScreenCubit(this.apiGateway, this.mycontext)
      : super(MyPositionScreenloading()) {
    updateData();
    mycontext.read<NavigationCubit>().adcontroller.stream.listen((event) {
      if (!isClosed) {
        if (event != 1 && event != 5 && event != 6) {
          unsubscribeSymbols();
        }
      }
    });
  }

  subscribeSymbols() {
    //  if (isClosed) return;
    streamSubscription = MDS_Controller()
        .marketUpdateStream
        .listen((List<FlairResponseModel> flairResponseModel) {
      if (searchvisible == false) {
        flairResponseModel.forEach((elements) {
          if (mapPositionlist.containsKey(elements.ric)) {
            mapPositionlist[elements.ric]!.forEach((element) {
              totlaPl = totlaPl - element.pl;
              totalTodayspl = totalTodayspl - element.todaysPl;
              // element.instrument.lastTrdPrice =
              //     elements.instrument.lastTrdPrice;
              totlaPl = totlaPl + element.gtepl();
              totalTodayspl = totalTodayspl + element.gettodayspl();
              // element.instrument.changePrice = elements.instrument.changePrice;
              // element.instrument.percChange = elements.instrument.percChange;

              // print("changep price of" +
              //     elements.instrument.securityName +
              //     "= " +
              //     elements.instrument.changePrice.toString());
            });
          }
        });
        if (!isClosed) emitdata(positionlist);
      } else {
        return;
      }
    });
    // List<Instrument> list = MDS_Controller().subscribeSymbols(List.generate(
    //     positionlist.length, (index) => positionlist[index].instrument));

    // emitdata(positionlist);
    List<Instrument> list = [];

    for (int i = 0; i < positionlist.length; i++) {
      list.add(positionlist[i].instrument);
    }
    if (list.isNotEmpty) MDS_Controller().subscribeSymbols(list);
    // List<Instrument> list = MDS_Controller().subscribeSymbols(List.generate(
    //     holdinglist.length, (index) => holdinglist[index].instrument));
    // print(index);
    for (var i = 0; i < list.length; i++) {
      positionlist[i].instrument = list[i];
    }
    emitdata(positionlist);
  }

  unsubscribeSymbols() {
    List<Instrument> feedList = List.generate(
        positionlist.length, (index) => positionlist[index].instrument);
    if (feedList.isEmpty) return;
    MDS_Controller().unsubscribeSymbols(feedList);
  }

  openSearch() {
    searchvisible = true;
    emitdata(positionlist);
  }

  List<String> getDefaultSortOrder() {
    defaultSortOrder.clear();
    positionlist.forEach((element) {
      defaultSortOrder.add(element.instrument.getRicAddress());
    });
    return defaultSortOrder;
  }

  openInitial() {
    searchvisible = false;
    emitdata(positionlist);
  }

  List<PositionModel> updatesortfilter(List<PositionModel> positionlist) {
    // list =
    //     List.from(UserController().portfolioresponce.result4, growable: true);
    List<PositionModel> realList = positionlist;
    List<PositionModel> finalList = [];
    List<String> filterTypes = [
      "Open", // 0
      "Close", // 1
      "Todays Trade", // 2
      "Cash", // 3
      "BTST", //4
      "Intraday", // 5
      "MTF", // 6
      "Smartfolio", // 7
      "Stock", // 8
      "Commodity", // 9
      "Currency", // 10
      "F&O" // 11
    ];

    if (filterarrayposition.isNotEmpty) {
      if (filterarrayposition.contains(filterTypes[0])) {
        for (var element in realList) {
          if (element.availablenetqty != 0) {
            finalList.add(element);
          }
        }
      }

      if (filterarrayposition.contains(filterTypes[1])) {
        for (var element in realList) {
          if (element.availablenetqty == 0) {
            finalList.add(element);
          }
        }
      }

      if (filterarrayposition.contains(filterTypes[3])) {
        for (var element in realList) {
          if (element.producttype == filterTypes[3].toUpperCase()) {
            finalList.add(element);
          }
        }
      }

      if (filterarrayposition.contains(filterTypes[4])) {
        for (var element in realList) {
          if (element.producttype == filterTypes[4].toUpperCase()) {
            finalList.add(element);
          }
        }
      }

      if (filterarrayposition.contains(filterTypes[5])) {
        for (var element in realList) {
          if (element.producttype == filterTypes[5].toUpperCase() ||
              element.producttype == "COMMINTRADAY" ||
              element.producttype == "FAOINTRADAY") {
            finalList.add(element);
          }
        }
      }

      if (filterarrayposition.contains(filterTypes[6])) {
        for (var element in realList) {
          if (!finalList.contains(element)) {
            if (element.producttype == filterTypes[6].toUpperCase()) {
              finalList.add(element);
            }
          }
        }
      }

      if (filterarrayposition.contains(filterTypes[8])) {
        for (var element in realList) {
          if (!finalList.contains(element)) {
            if (element.venuecode == "NSE" || element.venuecode == "BSE") {
              finalList.add(element);
            }
          }
        }
      }

      if (filterarrayposition.contains(filterTypes[9])) {
        for (var element in realList) {
          if (!finalList.contains(element)) {
            if (element.venuecode == "NCDEX" ||
                element.venuecode == "MCX" ||
                element.venuecode == "ICEX") {
              finalList.add(element);
            }
          }
        }
      }

      if (filterarrayposition.contains(filterTypes[10])) {
        for (var element in realList) {
          if (!finalList.contains(element)) {
            if (element.venuecode == "NSECD") {
              finalList.add(element);
            }
          }
        }
      }

      if (filterarrayposition.contains(filterTypes[11])) {
        for (var element in realList) {
          if (!finalList.contains(element)) {
            if (element.venuecode == "NSEFO" ||
                element.venuecode == "NSECD" ||
                element.venuecode == "NCDEX" ||
                element.venuecode == "MCX" ||
                element.venuecode == "ICEX") {
              finalList.add(element);
            }
          }
        }
      }
      realList = List.from(finalList);
    }
    if (filteredvalue != -1) {
      switch (filteredvalue) {
        case 0:
          realList.sort(((a, b) => (a.securitycode).compareTo(b.securitycode)));
          break;
        case 1:
          realList.sort(((a, b) => (b.securitycode).compareTo(a.securitycode)));
          break;
        case 2:
          realList.sort(((a, b) => a.pl.compareTo(b.pl)));
          break;
        case 3:
          realList.sort(((a, b) => b.pl.compareTo(a.pl)));
          break;
        case 4:
          realList.sort(((a, b) => a.plPercentage.compareTo(b.plPercentage)));
          break;
        case 5:
          realList.sort(((a, b) => a.plPercentage.compareTo(a.plPercentage)));
          break;
        case 6:
          realList
              .sort(((a, b) => a.investedAmount.compareTo(b.investedAmount)));
          break;
        case 7:
          realList
              .sort(((a, b) => (b.investedAmount).compareTo(a.investedAmount)));
          break;
      }
    }
    return realList;
  }

  updateSortList(int index) {
    filteredvalue = index;
    emitdata(positionlist);
  }

  updateFilterList(List<String> filterlist) {
    filterarrayposition = filterlist;
    emitdata(positionlist);
  }

  updateSearchList(String key) {
    List<PositionModel>? searchabledata = [];
    positionlist.forEach(((element) {
      if (element.securitycode1.startsWith(key.trim().toUpperCase()) ||
          element.securityname.startsWith(key.trim().toUpperCase()) ||
          element.securitycode1.contains(key.trim().toUpperCase())) {
        searchabledata.add(element);
      }
    }));
    emitdata(searchabledata);
  }

  resetSortList() {
    filterarrayposition.clear();
    filteredvalue = -1;
    searchvisible = false;
    List<PositionModel> list = [];

    defaultSortOrder.forEach((ric) {
      for (var element in positionlist) {
        if (ric == element.instrument.getRicAddress()) {
          list.add(element);
        }
      }
    });
    positionlist = list;
    emitdata(positionlist);
  }

  emitdata(List<PositionModel> positionlist) {
    double totalPercentage = 0.0;

    List<PositionModel> completelist = [];
    if (searchvisible == false) {
      completelist = updatesortfilter(positionlist);
    } else {
      completelist = positionlist;
    }

    totalCurrentInvest = 0.0;
    // for (var element in completelist) {
    //   totalinvested =
    //       totalinvested + (element.availablenetqty * element.avgrate);
    //   totalCurrentInvest = totalCurrentInvest +
    //       (element.availablenetqty * element.instrument.lastTrdPrice);
    //   element.pl = (element.availablenetqty * element.instrument.lastTrdPrice) -
    //       (element.availablenetqty * element.avgrate);

    //   element.plPercentage = ((element.pl * 100) /
    //               (element.avgrate * element.availablenetqty))
    //           .isNaN
    //       ? 0.00
    //       : (element.pl * 100) / (element.avgrate * element.availablenetqty);

    //   // print("## ltp = ${element.instrument.lastTrdPrice}");
    //   // print("## closeprice = ${element.instrument.closePrice}");

    //   element.todaysPl =
    //       (element.instrument.lastTrdPrice) - (element.instrument.closePrice);

    //   totalPercentage = (totlaPl * 100) / totalinvested;
    //   totalTodayspl = totalTodayspl + element.todaysPl;
    // }
    totalPercentage = (totlaPl * 100) / totalinvested;
    // totlaPl = totalCurrentInvest - totalinvested;
    // print(totlaPl);
    // double totlaPl = 0.0;
    // double totalPercentage = 0.0;
    // double totalinvested = 0.0;
    // double totalTodayspl = 0.0;
    // double totalCurrent = 0.00;
    // List<PositionModel> completelist = [];
    // if (searchvisible == false) {
    //   completelist = updatesortfilter(positionlist);
    // } else {
    //   completelist = positionlist;
    // }

    // List.generate(positionlist.length, (index) {
    //   totalinvested = totalinvested +
    //       double.parse(positionlist[index].investedAmount.toString());

    //   totalCurrent = totalCurrent + positionlist[index].currentAmount;
    //   totlaPl = totlaPl + positionlist[index].pl;
    //   totalPercentage = ((totalinvested - totalCurrent) / totalCurrent).isNaN
    //       ? 0.00
    //       : ((totalinvested - totalCurrent) / totalCurrent) * 100;
    //   totalTodayspl =
    //       totalTodayspl + double.parse(positionlist[index].todaysPl.toString());
    // });

    emit(MyPositionScreenInitial(
        positionlist: completelist,
        positionResponceMap: positionResponceMap,
        positionResponce: positionResponce,
        pl: totlaPl,
        totalTodaysPl: totalTodayspl,
        changePlPercentage: totalPercentage,
        intradaydata: list,
        searchvisible: searchvisible,
        filterval: filteredvalue,
        filterarrayposition: filterarrayposition));
  }

  updateData() {
    if (isClosed) return;
    if (positionlist.isNotEmpty) {
      unsubscribeSymbols();
    }
    totlaPl = 0.0;
    totalTodayspl = 0.0;
    mapPositionlist.clear();
    positionlist.clear();
    List.generate(UserController().portfolioresponce.result4.length, (index) {
      PositionModel positionModel = PositionModel.updatePosition(
          UserController().portfolioresponce.result4[index]);

      positionlist.add(positionModel);
      totlaPl = totlaPl + positionModel.gtepl();
      totalTodayspl = totalTodayspl + positionModel.gettodayspl();
      totalinvested = totalinvested + positionModel.investedAmount;
      if (!mapPositionlist
          .containsKey(positionModel.instrument.getRicAddress())) {
        mapPositionlist[positionModel.instrument.getRicAddress()] = [
          positionModel
        ];
      } else {
        mapPositionlist[positionModel.instrument.getRicAddress()]!
            .add(positionModel);
      }
    });
    defaultSortOrder = getDefaultSortOrder();
    subscribeSymbols();
    //   emitdata(positionlist);
  }
}

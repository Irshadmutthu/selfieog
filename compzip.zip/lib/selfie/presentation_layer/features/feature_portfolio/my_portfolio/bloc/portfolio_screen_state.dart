part of 'my_portfolio_screen_cubit.dart';

@immutable
abstract class MyPortfolioScreenState {}

class MyPortfolioScreenInitial extends MyPortfolioScreenState {
  final String errorMsg;
  List<Instrument>? feeddata = [];
  HoldingModel? holdingModel;
  MyPortfolioScreenInitial(
      {this.errorMsg = "", this.feeddata, this.holdingModel});
}

class MyPorfolioLoadingState extends MyPortfolioScreenState {}

import 'package:selfie_mobile_flutter/portfolio_model/Portfolio.dart';
import 'package:trading_api/responses/portfolio_responce.dart';

abstract class PositionScreenState {}

class MyPositionScreenInitial extends PositionScreenState {
  PortfolioResponce? positionResponce;
  List<Map<String, dynamic>> positionResponceMap;
  int filterval;
  double pl;
  double totalTodaysPl;
  double totalTodaysPlPercentage;
  List<Result4> intradaydata;
  double changePlPercentage;
  bool searchvisible;
  List<String> filterarrayposition = [];
  List<PositionModel> positionlist = [];
  MyPositionScreenInitial(
      {this.positionResponce,
      this.positionResponceMap = const [],
      required this.positionlist,
      this.searchvisible = false,
      this.pl = 0.0,
      this.totalTodaysPl = 0.0,
      this.totalTodaysPlPercentage = 0.0,
      required this.intradaydata,
      this.changePlPercentage = 0.0,
      this.filterval = -1,
      required this.filterarrayposition});
}

class MyPositionScreenloading extends PositionScreenState {}

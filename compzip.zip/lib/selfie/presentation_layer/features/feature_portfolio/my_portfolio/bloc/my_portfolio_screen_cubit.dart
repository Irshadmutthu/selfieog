import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/portfolio_model/Portfolio.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/bloc_navigation/navigation_cubit.dart';
import 'package:selfie_mobile_flutter/services/api_gateway.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/responses/portfolio_responce.dart';
import 'package:trading_api/utils/utils.dart';

part 'portfolio_screen_state.dart';

class MyPortfolioScreenCubit extends Cubit<MyPortfolioScreenState> {
  List<Map<String, dynamic>> portfolio_responce_map = [];
  List<Map<String, dynamic>> position_responce_map = [];
  List<Instrument> feedData = [];
  StreamSubscription? streamSubscription;
  Map<String, Instrument> feedMap = {};
  PortfolioResponce? _responce;
  TradingApiGateway apiGateway;

  BuildContext context;
  MyPortfolioScreenCubit({required this.apiGateway, required this.context})
      : super(MyPortfolioScreenInitial()) {
    try {
      for (var i = 0; i < UserController().indexList.length; i++) {
        //  feedData.add(UserController().indexList[i].getInstrument);
        feedMap[feedData[i].getRicAddress()] =
            MDS_Controller().feedData[feedData[i].getRicAddress()] ??
                feedData[i];
      }

      BlocProvider.of<NavigationCubit>(context)
          .adcontroller
          .stream
          .listen((event) {
        if (event == 1 && UserController().allowPortfolioRequest) {
          sendRequestforData(
              username: UserController().userId,
              loginid: UserController().userId);
        }
      });
    } catch (e) {}
    MDS_Controller().orderStatusStream.listen((event) {
      String orderStatus = event.getOrderStatus;
      switch (orderStatus) {
        case 'CANCELLED':
        case 'CONFIRMED':
        case 'EXECUTED':
          {
            if (isClosed) break;
            UserController().allowPortfolioRequest = true;
            sendRequestforData(
                username: UserController().userId,
                loginid: UserController().userId);
            break;
          }
      }
    });
  }

  //  MDS_Controller().orderStatusStream.listen((event) {
  //     String orderStatus = event.getOrderStatus;
  //     switch (orderStatus) {
  //       case 'CANCELLED':
  //       case 'CONFIRMED':
  //       case 'EXECUTED':
  //         {
  //           if (isClosed) break;
  //           UserController().allowPortfolioRequest = true;
  //           sendRequestforData(
  //               username: UserController().userId,
  //               loginid: UserController().userId);
  //           break;
  //         }
  //     }
  //   });

  changeTabIndex(int index, List<Map<String, dynamic>> portfolio_responce_map) {
    emit(MyPortfolioScreenInitial());
  }

  updateItemOfList(List<FlairResponseModel> data) {
    if (isClosed) {
      if (streamSubscription != null) streamSubscription!.cancel();
      return;
    }
    for (var element in data) {
      if (feedMap.containsKey(element.ric)) {
        feedMap[element.ric] = element.instrument;
      }
    }
    // emit(MarketOverviewInitial(UserController.userController.buyingPower,
    //     feedData = feedMap.values.toList()));
  }

  sendRequestforData(
      {required String username, required String loginid}) async {
    emit(MyPorfolioLoadingState());
    unsubscribeSymbols();
    try {
      _responce = await apiGateway.portfolioservicerequest(
          username: username, loginid: loginid);

      if (_responce!.errorCode == "0") {
        UserController().allowPortfolioRequest = false;
        portfolio_responce_map.clear();
        position_responce_map.clear();
        UserController().portfoliolist.clear();
        UserController().positionlist.clear();
        UserController().portfolioresponce = _responce!.copyWith();
        UserController().portfolioresetresponce = _responce!.copyWith();

        for (int i = 0;
            i < UserController().portfolioresponce.result3.length;
            i++) {
          portfolio_responce_map
              .add(UserController().portfolioresponce.result3[i].toJson());
        }

        for (int i = 0;
            i < UserController().portfolioresponce.result4.length;
            i++) {
          position_responce_map
              .add(UserController().portfolioresponce.result4[i].toJson());
        }
        UserController().portfoliolist = portfolio_responce_map;

        UserController().positionlist = position_responce_map;

        emit(MyPortfolioScreenInitial());
      } else {
        emit(MyPortfolioScreenInitial(
          errorMsg: _responce!.result2[0].errormessage.toString(),
        ));
      }
    } catch (e) {
      emit(MyPortfolioScreenInitial(
        errorMsg: e.toString(),
      ));
    }
  }

  unsubscribeSymbols() {
    if (feedData.isEmpty) return;
    MDS_Controller().unsubscribeSymbols(feedData);
  }
}


  // sendRequestforData() async {
  //   portfolio_responce_map.clear();
  //   position_responce_map.clear();
  //   //   try {
  //   //     _responce = await apiGateway.portfolioservicerequest(
  //   //         username: username, loginid: loginid);

  //   //     if (_responce!.errorCode == "0") {
  //   //       UserController().portfolioresponce = _responce!.copyWith();
  //      try {
  //       _responce = await apiGateway.portfolioservicerequest(
  //           username: username, loginid: loginid);
  //       UserController().portfolioresponce = _responce;
  //       emit(WatchlistIndexState(index: 1));
  //     } catch (e) {
  //       //  UserController().portfolioresponce = _responce2;
  //       // throw (e);
  //       emit(WatchlistIndexState(index: 1));
  //     }
  //   if (UserController().portfolioresponce.errorCode.toString().isEmpty) {
  //     emit(MyPorfolioLoadingState());
  //   }
  //   if (UserController().portfolioresponce.errorCode.toString() == "-1") {
  //     emit(MyPortfolioErrorState(errormsg: "Something went wrong"));
  //   } else {
  //     try {
  //       if (UserController().portfolioresponce.errorCode == "0") {
  //         UserController().portfolioresetresponce =
  //             UserController().portfolioresponce;
  //         int l1 = UserController().portfolioresponce.result3.length;
  //         int l2 = UserController().portfolioresponce.result4.length;
  //         for (int i = 0; i < l1; i++) {
  //           portfolio_responce_map
  //               .add(UserController().portfolioresponce.result3[i].toJson());
  //         }

  //         for (int i = 0; i < l2; i++) {
  //           position_responce_map
  //               .add(UserController().portfolioresponce.result4[i].toJson());
  //         }

  //         //       UserController().portfoliolist = List.from(portfolio_responce_map);

  //         //       UserController().positionlist = position_responce_map;

  //         emit(MyPortfolioScreenInitial(
  //             portfolio_responce_map: portfolio_responce_map,
  //             position_responce_map: position_responce_map,
  //             portfolioResponce: UserController().portfolioresponce));
  //       } else if (UserController().portfolioresponce.errorCode != "0") {
  //         emit(MyPortfolioErrorState(
  //             errormsg: UserController()
  //                 .portfolioresponce
  //                 .result2[0]
  //                 .errormessage
  //                 .toString()));
  //       } else {
  //         emit(MyPortfolioErrorState(
  //             errormsg: UserController()
  //                 .portfolioresponce
  //                 .result2[0]
  //                 .errormessage
  //                 .toString()));
  //       }
  //     } catch (e) {
  //       emit(MyPortfolioErrorState(errormsg: "Something went wrong"));
  //     }
  //   }

  //   //   } catch (e) {
  //   //     emit(MyPortfolioErrorState(errormsg: "Something went wrong"));
  //   //   }
  // }



part of 'holdings_component_cubit.dart';

@immutable
abstract class HoldingsComponentState {}

class HoldingsComponentInitial extends HoldingsComponentState {
  final List<Map<String, dynamic>> holdingList;
  final bool sortvisible;
  final int filterval;
  final bool searchvisible;
  double pl;
  double plPercentage;
  List<String>? filterElements;
  double todaysPl;
  PortfolioResponce portfolio = PortfolioResponce(
      result2: [], result3: [], result4: [], result5: [], errorCode: "");
  List<String> filterarrayposition = [];
  List<Result5> qtyresponce = [];
  List<HoldingModel> myholdinglist = [];
  HoldingsComponentInitial(
      {this.sortvisible = true,
      this.searchvisible = false,
      this.filterval = -1,
      required this.filterarrayposition,
      required this.holdingList,
      this.pl = 0.00,
      this.plPercentage = 0.00,
      this.todaysPl = 0.00,
      required this.portfolio,
      this.filterElements,
      required this.qtyresponce,
      required this.myholdinglist});
}

class HoldingInitstate extends HoldingsComponentState {}

class Holdingloadingstate extends HoldingsComponentState {}
// class HoldingsComponentSearch extends HoldingsComponentState {
//   HoldingsComponentSearch();
// }

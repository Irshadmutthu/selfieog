import 'package:flutter/material.dart';
import 'package:selfie_mobile_flutter/utils/shimmer_loader.dart';

import '../../../../../../theme/styles.dart';
import '../../../../../widgets/others/custom_dot.dart';

class HoldingListShimmer extends StatelessWidget {
  const HoldingListShimmer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: 6,
        shrinkWrap: true,
        itemBuilder: (context, index) {
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 16),
              decoration: BoxDecoration(
                  border: Border(
                bottom: BorderSide(
                    color: customColors().backgroundTertiary, width: 1),
              )),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Visibility(
                      // visible: widget.portfoliolist.containsKey("topview"),
                      visible: true,
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 0.0),
                                    child: ShimmerLoader(
                                      height: 20,
                                      width: 50,
                                    )),
                              ],
                            ),
                            ShimmerLoader(height: 20.0, width: 130.0)
                          ]),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                ShimmerLoader(height: 20.0, width: 100.0),
                              ],
                            ),
                            ShimmerLoader(height: 20.0, width: 80.0)
                          ]),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 4.0),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                ShimmerLoader(height: 20.0, width: 50.0)
                              ],
                            ),
                            Row(
                              children: [
                                ShimmerLoader(height: 20.0, width: 80.0)
                              ],
                            ),
                          ]),
                    ),
                  ],
                ),
              ),
            ),
          );
        });
  }
}

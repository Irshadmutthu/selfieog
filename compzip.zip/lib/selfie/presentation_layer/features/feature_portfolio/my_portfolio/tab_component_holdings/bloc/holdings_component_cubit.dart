import 'dart:async';
import 'dart:io';
import 'dart:math';

import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'package:provider/provider.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/portfolio_model/Portfolio.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/bloc_navigation/navigation_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/portfolio_content.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:trading_api/requests/edis_request.dart';
import 'package:trading_api/responses/edis_response.dart';
import 'package:trading_api/utils/utils.dart';
import 'package:trading_api/responses/portfolio_responce.dart';
import 'package:trading_api/responses/symbol_details_response.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../../../../../mds_controller.dart/mds_model.dart/instrument.dart';
import '../../../../../../../services/api_gateway.dart';

part 'holdings_component_state.dart';

class HoldingsComponentCubit extends Cubit<HoldingsComponentState> {
  List<String> filterarrayposition = [];
  TradingApiGateway apiGateway;
  int filteredvalue = -1;
  // List<Intraday> list = [];
  List<HoldingModel> holdinglist = [];
  Map<String, List<HoldingModel>> mapHoldinglist = {};
  bool searchvisible = false;
  List<Instrument> feedList = [];
  List<String> defaultSortOrder = [];
  StreamSubscription? streamSubscription;
  BuildContext context;
  Map<String, Result5> qtyMap = {};

  HoldingsComponentCubit(this.apiGateway, this.context)
      : super(Holdingloadingstate()) {
    //  bindholddata();
    // defaultSortOrder = getDefaultSortOrder();
    // emitdata(holdinglist);
    // emitdata(holdinglist);
    context.read<NavigationCubit>().adcontroller.stream.listen((event) {
      if (!isClosed) {
        if (event != 1 && event != 5 && event != 6) {
          unsubscribeSymbols();
        }
      }
    });
  }

  subscribeSymbols() {
    if (isClosed) return;

    // MDS_Controller().subscribeSymbols(List.generate(
    //     holdinglist.length, (index) => holdinglist[index].instrument!));
    streamSubscription = MDS_Controller()
        .marketUpdateStream
        .listen((List<FlairResponseModel> flairResponseModel) {
      if (searchvisible == false) {
        flairResponseModel.forEach((elements) {
          if (mapHoldinglist.containsKey(elements.ric)) {
            for (int i = 0; i < mapHoldinglist[elements.ric]!.length; i++) {
              totlapl = totlapl - mapHoldinglist[elements.ric]![i].pl;
              totlapl = totlapl + mapHoldinglist[elements.ric]![i].gtepl();
            }
            //     // mapHoldinglist[elements.ric]!.forEach((element) {
            //     //   totlapl = totlapl - element.pl;
            //     //   // element.instrument.lastTrdPrice =
            //     //   //     elements.instrument.lastTrdPrice;
            //     //   totlapl = totlapl + element.gtepl();
            //     // });
          }
        });
        if (!isClosed) emitdata(holdinglist);
      } else {
        return;
      }
    });

    if (feedList.isNotEmpty) MDS_Controller().subscribeSymbols(feedList);

    // List<Instrument> list = MDS_Controller().subscribeSymbols(List.generate(
    //     holdinglist.length, (index) => holdinglist[index].instrument!));
    // print(index);

    for (var i = 0; i < feedList.length; i++) {
      holdinglist[i].instrument = feedList[i];
    }
    emitdata(holdinglist);
  }

  unsubscribeSymbols() {
    if (feedList.isEmpty) return;
    MDS_Controller().unsubscribeSymbols(feedList);
  }

  openSearch() {
    searchvisible = true;
    emitdata(holdinglist);
  }

  // List<String> getDefaultSortOrder() {
  //   defaultSortOrder.clear();
  //   holdinglist.forEach((element) {
  //     defaultSortOrder.add(element.instrument.getRicAddress());
  //   });
  //   return defaultSortOrder;
  // }

  openInitial() {
    searchvisible = false;
    // holdinglist.clear();
    // bindholddata();
    emitdata(holdinglist);
  }

  // bindholddata() {
  //   list =
  //       List.from(UserController().portfolioresponce.result3, growable: true);
  //   HoldingModel holdingModel = HoldingModel();
  //   List.generate(list.length, (index) {
  //     HoldingModel h = holdingModel.getHoldingModel(list[index]);
  //     holdinglist.add(h);
  //   });
  // }

  List<HoldingModel> updatesortfilter(List<HoldingModel> holdings) {
    // list =
    //     List.from(UserController().portfolioresponce.result3, growable: true);
    List<HoldingModel> realList = holdings;
    List<HoldingModel> finalList = [];
    if (filterarrayposition.isNotEmpty) {
      for (var element in realList) {
        if (realList.contains(element)) {
        } else {
          for (int i = 0; i < filterarrayposition.length; i++) {
            if (element.producttype == filterarrayposition[i].toUpperCase() ||
                element.producttype
                    .endsWith(filterarrayposition[i].toUpperCase())) {
              finalList.add(element);
            }
          }
        }
      }
      realList = List.from(finalList);
    }
    if (filteredvalue != -1) {
      switch (filteredvalue) {
        case 0:
          realList.sort(((a, b) => (a.instrument.securityCode)
              .compareTo(b.instrument.securityCode)));
          break;
        case 1:
          realList.sort(((a, b) => (b.instrument.securityCode)
              .compareTo(a.instrument.securityCode)));
          break;
        case 2:
          realList.sort(((a, b) => a.pl.compareTo(b.pl)));
          break;
        case 3:
          realList.sort(((a, b) => b.pl.compareTo(a.pl)));
          break;
        case 4:
          realList.sort(((a, b) => a.plPercentage.compareTo(b.plPercentage)));
          break;
        case 5:
          realList.sort(((a, b) => a.plPercentage.compareTo(a.plPercentage)));
          break;
        case 6:
          realList
              .sort(((a, b) => a.investedAmount.compareTo(b.investedAmount)));
          break;
        case 7:
          realList
              .sort(((a, b) => (b.investedAmount).compareTo(a.investedAmount)));
          break;
      }
    }
    return realList;
  }

  updateSearchList(String key) {
    List<HoldingModel>? searchabledata = [];
    searchabledata.clear();
    holdinglist.forEach(((element) {
      if (element.securitycode1.startsWith(key.trim().toUpperCase()) ||
          element.instrument.securityName
              .startsWith(key.trim().toUpperCase()) ||
          element.securitycode1.contains(key.trim().toUpperCase())) {
        searchabledata.add(element);
      }
    }));
    emitdata(searchabledata);
  }

  // openSortList() {
  //   emit(HoldingsComponentInitial(
  //       holdingList: holdingsList2,
  //       sortvisible: true,
  //       //  portfolioResponce: UserController().portfolioresponce.result3,
  //       portfolio: UserController().portfolioresponce,
  //       qtyresponce: qtyresponce,
  //       filterarrayposition: filterarrayposition,
  //       myholdinglist: holdinglist));
  // }

  updateSortList(int index) {
    filteredvalue = index;
    emitdata(holdinglist);
  }

  updateFilterList(List<String> filterlist) {
    filterarrayposition = filterlist;
    emitdata(holdinglist);
  }

  resetSortList() {
    filterarrayposition.clear();
    filteredvalue = -1;
    searchvisible = false;
    // bindholddata();
    List<HoldingModel> list = [];

    defaultSortOrder.forEach((ric) {
      for (var element in holdinglist) {
        if (ric == element.instrument.getRicAddress()) {
          list.add(element);
        }
      }
    });
    holdinglist = list;
    // feedMap = map;
    // feedList = feedMap.values.toList();

    // calculations(searchvisible, filteredvalue, filterarrayposition);
    emitdata(holdinglist);
  }

  double totlapl = 0.0;
  double totalPercentage = 0.0;
  double totalinvested = 0.0;
  double todaysPl = 0.0;
  double avg = 0.0;
  double ltp = 0.0;
  double totalCurrentInvest = 0.0;
  List<Result5> qtyresponce = [];

  emitdata(List<HoldingModel> holdinglist) {
    // totalPercentage = 0.0;
    // totalinvested = 0.0;
    // totalCurrentInvest = 0.0;
    todaysPl = 0.0;
    avg = 0.0;
    ltp = 0.0;
    HoldingModel rowItem;
    List<HoldingModel> completelist = [];

    if (searchvisible == false) {
      completelist = updatesortfilter(holdinglist);
    } else {
      completelist = holdinglist;
    }

    // totalCurrentInvest = 0.0;
    totalPercentage = (totlapl * 100) / totalinvested;
    // for (var element in completelist) {
    //   avg = element.avgrate;
    //   ltp = element.instrument.lastTrdPrice;

    //   print("ltp of " + element.securitycode1 + "=" + ltp.toString());

    //   totalinvested =
    //       totalinvested + (element.availablenetqty * element.avgrate);
    //   totalCurrentInvest = totalCurrentInvest +
    //       (element.availablenetqty * element.instrument.lastTrdPrice);

    //   element.plPercentage = ((element.pl * 100) /
    //               (element.avgrate * element.availablenetqty))
    //           .isNaN
    //       ? 0.00
    //       : (element.pl * 100) / (element.avgrate * element.availablenetqty);
    //   print("## total invested = ${totalinvested}");
    //   print("## total current amount = ${totalCurrentInvest}");
    //   totlapl = (totalCurrentInvest - totalinvested) + element.realpl;

    //   totalPercentage = (totlapl * 100) / totalinvested;
    // }
    // List.generate(completelist.length, (int index) {
    //   rowItem = completelist[index];
    //   // HoldingModel h = holdingModel.getHoldingModel(list[index]);
    //   // holdinglist.add(h);
    // });
    emit(HoldingsComponentInitial(
        holdingList: holdingsList,
        pl: totlapl,
        plPercentage: totalPercentage,
        todaysPl: todaysPl,
        //    portfolioResponce: list,
        searchvisible: searchvisible,
        filterval: filteredvalue,
        portfolio: UserController().portfolioresponce,
        qtyresponce: qtyresponce,
        filterarrayposition: filterarrayposition,
        myholdinglist: completelist));
  }

  init() {
    searchvisible = false;
    emitdata(holdinglist);
  }

  calledis(Instrument instrument) async {
    // "user_id=ENJ004&venue=NSEMF&isin=INF204K01968&isinname=Nippon India PHARMA FUND-GROWTH PLAN-GROWTH OPTION&venuescripcode=299"
    EdisBlockResponse response = await apiGateway.edisBlockRequest(
        request: EdisBlock(
            intReqObj: EdisIntReqObj(
                dtoheader: edisDtoheader(loginId: UserController().userId),
                param1: "user_id=" +
                    UserController().userId +
                    "&" +
                    "venue=" +
                    instrument.venuecode +
                    "&isin=" +
                    instrument.isin +
                    "&isinname=" +
                    instrument.securityName +
                    "&venuescripcode=" +
                    instrument.scripcode +
                    ""),
            proc: "eDIS_Block"));

    Uri url = Uri.parse(response.eDisUrl! + response.encodedStr!);
    try {
      if (await canLaunchUrl(url)) {
        await launchUrl(url, mode: LaunchMode.externalApplication);
      } else {
        throw "Could not launch $url";
      }
      // ignore: empty_catches
    } catch (e) {}
  }

  updateData() {
    if (isClosed) return;
    if (holdinglist.isNotEmpty) {
      unsubscribeSymbols();
    }
    totlapl = 0.0;
    holdinglist.clear();
    mapHoldinglist.clear();
    qtyresponce.clear();
    defaultSortOrder.clear();
    for (var i = 0;
        i < UserController().portfolioresponce.result5.length;
        i++) {
      qtyMap[UserController().portfolioresponce.result5[i].venuecode +
              UserController().portfolioresponce.result5[i].venuescripcode] =
          UserController().portfolioresponce.result5[i];
    }
    List.generate(UserController().portfolioresponce.result3.length, (index) {
      HoldingModel model = HoldingModel.updateHoldingModel(
          UserController().portfolioresponce.result3[index]);

      holdinglist.add(model);
      feedList.add(model.instrument);
      totlapl = totlapl + model.gtepl();
      totalinvested = totalinvested + model.investedAmount;
      if (!mapHoldinglist.containsKey(model.instrument.getRicAddress())) {
        mapHoldinglist[model.instrument.getRicAddress()] = [holdinglist[index]];
      } else {
        mapHoldinglist[model.instrument.getRicAddress()]!
            .add(holdinglist[index]);
      }
      qtyresponce.add(
          qtyMap[model.instrument.venuecode + model.instrument.scripcode] ??
              Result5());
      defaultSortOrder.add(model.instrument.getRicAddress());
    });

    //  defaultSortOrder = getDefaultSortOrder();
    subscribeSymbols();
    // emitdata(holdinglist);
  }

  pledgeforMargin() async {
    // "user_id=ENJ004&venue=NSEMF&isin=INF204K01968&isinname=Nippon India PHARMA FUND-GROWTH PLAN-GROWTH OPTION&venuescripcode=299"
    final NetworkInfo _networkInfo = NetworkInfo();
    String IPaddress = "";
    try {
      IPaddress = (await _networkInfo.getWifiIP()) ?? "";
    } catch (e) {
      IPaddress = "";
    }

    EdisBlockResponse response = await apiGateway.edisBlockRequest(
        request: EdisBlock(
            intReqObj: EdisIntReqObj(
                dtoheader: edisDtoheader(loginId: UserController().userId),
                param1: "CRMID:" +
                    UserController().crmid +
                    "|IP:" +
                    IPaddress +
                    "|EUSER:" +
                    UserController().userId +
                    "|SOURCE:" +
                    "ANDROID"),
            proc: "eDIS_Block",
            reqMethode: "pledgeForMargin"));

    Uri url = Uri.parse(response.pledgeForMargin! + response.encodedStr!);
    try {
      if (await canLaunchUrl(url)) {
        await launchUrl(url, mode: LaunchMode.externalApplication);
      } else {
        throw "Could not launch $url";
      }
      // ignore: empty_catches
    } catch (e) {}
  }
}

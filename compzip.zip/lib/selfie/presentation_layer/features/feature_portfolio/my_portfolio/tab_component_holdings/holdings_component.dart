import 'dart:core';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/constants/enums.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_model.dart/instrument.dart';
import 'package:selfie_mobile_flutter/order_model/Order.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/portfolio_model/Portfolio.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/bloc_navigation/navigation_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/featur_symbolsearch/symbol_search/cubit/symbol_search_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_login/login_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/my_portfolio/tab_component_holdings/bloc/holdings_component_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/portfolio_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/search_insights_filter/portfolio_holding_filter_bar.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/textfields/position_search_field.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/default_order_settings/default_order_settings_values.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/portfolio_bottom_sheet_panel/fixed_button.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/sort.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/holdings/holding_bottom_sheets.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/holdings/holdings_tile.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/holdings/holdings_widgets.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';
import 'package:trading_api/utils/utils.dart';

import '../bloc/my_portfolio_screen_cubit.dart';
import 'holding_list_shimmer.dart';

class HoldingsComponent extends StatefulWidget {
  final Function(bool) onScrollEvent;
  final int length;
  HoldingsComponent({
    Key? key,
    required this.onScrollEvent,
    required this.length,
  }) : super(key: key);

  @override
  State<HoldingsComponent> createState() => _HoldingsComponentState();
}

class _HoldingsComponentState extends State<HoldingsComponent>
    with AutomaticKeepAliveClientMixin<HoldingsComponent> {
  int screenCount = 1;
  ScrollController _scrollBottomBarController =
      new ScrollController(); // set controller on scrolling
  final _editcontroller = TextEditingController();
  bool isScrollingDown = false;

  // List<Map<String, dynamic>> holdings = UserController().portfoliolist;

  List<String> selectedsortitem = [];
  void initState() {
    // TODO: implement initState
    super.initState();
    // _controller = BottomSheet.createAnimationController(this);
    // _controller!.duration = const Duration(milliseconds: 400);
    myScroll();
  }

  @override
  void dispose() {
    //   _controller!.dispose();
    super.dispose();
  }

  void myScroll() async {
    _scrollBottomBarController.addListener(() {
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        if (!isScrollingDown) {
          isScrollingDown = true;
          widget.onScrollEvent(false); //hide appbar
        }
      }
      if (_scrollBottomBarController.position.userScrollDirection ==
          ScrollDirection.forward) {
        if (isScrollingDown) {
          isScrollingDown = false;
          widget.onScrollEvent(true); //show appbar
        }
      }
    });
  }

  AnimationController? _controller;

  bool notify = false;
  bool notifysearch = false;
  List ab = [];
  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) =>
              HoldingsComponentCubit(context.gTradingApiGateway, context),
        ),
      ],
      child: RefreshIndicator(
        backgroundColor: customColors().primary,
        onRefresh: () async {
          UserController().allowPortfolioRequest = true;
          notify = true;
          BlocProvider.of<MyPortfolioScreenCubit>(context).sendRequestforData(
              username: UserController().userName,
              loginid: UserController().userId);
          //   BlocProvider.of<HoldingsComponentCubit>(context).updateData();
        },
        child: BlocConsumer<MyPortfolioScreenCubit, MyPortfolioScreenState>(
            listener: (context, state) {
          if (state is MyPortfolioScreenInitial) {
            context.read<HoldingsComponentCubit>().updateData();
          }
        }, builder: (context, state) {
          if (state is MyPorfolioLoadingState) {
            return HoldingListShimmer();
          }
          return BlocBuilder<HoldingsComponentCubit, HoldingsComponentState>(
              builder: (context, state) {
            return ListView(
              shrinkWrap: true,
              children: [
                SingleChildScrollView(
                  child: Column(
                    children: [
                      if (state is Holdingloadingstate)
                        const HoldingListShimmer()
                      else if (state is HoldingsComponentInitial)
                        Column(
                          children: [
                            state.filterarrayposition.isNotEmpty &&
                                    state.myholdinglist.isEmpty
                                ? Column(
                                    children: [
                                      const SizedBox(
                                        height: 6,
                                      ),
                                      Wrap(children: [
                                        SizedBox(
                                          width: double.infinity,
                                          child: holdingsContainer(
                                              context: context,
                                              amount: state.pl,
                                              percentage:
                                                  state.plPercentage.isNaN
                                                      ? 0.0
                                                      : state.plPercentage,
                                              onClickIcon: () {
                                                BlocProvider.of<
                                                            NavigationCubit>(
                                                        context)
                                                    .updateWatchList(5);
                                              }),
                                        ),
                                      ]),
                                      const SizedBox(
                                        height: 8,
                                      ),
                                    ],
                                  )
                                : SizedBox(),

                            state.myholdinglist.isNotEmpty &&
                                    state.searchvisible == false
                                ? Column(
                                    children: [
                                      const SizedBox(
                                        height: 6,
                                      ),
                                      Wrap(children: [
                                        SizedBox(
                                          width: double.infinity,
                                          child: holdingsContainer(
                                              context: context,
                                              amount: double.parse(
                                                  state.pl.toStringAsFixed(2)),
                                              percentage:
                                                  state.plPercentage.isNaN
                                                      ? 0.0
                                                      : state.plPercentage,
                                              onClickIcon: () {
                                                BlocProvider.of<
                                                            NavigationCubit>(
                                                        context)
                                                    .updateWatchList(5);
                                              }),
                                        ),
                                      ]),
                                      const SizedBox(
                                        height: 8,
                                      ),
                                    ],
                                  )
                                : SizedBox(),

                            Column(
                              children: [
                                if (state.myholdinglist.isEmpty &&
                                    !state.searchvisible)
                                  SingleChildScrollView(
                                    child: Column(
                                      children: [
                                        if (state
                                            .filterarrayposition.isNotEmpty)
                                          Column(
                                            children: [
                                              Opacity(
                                                opacity: 1.0,
                                                child: AbsorbPointer(
                                                  absorbing: false,
                                                  child: SearchFilterHoldings(
                                                    showBubble: state
                                                            .filterarrayposition
                                                            .isNotEmpty ||
                                                        notify == false,
                                                    showInsights: false,
                                                    showBubbleSort:
                                                        state.filterval != -1,
                                                    onFilterPress: () {
                                                      customShowModalBottomSheet(
                                                          context: context,
                                                          inputWidget:
                                                              PortfolioSortList(
                                                            currentval:
                                                                state.filterval,
                                                            filterlist: state
                                                                .filterElements,
                                                            filterarrayposition:
                                                                state
                                                                    .filterarrayposition,
                                                            selectedLocation:
                                                                SortFilterLocation
                                                                    .holding,
                                                            onPressFilter:
                                                                (List<String>
                                                                    el) {
                                                              ab =
                                                                  List.from(el);
                                                              state.filterElements =
                                                                  List.from(el);
                                                              BlocProvider.of<
                                                                          HoldingsComponentCubit>(
                                                                      context)
                                                                  .updateFilterList(
                                                                      el);
                                                            },
                                                            onPressSort:
                                                                (int index) {
                                                              BlocProvider.of<
                                                                          HoldingsComponentCubit>(
                                                                      context)
                                                                  .updateSortList(
                                                                      index);
                                                              Navigator.pop(
                                                                  context);
                                                            },
                                                            onPressReset: () {
                                                              BlocProvider.of<
                                                                          HoldingsComponentCubit>(
                                                                      context)
                                                                  .resetSortList();
                                                              //     filterarrayposition.clear();
                                                              Navigator.pop(
                                                                  context);
                                                            },
                                                          ));
                                                    },
                                                    //onSearchPress: () {
                                                    // BlocProvider.of<
                                                    //             HoldingsComponentCubit>(
                                                    //         context)
                                                    //     .openSearch();
                                                    //  },
                                                    onSortPress: () {
                                                      customShowModalBottomSheet(
                                                          context: context,
                                                          inputWidget:
                                                              PortfolioSortList(
                                                            currentval:
                                                                state.filterval,
                                                            selectedLocation:
                                                                SortFilterLocation
                                                                    .holding,
                                                            filterarrayposition:
                                                                state
                                                                    .filterarrayposition,
                                                            selectedTabIndex: 1,
                                                            onPressFilter:
                                                                (List<String>
                                                                    elements) {},
                                                            onPressSort:
                                                                (int value) {
                                                              BlocProvider.of<
                                                                          HoldingsComponentCubit>(
                                                                      context)
                                                                  .updateSortList(
                                                                      value);
                                                            },
                                                            onPressReset: () {
                                                              BlocProvider.of<
                                                                          HoldingsComponentCubit>(
                                                                      context)
                                                                  .resetSortList();
                                                              //             filterarrayposition.clear();
                                                              Navigator.pop(
                                                                  context);
                                                            },
                                                          ));
                                                    },
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(
                                                height: 6,
                                              ),
                                              // Padding(
                                              //   padding: EdgeInsets.only(top: 100),
                                              //   child:
                                              //       emptyContainerPortfolioHoldings(
                                              //           context),
                                              // )
                                            ],
                                          )
                                        else
                                          Column(
                                            children: [
                                              const SizedBox(
                                                height: 6,
                                              ),
                                              Padding(
                                                padding:
                                                    EdgeInsets.only(top: 100),
                                                child:
                                                    emptyContainerPortfolioHoldings(
                                                        context),
                                              )
                                            ],
                                          )
                                      ],
                                    ),
                                  )
                                else if (state.searchvisible)
                                  SingleChildScrollView(
                                    physics: NeverScrollableScrollPhysics(),
                                    child: Column(
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 8.0),
                                          child: Position_Search_Field(
                                              onBackPressed: () {
                                                _editcontroller.clear();
                                                BlocProvider.of<
                                                            HoldingsComponentCubit>(
                                                        context)
                                                    .resetSortList();
                                              },
                                              hintText: "Search eg: infy",
                                              controller: _editcontroller,
                                              onSearch: (String keyword) {
                                                BlocProvider.of<
                                                            HoldingsComponentCubit>(
                                                        context)
                                                    .updateSearchList(keyword);
                                              }),
                                        ),
                                        ListView.builder(
                                            physics: ScrollPhysics(),
                                            itemCount:
                                                state.myholdinglist.length,
                                            shrinkWrap: true,
                                            itemBuilder: (context, index) {
                                              return InkWell(
                                                onTap: () async {
                                                  customBottomSheet(
                                                    context: context,
                                                    fixedBottomWidget:
                                                        FixedButton(
                                                      future: false,
                                                      addMoreOnTap: () {
                                                        if (state
                                                                .myholdinglist[
                                                                    index]
                                                                .categorydesc !=
                                                            "Mutual Funds Units") {
                                                          OrderModel order = OrderModel(
                                                              state
                                                                  .myholdinglist[
                                                                      index]
                                                                  .instrument,
                                                              UserSettings
                                                                  .userSettings
                                                                  .orderSettings);
                                                          var qty = state
                                                              .myholdinglist
                                                              .elementAt(index)
                                                              .availablenetqty
                                                              .toInt();
                                                          order.productType =
                                                              getProductTypeId(state
                                                                  .myholdinglist
                                                                  .elementAt(
                                                                      index)
                                                                  .producttype);
                                                          if (qty > 0) {
                                                            order.buyOrSell =
                                                                SELL;
                                                          } else {
                                                            order.buyOrSell =
                                                                BUY;
                                                          }
                                                          order.buyOrSell = BUY;
                                                          context
                                                              .gNavigationService
                                                              .openOrderWindowPage(
                                                                  context, {
                                                            "order": order
                                                          });
                                                        }
                                                      },
                                                      ocoOnTap: () {
                                                        if (state
                                                                .myholdinglist[
                                                                    index]
                                                                .categorydesc !=
                                                            "Mutual Funds Units") {
                                                          OrderModel order = OrderModel(
                                                              state
                                                                  .myholdinglist[
                                                                      index]
                                                                  .instrument,
                                                              UserSettings
                                                                  .userSettings
                                                                  .orderSettings);

                                                          order.isOCOOrder =
                                                              true;
                                                          order.price = state
                                                              .myholdinglist
                                                              .elementAt(index)
                                                              .avgrate
                                                              .toStringAsFixed(state
                                                                  .myholdinglist[
                                                                      index]
                                                                  .instrument
                                                                  .precision);
                                                          order.qty = state
                                                              .myholdinglist
                                                              .elementAt(index)
                                                              .availablenetqty
                                                              .toInt();
                                                          order.productType = getProductListIndex(
                                                              state
                                                                  .myholdinglist
                                                                  .elementAt(
                                                                      index)
                                                                  .producttype,
                                                              state
                                                                  .myholdinglist[
                                                                      index]
                                                                  .instrument
                                                                  .venueIndex);
                                                          if (order.qty > 0) {
                                                            order.buyOrSell =
                                                                SELL;
                                                          } else {
                                                            order.buyOrSell =
                                                                BUY;
                                                          }

                                                          context
                                                              .gNavigationService
                                                              .openOCOOrderPage(
                                                            context,
                                                            {
                                                              "order": order,
                                                            },
                                                          );
                                                        }
                                                        // context
                                                        //     .gNavigationService
                                                        //     .openOCOOrderPage(
                                                        //   context,
                                                        //   {
                                                        //     "title":
                                                        //         "OCO Order",
                                                        //     "symbol":
                                                        //         "ITC Long",
                                                        //     "qty": "100",
                                                        //     "price": "278.80"
                                                        //   },
                                                        // );
                                                      },
                                                      squareOffOnTap: () {
                                                        if (state
                                                                .myholdinglist[
                                                                    index]
                                                                .categorydesc !=
                                                            "Mutual Funds Units") {
                                                          OrderModel order = OrderModel(
                                                              state
                                                                  .myholdinglist[
                                                                      index]
                                                                  .instrument,
                                                              UserSettings
                                                                  .userSettings
                                                                  .orderSettings);
                                                          order.productType =
                                                              getProductTypeId(state
                                                                  .myholdinglist
                                                                  .elementAt(
                                                                      index)
                                                                  .producttype);
                                                          order.squareOff =
                                                              true;
                                                          order.qty = state
                                                              .myholdinglist
                                                              .elementAt(index)
                                                              .availablenetqty
                                                              .toInt();
                                                          if (order.qty > 0) {
                                                            order.buyOrSell =
                                                                SELL;
                                                          } else {
                                                            order.buyOrSell =
                                                                BUY;
                                                          }
                                                          context
                                                              .gNavigationService
                                                              .openOrderWindowPage(
                                                                  context, {
                                                            "order": order
                                                          });
                                                        }
                                                      },
                                                    ),
                                                    ifport: true,
                                                    holdinglist:
                                                        state.myholdinglist,
                                                    index: index,
                                                    inputWidget:
                                                        BlocProvider.value(
                                                            value: BlocProvider
                                                                .of<HoldingsComponentCubit>(
                                                                    context),
                                                            child: BlocBuilder<
                                                                    HoldingsComponentCubit,
                                                                    HoldingsComponentState>(
                                                                builder:
                                                                    (context,
                                                                        state) {
                                                              if (state
                                                                  is HoldingsComponentInitial) {
                                                                return HoildinBottomSheet(
                                                                  edisOrPledge:
                                                                      (bool
                                                                          isedis) {
                                                                    if (isedis) {
                                                                      BlocProvider.of<HoldingsComponentCubit>(context).calledis(state
                                                                          .myholdinglist
                                                                          .elementAt(
                                                                              index)
                                                                          .instrument);
                                                                    } else {
                                                                      BlocProvider.of<HoldingsComponentCubit>(
                                                                              context)
                                                                          .pledgeforMargin();
                                                                    }
                                                                  },
                                                                  index: index,
                                                                  reportData:
                                                                      state.myholdinglist[
                                                                          index],
                                                                  qtydata: state
                                                                      .qtyresponce,
                                                                  pl: state
                                                                      .myholdinglist[
                                                                          index]
                                                                      .gtepl()
                                                                      .toStringAsFixed(
                                                                          2),
                                                                  pl_percentage: state
                                                                      .myholdinglist[
                                                                          index]
                                                                      .plPercentage
                                                                      .toString(),
                                                                  todays_pl: state
                                                                      .myholdinglist[
                                                                          index]
                                                                      .todaysPl
                                                                      .toString(),
                                                                  todays_pl_percentage: state
                                                                      .myholdinglist[
                                                                          index]
                                                                      .todaysPlPercentage
                                                                      .toString(),
                                                                  quantity: state.myholdinglist[index].availablenetqty %
                                                                              1 >
                                                                          0
                                                                      ? double.parse(state
                                                                              .myholdinglist[
                                                                                  index]
                                                                              .availablenetqty
                                                                              .toString())
                                                                          .toStringAsFixed(
                                                                              3)
                                                                      : state
                                                                          .myholdinglist[
                                                                              index]
                                                                          .availablenetqty
                                                                          .toInt()
                                                                          .toString(),
                                                                );
                                                              } else {
                                                                return Container();
                                                              }
                                                            })),
                                                    height: .678,
                                                    maxHeight: .85,
                                                  );
                                                },
                                                child: HoldingsListTile(
                                                  holdingModel: state
                                                      .myholdinglist[index],
                                                  reportData:
                                                      state.myholdinglist,
                                                  index: index,
                                                  quantity: state
                                                                  .myholdinglist[
                                                                      index]
                                                                  .availablenetqty %
                                                              1 >
                                                          0
                                                      ? double.parse(state
                                                              .myholdinglist[
                                                                  index]
                                                              .availablenetqty
                                                              .toString())
                                                          .toStringAsFixed(3)
                                                      : state
                                                          .myholdinglist[index]
                                                          .availablenetqty
                                                          .toInt()
                                                          .toString(),
                                                ),
                                              );
                                            }),
                                      ],
                                    ),
                                  )
                                else if (state.searchvisible == false)
                                  SingleChildScrollView(
                                    controller: _scrollBottomBarController,
                                    child: Column(
                                      children: [
                                        AbsorbPointer(
                                          absorbing: false,
                                          child: SearchFilterHoldings(
                                            showBubble: state
                                                .filterarrayposition.isNotEmpty,
                                            showInsights: false,
                                            showBubbleSort:
                                                state.filterval != -1,
                                            onFilterPress: () {
                                              customShowModalBottomSheet(
                                                  context: context,
                                                  inputWidget:
                                                      PortfolioSortList(
                                                    currentval: state.filterval,
                                                    filterlist:
                                                        state.filterElements,
                                                    filterarrayposition: state
                                                        .filterarrayposition,
                                                    selectedLocation:
                                                        SortFilterLocation
                                                            .holding,
                                                    onPressFilter:
                                                        (List<String> el) {
                                                      state.filterElements =
                                                          List.from(el);
                                                      BlocProvider.of<
                                                                  HoldingsComponentCubit>(
                                                              context)
                                                          .updateFilterList(el);
                                                    },
                                                    onPressSort: (int index) {
                                                      BlocProvider.of<
                                                                  HoldingsComponentCubit>(
                                                              context)
                                                          .updateSortList(
                                                              index);
                                                      Navigator.pop(context);
                                                    },
                                                    onPressReset: () {
                                                      BlocProvider.of<
                                                                  HoldingsComponentCubit>(
                                                              context)
                                                          .resetSortList();
                                                      // filterarrayposition.clear();
                                                      Navigator.pop(context);
                                                    },
                                                  ));
                                            },
                                            onSearchPress: () {
                                              BlocProvider.of<
                                                          HoldingsComponentCubit>(
                                                      context)
                                                  .openSearch();
                                            },
                                            onSortPress: () {
                                              customShowModalBottomSheet(
                                                  context: context,
                                                  inputWidget:
                                                      PortfolioSortList(
                                                    currentval: state.filterval,
                                                    filterarrayposition: state
                                                        .filterarrayposition,
                                                    selectedLocation:
                                                        SortFilterLocation
                                                            .holding,
                                                    selectedTabIndex: 1,
                                                    onPressFilter: (List<String>
                                                        elements) {
                                                      state.filterElements =
                                                          List.from(elements);
                                                      BlocProvider.of<
                                                                  HoldingsComponentCubit>(
                                                              context)
                                                          .updateFilterList(
                                                              elements);
                                                    },
                                                    onPressSort: (int value) {
                                                      BlocProvider.of<
                                                                  HoldingsComponentCubit>(
                                                              context)
                                                          .updateSortList(
                                                              value);
                                                      Navigator.pop(context);
                                                    },
                                                    onPressReset: () {
                                                      BlocProvider.of<
                                                                  HoldingsComponentCubit>(
                                                              context)
                                                          .resetSortList();
                                                      //       filterarrayposition.clear();
                                                      Navigator.pop(context);
                                                    },
                                                  ));
                                            },
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 6,
                                        ),
                                        ListView.builder(
                                            physics:
                                                NeverScrollableScrollPhysics(),
                                            itemCount:
                                                state.myholdinglist.length,
                                            shrinkWrap: true,
                                            itemBuilder: (context, index) {
                                              return InkWell(
                                                onTap: () {
                                                  fillSymbolData(
                                                      context,
                                                      state.myholdinglist[index]
                                                          .instrument);

                                                  customBottomSheet(
                                                    context: context,
                                                    fixedBottomWidget:
                                                        FixedButton(
                                                            future: false,
                                                            addMoreOnTap: () {
                                                              // print(state
                                                              //     .myholdinglist[
                                                              //         index]
                                                              //     .categorydesc);
                                                              if (state
                                                                      .myholdinglist[
                                                                          index]
                                                                      .categorydesc !=
                                                                  "Mutual Funds Units") {
                                                                OrderModel order = OrderModel(
                                                                    state
                                                                        .myholdinglist[
                                                                            index]
                                                                        .instrument,
                                                                    UserSettings
                                                                        .userSettings
                                                                        .orderSettings);
                                                                var qty = state
                                                                    .myholdinglist
                                                                    .elementAt(
                                                                        index)
                                                                    .availablenetqty
                                                                    .toInt();
                                                                order.productType = getProductTypeId(state
                                                                    .myholdinglist
                                                                    .elementAt(
                                                                        index)
                                                                    .producttype);
                                                                if (qty > 0) {
                                                                  order.buyOrSell =
                                                                      SELL;
                                                                } else {
                                                                  order.buyOrSell =
                                                                      BUY;
                                                                }
                                                                order.buyOrSell =
                                                                    BUY;
                                                                context
                                                                    .gNavigationService
                                                                    .openOrderWindowPage(
                                                                        context,
                                                                        {
                                                                      "order":
                                                                          order
                                                                    });
                                                              }
                                                            },
                                                            ocoOnTap: () {
                                                              if (state
                                                                      .myholdinglist[
                                                                          index]
                                                                      .categorydesc !=
                                                                  "Mutual Funds Units") {
                                                                OrderModel order = OrderModel(
                                                                    state
                                                                        .myholdinglist[
                                                                            index]
                                                                        .instrument,
                                                                    UserSettings
                                                                        .userSettings
                                                                        .orderSettings);

                                                                order.isOCOOrder =
                                                                    true;
                                                                order.price = state
                                                                    .myholdinglist
                                                                    .elementAt(
                                                                        index)
                                                                    .avgrate
                                                                    .toStringAsFixed(state
                                                                        .myholdinglist[
                                                                            index]
                                                                        .instrument
                                                                        .precision);
                                                                order.qty = state
                                                                    .myholdinglist
                                                                    .elementAt(
                                                                        index)
                                                                    .availablenetqty
                                                                    .toInt();
                                                                order.productType = getProductListIndex(
                                                                    state
                                                                        .myholdinglist
                                                                        .elementAt(
                                                                            index)
                                                                        .producttype,
                                                                    state
                                                                        .myholdinglist[
                                                                            index]
                                                                        .instrument
                                                                        .venueIndex);
                                                                if (order.qty >
                                                                    0) {
                                                                  order.buyOrSell =
                                                                      SELL;
                                                                } else {
                                                                  order.buyOrSell =
                                                                      BUY;
                                                                }

                                                                context
                                                                    .gNavigationService
                                                                    .openOCOOrderPage(
                                                                  context,
                                                                  {
                                                                    "order":
                                                                        order,
                                                                  },
                                                                );
                                                              }
                                                            },
                                                            squareOffOnTap: () {
                                                              if (state
                                                                      .myholdinglist[
                                                                          index]
                                                                      .categorydesc !=
                                                                  "Mutual Funds Units") {
                                                                OrderModel order = OrderModel(
                                                                    state
                                                                        .myholdinglist[
                                                                            index]
                                                                        .instrument,
                                                                    UserSettings
                                                                        .userSettings
                                                                        .orderSettings);
                                                                order.productType = getProductTypeId(state
                                                                    .myholdinglist
                                                                    .elementAt(
                                                                        index)
                                                                    .producttype);
                                                                order.squareOff =
                                                                    true;
                                                                order.qty = state
                                                                    .myholdinglist
                                                                    .elementAt(
                                                                        index)
                                                                    .availablenetqty
                                                                    .toInt();
                                                                if (order.qty >
                                                                    0) {
                                                                  order.buyOrSell =
                                                                      SELL;
                                                                } else {
                                                                  order.buyOrSell =
                                                                      BUY;
                                                                }
                                                                context
                                                                    .gNavigationService
                                                                    .openOrderWindowPage(
                                                                        context,
                                                                        {
                                                                      "order":
                                                                          order
                                                                    });
                                                              }
                                                            }),
                                                    ifport: true,
                                                    holdinglist:
                                                        state.myholdinglist,
                                                    index: index,
                                                    inputWidget:
                                                        BlocProvider.value(
                                                            value: BlocProvider
                                                                .of<HoldingsComponentCubit>(
                                                                    context),
                                                            child: BlocBuilder<
                                                                    HoldingsComponentCubit,
                                                                    HoldingsComponentState>(
                                                                builder:
                                                                    (context,
                                                                        state) {
                                                              if (state
                                                                  is HoldingsComponentInitial) {
                                                                return HoildinBottomSheet(
                                                                  edisOrPledge:
                                                                      (bool
                                                                          isedis) {
                                                                    if (isedis) {
                                                                      BlocProvider.of<HoldingsComponentCubit>(context).calledis(state
                                                                          .myholdinglist
                                                                          .elementAt(
                                                                              index)
                                                                          .instrument);
                                                                    } else {
                                                                      BlocProvider.of<HoldingsComponentCubit>(
                                                                              context)
                                                                          .pledgeforMargin();
                                                                    }
                                                                  },
                                                                  index: index,
                                                                  reportData:
                                                                      state.myholdinglist[
                                                                          index],
                                                                  qtydata: state
                                                                      .qtyresponce,
                                                                  pl: state
                                                                      .myholdinglist[
                                                                          index]
                                                                      .gtepl()
                                                                      .toStringAsFixed(
                                                                          2),
                                                                  pl_percentage: state
                                                                      .myholdinglist[
                                                                          index]
                                                                      .plPercentage
                                                                      .toString(),
                                                                  todays_pl: state
                                                                      .todaysPl
                                                                      .toString(),
                                                                  todays_pl_percentage: state
                                                                      .plPercentage
                                                                      .toString(),
                                                                  quantity: state.myholdinglist[index].availablenetqty %
                                                                              1 >
                                                                          0
                                                                      ? double.parse(state
                                                                              .myholdinglist[
                                                                                  index]
                                                                              .availablenetqty
                                                                              .toString())
                                                                          .toStringAsFixed(
                                                                              3)
                                                                      : state
                                                                          .myholdinglist[
                                                                              index]
                                                                          .availablenetqty
                                                                          .toInt()
                                                                          .toString(),
                                                                );
                                                              } else {
                                                                return Container();
                                                              }
                                                            })),
                                                    height: .678,
                                                    maxHeight: .85,
                                                  );
                                                },

                                                // onTap: () async {
                                                //   Instrument instrument =
                                                //       Instrument(
                                                //     scripcode: state
                                                //         .myholdinglist
                                                //         .elementAt(index)
                                                //         .venuescripcode,
                                                //     venueIndex: getVenueIndex(
                                                //         state.myholdinglist
                                                //             .elementAt(index)
                                                //             .venuecode),
                                                //   );
                                                //   // fillSymbolData(
                                                //   //     context,
                                                //   //     state.myholdinglist[index]
                                                //   //         .instrument!);

                                                //   customBottomSheet(
                                                //     fixedBottomWidget:
                                                //         FixedButton(
                                                //       elevation: true,
                                                //       addMoreOnTap: () {
                                                //         // OrderModel order =
                                                //         //     OrderModel(
                                                //         //         instrument,
                                                //         //         UserSettings
                                                //         //             .userSettings
                                                //         //             .orderSettings);
                                                //         // order.buyOrSell = BUY;
                                                //         // context
                                                //         //     .gNavigationService
                                                //         //     .openOrderWindowPage(
                                                //         //         context, {
                                                //         //   "order": order
                                                //         // });
                                                //       },
                                                //       squareOffOnTap: () {
                                                //         OrderModel order =
                                                //             OrderModel(
                                                //                 instrument,
                                                //                 UserSettings
                                                //                     .userSettings
                                                //                     .orderSettings);

                                                //         // order.squareOff = true;
                                                //         // order.qty = state
                                                //         //     .myholdinglist
                                                //         //     .elementAt(index)
                                                //         //     .availablenetqty
                                                //         //     .toInt();
                                                //         if (order.qty > 0) {
                                                //           order.buyOrSell =
                                                //               SELL;
                                                //         } else {
                                                //           order.buyOrSell = BUY;
                                                //         }
                                                //         context
                                                //             .gNavigationService
                                                //             .openOrderWindowPage(
                                                //                 context, {
                                                //           "order": order
                                                //         });
                                                //       },
                                                //       future: false,
                                                //       ocoOnTap: () {
                                                //         // context.gNavigationService
                                                //         //     .openOCOOrderPage(
                                                //         //   context,
                                                //         //   {
                                                //         //     "title": "OCO Order",
                                                //         //     "symbol": "ITC Long",
                                                //         //     "qty": "100",
                                                //         //     "price": "278.80"
                                                //         //   },
                                                //         // );
                                                //       },
                                                //     ),
                                                //     height: .678,
                                                //     maxHeight: .85,
                                                //     ifport: true,
                                                //     context: context,
                                                //     // portfoliolist: state
                                                //     //     .myholdinglist[index]
                                                //     //     .toJson(),
                                                //     ltp: state
                                                //         .myholdinglist[index]
                                                //         .mktrate,
                                                //     percentage: state
                                                //         .myholdinglist[index]
                                                //         .plPercentage,
                                                //     change: double.parse(state
                                                //         .myholdinglist[index].pl
                                                //         .toStringAsFixed(2)
                                                //         .toString()),
                                                //     inputWidget:
                                                //         HoildinBottomSheet(
                                                //       index: index,
                                                //       reportData:
                                                //           state.myholdinglist,
                                                //       qtydata:
                                                //           state.qtyresponce,
                                                //       pl: state
                                                //           .myholdinglist[index]
                                                //           .pl
                                                //           .toStringAsFixed(2),
                                                //       quantity: holdingModel
                                                //                       .availablenetqty %
                                                //                   1 >
                                                //               0
                                                //           ? double.parse(holdingModel
                                                //                   .availablenetqty
                                                //                   .toString())
                                                //               .toStringAsFixed(
                                                //                   3)
                                                //           : holdingModel
                                                //               .availablenetqty
                                                //               .toInt()
                                                //               .toString(),
                                                //       pl_percentage: state
                                                //           .myholdinglist[index]
                                                //           .plPercentage
                                                //           .toStringAsFixed(2),
                                                //       todays_pl: state
                                                //           .myholdinglist[index]
                                                //           .todaysPl
                                                //           .toString(),
                                                //       todays_pl_percentage: state
                                                //           .myholdinglist[index]
                                                //           .todaysPlPercentage
                                                //           .toString(),
                                                //       // UserController()
                                                //       //     .myholdinglist
                                                //       //     .reportData[index]
                                                //       //     .toJson(),
                                                //     ),
                                                //   );
                                                // },

                                                child: HoldingsListTile(
                                                  holdingModel: state
                                                      .myholdinglist[index],
                                                  reportData:
                                                      state.myholdinglist,
                                                  index: index,
                                                  quantity: state
                                                                  .myholdinglist[
                                                                      index]
                                                                  .availablenetqty %
                                                              1 >
                                                          0
                                                      ? double.parse(state
                                                              .myholdinglist[
                                                                  index]
                                                              .availablenetqty
                                                              .toString())
                                                          .toStringAsFixed(3)
                                                      : state
                                                          .myholdinglist[index]
                                                          .availablenetqty
                                                          .toInt()
                                                          .toString(),
                                                ),
                                              );
                                            }),
                                      ],
                                    ),
                                  )
                              ],
                            )
                            // else
                            //   Column(
                            //     children: [
                            //       HoldingListShimmer(),
                            //       Padding(
                            //         padding: EdgeInsets.only(top: 100),
                            //         child: emptyContainerPortfolioHoldings(context),
                            //       )
                            //     ],
                            //   )
                          ],
                        )
                    ],
                  ),
                ),
              ],
            );
          });
        }),
      ),
    );
  }

  void filterdata(String name) {
    List<Map<String, dynamic>> list = [];

    holdingsList.forEach((element) {
      if (element.containsValue(name)) {
        list.add(element);
      }

      setState(() {
        holdingsList = List.from(list);
      });
    });
  }

  @override
  bool get wantKeepAlive => true;
}

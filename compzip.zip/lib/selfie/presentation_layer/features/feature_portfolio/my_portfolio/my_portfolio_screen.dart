import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/portfolio_model/Portfolio.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/my_portfolio/bloc/my_portfolio_screen_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/my_portfolio/tab_component_holdings/holdings_component.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/smartfolio/samrtfolio_page.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/appbar/customAppbarMain.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/others/custom_top_tab.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/position/position_inner.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/watchlist/market_overview.dart';
import 'package:selfie_mobile_flutter/text/portfolio.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'tab_component_holdings/bloc/holdings_component_cubit.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';

class MyPortfolioScreen extends StatefulWidget {
  const MyPortfolioScreen({Key? key}) : super(key: key);

  @override
  State<MyPortfolioScreen> createState() => _MyPortfolioScreenState();
}

class _MyPortfolioScreenState extends State<MyPortfolioScreen>
    with TickerProviderStateMixin {
  bool _showAppbar = true;
  List<HoldingModel> list = [];
  void initState() {
    // TODO: implement initState
    super.initState();
    _controller = BottomSheet.createAnimationController(this);
    _controller!.duration = const Duration(milliseconds: 400);
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  AnimationController? _controller;
  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
            create: (context) => MyPortfolioScreenCubit(
                apiGateway: context.gTradingApiGateway, context: context)),
      ],
      child: Stack(
        children: [
          BlocConsumer<MyPortfolioScreenCubit, MyPortfolioScreenState>(
              listener: (context, state) {
            if (state is MyPortfolioScreenInitial) {
              if (state.errorMsg != "") {
                ScaffoldMessenger.of(context).showSnackBar(
                    showErrorDialogue(errorMessage: state.errorMsg));
              }
            }
          }, builder: (context, state) {
            return Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  AnimatedContainer(
                    margin: const EdgeInsets.only(top: 8.0),
                    height: !_showAppbar ? 0 : 58,
                    curve: Curves.easeInOut,
                    duration: const Duration(milliseconds: 400),
                    child: CustomAppBarMain(
                      title: portfolioIndexTitle,
                      endIcon: InkWell(
                        onTap: () {
                          customBottomSheet(
                              controller: _controller,
                              height: .9,
                              minimumHeight: .7,
                              context: context,
                              inputWidget: MarKetOverview());
                        },
                        child: const Padding(
                          padding: EdgeInsets.only(right: 16),
                          child: ImageIcon(
                            AssetImage("assets/frame.png"),
                            size: 24,
                          ),
                        ),
                      ),
                      onTapTitle: () {},
                    ),
                  ),
                  const SizedBox(height: 8),
                  Expanded(
                    child: CustomTabBar(
                      tabContent: [
                        "Holdings (${UserController().portfolioresponce.result3.length})",
                        "Position (${UserController().portfolioresponce.result4.length})",

                        "Smartfolio"
                        // UserController().portfolioresponce..isNotEmpty
                        //     ? "Smartfolio(${UserController().portfolioresponce..length})"
                        //     : "Smartfolio"
                      ],
                      onTap: (index) {},
                      tabBarViewChildern: [
                        BlocProvider(
                          create: (context) => HoldingsComponentCubit(
                              context.gTradingApiGateway, context),
                          child: HoldingsComponent(
                            onScrollEvent: (bool showAppBar) {
                              // setState(() {
                              //   _showAppbar = showAppBar;
                              // });
                            },
                            length: list.length,
                          ),
                        ),
                        PositionInnerWidget(),
                        SmartfolioPage()
                      ],
                    ),
                  )
                ]);
          }),
        ],
      ),
    );
  }
}

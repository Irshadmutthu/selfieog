import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/order_model/Order.dart';
import 'package:selfie_mobile_flutter/portfolio_model/Portfolio.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/position_long_press/bloc/position_long_press_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/buttons/BasketButton.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/bottomsheet_basket_widget.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/scrollable_bottomsheet/scrollable_bottomsheet.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/portfolio/portfolio_position_list_item_selected.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/utils/order_settings.dart';
import 'package:trading_api/requests/order_request.dart';
import 'package:trading_api/utils/utils.dart';

import '../../../../../../constants/enums.dart';
import '../../../../../../user_controller/user_controller.dart';
import '../../../../../../utils/user_settings.dart';
import '../../../../../../utils/utils.dart';
import '../../../../../widgets/custom_app_components/alert_dialogs.dart';

class Portfolio_Position_LongPress extends StatefulWidget {
  List<PositionModel> positionlist;
  Portfolio_Position_LongPress({Key? key, required this.positionlist})
      : super(key: key);

  @override
  _Portfolio_Position_LongPressState createState() =>
      _Portfolio_Position_LongPressState();
}

class _Portfolio_Position_LongPressState
    extends State<Portfolio_Position_LongPress> {
  List<PositionModel> checklist = [];
  int ErrorCode = 0;
  int checkcount = 0;
  int listConut = 0;
  AnimationController? _controller;

  @override
  Widget build(BuildContext context) {
    double mheight = MediaQuery.of(context).size.height * 1.222;
    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(0.0),
          child: AppBar(
            elevation: 0,
            backgroundColor: customColors().backgroundPrimary,
          )),
      bottomNavigationBar: SizedBox(
        height: screenSize.height * 0.13,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Divider(
              thickness: 1.0,
              color: customColors().backgroundTertiary,
            ),
            Padding(
              padding: const EdgeInsets.only(
                  left: 16.0, right: 16.0, top: 8.0, bottom: 12.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Expanded(
                    flex: 2,
                    child: BasketButton(
                        onpress: () {
                          checkcount != 0
                              ? customShowModalBottomSheet(
                                  controller: _controller,
                                  context: context,
                                  inputWidget: SelectBasketWidget(
                                    title: "Select or Create new Basket",
                                    basketList: const [
                                      {
                                        "name":
                                            "All weather investing-B-sun Dec 12 2021"
                                      },
                                      {"name": "Top 250 stock"},
                                      {"name": "Trial 1"}
                                    ],
                                    controller: _controller,
                                  ))
                              : "";
                        },
                        text: "Add to Basket",
                        bgcolor: checkcount == 0
                            ? customColors().backgroundPrimary.withOpacity(0.4)
                            : customColors().backgroundPrimary,
                        bordercolor: checkcount == 0
                            ? customColors().primary.withOpacity(0.4)
                            : customColors().primary,
                        textStyle: checkcount == 0
                            ? customTextStyle(fontStyle: FontStyle.BodyL_Bold)
                                .copyWith(
                                    color:
                                        customColors().primary.withOpacity(0.4))
                            : customTextStyle(
                                fontStyle: FontStyle.BodyL_Bold,
                                color: FontColor.Primary)),
                  ),
                  Expanded(
                    flex: 2,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: BasketButton(
                          onpress: () async {
                            await showAlertDilogue(
                                context: context,
                                content:
                                    "Do you want to Square off selected orders ?",
                                negativeButtonName: "Cancel",
                                onPositiveButtonClick: () {
                                  Navigator.of(context).pop(true);

                                  for (var element in checklist) {
                                    OrderModel model = OrderModel(
                                        element.instrument,
                                        UserSettings
                                            .userSettings.orderSettings);
                                    model.buyOrSell =
                                        element.availablenetqty > 0
                                            ? BUY
                                            : SELL;
                                    model.productType =
                                        getProductTypeId(element.producttype);
                                    model.squareOff = true;
                                    model.qty = element.availablenetqty.toInt();
                                    callSqaureoff(model);
                                    listConut++;
                                  }
                                  // Navigator.pop(context);
                                  context.gNavigationService.back(context,
                                      arg: {"isSquareOffAll": true});
                                  // if (ErrorCode != 0) {
                                  //   //replace with sanck bar
                                  //   //Some square off request failed to sent
                                  //   ScaffoldMessenger.of(context).showSnackBar(
                                  //       showSuccessDialogue(
                                  //           errorMessage:
                                  //               "Some square off requests failed to sent"));
                                  //   Navigator.pop(context);
                                  // } else {
                                  //   ScaffoldMessenger.of(context).showSnackBar(
                                  //       showSuccessDialogue(
                                  //           errorMessage:
                                  //               "orders sent to exchange"));
                                  //   Navigator.pop(context);
                                  // }
                                },
                                onNegativeButtonClick: () {
                                  Navigator.of(context).pop(true);
                                });
                          },
                          text: "Square Off",
                          bgcolor: checkcount == 0
                              ? customColors().danger.withOpacity(0.4)
                              : customColors().danger,
                          bordercolor: checkcount == 0
                              ? customColors().danger.withOpacity(0.1)
                              : customColors().danger,
                          textStyle: customTextStyle(
                              fontStyle: FontStyle.BodyL_Bold,
                              color: FontColor.White)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
                border: Border(
                    bottom: BorderSide(
                        width: 2.0, color: customColors().backgroundTertiary))),
            child: Padding(
              padding: EdgeInsets.only(
                top: mheight * .04,
              ),
              child: Center(
                child: Row(
                  children: [
                    IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const ImageIcon(
                            AssetImage("assets/arrow_left.png"),
                            size: 24)),
                    Expanded(
                      child: SizedBox(
                        width: double.maxFinite,
                        child: Row(
                          children: [
                            Text(
                              checkcount.toString() +
                                  "/" +
                                  widget.positionlist.length.toString(),
                              style: customTextStyle(
                                  fontStyle: FontStyle.BodyL_SemiBold,
                                  color: FontColor.FontPrimary),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 8.0),
                              child: Text(
                                "Selected",
                                style: customTextStyle(
                                    fontStyle: FontStyle.BodyL_SemiBold,
                                    color: FontColor.FontSecondary),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    Row(
                      children: [
                        Text(
                          "All",
                          style: customTextStyle(
                              fontStyle: FontStyle.BodyL_Regular,
                              color: FontColor.FontPrimary),
                        ),
                        Checkbox(
                          activeColor: customColors().primary,
                          onChanged: (value) {
                            checkall();
                          },
                          value: checklist.length == widget.positionlist.length
                              ? true
                              : false,
                        ),
                      ],
                    ),
                    // Visibility(
                    //   visible: _clearbtn,
                    //   child: IconButton(
                    //     icon: ImageIcon(const AssetImage("assets/close.png"),
                    //         color: customColors().fontPrimary),
                    //     onPressed: () => widget.controller.clear(),
                    //   ),
                    // ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 5.0),
                    child: ListView.builder(
                        itemCount: widget.positionlist.length,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemBuilder: (context, index) {
                          return PortfolioPositionListItemSelected(
                            positions: widget.positionlist[index],
                            checklist: checklist,
                            upcount: updatecount,
                          );
                        }),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  void checkall() {
    setState(() {
      if (checklist.isEmpty) {
        for (int i = 0; i < widget.positionlist.length; i++) {
          checklist.add(widget.positionlist[i]);
        }
      } else {
        checklist.clear();
      }
      checkcount = checklist.length;
    });
  }

  void updatecount(int count) {
    setState(() {
      checkcount = count;
    });
  }

  callSqaureoff(OrderModel order) async {
    var response = await BlocProvider.of<PositionLongpressCubit>(context)
        .sendNeworderRequest(
            orderRquest: OrderRquest(
                proc: "new_order_service",
                intReqObj: SendOrderIntReqObj(
                  buySell: order.buyOrSell.toString(),
                  channel: 18,
                  discloseQty: order.discloseQty,
                  expirationDate:
                      doDateConversion(order.instrument.contractDate),
                  gid: 0,
                  goodtilldate: changeDateFormat(order.tifDate),
                  instrumentType: order.instrument.type,
                  ioc: '0',
                  lots: order.lots,
                  ltPrice: order.price,
                  moh: ' ',
                  orderType: order.isModify ? 2 : 1, //widget.order.OrderType
                  price: order.price,
                  priceCondition: "1",
                  proClient: 'CLI',
                  productType: order.productType,
                  qty: order.instrument.venueIndex == 7 ||
                          order.instrument.venueIndex == 6
                      ? order.lots.toString()
                      : order.qty.toString(),
                  qtyChange: order.qtyChange,
                  securityCode: order.instrument.securityCode,
                  segment: order.segment,
                  series: order.instrument.series,
                  strikePrice: 0,
                  tifCd: order.timeCondition,
                  transId: order.TransId ?? " ",
                  triggerPrice: order.triggerPrice,
                  venueCode: order.instrument.venuecode,
                  venueScripCode: order.instrument.scripcode,
                  dtoheader: OrderDtoheader(
                      loginId: UserController().userId,
                      creationTime: DateTime.now().microsecondsSinceEpoch,
                      messageType: order.isModify ? 11 : 10),
                ),
                corelationId: DateTime.now().microsecondsSinceEpoch));
    if (response.errorCode != null) {
      if (response.errorCode != 0) {
        ErrorCode++;
      }
    } else {
      ErrorCode++;
    }
  }

  onLoading(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return StreamBuilder(
            stream: Stream.periodic(const Duration(milliseconds: 1)),
            builder: (context, snap) {
              return Dialog(
                child: Container(
                  height: 120,
                  width: 100,
                  color: customColors().backgroundPrimary,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(
                        color: customColors().primary,
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      Text(
                        "$listConut / $checkcount",
                        style: customTextStyle(
                            fontStyle: FontStyle.BodyL_SemiBold,
                            color: FontColor.FontPrimary),
                      ),
                    ],
                  ),
                ),
              );
            });
      },
    );
  }
}

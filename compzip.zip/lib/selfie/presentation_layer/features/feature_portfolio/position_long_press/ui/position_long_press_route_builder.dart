import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/portfolio_model/Portfolio.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/position_long_press/ui/portfilo_position_long_press_page.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';

import '../bloc/position_long_press_cubit.dart';

class PositionLongPressRouteBuilder {
  final ServiceLocator _serviceLocator;
  List<PositionModel> positionlist;
  PositionLongPressRouteBuilder(this._serviceLocator, this.positionlist);

  Widget call(BuildContext context) {
    return MultiBlocProvider(
        providers: [
          BlocProvider(
              create: (context) => PositionLongpressCubit(
                  apiGateway: _serviceLocator.tradingApi))
        ],
        child: MultiRepositoryProvider(providers: [
          RepositoryProvider.value(value: _serviceLocator.navigationService),
          RepositoryProvider<CubitsLocator>.value(value: _serviceLocator),
        ], child: Portfolio_Position_LongPress(positionlist: positionlist)));
  }
}

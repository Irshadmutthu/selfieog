import 'package:bloc/bloc.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/position_long_press/bloc/position_long_press_state.dart';
import 'package:trading_api/requests/order_request.dart';
import 'package:trading_api/responses/order_response.dart';

import '../../../../../../services/api_gateway.dart';

class PositionLongpressCubit extends Cubit<PositionLongPressState> {
  TradingApiGateway apiGateway;
  late OrderResponse _response;
  PositionLongpressCubit({required this.apiGateway})
      : super(PositionLongPressInitial());
  Future<OrderResponse> sendNeworderRequest(
      {required OrderRquest orderRquest}) async {
    _response = await apiGateway.newOrderRequest(orderRquest: orderRquest);
    return _response;
  }
}

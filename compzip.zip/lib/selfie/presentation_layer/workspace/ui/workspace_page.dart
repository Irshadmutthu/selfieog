import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:selfie_mobile_flutter/app_page_injectable.dart';
import 'package:selfie_mobile_flutter/mds_controller.dart/mds_controller.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/bloc_navigation/navigation_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_idea/idea_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_order/order_book/ui/order_book_screen.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/bloc/holding_overview_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/page_holding_overview/holding_overview_tab/ui/holding_tab_page.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/holding_overview/page_holding_overview/ui/holding.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/my_portfolio/my_portfolio_screen.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/my_portfolio/tab_component_holdings/bloc/holdings_component_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_portfolio/smartfolio/smartfolio_holdings.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_watchlist/bloc/watchlist_cubit.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/feature_watchlist/page_watchlist/watchlist_screen.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/features/more_option/more_option.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/more_content.dart';
import 'package:selfie_mobile_flutter/selfie/repository_layer/portfolio_content.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/alert_dialogs.dart';
import 'package:selfie_mobile_flutter/selfie/widgets/custom_app_components/custom_bottom_bar.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/theme/styles.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/network/network_service_status.dart';
import 'package:selfie_mobile_flutter/utils/utils.dart';

class WorkspacePage extends StatefulWidget {
  final ServiceLocator serviceLocator;
  const WorkspacePage({Key? key, required this.serviceLocator})
      : super(key: key);

  @override
  _WorkspacePageState createState() => _WorkspacePageState();
}

class _WorkspacePageState extends State<WorkspacePage> {
  int selectedIndex = 0;
  bool returnVal = false;
  StreamSubscription? subscription;
  StreamSubscription? navSubscription;
  StreamSubscription? networkSubscription;
  int pageIndex = -1;
  // late Stream<NetworkStatus> stream;

  @override
  void dispose() {
    if (subscription != null) {
      subscription!.cancel();
    }
    super.dispose();
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    NetworkStatusService.networkStatusController.stream
        .listen((NetworkStatus status) {
      if (status == NetworkStatus.Online) {
        ScaffoldMessenger.of(context).showSnackBar(
            showSuccessDialogue(errorMessage: "Inernet connection restored"));
      } else if (status == NetworkStatus.Offline) {
        ScaffoldMessenger.of(context).showSnackBar(
            showErrorDialogue(errorMessage: "Inernet connection lost"));
      }
    });

    navSubscription =
        context.read<NavigationCubit>().adcontroller.stream.listen((event) {
      pageIndex = event;
    });

    subscription = context.gTradingApiGateway.networkStreamController.stream
        .listen((event) {
      if (event.contains("session timeout")) {
        showAlertDilogue(
            context: context,
            content: "Session timeout",
            positiveButtonName: "Relogin",
            onPositiveButtonClick: () async {
              await logout(context);
            });
        // ScaffoldMessenger.of(context).showSnackBar(showErrorDialogueWithAction(
        //     errorMessage: "Server session timeout",
        //     onPressed: () async {
        //       NetworkStatusService.networkStatusController.sink
        //           .add(NetworkStatus.Online);
        //       await logout(context);
        //     }));
      }
    });

    subscription = MDS_Controller().orderStatusStream.listen((event) {
      String orderStatus = event.getOrderStatus;
      String message = event.getQuotedMessage;
      switch (orderStatus) {
        case 'CANCELLED':
        case 'CONFIRMED':
        case 'EXECUTED':
          {
            UserController().allowOrderbookRequest = true;
            UserController().allowPortfolioRequest = true;
            break;
          }
      }

      ScaffoldMessenger.of(context).clearSnackBars();
      ScaffoldMessenger.of(context).showSnackBar(
        showOrderStatus(
            context: context, status: orderStatus, message: message),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;

    return WillPopScope(
      onWillPop: () async {
        if (selectedIndex == 0) {
          await showAlertDilogue(
              context: context,
              content: "Do you want to exit the app?",
              positiveButtonName: "Yes",
              negativeButtonName: "No",
              onPositiveButtonClick: () {
                setState(() {
                  returnVal = true;
                });
                Navigator.of(context).pop(true);
              },
              onNegativeButtonClick: () {
                setState(() {
                  returnVal = false;
                });
                Navigator.of(context).pop(true);
              });
        } else {
          BlocProvider.of<NavigationCubit>(context).updateWatchList(0);
          setState(() {
            selectedIndex = 0;
          });
        }
        return returnVal;
      },
      child: Scaffold(
          appBar: PreferredSize(
              preferredSize: const Size.fromHeight(0.0),
              child: AppBar(
                elevation: 0,
                backgroundColor: customColors().backgroundPrimary,
              )),
          bottomNavigationBar: CustomBottomNavigationBar(
              selectedIndex: selectedIndex,
              context: context,
              onTap: (int value) {
                BlocProvider.of<NavigationCubit>(context)
                    .updateWatchList(value);
                setState(() {
                  selectedIndex = value;
                });
              }),
          body: BlocBuilder<NavigationCubit, NavigationState>(
            builder: (context, state) {
              if (state is WatchlistIndexState) {
                return IndexedStack(index: state.index, children: [
                  BlocProvider(
                    create: (context) => WatchlistCubit(
                        tradingApiGateway: context.gTradingApiGateway,
                        context: context),
                    child: WatchlistScreen(),
                  ),
                  const MyPortfolioScreen(),
                  const OrderBookScreen(),
                  const IdeaPage(),

                  // MultiBlocProvider(
                  //     providers: [
                  //       BlocProvider(
                  //           create: (context) => WorkSpaceCubit(
                  //               serviceLocator: widget.serviceLocator)),
                  //     ],
                  //     child: MultiRepositoryProvider(providers: [
                  //       RepositoryProvider.value(
                  //           value: widget.serviceLocator.navigationService),
                  //       RepositoryProvider<CubitsLocator>.value(
                  //           value: widget.serviceLocator),
                  //     ], child: CustomCalanderPage())),

                  const MoreOptionPage(),
                  //MoreScreen(),
                  const HoldingPage(),
                  HoldingTabPage(
                    tabIndex: state.args["tabIndex"] ?? 0,
                    tabName: state.args["pageName"] ?? "",
                  ),
                  SmartfolioHoldings(items: SmartfoliContent, selecteditem: 0),
                ]);
              }
              return Container();
            },
          )),
    );
  }
}

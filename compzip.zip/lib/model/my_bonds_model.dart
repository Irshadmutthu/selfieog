// To parse this JSON data, do
//
//     final myBondsModel = myBondsModelFromJson(jsonString);

import 'dart:convert';

import 'package:selfie_mobile_flutter/model/bonds_list_data_model.dart';

MyBondsModel myBondsModelFromJson(String str) =>
    MyBondsModel.fromJson(json.decode(str));

String myBondsModelToJson(MyBondsModel data) => json.encode(data.toJson());

class MyBondsModel {
  MyBondsModel({
    this.myBondsData,
  });

  List<BondsListData>? myBondsData;

  MyBondsModel copyWith({
    List<BondsListData>? myBondsData,
  }) =>
      MyBondsModel(
        myBondsData: [BondsListData.fromJson({})],
      );

  factory MyBondsModel.fromJson(Map<String, dynamic> json) => MyBondsModel(
        myBondsData:
            json["Result3"] == null || json["Result3"][0].toString() == "{}"
                ? []
                : List<BondsListData>.from(
                    json["Result3"].map((x) => BondsListData.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Result3": myBondsData == null
            ? []
            : List<dynamic>.from(myBondsData!.map((x) => x.toJson())),
      };
}

// class MyBondsData {
//   MyBondsData({
//     this.yield,
//     this.issuedate,
//     this.mininvestment,
//     this.maturitydate,
//     this.name,
//     this.interest,
//     this.selected,
//     this.coupon,
//     this.interestpayment,
//     this.nextpayment,
//     this.misc1,
//     this.id,
//     this.imageurl,
//     this.type,
//   });

//   String? yield;
//   String? issuedate;
//   String? mininvestment;
//   String? maturitydate;
//   String? name;
//   String? interest;
//   String? selected;
//   String? coupon;
//   String? interestpayment;
//   String? nextpayment;
//   String? misc1;
//   String? id;
//   String? imageurl;
//   String? type;

//   MyBondsData copyWith({
//     String? yield,
//     String? issuedate,
//     String? mininvestment,
//     String? maturitydate,
//     String? name,
//     String? interest,
//     String? selected,
//     String? coupon,
//     String? interestpayment,
//     String? nextpayment,
//     String? misc1,
//     String? id,
//     String? imageurl,
//     String? type,
//   }) =>
//       MyBondsData(
//         yield: yield ?? this.yield,
//         issuedate: issuedate ?? this.issuedate,
//         mininvestment: mininvestment ?? this.mininvestment,
//         maturitydate: maturitydate ?? this.maturitydate,
//         name: name ?? this.name,
//         interest: interest ?? this.interest,
//         selected: selected ?? this.selected,
//         coupon: coupon ?? this.coupon,
//         interestpayment: interestpayment ?? this.interestpayment,
//         nextpayment: nextpayment ?? this.nextpayment,
//         misc1: misc1 ?? this.misc1,
//         id: id ?? this.id,
//         imageurl: imageurl ?? this.imageurl,
//         type: type ?? this.type,
//       );

//   factory MyBondsData.fromJson(Map<String, dynamic> json) => MyBondsData(
//         yield: json["YIELD"] ?? "-",
//         issuedate: json["ISSUEDATE"] ?? "-",
//         mininvestment: json["MININVESTMENT"] ?? "-",
//         maturitydate: json["MATURITYDATE"] ?? "-",
//         name: json["NAME"] ?? "-",
//         interest: json["INTEREST"] ?? "-",
//         selected: json["SELECTED"] ?? "-",
//         coupon: json["COUPON"] ?? "-",
//         interestpayment: json["INTERESTPAYMENT"] ?? "-",
//         nextpayment: json["NEXTPAYMENT"] ?? "-",
//         misc1: json["MISC1"] ?? "-",
//         id: json["ID"] ?? "-",
//         imageurl: json["IMAGEURL"] ?? "-",
//         type: json["TYPE"] ?? "-",
//       );

//   Map<String, dynamic> toJson() => {
//         "YIELD": yield ?? "",
//         "ISSUEDATE": issuedate ?? "",
//         "MININVESTMENT": mininvestment ?? "",
//         "MATURITYDATE": maturitydate ?? "",
//         "NAME": name ?? "",
//         "INTEREST": interest ?? "",
//         "SELECTED": selected ?? "",
//         "COUPON": coupon ?? "",
//         "INTERESTPAYMENT": interestpayment ?? "",
//         "NEXTPAYMENT": nextpayment ?? "",
//         "MISC1": misc1 ?? "",
//         "ID": id ?? "",
//         "IMAGEURL": imageurl ?? "",
//         "TYPE": type ?? "",
//       };
// }

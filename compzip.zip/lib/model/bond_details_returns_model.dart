// To parse this JSON data, do
//
//     final bondDetailsReturnsModel = bondDetailsReturnsModelFromJson(jsonString);

import 'dart:convert';

BondDetailsReturnsModel bondDetailsReturnsModelFromJson(String str) =>
    BondDetailsReturnsModel.fromJson(json.decode(str));

String bondDetailsReturnsModelToJson(BondDetailsReturnsModel data) =>
    json.encode(data.toJson());

class BondDetailsReturnsModel {
  BondDetailsReturnsModel({
    this.bondDetailsReturnsFirstTImelineTileModel,
    this.bondDetailsReturnsTImelineTileModel,
    this.bondDetailsReturnsContainerModel,
  });

  List<BondDetailsReturnsFirstTImelineTileModel>?
      bondDetailsReturnsFirstTImelineTileModel;
  List<BondDetailsReturnsTImelineTileModel>?
      bondDetailsReturnsTImelineTileModel;
  List<BondDetailsReturnsContainerModel>? bondDetailsReturnsContainerModel;

  BondDetailsReturnsModel copyWith({
    List<BondDetailsReturnsFirstTImelineTileModel>?
        bondDetailsReturnsFirstTImelineTileModel,
    List<BondDetailsReturnsTImelineTileModel>?
        bondDetailsReturnsTImelineTileModel,
    List<BondDetailsReturnsContainerModel>? bondDetailsReturnsContainerModel,
  }) =>
      BondDetailsReturnsModel(
        bondDetailsReturnsFirstTImelineTileModel:
            bondDetailsReturnsFirstTImelineTileModel ??
                this.bondDetailsReturnsFirstTImelineTileModel,
        bondDetailsReturnsTImelineTileModel:
            bondDetailsReturnsTImelineTileModel ??
                this.bondDetailsReturnsTImelineTileModel,
        bondDetailsReturnsContainerModel: bondDetailsReturnsContainerModel ??
            this.bondDetailsReturnsContainerModel,
      );

  factory BondDetailsReturnsModel.fromJson(Map<String, dynamic> json) =>
      BondDetailsReturnsModel(
        bondDetailsReturnsFirstTImelineTileModel:
            json["Result5"] == null || json["Result5"][0].toString() == "{}"
                ? []
                : List<BondDetailsReturnsFirstTImelineTileModel>.from(
                    json["Result5"].map((x) =>
                        BondDetailsReturnsFirstTImelineTileModel.fromJson(x))),
        bondDetailsReturnsTImelineTileModel: json["Result6"] == null ||
                json["Result6"][0].toString() == "{}"
            ? []
            : List<BondDetailsReturnsTImelineTileModel>.from(json["Result6"]
                .map((x) => BondDetailsReturnsTImelineTileModel.fromJson(x))),
        bondDetailsReturnsContainerModel: json["Result7"] == null
            ? [BondDetailsReturnsContainerModel.fromJson({})]
            : List<BondDetailsReturnsContainerModel>.from(json["Result7"]
                .map((x) => BondDetailsReturnsContainerModel.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Result5": bondDetailsReturnsFirstTImelineTileModel == null
            ? []
            : List<dynamic>.from(bondDetailsReturnsFirstTImelineTileModel!
                .map((x) => x.toJson())),
        "Result6": bondDetailsReturnsTImelineTileModel == null
            ? []
            : List<dynamic>.from(
                bondDetailsReturnsTImelineTileModel!.map((x) => x.toJson())),
        "Result7": bondDetailsReturnsContainerModel == null
            ? []
            : List<dynamic>.from(
                bondDetailsReturnsContainerModel!.map((x) => x.toJson())),
      };
}

class BondDetailsReturnsFirstTImelineTileModel {
  BondDetailsReturnsFirstTImelineTileModel({
    this.date,
    this.accrudeinterest,
    this.year,
    this.investment,
    this.premium,
  });

  String? date;
  String? accrudeinterest;
  String? year;
  String? investment;
  String? premium;

  BondDetailsReturnsFirstTImelineTileModel copyWith({
    String? date,
    String? accrudeinterest,
    String? year,
    String? investment,
    String? premium,
  }) =>
      BondDetailsReturnsFirstTImelineTileModel(
        date: date ?? this.date,
        accrudeinterest: accrudeinterest ?? this.accrudeinterest,
        year: year ?? this.year,
        investment: investment ?? this.investment,
        premium: premium ?? this.premium,
      );

  factory BondDetailsReturnsFirstTImelineTileModel.fromJson(
          Map<String, dynamic> json) =>
      BondDetailsReturnsFirstTImelineTileModel(
        date: json["DATE"] ?? "-",
        accrudeinterest: json["ACCRUDEINTEREST"] ?? "-",
        year: json["YEAR"] ?? "-",
        investment: json["INVESTMENT"] ?? "-",
        premium: json["PREMIUM"] ?? "-",
      );

  Map<String, dynamic> toJson() => {
        "DATE": date ?? "",
        "ACCRUDEINTEREST": accrudeinterest ?? "",
        "YEAR": year ?? "",
        "INVESTMENT": investment ?? "",
        "PREMIUM": premium ?? "",
      };
}

class BondDetailsReturnsTImelineTileModel {
  BondDetailsReturnsTImelineTileModel({
    this.date,
    this.year,
    this.interest,
  });

  String? date;
  String? year;
  String? interest;

  BondDetailsReturnsTImelineTileModel copyWith({
    String? date,
    String? year,
    String? interest,
  }) =>
      BondDetailsReturnsTImelineTileModel(
        date: date ?? this.date,
        year: year ?? this.year,
        interest: interest ?? this.interest,
      );

  factory BondDetailsReturnsTImelineTileModel.fromJson(
          Map<String, dynamic> json) =>
      BondDetailsReturnsTImelineTileModel(
        date: json["DATE"] ?? "-",
        year: json["YEAR"] ?? "-",
        interest: json["INTEREST"] ?? "-",
      );

  Map<String, dynamic> toJson() => {
        "DATE": date ?? "",
        "YEAR": year ?? "",
        "INTEREST": interest ?? "",
      };
}

class BondDetailsReturnsContainerModel {
  BondDetailsReturnsContainerModel({
    this.totalinvestment,
    this.interestearned,
    this.facevalue,
    this.totalreturns,
    this.units,
    this.unitInterval,
  });

  String? totalinvestment;
  String? interestearned;
  String? facevalue;
  String? totalreturns;
  String? units;
  int? unitInterval;

  BondDetailsReturnsContainerModel copyWith({
    String? totalinvestment,
    String? interestearned,
    String? facevalue,
    String? totalreturns,
    String? units,
    int? unitInterval,
  }) =>
      BondDetailsReturnsContainerModel(
        totalinvestment: totalinvestment ?? this.totalinvestment,
        interestearned: interestearned ?? this.interestearned,
        facevalue: facevalue ?? this.facevalue,
        totalreturns: totalreturns ?? this.totalreturns,
        units: units ?? this.units,
        unitInterval: unitInterval ?? this.unitInterval,
      );

  factory BondDetailsReturnsContainerModel.fromJson(
          Map<String, dynamic> json) =>
      BondDetailsReturnsContainerModel(
        totalinvestment: json["TOTALINVESTMENT"] ?? "-",
        interestearned: json["INTERESTEARNED"] ?? "-",
        facevalue: json["FACEVALUE"] ?? "-",
        totalreturns: json["TOTALRETURNS"] ?? "-",
        units: json["UNITS"] ?? "1",
        unitInterval: json["UNITINTERVAL"] != null
            ? int.tryParse(json["UNITINTERVAL"]) ?? 1
            : 1,
      );

  Map<String, dynamic> toJson() => {
        "TOTALINVESTMENT": totalinvestment ?? "",
        "INTERESTEARNED": interestearned ?? "",
        "FACEVALUE": facevalue ?? "",
        "TOTALRETURNS": totalreturns ?? "",
        "UNITS": units ?? "",
        "UNITINTERVAL": unitInterval ?? 1
      };
}

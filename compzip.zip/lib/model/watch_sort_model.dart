class WatchSortModel {
  int _sortId = -1;
  List<String> _sortOrder = [];

  WatchSortModel();

  int get getSortId => _sortId;
  List<String> get getSortOrder => _sortOrder;

  set setSortId(int id) {
    _sortId = id;
  }

  set setSortOrder(List<String> order) {
    _sortOrder = order;
  }
}

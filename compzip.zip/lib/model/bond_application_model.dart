// To parse this JSON data, do
//
//     final bondApplicationArgumentModel = bondApplicationArgumentModelFromJson(jsonString);

import 'dart:convert';

BondApplicationArgumentModel bondApplicationArgumentModelFromJson(String str) =>
    BondApplicationArgumentModel.fromJson(json.decode(str));

String bondApplicationArgumentModelToJson(BondApplicationArgumentModel data) =>
    json.encode(data.toJson());

class BondApplicationArgumentModel {
  BondApplicationArgumentModel({
    this.bondId,
    this.buySellInvestStatus,
    this.totalInvestment,
    this.yield,
    this.minInvestment,
    this.maturityDate,
    this.coupon,
    this.installments,
    this.issueDate,
    this.unit,
    this.misc1,
    this.bondtype,
    this.name,
  });

  String? bondId;
  String? buySellInvestStatus;
  String? totalInvestment;
  String? yield;
  String? minInvestment;
  String? maturityDate;
  String? coupon;
  String? installments;
  String? issueDate;
  String? unit;
  String? misc1;
  String? bondtype;
  String? name;

  BondApplicationArgumentModel copyWith({
    String? bondId,
    String? buySellInvestStatus,
    String? totalInvestment,
    String? yield,
    String? minInvestment,
    String? maturityDate,
    String? coupon,
    String? installments,
    String? issueDate,
    String? unit,
    String? misc1,
    String? bondtype,
    String? name,
  }) =>
      BondApplicationArgumentModel(
        bondId: bondId ?? this.bondId,
        buySellInvestStatus: buySellInvestStatus ?? this.buySellInvestStatus,
        totalInvestment: totalInvestment ?? this.totalInvestment,
        yield: yield ?? this.yield,
        minInvestment: minInvestment ?? this.minInvestment,
        maturityDate: maturityDate ?? this.maturityDate,
        coupon: coupon ?? this.coupon,
        installments: installments ?? this.installments,
        issueDate: issueDate ?? this.issueDate,
        unit: unit ?? this.unit,
        misc1: misc1 ?? this.misc1,
        bondtype: bondtype ?? this.bondtype,
        name: name ?? this.name,
      );

  factory BondApplicationArgumentModel.fromJson(Map<String, dynamic> json) =>
      BondApplicationArgumentModel(
        bondId: json["bondId"] ?? "-",
        buySellInvestStatus: json["buySellInvestStatus"] ?? "-",
        totalInvestment: json["TOTALINVESTMENT"] ?? "-",
        yield: json["YIELD"] ?? "-",
        minInvestment: json["MININVESTMENT"] ?? "-",
        maturityDate: json["MATURITYDATE"] ?? "-",
        coupon: json["COUPON"] ?? "-",
        installments: json["INSTALLMENTS"] ?? "-",
        issueDate: json["ISSUEDATE"] ?? "-",
        unit: json["UNITS"] ?? "-",
        misc1: json["MISC1"] ?? "-",
        bondtype: json["BONDTYPE"] ?? "-",
        name: json["NAME"] ?? "-",
      );

  Map<String, dynamic> toJson() => {
        "bondId": bondId ?? "",
        "buySellInvestStatus": buySellInvestStatus ?? "",
        "TOTALINVESTMENT": totalInvestment ?? "",
        "YIELD": yield ?? "",
        "MININVESTMENT": minInvestment ?? "",
        "MATURITYDATE": maturityDate ?? "",
        "COUPON": coupon ?? "",
        "INSTALLMENTS": installments ?? "",
        "ISSUEDATE": issueDate ?? "",
        "UNITS": unit ?? "",
        "MISC1": misc1 ?? "",
        "BONDTYPE": bondtype ?? "",
        "NAME": name ?? "",
      };
}

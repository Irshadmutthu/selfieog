// To parse this JSON data, do
//
//     final bondDetailsOverviewModel = bondDetailsOverviewModelFromJson(jsonString);

import 'dart:convert';

BondDetailsOverviewModel bondDetailsOverviewModelFromJson(String str) =>
    BondDetailsOverviewModel.fromJson(json.decode(str));

String bondDetailsOverviewModelToJson(BondDetailsOverviewModel data) =>
    json.encode(data.toJson());

class BondDetailsOverviewModel {
  BondDetailsOverviewModel({
    this.bondDetailsOverviewData,
  });

  List<BondDetailsOverviewData>? bondDetailsOverviewData;

  BondDetailsOverviewModel copyWith({
    List<BondDetailsOverviewData>? bondDetailsOverviewData,
  }) =>
      BondDetailsOverviewModel(
        bondDetailsOverviewData:
            bondDetailsOverviewData ?? this.bondDetailsOverviewData,
      );

  factory BondDetailsOverviewModel.fromJson(Map<String, dynamic> json) =>
      BondDetailsOverviewModel(
        bondDetailsOverviewData: json["Result4"] == null
            ? [BondDetailsOverviewData.fromJson({})]
            : List<BondDetailsOverviewData>.from(json["Result4"]
                .map((x) => BondDetailsOverviewData.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Result4": bondDetailsOverviewData == null
            ? []
            : List<dynamic>.from(
                bondDetailsOverviewData!.map((x) => x.toJson())),
      };
}

class BondDetailsOverviewData {
  BondDetailsOverviewData({
    this.tenureremaining,
    this.listed,
    this.nri,
    this.issuedate,
    this.bondDetailsOverviewYield,
    this.mininvestment,
    this.issuermode,
    this.facevalue,
    this.maturitydate,
    this.coupon,
    this.perpetual,
    this.creditrating,
    this.instrumenttype,
    this.interestpayment,
    this.calloption,
    this.lotsize,
    this.bankbondtype,
    this.bondpricelevel,
    this.misc1,
  });

  String? tenureremaining;
  String? listed;
  String? nri;
  String? issuedate;
  String? bondDetailsOverviewYield;
  String? mininvestment;
  String? issuermode;
  String? facevalue;
  String? maturitydate;
  String? coupon;
  String? perpetual;
  String? creditrating;
  String? instrumenttype;
  String? interestpayment;
  String? calloption;
  String? lotsize;
  String? bankbondtype;
  String? bondpricelevel;
  String? misc1;

  BondDetailsOverviewData copyWith({
    String? tenureremaining,
    String? listed,
    String? nri,
    String? issuedate,
    String? result4Yield,
    String? mininvestment,
    String? issuermode,
    String? facevalue,
    String? maturitydate,
    String? coupon,
    String? perpetual,
    String? creditrating,
    String? instrumenttype,
    String? interestpayment,
    String? calloption,
    String? lotsize,
    String? bankbondtype,
    String? bondpricelevel,
    String? misc1,
  }) =>
      BondDetailsOverviewData(
        tenureremaining: tenureremaining ?? this.tenureremaining,
        listed: listed ?? this.listed,
        nri: nri ?? this.nri,
        issuedate: issuedate ?? this.issuedate,
        bondDetailsOverviewYield: result4Yield ?? this.bondDetailsOverviewYield,
        mininvestment: mininvestment ?? this.mininvestment,
        issuermode: issuermode ?? this.issuermode,
        facevalue: facevalue ?? this.facevalue,
        maturitydate: maturitydate ?? this.maturitydate,
        coupon: coupon ?? this.coupon,
        perpetual: perpetual ?? this.perpetual,
        creditrating: creditrating ?? this.creditrating,
        instrumenttype: instrumenttype ?? this.instrumenttype,
        interestpayment: interestpayment ?? this.interestpayment,
        calloption: calloption ?? this.calloption,
        lotsize: lotsize ?? this.lotsize,
        bankbondtype: bankbondtype ?? this.bankbondtype,
        bondpricelevel: bondpricelevel ?? this.bondpricelevel,
        misc1: misc1 ?? this.misc1,
      );

  factory BondDetailsOverviewData.fromJson(Map<String, dynamic> json) =>
      BondDetailsOverviewData(
        tenureremaining: json["TENUREREMAINING"] ?? "-",
        listed: json["LISTED"] ?? "-",
        nri: json["NRI"] ?? "-",
        issuedate: json["ISSUEDATE"] ?? "-",
        bondDetailsOverviewYield: json["YIELD"] ?? "-",
        mininvestment: json["MININVESTMENT"] ?? "-",
        issuermode: json["ISSUERMODE"] ?? "-",
        facevalue: json["FACEVALUE"] ?? "-",
        maturitydate: json["MATURITYDATE"] ?? "-",
        coupon: json["COUPON"] ?? "-",
        perpetual: json["PERPETUAL"] ?? "-",
        creditrating: json["CREDITRATING"] ?? "-",
        instrumenttype: json["INSTRUMENTTYPE"] ?? "-",
        interestpayment: json["INTERESTPAYMENT"] ?? "-",
        calloption: json["CALLOPTION"] ?? "-",
        lotsize: json["LOTSIZE"] ?? "-",
        bankbondtype: json["BANKBONDTYPE"] ?? "-",
        bondpricelevel: json["BONDPRICELEVEL"] ?? "-",
        misc1: json["MISC1"] ?? "-",
      );

  Map<String, dynamic> toJson() => {
        "TENUREREMAINING": tenureremaining ?? "",
        "LISTED": listed ?? "",
        "NRI": nri ?? "",
        "ISSUEDATE": issuedate ?? "",
        "YIELD": bondDetailsOverviewYield ?? "",
        "MININVESTMENT": mininvestment ?? "",
        "ISSUERMODE": issuermode ?? "",
        "FACEVALUE": facevalue ?? "",
        "MATURITYDATE": maturitydate ?? "",
        "COUPON": coupon ?? "",
        "PERPETUAL": perpetual ?? "",
        "CREDITRATING": creditrating ?? "",
        "INSTRUMENTTYPE": instrumenttype ?? "",
        "INTERESTPAYMENT": interestpayment ?? "",
        "CALLOPTION": calloption ?? "",
        "LOTSIZE": lotsize ?? "",
        "BANKBONDTYPE": bankbondtype ?? "",
        "BONDPRICELEVEL": bondpricelevel ?? "",
        "MISC1": misc1 ?? "",
      };
}

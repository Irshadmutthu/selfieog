// To parse this JSON data, do
//
//     final bondDetailsReturnsModel = bondDetailsReturnsModelFromJson(jsonString);

import 'dart:convert';

BondDetailsIssuerModel bondDetailsIssuerModelFromJson(String str) =>
    BondDetailsIssuerModel.fromJson(json.decode(str));

String bondDetailsIssuerModelToJson(BondDetailsIssuerModel data) =>
    json.encode(data.toJson());

class BondDetailsIssuerModel {
  BondDetailsIssuerModel({
    this.bondDetailsIssuerData,
  });

  List<BondDetailsIssuerData>? bondDetailsIssuerData;

  BondDetailsIssuerModel copyWith({
    List<BondDetailsIssuerData>? bondDetailsReturnsData,
  }) =>
      BondDetailsIssuerModel(
        bondDetailsIssuerData:
            bondDetailsReturnsData ?? this.bondDetailsIssuerData,
      );

  factory BondDetailsIssuerModel.fromJson(Map<String, dynamic> json) =>
      BondDetailsIssuerModel(
        bondDetailsIssuerData: json["Result8"] == null
            ? [BondDetailsIssuerData.fromJson({})]
            : List<BondDetailsIssuerData>.from(
                json["Result8"].map((x) => BondDetailsIssuerData.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Result8": bondDetailsIssuerData == null
            ? []
            : List<dynamic>.from(bondDetailsIssuerData!.map((x) => x.toJson())),
      };
}

class BondDetailsIssuerData {
  BondDetailsIssuerData({
    this.keyhighlights,
    this.industry,
    this.annualrevenue,
    this.typeofissuer,
    this.title,
  });

  String? keyhighlights;
  String? industry;
  String? annualrevenue;
  String? typeofissuer;
  String? title;

  BondDetailsIssuerData copyWith({
    String? keyhighlights,
    String? industry,
    String? annualrevenue,
    String? typeofissuer,
    String? title,
  }) =>
      BondDetailsIssuerData(
        keyhighlights: keyhighlights ?? this.keyhighlights,
        industry: industry ?? this.industry,
        annualrevenue: annualrevenue ?? this.annualrevenue,
        typeofissuer: typeofissuer ?? this.typeofissuer,
        title: title ?? this.title,
      );

  factory BondDetailsIssuerData.fromJson(Map<String, dynamic> json) =>
      BondDetailsIssuerData(
        keyhighlights: json["KEYHIGHLIGHTS"] ?? "-",
        industry: json["INDUSTRY"] ?? "-",
        annualrevenue: json["ANNUALREVENUE"] ?? "-",
        typeofissuer: json["TYPEOFISSUER"] ?? "-",
        title: json["TITLE"] ?? "-",
      );

  Map<String, dynamic> toJson() => {
        "KEYHIGHLIGHTS": keyhighlights ?? "",
        "INDUSTRY": industry ?? "",
        "ANNUALREVENUE": annualrevenue ?? "",
        "TYPEOFISSUER": typeofissuer ?? "",
        "TITLE": title ?? "",
      };
}

import 'dart:convert';
import 'package:trading_api/common/common_methods.dart';

ProfileResponse profileResponseFromJson(String str) =>
    ProfileResponse.fromJson(json.decode(str));

String profileResponseToJson(ProfileResponse data) =>
    json.encode(data.toJson());

class ProfileResponse {
  ProfileResponse({
    this.result3,
    this.result2,
    this.errorCode,
  });

  List<Result3>? result3;
  List<Result2>? result2;
  String? errorCode;

  ProfileResponse copyWith({
    List<Result3>? result3,
    List<Result2>? result2,
    String? errorCode,
  }) =>
      ProfileResponse(
        result3: result3 ?? this.result3,
        result2: result2 ?? this.result2,
        errorCode: errorCode ?? this.errorCode,
      );

  factory ProfileResponse.fromJson(Map<String, dynamic> json) =>
      ProfileResponse(
        result3: json["Result3"] == null
            ? [Result3.fromJson({})]
            : List<Result3>.from(
                json["Result3"].map((x) => Result3.fromJson(x))),
        result2: json["Result2"] == null
            ? [Result2.fromJson({})]
            : List<Result2>.from(
                json["Result2"].map((x) => Result2.fromJson(x))),
        errorCode: json["Error Code"] ?? "0",
      );

  Map<String, dynamic> toJson() => {
        "Result3": result3 == null
            ? null
            : List<dynamic>.from(result3!.map((x) => x.toJson())),
        "Result2": result2 == null
            ? null
            : List<dynamic>.from(result2!.map((x) => x.toJson())),
        "Error Code": errorCode ?? "0",
      };
}

class Result2 {
  Result2({
    this.errormessage,
    this.errorcode,
  });

  String? errormessage;
  String? errorcode;

  Result2 copyWith({
    String? errormessage,
    String? errorcode,
  }) =>
      Result2(
        errormessage: errormessage ?? this.errormessage,
        errorcode: errorcode ?? this.errorcode,
      );

  factory Result2.fromJson(Map<String, dynamic> json) => Result2(
        errormessage: json["ERRORMESSAGE"] ?? "",
        errorcode: json["ERRORCODE"] == "" ? null : json["ERRORCODE"],
      );

  Map<String, dynamic> toJson() => {
        "ERRORMESSAGE": errormessage ?? "",
        "ERRORCODE": errorcode ?? "0",
      };
}

class Result3 {
  Result3({
    this.location = "-",
    this.marginfundingallowed = "-",
    this.phoneno = "",
    this.state = "-",
    this.limit = "-",
    this.pincode = "-",
    this.itclient = "-",
    this.country = "-",
    this.brcontactperson = "-",
    this.dob,
    this.brphone1 = "-",
    this.username = "-",
    this.address1 = "-",
    this.parentusercode = "-",
    this.address2 = "-",
    this.brphone2 = "-",
    this.brstate = "-",
    this.poasigned = false,
    this.minimumordervalue = "-",
    this.brdistrict = "-",
    this.brmgrname = "-",
    this.bremailid = "-",
    this.vantagetrade = "-",
    this.activesegments = const [],
    this.inactivesegments = const [],
    this.activeProducts = const [],
    this.inactiveProducts = const [],
    this.clienttype = "-",
    this.braddress4 = "-",
    this.braddress1 = "-",
    this.usercode = "-",
    this.braddress2 = "-",
    this.braddress3 = "-",
    this.city = "-",
    this.b2Bpartner = "-",
    this.tradingallowed = "-",
    this.margintradeallowed = "-",
    this.orderallowed = "-",
    this.emailid = "-",
    this.dpid = const [],
    this.dpClientid = "-",
    this.bankAccountNumber = const [],
    this.bankName = const [],
  });

  String? location;
  String? marginfundingallowed;
  String? phoneno;
  String? state;
  String? limit;
  String? pincode;
  String? itclient;
  String? country;
  String? brcontactperson;
  DateTime? dob;
  String? brphone1;
  String? username;
  String? address1;
  String? parentusercode;
  String? address2;
  String? brphone2;
  String? brstate;
  bool? poasigned;
  String? minimumordervalue;
  String? brdistrict;
  String? brmgrname;
  String? bremailid;
  String? vantagetrade;
  List<String>? activesegments;
  List<String>? inactivesegments;
  List<String>? activeProducts;
  List<String>? inactiveProducts;
  String? clienttype;
  String? braddress4;
  String? braddress1;
  String? usercode;
  String? braddress2;
  String? braddress3;
  String? city;
  String? b2Bpartner;
  String? tradingallowed;
  String? margintradeallowed;
  String? orderallowed;
  String? emailid;
  List<String>? dpid;
  String? dpClientid;
  List<String>? bankAccountNumber;
  List<String>? bankName;

  Result3 copyWith(
          {String? location,
          String? marginfundingallowed,
          String? phoneno,
          String? state,
          String? limit,
          String? pincode,
          String? itclient,
          String? country,
          String? brcontactperson,
          DateTime? dob,
          String? brphone1,
          String? username,
          String? address1,
          String? parentusercode,
          String? address2,
          String? brphone2,
          String? brstate,
          bool? poasigned,
          String? minimumordervalue,
          String? brdistrict,
          String? brmgrname,
          String? bremailid,
          String? vantagetrade,
          List<String>? activesegments,
          List<String>? inactivesegments,
          List<String>? activeProducts,
          List<String>? inactiveProducts,
          String? clienttype,
          String? braddress4,
          String? braddress1,
          String? usercode,
          String? braddress2,
          String? braddress3,
          String? city,
          String? b2Bpartner,
          String? tradingallowed,
          String? margintradeallowed,
          String? orderallowed,
          String? emailid,
          List<String>? dpid,
          String? dpClientid,
          List<String>? bankAccountid,
          List<String>? bankName}) =>
      Result3(
        location: location ?? this.location,
        marginfundingallowed: marginfundingallowed ?? this.marginfundingallowed,
        phoneno: phoneno ?? this.phoneno,
        state: state ?? this.state,
        limit: limit ?? this.limit,
        pincode: pincode ?? this.pincode,
        itclient: itclient ?? this.itclient,
        country: country ?? this.country,
        brcontactperson: brcontactperson ?? this.brcontactperson,
        dob: dob ?? this.dob,
        brphone1: brphone1 ?? this.brphone1,
        username: username ?? this.username,
        address1: address1 ?? this.address1,
        parentusercode: parentusercode ?? this.parentusercode,
        address2: address2 ?? this.address2,
        brphone2: brphone2 ?? this.brphone2,
        brstate: brstate ?? this.brstate,
        poasigned: poasigned ?? this.poasigned,
        minimumordervalue: minimumordervalue ?? this.minimumordervalue,
        brdistrict: brdistrict ?? this.brdistrict,
        brmgrname: brmgrname ?? this.brmgrname,
        bremailid: bremailid ?? this.bremailid,
        vantagetrade: vantagetrade ?? this.vantagetrade,
        activesegments: activesegments ?? this.activesegments,
        inactivesegments: inactivesegments ?? this.inactivesegments,
        activeProducts: activeProducts ?? this.activeProducts,
        inactiveProducts: inactiveProducts ?? this.inactiveProducts,
        clienttype: clienttype ?? this.clienttype,
        braddress4: braddress4 ?? this.braddress4,
        braddress1: braddress1 ?? this.braddress1,
        usercode: usercode ?? this.usercode,
        braddress2: braddress2 ?? this.braddress2,
        braddress3: braddress3 ?? this.braddress3,
        city: city ?? this.city,
        b2Bpartner: b2Bpartner ?? this.b2Bpartner,
        tradingallowed: tradingallowed ?? this.tradingallowed,
        margintradeallowed: margintradeallowed ?? this.margintradeallowed,
        orderallowed: orderallowed ?? this.orderallowed,
        emailid: emailid ?? this.emailid,
        dpid: dpid ?? this.dpid,
        dpClientid: dpClientid ?? this.dpClientid,
        bankAccountNumber: bankAccountid ?? bankAccountNumber,
        bankName: bankAccountid ?? this.bankName,
      );

  factory Result3.fromJson(Map<String, dynamic> json) => Result3(
        location: json["LOCATION"] ?? "-",
        marginfundingallowed: json["MARGINFUNDINGALLOWED"] ?? "-",
        phoneno: json["PHONENO"] ?? "",
        state: json["STATE"] ?? "-",
        limit: json["LIMIT"] ?? "-",
        pincode: json["PINCODE"] ?? "-",
        itclient: json["ITCLIENT"] ?? "-",
        country: json["COUNTRY"] ?? "-",
        brcontactperson: json["BRCONTACTPERSON"] ?? "-",
        dob: json["DOB"] == null ? null : DateTime.parse(json["DOB"]),
        brphone1: json["BRPHONE1"] ?? "-",
        username: json["USERNAME"] ?? "-",
        address1: json["ADDRESS1"] ?? "-",
        parentusercode: json["PARENTUSERCODE"] ?? "-",
        address2: json["ADDRESS2"] ?? "-",
        brphone2: json["BRPHONE2"] ?? "-",
        brstate: json["BRSTATE"] ?? "-",
        poasigned: json["POASIGNED"] != null && json["POASIGNED"] == "Y"
            ? true
            : false,
        minimumordervalue: json["MINIMUMORDERVALUE"] ?? "",
        brdistrict: json["BRDISTRICT"] ?? "-",
        brmgrname: json["BRMGRNAME"] ?? "-",
        bremailid: json["BREMAILID"] ?? "-",
        vantagetrade: json["VANTAGETRADE"] ?? "-",
        activesegments:
            json["ACTIVESEGMENTS"] == null || json["ACTIVESEGMENTS"] == ""
                ? []
                : stringSeparationToList(
                    inputString: json["ACTIVESEGMENTS"], separatoinValue: ","),
        inactivesegments:
            json["INACTIVESEGMENTS"] == null || json["INACTIVESEGMENTS"] == ""
                ? []
                : stringSeparationToList(
                    inputString: json["INACTIVESEGMENTS"],
                    separatoinValue: ","),
        activeProducts:
            json["ACTIVEPRODUCTS"] == null || json["ACTIVEPRODUCTS"] == ""
                ? []
                : stringSeparationToList(
                    inputString: json["ACTIVEPRODUCTS"], separatoinValue: ","),
        inactiveProducts:
            json["INACTIVEPRODUCTS"] == null || json["INACTIVEPRODUCTS"] == ""
                ? []
                : stringSeparationToList(
                    inputString: json["INACTIVEPRODUCTS"],
                    separatoinValue: ","),
        clienttype: json["CLIENTTYPE"] ?? "-",
        braddress4: json["BRADDRESS4"] ?? "-",
        braddress1: json["BRADDRESS1"] ?? "-",
        usercode: json["USERCODE"] ?? "-",
        braddress2: json["BRADDRESS2"] ?? "-",
        braddress3: json["BRADDRESS3"] ?? "-",
        city: json["CITY"] ?? "-",
        b2Bpartner: json["B2BPARTNER"] ?? "-",
        tradingallowed: json["TRADINGALLOWED"] ?? "-",
        margintradeallowed: json["MARGINTRADEALLOWED"] ?? "-",
        orderallowed: json["ORDERALLOWED"] ?? "-",
        emailid: json["EMAILID"] ?? "-",
        dpid: json["DPID"] == null
            ? []
            : stringSeparationToList(
                inputString: json["DPID"], separatoinValue: ","),
        dpClientid: json["DPCLIENTID"] ?? "-",
        bankAccountNumber: json["BANKACNO"] == null
            ? []
            : stringSeparationToList(
                inputString: json["BANKACNO"], separatoinValue: ","),
        bankName: json["BANKNAME"] == null
            ? []
            : stringSeparationToList(
                inputString: json["BANKNAME"], separatoinValue: ","),
      );

  Map<String, dynamic> toJson() => {
        "LOCATION": location ?? "",
        "MARGINFUNDINGALLOWED": marginfundingallowed ?? "",
        "PHONENO": phoneno ?? "",
        "STATE": state ?? "",
        "LIMIT": limit ?? "",
        "PINCODE": pincode ?? "",
        "ITCLIENT": itclient ?? "",
        "COUNTRY": country ?? "",
        "BRCONTACTPERSON": brcontactperson ?? "",
        "DOB": dob == null ? null : dob!.toIso8601String(),
        "BRPHONE1": brphone1 ?? "",
        "USERNAME": username ?? "",
        "ADDRESS1": address1 ?? "",
        "PARENTUSERCODE": parentusercode ?? "",
        "ADDRESS2": address2 ?? "",
        "BRPHONE2": brphone2 ?? "",
        "BRSTATE": brstate ?? "",
        "POASIGNED": poasigned ?? false,
        "MINIMUMORDERVALUE": minimumordervalue ?? "",
        "BRDISTRICT": brdistrict ?? "",
        "BRMGRNAME": brmgrname ?? "",
        "BREMAILID": bremailid ?? "",
        "VANTAGETRADE": vantagetrade ?? "",
        "ACTIVESEGMENTS": activesegments ?? "",
        "INACTIVESEGMENTS": inactivesegments ?? "",
        "ACTIVEPRODUCTS": activeProducts ?? "",
        "INACTIVEPRODUCTS": inactiveProducts ?? "",
        "CLIENTTYPE": clienttype ?? "",
        "BRADDRESS4": braddress4 ?? "",
        "BRADDRESS1": braddress1 ?? "",
        "USERCODE": usercode ?? "",
        "BRADDRESS2": braddress2 ?? "",
        "BRADDRESS3": braddress3 ?? "",
        "CITY": city ?? "",
        "B2BPARTNER": b2Bpartner ?? "",
        "TRADINGALLOWED": tradingallowed ?? "",
        "MARGINTRADEALLOWED": margintradeallowed ?? "",
        "ORDERALLOWED": orderallowed ?? "",
        "EMAILID": emailid ?? "",
        "DPID": dpid == null ? [] : listAfterRemove(datalist: dpid),
        "DPCLIENTID": dpClientid ?? "",
        "BANKACNO": dpClientid == null
            ? []
            : listAfterRemove(datalist: bankAccountNumber),
        "BANKNAME": bankName == null ? [] : listAfterRemove(datalist: bankName)
      };
}

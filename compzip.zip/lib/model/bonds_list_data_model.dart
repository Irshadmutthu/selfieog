class BondsListData {
  BondsListData({
    this.yield,
    this.issuedate,
    this.mininvestment,
    this.maturitydate,
    this.name,
    this.interest,
    this.selected,
    this.coupon,
    this.interestpayment,
    this.nextpayment,
    this.misc1,
    this.id,
    this.imageurl,
    this.type,
  });

  String? yield;
  String? issuedate;
  String? mininvestment;
  String? maturitydate;
  String? name;
  String? interest;
  String? selected;
  String? coupon;
  String? interestpayment;
  String? nextpayment;
  String? misc1;
  String? id;
  String? imageurl;
  String? type;

  BondsListData copyWith({
    String? yield,
    String? issuedate,
    String? mininvestment,
    String? maturitydate,
    String? name,
    String? interest,
    String? selected,
    String? coupon,
    String? interestpayment,
    String? nextpayment,
    String? misc1,
    String? id,
    String? imageurl,
    String? type,
  }) =>
      BondsListData(
        yield: yield ?? this.yield,
        issuedate: issuedate ?? this.issuedate,
        mininvestment: mininvestment ?? this.mininvestment,
        maturitydate: maturitydate ?? this.maturitydate,
        name: name ?? this.name,
        interest: interest ?? this.interest,
        selected: selected ?? this.selected,
        coupon: coupon ?? this.coupon,
        interestpayment: interestpayment ?? this.interestpayment,
        nextpayment: nextpayment ?? this.nextpayment,
        misc1: misc1 ?? this.misc1,
        id: id ?? this.id,
        imageurl: imageurl ?? this.imageurl,
        type: type ?? this.type,
      );

  factory BondsListData.fromJson(Map<String, dynamic> json) => BondsListData(
        yield: json["YIELD"] ?? "-",
        issuedate: json["ISSUEDATE"] ?? "-",
        mininvestment: json["MININVESTMENT"] ?? "-",
        maturitydate: json["MATURITYDATE"] ?? "-",
        name: json["NAME"] ?? "-",
        interest: json["INTEREST"] ?? "-",
        selected: json["SELECTED"] ?? "-",
        coupon: json["COUPON"] ?? "-",
        interestpayment: json["INTERESTPAYMENT"] ?? "-",
        nextpayment: json["NEXTPAYMENT"] ?? "-",
        misc1: json["MISC1"] ?? "-",
        id: json["ID"] ?? "-",
        imageurl: json["IMAGEURL"] ?? "-",
        type: json["TYPE"] ?? "-",
      );

  Map<String, dynamic> toJson() => {
        "YIELD": yield ?? "",
        "ISSUEDATE": issuedate ?? "",
        "MININVESTMENT": mininvestment ?? "",
        "MATURITYDATE": maturitydate ?? "",
        "NAME": name ?? "",
        "INTEREST": interest ?? "",
        "SELECTED": selected ?? "",
        "COUPON": coupon ?? "",
        "INTERESTPAYMENT": interestpayment ?? "",
        "NEXTPAYMENT": nextpayment ?? "",
        "MISC1": misc1 ?? "",
        "ID": id ?? "",
        "IMAGEURL": imageurl ?? "",
        "TYPE": type ?? "",
      };
}

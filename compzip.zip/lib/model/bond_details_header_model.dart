// To parse this JSON data, do
//
//     final bondDetailsHeaderModel = bondDetailsHeaderModelFromJson(jsonString);

import 'dart:convert';

BondDetailsHeaderModel bondDetailsHeaderModelFromJson(String str) =>
    BondDetailsHeaderModel.fromJson(json.decode(str));

String bondDetailsHeaderModelToJson(BondDetailsHeaderModel data) =>
    json.encode(data.toJson());

class BondDetailsHeaderModel {
  BondDetailsHeaderModel({
    this.bondDetailsHeaderData,
  });

  List<BondDetailsHeaderData>? bondDetailsHeaderData;

  BondDetailsHeaderModel copyWith({
    List<BondDetailsHeaderData>? bondDetailsHeaderData,
  }) =>
      BondDetailsHeaderModel(
        bondDetailsHeaderData:
            bondDetailsHeaderData ?? this.bondDetailsHeaderData,
      );

  factory BondDetailsHeaderModel.fromJson(Map<String, dynamic> json) =>
      BondDetailsHeaderModel(
        bondDetailsHeaderData: json["Result3"] == null
            ? [BondDetailsHeaderData.fromJson({})]
            : List<BondDetailsHeaderData>.from(
                json["Result3"].map((x) => BondDetailsHeaderData.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Result3": bondDetailsHeaderData == null
            ? []
            : List<dynamic>.from(bondDetailsHeaderData!.map((x) => x.toJson())),
      };
}

class BondDetailsHeaderData {
  BondDetailsHeaderData(
      {this.selected,
      this.bondtype,
      this.isin,
      this.type,
      this.name,
      this.interest,
      this.nextPayment,
      this.misc1});

  String? selected;
  String? bondtype;
  String? isin;
  String? type;
  String? name;
  String? interest;
  // double? interest;
  String? nextPayment;
  String? misc1;

  BondDetailsHeaderData copyWith({
    String? selected,
    String? bondtype,
    String? isin,
    String? type,
    String? name,
    String? interest,

    // double? interest,
    String? nextPayment,
    String? misc1,
  }) =>
      BondDetailsHeaderData(
        selected: selected ?? this.selected,
        bondtype: bondtype ?? this.bondtype,
        isin: isin ?? this.isin,
        type: type ?? this.type,
        name: name ?? this.name,
        interest: interest ?? this.interest,
        nextPayment: nextPayment ?? this.nextPayment,
        misc1: misc1 ?? this.misc1,
      );

  factory BondDetailsHeaderData.fromJson(Map<String, dynamic> json) =>
      BondDetailsHeaderData(
        selected: json["SELECTED"] ?? "-",
        bondtype: json["BONDTYPE"] ?? "-",
        isin: json["ISIN"] ?? "-",
        type: json["TYPE"] ?? "-",
        name: json["NAME"] ?? "-",
        interest: json["INTEREST"] ?? "-",
        // interest: json["INTEREST"] != null
        //     ? double.tryParse(json["INTEREST"]) ?? 0.0
        //     : 0.0,
        nextPayment: json["NEXTPAYMENT"] ?? "-",
        misc1: json["MISC1"] ?? "-",
      );

  Map<String, dynamic> toJson() => {
        "SELECTED": selected ?? "",
        "BONDTYPE": bondtype ?? "",
        "ISIN": isin ?? "",
        "TYPE": type ?? "",
        "NAME": name ?? "",
        "INTEREST": interest ?? 0,
        "NEXTPAYMENT": nextPayment ?? "",
        "MISC1": misc1 ?? "",
      };
}

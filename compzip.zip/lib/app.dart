import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';
import 'package:selfie_mobile_flutter/constants/prefefence_utils.dart';
import 'package:selfie_mobile_flutter/navigation/navigation.dart';
import 'package:selfie_mobile_flutter/selfie/presentation_layer/bloc_navigation/navigation_cubit.dart';
import 'package:selfie_mobile_flutter/services/service_locator.dart';
import 'package:selfie_mobile_flutter/theme/custom_theme.dart';
import 'package:selfie_mobile_flutter/user_controller/user_controller.dart';
import 'package:selfie_mobile_flutter/utils/user_settings.dart';
import 'app_routes_factory.dart';
import 'app_theme.dart';
import 'app_page_injectable.dart';

class TradingApp extends StatefulWidget {
  final String initialRoute;
  final ServiceLocator serviceLocator;

  const TradingApp(
      {Key? key, required this.initialRoute, required this.serviceLocator})
      : super(key: key);

  @override
  _TradingAppState createState() => _TradingAppState();
}

class _TradingAppState extends State<TradingApp> {
  final GlobalKey<NavigatorState> _navigatorKey = GlobalKey();
  late StreamSubscription<void> heartbeatSubscription;
  late StreamSubscription<void> logoutSubscription;
  late StreamSubscription<dynamic> streamingSubscription;
  CustomMode themeMode = CustomMode.Light;

  @override
  void initState() {
    SystemChrome.setSystemUIOverlayStyle(lightTheme);
    getUserCredentials();
    getTheme();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  getTheme() async {
    bool? storedThemeStatus = await PreferenceUtils.preferenceHasKey("theme");

    if (storedThemeStatus == false) {
      await PreferenceUtils.storeDataToShared(
          "theme", getThemeModeString(CustomMode.Light).toString());
      ;
    } else {
      String? storedTheme = await PreferenceUtils.getDataFromShared("theme");
      if (storedTheme == "") {
        await PreferenceUtils.storeDataToShared(
            "theme", getThemeModeString(CustomMode.Light).toString());
      }
    }
    String? storedTheme = await PreferenceUtils.getDataFromShared("theme");
    themeMode = getThemeMode(storedTheme!);
    switch (themeMode) {
      case CustomMode.Light:
        {
          SystemChrome.setSystemUIOverlayStyle(lightTheme);
          break;
        }
      case CustomMode.Mid:
        {
          SystemChrome.setSystemUIOverlayStyle(midTheme);
          break;
        }
      case CustomMode.Dark:
        {
          SystemChrome.setSystemUIOverlayStyle(darkTheme);
          break;
        }
    }
    await Provider.of<CustomTheme>(context, listen: false)
        .toggleTheme(themeMode);
  }

  getUserCredentials() async {
    String? userCode = await PreferenceUtils.getDataFromShared("userCode");
    if (userCode != null && userCode != "") {
      String? userData = await PreferenceUtils.getDataFromShared(userCode);
      UserSettings.userSettings.fromJsonString(userData!);
      UserController().userName = UserSettings().userPersonalSettings.username;
      UserController.userController.userId = userCode;
    }
  }

  @override
  Widget build(BuildContext context) {
    return MultiRepositoryProvider(
      providers: [
        RepositoryProvider.value(value: widget.serviceLocator),
      ],
      child: AppTheme(
        child: BlocProvider(
          create: (context) => NavigationCubit(),
          child: MaterialApp(
            navigatorKey: _navigatorKey,
            initialRoute: widget.initialRoute,
            onGenerateRoute: onGenerateAppRoute(
              AppRoutesFactory(widget.serviceLocator),
            ),
            localizationsDelegates: const [
              // GlobalMaterialLocalizations.delegate,
              // GlobalWidgetsLocalizations.delegate,
              // GlobalCupertinoLocalizations.delegate,
            ],
            debugShowCheckedModeBanner: false,
            supportedLocales: const [Locale('en', 'US'), Locale('ar', 'AE')],
            //locale: const Locale('ar', 'AE'),
            themeMode: CustomTheme.modelTheme == CustomMode.Light
                ? ThemeMode.light
                : ThemeMode.dark,
            theme: Provider.of<CustomTheme>(context).currentTheme,
          ),
        ),
      ),
    );
  }
}
